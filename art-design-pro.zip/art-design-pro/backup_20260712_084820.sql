/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.18-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: 127.0.0.1    Database: art_design_pro
-- ------------------------------------------------------
-- Server version	10.11.18-MariaDB-0+deb12u1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `app_categories`
--

DROP TABLE IF EXISTS `app_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `icon` varchar(255) DEFAULT '',
  `sort_order` int(11) DEFAULT 0,
  `status` char(1) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_categories`
--

LOCK TABLES `app_categories` WRITE;
/*!40000 ALTER TABLE `app_categories` DISABLE KEYS */;
INSERT INTO `app_categories` VALUES
(1,'工具','',1,'1','2026-07-10 22:39:49'),
(2,'创作','',2,'1','2026-07-10 22:39:49'),
(3,'效率','',3,'1','2026-07-10 22:39:49'),
(4,'生活','',4,'1','2026-07-10 22:39:49'),
(5,'游戏','',5,'1','2026-07-10 22:39:49'),
(6,'教育','',6,'1','2026-07-10 22:39:49'),
(7,'社交','',7,'1','2026-07-10 22:39:49');
/*!40000 ALTER TABLE `app_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_clicks`
--

DROP TABLE IF EXISTS `app_clicks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_clicks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_app_time` (`app_id`,`create_time`),
  KEY `idx_time` (`create_time`)
) ENGINE=InnoDB AUTO_INCREMENT=269 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_clicks`
--

LOCK TABLES `app_clicks` WRITE;
/*!40000 ALTER TABLE `app_clicks` DISABLE KEYS */;
INSERT INTO `app_clicks` VALUES
(1,1,0,'2026-07-10 22:49:26'),
(2,1,0,'2026-07-10 22:49:26'),
(3,1,0,'2026-07-10 22:49:26'),
(4,1,0,'2026-07-10 22:49:26'),
(5,1,0,'2026-07-10 22:49:26'),
(6,1,0,'2026-07-10 22:49:26'),
(7,1,0,'2026-07-10 22:49:26'),
(8,1,0,'2026-07-10 22:49:26'),
(9,1,0,'2026-07-10 22:49:26'),
(10,1,0,'2026-07-10 22:49:26'),
(11,1,0,'2026-07-10 22:49:26'),
(12,1,0,'2026-07-10 22:49:26'),
(13,1,0,'2026-07-10 22:49:26'),
(14,1,0,'2026-07-10 22:49:26'),
(15,1,0,'2026-07-10 22:49:26'),
(16,1,0,'2026-07-10 22:49:26'),
(17,1,0,'2026-07-10 22:49:26'),
(18,1,0,'2026-07-10 22:49:26'),
(19,1,0,'2026-07-10 22:49:26'),
(20,1,0,'2026-07-10 22:49:26'),
(21,3,0,'2026-07-10 22:49:26'),
(22,3,0,'2026-07-10 22:49:26'),
(23,3,0,'2026-07-10 22:49:26'),
(24,3,0,'2026-07-10 22:49:26'),
(25,3,0,'2026-07-10 22:49:26'),
(26,3,0,'2026-07-10 22:49:26'),
(27,3,0,'2026-07-10 22:49:26'),
(28,3,0,'2026-07-10 22:49:26'),
(29,3,0,'2026-07-10 22:49:26'),
(30,3,0,'2026-07-10 22:49:26'),
(31,3,0,'2026-07-10 22:49:26'),
(32,3,0,'2026-07-10 22:49:26'),
(33,3,0,'2026-07-10 22:49:26'),
(34,3,0,'2026-07-10 22:49:26'),
(35,3,0,'2026-07-10 22:49:26'),
(36,3,0,'2026-07-10 22:49:26'),
(37,3,0,'2026-07-10 22:49:26'),
(38,3,0,'2026-07-10 22:49:26'),
(39,6,0,'2026-07-10 22:49:26'),
(40,6,0,'2026-07-10 22:49:26'),
(41,6,0,'2026-07-10 22:49:26'),
(42,6,0,'2026-07-10 22:49:26'),
(43,6,0,'2026-07-10 22:49:26'),
(44,6,0,'2026-07-10 22:49:26'),
(45,6,0,'2026-07-10 22:49:26'),
(46,6,0,'2026-07-10 22:49:26'),
(47,6,0,'2026-07-10 22:49:26'),
(48,6,0,'2026-07-10 22:49:26'),
(49,6,0,'2026-07-10 22:49:26'),
(50,6,0,'2026-07-10 22:49:26'),
(51,6,0,'2026-07-10 22:49:26'),
(52,6,0,'2026-07-10 22:49:26'),
(53,6,0,'2026-07-10 22:49:26'),
(54,4,0,'2026-07-10 22:49:26'),
(55,4,0,'2026-07-10 22:49:26'),
(56,4,0,'2026-07-10 22:49:26'),
(57,4,0,'2026-07-10 22:49:26'),
(58,4,0,'2026-07-10 22:49:26'),
(59,4,0,'2026-07-10 22:49:26'),
(60,4,0,'2026-07-10 22:49:26'),
(61,4,0,'2026-07-10 22:49:26'),
(62,4,0,'2026-07-10 22:49:26'),
(63,4,0,'2026-07-10 22:49:26'),
(64,4,0,'2026-07-10 22:49:26'),
(65,4,0,'2026-07-10 22:49:26'),
(66,2,0,'2026-07-10 22:49:26'),
(67,2,0,'2026-07-10 22:49:26'),
(68,2,0,'2026-07-10 22:49:26'),
(69,2,0,'2026-07-10 22:49:26'),
(70,2,0,'2026-07-10 22:49:26'),
(71,2,0,'2026-07-10 22:49:26'),
(72,2,0,'2026-07-10 22:49:26'),
(73,2,0,'2026-07-10 22:49:26'),
(74,2,0,'2026-07-10 22:49:26'),
(75,2,0,'2026-07-10 22:49:26'),
(76,5,0,'2026-07-10 22:49:26'),
(77,5,0,'2026-07-10 22:49:26'),
(78,5,0,'2026-07-10 22:49:26'),
(79,5,0,'2026-07-10 22:49:26'),
(80,5,0,'2026-07-10 22:49:26'),
(81,5,0,'2026-07-10 22:49:26'),
(82,5,0,'2026-07-10 22:49:26'),
(83,7,0,'2026-07-10 22:49:26'),
(84,7,0,'2026-07-10 22:49:26'),
(85,7,0,'2026-07-10 22:49:26'),
(86,7,0,'2026-07-10 22:49:26'),
(87,7,0,'2026-07-10 22:49:26'),
(88,8,0,'2026-07-10 22:49:26'),
(89,8,0,'2026-07-10 22:49:26'),
(90,8,0,'2026-07-10 22:49:26'),
(91,9,0,'2026-07-10 22:49:26'),
(92,9,0,'2026-07-10 22:49:26'),
(93,9,0,'2026-07-09 22:49:26'),
(94,9,0,'2026-07-09 22:49:26'),
(95,9,0,'2026-07-09 22:49:26'),
(96,9,0,'2026-07-09 22:49:26'),
(97,9,0,'2026-07-09 22:49:26'),
(98,9,0,'2026-07-09 22:49:26'),
(99,9,0,'2026-07-09 22:49:26'),
(100,9,0,'2026-07-09 22:49:26'),
(101,9,0,'2026-07-09 22:49:26'),
(102,9,0,'2026-07-09 22:49:26'),
(103,9,0,'2026-07-09 22:49:26'),
(104,9,0,'2026-07-09 22:49:26'),
(105,9,0,'2026-07-09 22:49:26'),
(106,9,0,'2026-07-09 22:49:26'),
(107,9,0,'2026-07-09 22:49:26'),
(108,9,0,'2026-07-09 22:49:26'),
(109,9,0,'2026-07-09 22:49:26'),
(110,9,0,'2026-07-09 22:49:26'),
(111,9,0,'2026-07-09 22:49:26'),
(112,9,0,'2026-07-09 22:49:26'),
(113,9,0,'2026-07-09 22:49:26'),
(114,9,0,'2026-07-09 22:49:26'),
(115,9,0,'2026-07-09 22:49:26'),
(116,9,0,'2026-07-08 22:49:26'),
(117,9,0,'2026-07-08 22:49:26'),
(118,9,0,'2026-07-08 22:49:26'),
(119,9,0,'2026-07-08 22:49:26'),
(120,9,0,'2026-07-08 22:49:26'),
(121,9,0,'2026-07-08 22:49:26'),
(122,9,0,'2026-07-08 22:49:26'),
(123,9,0,'2026-07-08 22:49:26'),
(124,9,0,'2026-07-08 22:49:26'),
(125,9,0,'2026-07-08 22:49:26'),
(126,9,0,'2026-07-08 22:49:26'),
(127,9,0,'2026-07-08 22:49:26'),
(128,9,0,'2026-07-08 22:49:26'),
(129,9,0,'2026-07-08 22:49:26'),
(130,9,0,'2026-07-08 22:49:26'),
(131,9,0,'2026-07-08 22:49:26'),
(132,9,0,'2026-07-07 22:49:26'),
(133,9,0,'2026-07-07 22:49:26'),
(134,9,0,'2026-07-07 22:49:26'),
(135,9,0,'2026-07-07 22:49:26'),
(136,9,0,'2026-07-07 22:49:26'),
(137,9,0,'2026-07-07 22:49:26'),
(138,9,0,'2026-07-06 22:49:26'),
(139,9,0,'2026-07-06 22:49:26'),
(140,9,0,'2026-07-06 22:49:26'),
(141,9,0,'2026-07-06 22:49:26'),
(142,9,0,'2026-07-05 22:49:26'),
(143,9,0,'2026-07-05 22:49:26'),
(144,9,0,'2026-07-05 22:49:26'),
(145,9,0,'2026-07-04 22:49:26'),
(146,9,0,'2026-07-04 22:49:26'),
(147,8,0,'2026-07-09 22:49:26'),
(148,8,0,'2026-07-09 22:49:26'),
(149,8,0,'2026-07-09 22:49:26'),
(150,8,0,'2026-07-09 22:49:26'),
(151,8,0,'2026-07-09 22:49:26'),
(152,8,0,'2026-07-09 22:49:26'),
(153,8,0,'2026-07-09 22:49:26'),
(154,8,0,'2026-07-09 22:49:26'),
(155,8,0,'2026-07-09 22:49:26'),
(156,8,0,'2026-07-09 22:49:26'),
(157,8,0,'2026-07-09 22:49:26'),
(158,8,0,'2026-07-09 22:49:26'),
(159,8,0,'2026-07-09 22:49:26'),
(160,8,0,'2026-07-09 22:49:26'),
(161,8,0,'2026-07-08 22:49:26'),
(162,8,0,'2026-07-08 22:49:26'),
(163,8,0,'2026-07-08 22:49:26'),
(164,8,0,'2026-07-08 22:49:26'),
(165,8,0,'2026-07-08 22:49:26'),
(166,8,0,'2026-07-08 22:49:26'),
(167,8,0,'2026-07-08 22:49:26'),
(168,8,0,'2026-07-08 22:49:26'),
(169,8,0,'2026-07-08 22:49:26'),
(170,8,0,'2026-07-07 22:49:26'),
(171,8,0,'2026-07-07 22:49:26'),
(172,8,0,'2026-07-07 22:49:26'),
(173,8,0,'2026-07-07 22:49:26'),
(174,8,0,'2026-07-07 22:49:26'),
(175,8,0,'2026-07-07 22:49:26'),
(176,8,0,'2026-07-06 22:49:26'),
(177,8,0,'2026-07-06 22:49:26'),
(178,8,0,'2026-07-06 22:49:26'),
(179,8,0,'2026-07-06 22:49:26'),
(180,8,0,'2026-07-05 22:49:26'),
(181,8,0,'2026-07-05 22:49:26'),
(182,8,0,'2026-07-05 22:49:26'),
(183,8,0,'2026-07-04 22:49:26'),
(184,8,0,'2026-07-04 22:49:26'),
(185,7,0,'2026-07-09 22:49:26'),
(186,7,0,'2026-07-09 22:49:26'),
(187,7,0,'2026-07-09 22:49:26'),
(188,7,0,'2026-07-09 22:49:26'),
(189,7,0,'2026-07-09 22:49:26'),
(190,7,0,'2026-07-09 22:49:26'),
(191,7,0,'2026-07-09 22:49:26'),
(192,7,0,'2026-07-09 22:49:26'),
(193,7,0,'2026-07-09 22:49:26'),
(194,7,0,'2026-07-09 22:49:26'),
(195,7,0,'2026-07-08 22:49:26'),
(196,7,0,'2026-07-08 22:49:26'),
(197,7,0,'2026-07-08 22:49:26'),
(198,7,0,'2026-07-08 22:49:26'),
(199,7,0,'2026-07-08 22:49:26'),
(200,7,0,'2026-07-08 22:49:26'),
(201,7,0,'2026-07-08 22:49:26'),
(202,7,0,'2026-07-08 22:49:26'),
(203,7,0,'2026-07-08 22:49:26'),
(204,7,0,'2026-07-07 22:49:26'),
(205,7,0,'2026-07-07 22:49:26'),
(206,7,0,'2026-07-07 22:49:26'),
(207,7,0,'2026-07-07 22:49:26'),
(208,7,0,'2026-07-07 22:49:26'),
(209,7,0,'2026-07-06 22:49:26'),
(210,7,0,'2026-07-06 22:49:26'),
(211,7,0,'2026-07-06 22:49:26'),
(212,7,0,'2026-07-06 22:49:26'),
(213,7,0,'2026-07-05 22:49:26'),
(214,7,0,'2026-07-05 22:49:26'),
(215,7,0,'2026-07-05 22:49:26'),
(216,7,0,'2026-07-04 22:49:26'),
(217,5,0,'2026-07-09 22:49:26'),
(218,5,0,'2026-07-09 22:49:26'),
(219,5,0,'2026-07-09 22:49:26'),
(220,5,0,'2026-07-09 22:49:26'),
(221,5,0,'2026-07-09 22:49:26'),
(222,5,0,'2026-07-09 22:49:26'),
(223,5,0,'2026-07-09 22:49:26'),
(224,5,0,'2026-07-09 22:49:26'),
(225,5,0,'2026-07-09 22:49:26'),
(226,5,0,'2026-07-09 22:49:26'),
(227,5,0,'2026-07-08 22:49:26'),
(228,5,0,'2026-07-08 22:49:26'),
(229,5,0,'2026-07-08 22:49:26'),
(230,5,0,'2026-07-08 22:49:26'),
(231,5,0,'2026-07-08 22:49:26'),
(232,5,0,'2026-07-08 22:49:26'),
(233,5,0,'2026-07-08 22:49:26'),
(234,5,0,'2026-07-07 22:49:26'),
(235,5,0,'2026-07-07 22:49:26'),
(236,5,0,'2026-07-07 22:49:26'),
(237,5,0,'2026-07-07 22:49:26'),
(238,5,0,'2026-07-06 22:49:26'),
(239,5,0,'2026-07-06 22:49:26'),
(240,5,0,'2026-07-05 22:49:26'),
(241,5,0,'2026-07-05 22:49:26'),
(242,5,0,'2026-07-05 22:49:26'),
(243,5,0,'2026-07-04 22:49:26'),
(244,1,0,'2026-07-09 22:49:26'),
(245,1,0,'2026-07-09 22:49:26'),
(246,1,0,'2026-07-09 22:49:26'),
(247,1,0,'2026-07-09 22:49:26'),
(248,1,0,'2026-07-09 22:49:26'),
(249,1,0,'2026-07-09 22:49:26'),
(250,1,0,'2026-07-09 22:49:26'),
(251,1,0,'2026-07-09 22:49:26'),
(252,1,0,'2026-07-09 22:49:26'),
(253,1,0,'2026-07-09 22:49:26'),
(254,1,0,'2026-07-08 22:49:26'),
(255,1,0,'2026-07-08 22:49:26'),
(256,1,0,'2026-07-08 22:49:26'),
(257,1,0,'2026-07-08 22:49:26'),
(258,1,0,'2026-07-08 22:49:26'),
(259,1,0,'2026-07-08 22:49:26'),
(260,1,0,'2026-07-07 22:49:26'),
(261,1,0,'2026-07-07 22:49:26'),
(262,1,0,'2026-07-07 22:49:26'),
(263,1,0,'2026-07-06 22:49:26'),
(264,1,0,'2026-07-06 22:49:26'),
(265,1,0,'2026-07-06 22:49:26'),
(266,1,0,'2026-07-05 22:49:26'),
(267,1,0,'2026-07-05 22:49:26'),
(268,1,0,'2026-07-04 22:49:26');
/*!40000 ALTER TABLE `app_clicks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_comments`
--

DROP TABLE IF EXISTS `app_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_id` int(11) NOT NULL,
  `parent_id` int(11) DEFAULT 0,
  `user_id` int(11) DEFAULT 0,
  `user_name` varchar(100) DEFAULT '',
  `user_avatar` varchar(20) DEFAULT '#FF5777',
  `device` varchar(200) DEFAULT '',
  `version` varchar(50) DEFAULT '',
  `content` text DEFAULT NULL,
  `likes` int(11) DEFAULT 0,
  `replies` int(11) DEFAULT 0,
  `reported` int(11) DEFAULT 0,
  `is_pinned` tinyint(1) DEFAULT 0,
  `rating` decimal(2,1) DEFAULT 0.0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_app_comments_app_id` (`app_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_comments`
--

LOCK TABLES `app_comments` WRITE;
/*!40000 ALTER TABLE `app_comments` DISABLE KEYS */;
INSERT INTO `app_comments` VALUES
(1,5,0,13,'','#FF5777','','','很好用',0,0,0,0,5.0,'2026-05-13 22:39:54'),
(2,1,0,5,'','#FF5777','','','推荐！',0,0,0,0,5.0,'2026-05-29 22:39:54'),
(4,3,0,10,'','#FF5777','','','还可以',0,0,0,0,5.0,'2026-05-12 22:39:54'),
(5,2,0,2,'','#FF5777','','','需要改进',0,0,0,0,5.0,'2026-07-03 22:39:54'),
(6,7,0,7,'','#FF5777','','','很棒的应用',0,0,0,0,5.0,'2026-05-22 22:39:54'),
(8,5,0,6,'','#FF5777','','','推荐！',0,0,0,0,4.0,'2026-07-07 22:39:54'),
(9,4,0,15,'','#FF5777','','','不错',0,0,0,0,4.0,'2026-06-25 22:39:54'),
(10,4,0,7,'','#FF5777','','','还可以',0,0,0,0,5.0,'2026-06-05 22:39:54');
/*!40000 ALTER TABLE `app_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_favorites`
--

DROP TABLE IF EXISTS `app_favorites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_favorites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `app_id` int(11) NOT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`app_id`),
  KEY `idx_app_favorites_user` (`user_id`),
  KEY `idx_app_favorites_app` (`app_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_favorites`
--

LOCK TABLES `app_favorites` WRITE;
/*!40000 ALTER TABLE `app_favorites` DISABLE KEYS */;
INSERT INTO `app_favorites` VALUES
(1,9,1,'2026-06-05 22:39:54'),
(2,10,5,'2026-06-18 22:39:54'),
(3,2,8,'2026-07-09 22:39:54'),
(4,4,2,'2026-05-12 22:39:54'),
(5,3,6,'2026-05-12 22:39:54'),
(6,11,1,'2026-05-13 22:39:54'),
(7,6,4,'2026-06-29 22:39:54'),
(8,11,6,'2026-06-15 22:39:54'),
(9,9,6,'2026-06-19 22:39:54'),
(10,6,6,'2026-06-12 22:39:54'),
(12,15,4,'2026-07-07 22:39:54'),
(13,7,9,'2026-07-07 22:39:54'),
(14,7,2,'2026-05-25 22:39:54'),
(15,5,3,'2026-05-14 22:39:54');
/*!40000 ALTER TABLE `app_favorites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_official_tags`
--

DROP TABLE IF EXISTS `app_official_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_official_tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `color` varchar(20) DEFAULT '#2563eb',
  `bg_color` varchar(20) DEFAULT '#dbeafe',
  `sort_order` int(11) DEFAULT 0,
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_official_tags`
--

LOCK TABLES `app_official_tags` WRITE;
/*!40000 ALTER TABLE `app_official_tags` DISABLE KEYS */;
INSERT INTO `app_official_tags` VALUES
(1,'热门','#2563eb','#dbeafe',1,'1','2026-07-10 22:39:49'),
(2,'推荐','#2563eb','#dbeafe',2,'1','2026-07-10 22:39:49'),
(3,'新品','#2563eb','#dbeafe',3,'1','2026-07-10 22:39:49'),
(4,'精品','#2563eb','#dbeafe',4,'1','2026-07-10 22:39:49');
/*!40000 ALTER TABLE `app_official_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_purchases`
--

DROP TABLE IF EXISTS `app_purchases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_purchases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `price_type` varchar(20) DEFAULT 'free',
  `original_price` decimal(10,2) DEFAULT 0.00,
  `paid_price` decimal(10,2) DEFAULT 0.00,
  `discount_rate` decimal(3,1) DEFAULT 1.0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_app_purchases_app` (`app_id`),
  KEY `idx_app_purchases_user` (`user_id`),
  KEY `idx_app_purchases_user_app` (`user_id`,`app_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_purchases`
--

LOCK TABLES `app_purchases` WRITE;
/*!40000 ALTER TABLE `app_purchases` DISABLE KEYS */;
INSERT INTO `app_purchases` VALUES
(1,9,6,'','free',0.00,12.79,1.0,'2026-05-12 22:39:54'),
(2,3,6,'','free',0.00,5.03,1.0,'2026-05-21 22:39:54'),
(3,7,8,'','free',0.00,16.36,1.0,'2026-06-22 22:39:54'),
(4,9,7,'','free',0.00,28.55,1.0,'2026-05-15 22:39:54'),
(5,1,8,'','free',0.00,14.38,1.0,'2026-07-08 22:39:54'),
(6,2,15,'','free',0.00,17.64,1.0,'2026-06-15 22:39:54');
/*!40000 ALTER TABLE `app_purchases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_store`
--

DROP TABLE IF EXISTS `app_store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `package_name` varchar(200) DEFAULT '',
  `version` varchar(50) DEFAULT '1.0.0',
  `version_code` varchar(50) DEFAULT '100',
  `icon` varchar(500) DEFAULT '',
  `icon_bg_color` varchar(20) DEFAULT '#00BFA5',
  `size_mb` decimal(10,1) DEFAULT 0.0,
  `downloads` int(11) DEFAULT 0,
  `rating` decimal(2,1) DEFAULT 0.0,
  `description` text DEFAULT NULL,
  `update_content` text DEFAULT NULL,
  `screenshots` text DEFAULT NULL,
  `tags` text DEFAULT NULL,
  `download_url` varchar(500) DEFAULT '',
  `coin_count` int(11) DEFAULT 0,
  `coin_people` int(11) DEFAULT 0,
  `developer` varchar(100) DEFAULT '',
  `category` varchar(100) DEFAULT '工具',
  `categories` text DEFAULT NULL,
  `category_id` int(11) DEFAULT 0,
  `status` varchar(2) DEFAULT '1',
  `is_pinned` tinyint(1) DEFAULT 0,
  `user_id` int(11) DEFAULT 0,
  `official_tags` text DEFAULT NULL,
  `content_permission` varchar(20) DEFAULT 'public',
  `content_price` decimal(10,2) DEFAULT 0.00,
  `content_price_type` varchar(20) DEFAULT 'free',
  `access_password` varchar(100) DEFAULT '',
  `access_password_tips` varchar(500) DEFAULT '',
  `is_featured` tinyint(1) DEFAULT 0,
  `is_official` tinyint(1) DEFAULT 0,
  `has_ads` int(11) DEFAULT 0,
  `requires_network` int(11) DEFAULT 1,
  `has_paid_content` int(11) DEFAULT 0,
  `is_free` int(11) DEFAULT 1,
  `price_type` varchar(20) DEFAULT 'free',
  `price_amount` decimal(10,2) DEFAULT 0.00,
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_app_store_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_store`
--

LOCK TABLES `app_store` WRITE;
/*!40000 ALTER TABLE `app_store` DISABLE KEYS */;
INSERT INTO `app_store` VALUES
(1,'Pro Photo Editor','AIGram.pro.editor','1.2.3','120','','camera',0.0,3865,3.7,'专业级照片编辑工具，AI智能修图',NULL,NULL,'[\"photo\",\"editor\",\"AI\"]','',0,0,'bobwang','工具',NULL,0,'1',0,14,NULL,'public',0.00,'free','','',0,0,0,1,0,1,'free',0.00,'2026-05-12 22:39:49','2026-07-10 22:39:49'),
(2,'Pixel Draw','Pixel.Draw.app','2.0.1','101','','brush',0.0,791,4.0,'像素风绘画应用，支持图层和动画',NULL,NULL,'[\"draw\",\"pixel\",\"art\"]','',0,0,'pixel_art','工具',NULL,0,'1',0,1,NULL,'public',0.00,'free','','',0,0,0,1,0,1,'free',0.00,'2026-06-08 22:39:49','2026-07-10 22:39:49'),
(3,'Code Helper','Code.Helper.pro','3.5.0','200','','code',0.0,4675,2.9,'智能代码助手，支持多种编程语言',NULL,NULL,'[\"code\",\"dev\",\"tool\"]','',0,0,'code_ninja','工具',NULL,0,'1',0,2,NULL,'public',0.00,'free','','',0,0,0,1,0,1,'free',0.00,'2026-06-22 22:39:49','2026-07-10 22:39:49'),
(4,'Music Maker','Music.Maker.studio','1.0.0','80','','music',0.0,4272,4.1,'AI驱动的音乐创作工作室',NULL,NULL,'[\"music\",\"create\",\"AI\"]','',0,0,'tech_guru','创作',NULL,0,'1',0,7,NULL,'public',0.00,'free','','',0,0,0,1,0,1,'free',0.00,'2026-07-04 22:39:49','2026-07-10 22:39:49'),
(5,'Video Snap','Video.Snap.lite','4.2.1','95','','video',0.0,2168,4.0,'短视频快速剪辑和滤镜工具',NULL,NULL,'[\"video\",\"edit\",\"social\"]','',0,0,'frontend_dev','创作',NULL,0,'1',0,5,NULL,'public',0.00,'free','','',0,0,0,1,0,1,'free',0.00,'2026-04-23 22:39:49','2026-07-10 22:39:49'),
(7,'Mind Map Pro','Mind.Map.visual','1.5.2','75','','mindmap',0.0,2839,3.4,'思维导图可视化工具',NULL,NULL,'[\"mindmap\",\"study\",\"visual\"]','',0,0,'design_master','效率',NULL,0,'1',0,11,NULL,'public',0.00,'free','','',0,0,0,1,0,1,'free',0.00,'2026-04-24 22:39:49','2026-07-10 22:39:49'),
(10,'待审核应用','com.demo.pending','0.1.0','30','','default',0.0,1265,3.1,'这是一个待审核的应用',NULL,NULL,'[\"test\"]','',0,0,'mobile_dev','工具',NULL,0,'0',0,4,NULL,'public',0.00,'free','','',0,0,0,1,0,1,'free',0.00,'2026-04-24 22:39:49','2026-07-10 22:39:49'),
(11,'已拒绝应用','com.demo.rejected','0.1.0','20','','default',0.0,648,4.2,'这是一个被拒绝的应用',NULL,NULL,'[\"test\"]','',0,0,'game_dev','工具',NULL,0,'2',0,11,NULL,'public',0.00,'free','','',0,0,0,1,0,1,'free',0.00,'2026-06-03 22:39:49','2026-07-10 22:39:49'),
(12,'百变引擎','百变引擎_13.7.07','13.7.07','100','','#00BFA5',19.5,0,5.0,'66',NULL,'[\"/uploads/1783770613292-211438868.jpg\"]','[\"官方版\"]','6666',0,0,'alexmorgan','工具',NULL,0,'1',0,19,'[]','public',0.00,'free','','',0,0,1,1,0,1,'free',0.00,'2026-07-11 11:50:41','2026-07-11 11:50:41');
/*!40000 ALTER TABLE `app_store` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_tips`
--

DROP TABLE IF EXISTS `app_tips`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_tips` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(64) DEFAULT '',
  `amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `tip_type` varchar(20) DEFAULT 'balance',
  `message` varchar(255) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_app_tips_app` (`app_id`),
  KEY `idx_app_tips_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_tips`
--

LOCK TABLES `app_tips` WRITE;
/*!40000 ALTER TABLE `app_tips` DISABLE KEYS */;
/*!40000 ALTER TABLE `app_tips` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_uploads`
--

DROP TABLE IF EXISTS `app_uploads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_uploads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_id` int(11) DEFAULT 0,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `name` varchar(200) NOT NULL,
  `package_name` varchar(200) DEFAULT '',
  `category` varchar(100) DEFAULT '工具',
  `description` text DEFAULT NULL,
  `icon` varchar(500) DEFAULT '',
  `icon_bg_color` varchar(20) DEFAULT '#00BFA5',
  `version` varchar(50) DEFAULT '1.0.0',
  `version_code` varchar(50) DEFAULT '100',
  `size_mb` decimal(10,1) DEFAULT 0.0,
  `download_url` varchar(500) DEFAULT '',
  `screenshots` text DEFAULT NULL,
  `tags` text DEFAULT NULL,
  `version_type` varchar(20) DEFAULT '',
  `has_ads` int(11) DEFAULT 0,
  `requires_network` int(11) DEFAULT 1,
  `has_paid_content` int(11) DEFAULT 0,
  `is_free` int(11) DEFAULT 1,
  `downloads` int(11) DEFAULT 0,
  `rating` decimal(2,1) DEFAULT 0.0,
  `coin_count` int(11) DEFAULT 0,
  `coin_people` int(11) DEFAULT 0,
  `review_count` int(11) DEFAULT 0,
  `five_star_count` int(11) DEFAULT 0,
  `status` varchar(2) DEFAULT '0',
  `submission_status` varchar(20) DEFAULT 'draft',
  `review_comment` text DEFAULT NULL,
  `review_by` varchar(100) DEFAULT '',
  `review_time` datetime DEFAULT NULL,
  `price_type` varchar(20) DEFAULT 'free',
  `price_amount` decimal(10,2) DEFAULT 0.00,
  `official_tags` text DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_app_uploads_user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_uploads`
--

LOCK TABLES `app_uploads` WRITE;
/*!40000 ALTER TABLE `app_uploads` DISABLE KEYS */;
INSERT INTO `app_uploads` VALUES
(1,0,0,'','E2E App','com.e2e.test','工具','Test app','','#00BFA5','1.0.0','100',0.0,'',NULL,NULL,'',0,1,0,1,0,0.0,0,0,0,0,'0','draft',NULL,'',NULL,'free',0.00,NULL,'2026-07-10 19:34:30','2026-07-10 19:34:30'),
(2,3,0,'','E2E Test App','com.e2e.app','工具','Real E2E test application','','#00BFA5','1.0.0','100',0.0,'',NULL,NULL,'',0,1,0,1,0,0.0,0,0,0,0,'0','approved','','alexmorgan','2026-07-10 20:07:11','free',0.00,NULL,'2026-07-10 19:37:24','2026-07-10 20:07:11'),
(3,0,0,'','test_crud_app','com.test.crud','工具','CRUD test app','','#4ECDC4','1.0.0','1',10.0,'https://example.com/test.apk','\"[]\"','\"[]\"','',0,0,0,1,0,0.0,0,0,0,0,'0','draft',NULL,'',NULL,'free',0.00,'\"[]\"','2026-07-10 20:09:51','2026-07-10 20:09:51'),
(4,0,0,'','test_crud_app','com.test.crud','工具','CRUD test','','#4ECDC4','1.0.0','1',10.0,'https://example.com/test.apk','\"[]\"','\"[]\"','',0,0,0,1,0,0.0,0,0,0,0,'0','draft',NULL,'',NULL,'free',0.00,'\"[]\"','2026-07-10 20:11:45','2026-07-10 20:11:45'),
(5,0,0,'','test_crud_app','com.test.crud','工具','CRUD test','','#4ECDC4','1.0.0','1',10.0,'https://example.com/test.apk','\"[]\"','\"[]\"','',0,0,0,1,0,0.0,0,0,0,0,'0','draft',NULL,'',NULL,'free',0.00,'\"[]\"','2026-07-10 20:13:26','2026-07-10 20:13:26'),
(6,0,0,'','test_crud_app','com.test.crud','工具','CRUD test','','#4ECDC4','1.0.0','1',10.0,'https://example.com/test.apk','\"[]\"','\"[]\"','',0,0,0,1,0,0.0,0,0,0,0,'0','draft',NULL,'',NULL,'free',0.00,'\"[]\"','2026-07-10 20:13:56','2026-07-10 20:13:56'),
(7,0,0,'','test_crud_app','com.test.crud','工具','CRUD test','','#4ECDC4','1.0.0','1',10.0,'https://example.com/test.apk','\"[]\"','\"[]\"','',0,0,0,1,0,0.0,0,0,0,0,'0','draft',NULL,'',NULL,'free',0.00,'\"[]\"','2026-07-10 20:17:40','2026-07-10 20:17:40'),
(8,12,19,'alexmorgan','百变引擎','百变引擎_13.7.07','工具','66','','#00BFA5','13.7.07','100',19.5,'6666','[\"/uploads/1783770613292-211438868.jpg\"]','[\"官方版\"]','官方版',1,1,0,1,0,0.0,0,0,0,0,'0','approved','','alexmorgan','2026-07-11 11:50:41','free',0.00,'[]','2026-07-11 11:50:19','2026-07-11 11:50:41'),
(9,0,19,'alexmorgan','百变引擎','百变引擎_13.7.07','工具','','/uploads/icon-1783816289499-38219570.png','#00BFA5','13.7.07','100',19.5,'http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783816251341-825401419.apk','[]','[\"官方版\"]','官方版',0,1,0,1,0,0.0,0,0,0,0,'0','draft',NULL,'',NULL,'free',0.00,'[]','2026-07-12 00:32:20','2026-07-12 00:32:20');
/*!40000 ALTER TABLE `app_uploads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_versions`
--

DROP TABLE IF EXISTS `app_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_versions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_id` int(11) NOT NULL,
  `version` varchar(50) NOT NULL,
  `version_code` varchar(50) DEFAULT '',
  `size_mb` decimal(10,1) DEFAULT 0.0,
  `downloads` int(11) DEFAULT 0,
  `rating` decimal(2,1) DEFAULT 0.0,
  `update_content` text DEFAULT NULL,
  `tags` text DEFAULT NULL,
  `download_url` varchar(500) DEFAULT '',
  `is_current` tinyint(1) DEFAULT 0,
  `user_id` int(11) DEFAULT 0,
  `user_name` varchar(100) DEFAULT '',
  `official_tags` text DEFAULT NULL,
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  `description` text DEFAULT NULL,
  `screenshots` text DEFAULT NULL,
  `has_ads` int(11) DEFAULT 0,
  `has_paid_content` int(11) DEFAULT 0,
  `is_free` int(11) DEFAULT 1,
  `requires_network` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_app_versions_app_id` (`app_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_versions`
--

LOCK TABLES `app_versions` WRITE;
/*!40000 ALTER TABLE `app_versions` DISABLE KEYS */;
INSERT INTO `app_versions` VALUES
(2,3,'3.5.4.5','216',0.0,0,0.0,'Bug修复和性能优化',NULL,'',0,0,'',NULL,'1','2026-05-30 22:39:54',NULL,NULL,0,0,1,0),
(4,5,'2.3.7.1','783',0.0,0,0.0,'Bug修复和性能优化',NULL,'',0,0,'',NULL,'1','2026-06-02 22:39:54',NULL,NULL,0,0,1,0),
(8,4,'3.7.5.2','690',0.0,0,0.0,'Bug修复和性能优化',NULL,'',0,0,'',NULL,'1','2026-05-16 22:39:54',NULL,NULL,0,0,1,0),
(9,0,'13.7.07','100',19.5,0,0.0,'','[\"官方版\"]','6666',1,19,'alexmorgan',NULL,'1','2026-07-11 11:50:41','66','[\"/uploads/1783770613292-211438868.jpg\"]',0,0,1,0);
/*!40000 ALTER TABLE `app_versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `avatar_frames`
--

DROP TABLE IF EXISTS `avatar_frames`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `avatar_frames` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `image_url` varchar(500) DEFAULT '',
  `thumbnail_url` varchar(500) DEFAULT '',
  `description` varchar(500) DEFAULT '',
  `obtain_type` varchar(20) DEFAULT 'manual',
  `exp_level_required` int(11) DEFAULT 0,
  `member_level_required` int(11) DEFAULT 0,
  `sort_order` int(11) DEFAULT 0,
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `avatar_frames`
--

LOCK TABLES `avatar_frames` WRITE;
/*!40000 ALTER TABLE `avatar_frames` DISABLE KEYS */;
INSERT INTO `avatar_frames` VALUES
(1,'金色边框','','','','manual',0,0,0,'1','2026-07-10 22:39:54','2026-07-10 22:39:54'),
(2,'炫彩边框','','','','manual',0,0,0,'1','2026-07-10 22:39:54','2026-07-11 16:28:24'),
(3,'简约边框','','','','manual',0,0,0,'1','2026-07-10 22:39:54','2026-07-10 22:39:54'),
(4,'节日边框','','','','manual',0,0,0,'1','2026-07-10 22:39:54','2026-07-10 22:39:54'),
(5,'金色边框','/frames/gold.png','/frames/gold_thumb.png','金闪闪的会员框','membership',0,0,1,'1','2026-07-11 21:07:13','2026-07-11 21:07:13'),
(6,'钻石边框','/frames/diamond.png','/frames/diamond_thumb.png','钻石边框','membership',0,0,2,'1','2026-07-11 21:07:13','2026-07-11 21:07:13');
/*!40000 ALTER TABLE `avatar_frames` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `balance_records`
--

DROP TABLE IF EXISTS `balance_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `balance_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `type` varchar(20) NOT NULL DEFAULT 'earn',
  `amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `balance` decimal(10,2) DEFAULT 0.00,
  `source` varchar(200) DEFAULT '',
  `description` text DEFAULT NULL,
  `ref_id` int(11) DEFAULT 0,
  `ref_type` varchar(50) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_balance_records_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance_records`
--

LOCK TABLES `balance_records` WRITE;
/*!40000 ALTER TABLE `balance_records` DISABLE KEYS */;
INSERT INTO `balance_records` VALUES
(1,19,'alexmorgan','earn',5000.00,5000.00,'卡密兑换','使用卡密 CDKEY-MRG47L1VS1EE 获得5000元余额',0,'','2026-07-11 08:41:23'),
(2,19,'alexmorgan','expense',10.00,4990.00,'会员购买','购买黄金会员',0,'','2026-07-11 08:56:31'),
(3,19,'alexmorgan','expense',10.00,4980.00,'会员购买','购买黄金会员',0,'','2026-07-11 09:14:35'),
(4,19,'alexmorgan','expense',10.00,4970.00,'会员购买','购买黄金会员',0,'','2026-07-11 09:14:38'),
(5,19,'Alex Morgan','expense',1.00,4969.00,'帖子打赏','打赏帖子「开源项目推荐合集」',0,'','2026-07-11 11:39:17'),
(6,1,'bobwang','expense',10.00,78.50,'会员购买','购买黄金会员',0,'','2026-07-11 20:37:08'),
(7,1,'bobwang','earn',3.00,91.50,'会员开通赠送','开通黄金会员赠送余额',0,'','2026-07-11 20:37:08'),
(8,4,'design_master','expense',10.00,0.00,'会员购买','购买黄金会员',0,'','2026-07-11 20:38:36'),
(9,4,'design_master','earn',3.00,13.00,'会员开通赠送','开通黄金会员赠送余额',0,'','2026-07-11 20:38:36'),
(14,21,'testcoupon','expense',10.00,90.00,'会员购买','购买黄金会员',0,'','2026-07-11 20:48:23'),
(15,21,'testcoupon','expense',10.00,90.00,'会员购买','购买黄金会员',0,'','2026-07-11 20:49:43'),
(16,21,'testcoupon','earn',8.00,108.00,'会员开通赠送','开通黄金会员赠送余额',0,'','2026-07-11 20:49:43'),
(17,21,'testcoupon','expense',10.00,88.00,'会员购买','购买黄金会员',0,'','2026-07-11 20:49:53'),
(18,21,'testcoupon','earn',3.00,101.00,'会员开通赠送','开通黄金会员赠送余额',0,'','2026-07-11 20:49:53'),
(19,22,'titletest','expense',10.00,90.00,'会员购买','购买黄金会员',0,'','2026-07-11 21:07:31'),
(20,22,'titletest','earn',8.00,108.00,'会员开通赠送','开通黄金会员赠送余额',0,'','2026-07-11 21:07:31'),
(21,23,'birthdaytest','expense',10.00,90.00,'会员购买','购买黄金会员',0,'','2026-07-11 21:08:20'),
(22,23,'birthdaytest','earn',8.00,108.00,'会员开通赠送','开通黄金会员赠送余额',0,'','2026-07-11 21:08:20'),
(23,19,'alexmorgan','expense',5.00,4964.00,'会员购买','购买黄金会员',0,'','2026-07-12 00:11:10'),
(24,19,'alexmorgan','earn',3.00,4972.00,'会员开通赠送','开通黄金会员赠送余额',0,'','2026-07-12 00:11:10');
/*!40000 ALTER TABLE `balance_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `balance_transfer_records`
--

DROP TABLE IF EXISTS `balance_transfer_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `balance_transfer_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from_user_id` int(11) NOT NULL,
  `from_user_name` varchar(100) DEFAULT '',
  `to_user_id` int(11) NOT NULL,
  `to_user_name` varchar(100) DEFAULT '',
  `amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `fee` decimal(10,2) DEFAULT 0.00,
  `remark` varchar(300) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance_transfer_records`
--

LOCK TABLES `balance_transfer_records` WRITE;
/*!40000 ALTER TABLE `balance_transfer_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance_transfer_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `browse_history`
--

DROP TABLE IF EXISTS `browse_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `browse_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `item_type` varchar(10) NOT NULL,
  `item_id` int(11) NOT NULL,
  `item_title` varchar(300) DEFAULT '',
  `item_cover` varchar(500) DEFAULT '',
  `item_url` varchar(500) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `browse_history`
--

LOCK TABLES `browse_history` WRITE;
/*!40000 ALTER TABLE `browse_history` DISABLE KEYS */;
INSERT INTO `browse_history` VALUES
(9,19,'post',12,'开源项目推荐合集','','/p/12','2026-07-11 11:38:49'),
(10,19,'app',8,'Weather AI','','/a/8','2026-07-11 11:42:25'),
(11,19,'app',6,'Task Flow','','/a/6','2026-07-11 11:43:03'),
(12,19,'app',9,'Fitness Coach','','/a/9','2026-07-11 11:43:25'),
(13,19,'app',7,'Mind Map Pro','','/a/7','2026-07-11 11:43:32'),
(16,19,'app',12,'百变引擎','','/a/12','2026-07-11 15:41:57');
/*!40000 ALTER TABLE `browse_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `card_keys`
--

DROP TABLE IF EXISTS `card_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `card_keys` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `card_no` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `type` varchar(20) NOT NULL DEFAULT 'membership',
  `target_id` int(11) DEFAULT 0,
  `target_name` varchar(100) DEFAULT '',
  `value` int(11) DEFAULT 0,
  `extra_points` int(11) DEFAULT 0,
  `extra_experience` int(11) DEFAULT 0,
  `extra_balance` decimal(10,2) DEFAULT 0.00,
  `duration` int(11) DEFAULT 0,
  `duration_unit` varchar(10) DEFAULT '',
  `status` varchar(2) DEFAULT '0',
  `create_by` varchar(100) DEFAULT '管理员',
  `create_time` datetime DEFAULT current_timestamp(),
  `redeem_by` varchar(100) DEFAULT '',
  `redeem_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `card_no` (`card_no`),
  KEY `idx_card_keys_card_no` (`card_no`),
  KEY `idx_card_keys_type` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `card_keys`
--

LOCK TABLES `card_keys` WRITE;
/*!40000 ALTER TABLE `card_keys` DISABLE KEYS */;
INSERT INTO `card_keys` VALUES
(1,'CDK-KHWVRT97','0kmgb0','points',0,'',462,0,0,0.00,0,'','0','管理员','2026-07-10 22:39:53','',NULL),
(2,'CDK-5290BIZB','hpmpf2','points',0,'',403,0,0,0.00,0,'','0','管理员','2026-07-10 22:39:53','',NULL),
(3,'CDK-RV1LEJFT','0c65nx','points',0,'',153,0,0,0.00,0,'','0','管理员','2026-07-10 22:39:53','',NULL),
(4,'CDK-RZEZXZ38','pjkj1k','points',0,'',211,0,0,0.00,0,'','0','管理员','2026-07-10 22:39:53','',NULL),
(5,'CDK-DHIJ209G','ux6bph','points',0,'',593,0,0,0.00,0,'','0','管理员','2026-07-10 22:39:53','',NULL),
(6,'CDK-B03HO2DX','w2gns1','points',0,'',123,0,0,0.00,0,'','0','管理员','2026-07-10 22:39:53','',NULL),
(7,'CDK-GO78G7ZS','6kxhzr','points',0,'',404,0,0,0.00,0,'','0','管理员','2026-07-10 22:39:53','',NULL),
(8,'CDK-EQI7TQLR','qp3uc1','points',0,'',568,0,0,0.00,0,'','0','管理员','2026-07-10 22:39:53','',NULL),
(9,'CDK-5XH0BZBA','s17s02','points',0,'',512,0,0,0.00,0,'','0','管理员','2026-07-10 22:39:53','',NULL),
(10,'CDK-55Y88WZ9','fpawmz','points',0,'',581,0,0,0.00,0,'','0','管理员','2026-07-10 22:39:53','',NULL),
(11,'CDK-KT12HIH0','0ve3ri','points',0,'',555,0,0,0.00,0,'','0','管理员','2026-07-10 22:39:53','',NULL),
(12,'CDK-YG0XEHLD','1iyd5a','points',0,'',289,0,0,0.00,0,'','0','管理员','2026-07-10 22:39:53','',NULL),
(13,'CDK-VNXEKNE9','vcwhtn','points',0,'',495,0,0,0.00,0,'','1','管理员','2026-07-10 22:39:53','','2026-07-10 22:39:53'),
(14,'CDK-8JFVFCN8','yxnsyx','points',0,'',428,0,0,0.00,0,'','1','管理员','2026-07-10 22:39:53','','2026-07-10 22:39:53'),
(15,'CDK-2IQ5GVLW','54fvq5','points',0,'',493,0,0,0.00,0,'','1','管理员','2026-07-10 22:39:53','','2026-07-10 22:39:53'),
(16,'CDK-376FCU46','qj8d61','points',0,'',428,0,0,0.00,0,'','1','管理员','2026-07-10 22:39:53','','2026-07-10 22:39:53'),
(17,'CDK-NU7STSR7','7ok43h','points',0,'',342,0,0,0.00,0,'','2','管理员','2026-07-10 22:39:53','',NULL),
(18,'CDK-LSQZ95KR','8kustz','points',0,'',344,0,0,0.00,0,'','2','管理员','2026-07-10 22:39:53','',NULL),
(19,'CDK-V63CBG8O','xznppx','points',0,'',234,0,0,0.00,0,'','2','管理员','2026-07-10 22:39:53','',NULL),
(20,'CDK-38YSP7G6','a1j12m','points',0,'',250,0,0,0.00,0,'','2','管理员','2026-07-10 22:39:53','',NULL),
(21,'CDKEY-MRG47L1VS1EE','VDIR0Q5M','balance',1,'5000元余额',5000,99999,2000,0.00,12,'month','1','管理员','2026-07-11 08:41:04','alexmorgan','2026-07-11 08:41:23');
/*!40000 ALTER TABLE `card_keys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_gift_records`
--

DROP TABLE IF EXISTS `chat_gift_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_gift_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `room_id` int(11) DEFAULT 0,
  `gift_id` int(11) NOT NULL,
  `from_user_id` int(11) NOT NULL,
  `to_user_id` int(11) DEFAULT 0,
  `quantity` int(11) DEFAULT 1,
  `points_cost` int(11) DEFAULT 0,
  `message_id` int(11) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_gift_records`
--

LOCK TABLES `chat_gift_records` WRITE;
/*!40000 ALTER TABLE `chat_gift_records` DISABLE KEYS */;
INSERT INTO `chat_gift_records` VALUES
(1,3,1,2,7,3,0,0,'2026-07-10 22:39:53'),
(2,3,2,15,4,8,0,0,'2026-07-10 22:39:53'),
(3,1,3,15,6,6,0,0,'2026-07-10 22:39:53'),
(4,2,4,9,15,6,0,0,'2026-07-10 22:39:53'),
(5,4,1,3,5,2,0,0,'2026-07-10 22:39:53'),
(6,2,2,14,4,5,0,0,'2026-07-10 22:39:53'),
(7,2,3,12,11,7,0,0,'2026-07-10 22:39:53'),
(8,3,4,9,10,8,0,0,'2026-07-10 22:39:53'),
(9,1,1,8,5,8,0,0,'2026-07-10 22:39:53'),
(10,4,2,11,2,3,0,0,'2026-07-10 22:39:53');
/*!40000 ALTER TABLE `chat_gift_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_gifts`
--

DROP TABLE IF EXISTS `chat_gifts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_gifts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `icon` varchar(500) DEFAULT '',
  `price` int(11) DEFAULT 0,
  `coin_type` varchar(20) DEFAULT 'coin',
  `animation` varchar(500) DEFAULT '',
  `sort_order` int(11) DEFAULT 0,
  `status` varchar(20) DEFAULT 'active',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_gifts`
--

LOCK TABLES `chat_gifts` WRITE;
/*!40000 ALTER TABLE `chat_gifts` DISABLE KEYS */;
INSERT INTO `chat_gifts` VALUES
(1,'flower','',5,'coin','',0,'active','2026-07-10 22:39:53'),
(2,'heart','',10,'coin','',0,'active','2026-07-10 22:39:53'),
(3,'star','',20,'coin','',0,'active','2026-07-10 22:39:53'),
(4,'rocket','',50,'coin','',0,'active','2026-07-10 22:39:53');
/*!40000 ALTER TABLE `chat_gifts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_reports`
--

DROP TABLE IF EXISTS `chat_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reporter_id` int(11) NOT NULL,
  `message_id` int(11) DEFAULT 0,
  `target_user_id` int(11) DEFAULT 0,
  `conversation_id` int(11) DEFAULT 0,
  `reason` varchar(50) DEFAULT '',
  `detail` text DEFAULT '',
  `status` varchar(20) DEFAULT 'pending',
  `handler_id` int(11) DEFAULT 0,
  `handle_notes` text DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  `handle_time` datetime DEFAULT NULL,
  `room_id` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_reports`
--

LOCK TABLES `chat_reports` WRITE;
/*!40000 ALTER TABLE `chat_reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `chat_reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_room_admin_logs`
--

DROP TABLE IF EXISTS `chat_room_admin_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_room_admin_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `room_id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `admin_name` varchar(100) DEFAULT '',
  `action` varchar(50) NOT NULL,
  `target_user_id` int(11) DEFAULT 0,
  `target_user_name` varchar(100) DEFAULT '',
  `detail` text DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_room_admin_logs`
--

LOCK TABLES `chat_room_admin_logs` WRITE;
/*!40000 ALTER TABLE `chat_room_admin_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `chat_room_admin_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_room_bans`
--

DROP TABLE IF EXISTS `chat_room_bans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_room_bans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `room_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `type` varchar(20) DEFAULT 'temp',
  `reason` text DEFAULT '',
  `ban_until` datetime DEFAULT NULL,
  `banned_by` int(11) NOT NULL,
  `status` varchar(20) DEFAULT 'active',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `room_id` (`room_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_room_bans`
--

LOCK TABLES `chat_room_bans` WRITE;
/*!40000 ALTER TABLE `chat_room_bans` DISABLE KEYS */;
/*!40000 ALTER TABLE `chat_room_bans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_room_files`
--

DROP TABLE IF EXISTS `chat_room_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_room_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `room_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `file_name` varchar(500) NOT NULL,
  `file_url` varchar(500) NOT NULL,
  `file_type` varchar(50) DEFAULT 'other',
  `file_size` int(11) DEFAULT 0,
  `mime_type` varchar(200) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_chat_room_files_room_id` (`room_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_room_files`
--

LOCK TABLES `chat_room_files` WRITE;
/*!40000 ALTER TABLE `chat_room_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `chat_room_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_room_join_requests`
--

DROP TABLE IF EXISTS `chat_room_join_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_room_join_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `room_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `user_avatar` varchar(200) DEFAULT '',
  `reason` text DEFAULT '',
  `status` varchar(20) DEFAULT 'pending',
  `reviewed_by` int(11) DEFAULT 0,
  `reviewed_name` varchar(100) DEFAULT '',
  `review_comment` text DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  `review_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `room_id` (`room_id`,`user_id`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_room_join_requests`
--

LOCK TABLES `chat_room_join_requests` WRITE;
/*!40000 ALTER TABLE `chat_room_join_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `chat_room_join_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_room_limit_upgrades`
--

DROP TABLE IF EXISTS `chat_room_limit_upgrades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_room_limit_upgrades` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `room_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `current_limit` int(11) DEFAULT 50,
  `request_limit` int(11) NOT NULL,
  `reason` text DEFAULT '',
  `status` varchar(20) DEFAULT 'pending',
  `reviewed_by` int(11) DEFAULT 0,
  `reviewed_name` varchar(100) DEFAULT '',
  `review_comment` text DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  `review_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_room_limit_upgrades`
--

LOCK TABLES `chat_room_limit_upgrades` WRITE;
/*!40000 ALTER TABLE `chat_room_limit_upgrades` DISABLE KEYS */;
/*!40000 ALTER TABLE `chat_room_limit_upgrades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_room_members`
--

DROP TABLE IF EXISTS `chat_room_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_room_members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `room_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `role` varchar(20) DEFAULT 'member',
  `muted_until` datetime DEFAULT NULL,
  `status` varchar(20) DEFAULT 'active',
  `join_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `room_id` (`room_id`,`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_room_members`
--

LOCK TABLES `chat_room_members` WRITE;
/*!40000 ALTER TABLE `chat_room_members` DISABLE KEYS */;
INSERT INTO `chat_room_members` VALUES
(1,1,2,'member',NULL,'active','2026-07-10 22:39:53'),
(2,1,3,'member',NULL,'active','2026-07-10 22:39:53'),
(3,1,4,'owner',NULL,'active','2026-07-10 22:39:53'),
(4,1,7,'member',NULL,'active','2026-07-10 22:39:53'),
(5,1,9,'member',NULL,'active','2026-07-10 22:39:53'),
(6,1,10,'member',NULL,'active','2026-07-10 22:39:53'),
(7,1,11,'member',NULL,'active','2026-07-10 22:39:53'),
(8,1,12,'member',NULL,'active','2026-07-10 22:39:53'),
(9,1,13,'member',NULL,'active','2026-07-10 22:39:53'),
(10,1,14,'member',NULL,'active','2026-07-10 22:39:53'),
(11,2,3,'member',NULL,'active','2026-07-10 22:39:53'),
(12,2,4,'member',NULL,'active','2026-07-10 22:39:53'),
(13,2,5,'owner',NULL,'active','2026-07-10 22:39:53'),
(14,2,6,'member',NULL,'active','2026-07-10 22:39:53'),
(15,2,8,'member',NULL,'active','2026-07-10 22:39:53'),
(16,2,9,'member',NULL,'active','2026-07-10 22:39:53'),
(17,2,11,'member',NULL,'active','2026-07-10 22:39:53'),
(18,2,12,'member',NULL,'active','2026-07-10 22:39:53'),
(19,2,13,'member',NULL,'active','2026-07-10 22:39:53'),
(20,2,14,'member',NULL,'active','2026-07-10 22:39:53'),
(21,2,15,'member',NULL,'active','2026-07-10 22:39:53'),
(22,2,16,'member',NULL,'active','2026-07-10 22:39:53'),
(23,3,2,'owner',NULL,'active','2026-07-10 22:39:53'),
(24,3,3,'member',NULL,'active','2026-07-10 22:39:53'),
(25,3,5,'member',NULL,'active','2026-07-10 22:39:53'),
(26,3,6,'member',NULL,'active','2026-07-10 22:39:53'),
(27,3,7,'member',NULL,'active','2026-07-10 22:39:53'),
(28,3,8,'member',NULL,'active','2026-07-10 22:39:53'),
(29,3,9,'member',NULL,'active','2026-07-10 22:39:53'),
(30,3,10,'member',NULL,'active','2026-07-10 22:39:53'),
(31,3,11,'member',NULL,'active','2026-07-10 22:39:53'),
(32,3,13,'member',NULL,'active','2026-07-10 22:39:53'),
(33,3,14,'member',NULL,'active','2026-07-10 22:39:53'),
(34,3,15,'member',NULL,'active','2026-07-10 22:39:53'),
(35,3,16,'member',NULL,'active','2026-07-10 22:39:53'),
(36,4,5,'member',NULL,'active','2026-07-10 22:39:53'),
(37,4,6,'member',NULL,'active','2026-07-10 22:39:53'),
(38,4,7,'member',NULL,'active','2026-07-10 22:39:53'),
(39,4,9,'member',NULL,'active','2026-07-10 22:39:53'),
(40,4,10,'member',NULL,'active','2026-07-10 22:39:53'),
(41,4,11,'member',NULL,'active','2026-07-10 22:39:53'),
(42,4,12,'member',NULL,'active','2026-07-10 22:39:53'),
(43,4,13,'owner',NULL,'active','2026-07-10 22:39:53'),
(44,4,16,'member',NULL,'active','2026-07-10 22:39:53');
/*!40000 ALTER TABLE `chat_room_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_room_messages`
--

DROP TABLE IF EXISTS `chat_room_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_room_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `room_id` int(11) NOT NULL,
  `from_user_id` int(11) NOT NULL,
  `from_user_name` varchar(100) DEFAULT '',
  `from_user_avatar` varchar(200) DEFAULT '',
  `content` text DEFAULT '',
  `image_url` text DEFAULT '',
  `message_type` varchar(20) DEFAULT 'text',
  `mention_ids` text DEFAULT '[]',
  `is_recalled` tinyint(1) DEFAULT 0,
  `report_status` varchar(20) DEFAULT 'none',
  `order_card` text DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_room_messages`
--

LOCK TABLES `chat_room_messages` WRITE;
/*!40000 ALTER TABLE `chat_room_messages` DISABLE KEYS */;
INSERT INTO `chat_room_messages` VALUES
(1,1,10,'','','这是聊天消息 #1','','text','[]',0,'none','','2026-07-09 07:39:53'),
(2,1,13,'','','这是聊天消息 #2','','text','[]',0,'none','','2026-07-10 08:39:53'),
(3,1,16,'','','这是聊天消息 #3','','text','[]',0,'none','','2026-07-10 09:39:53'),
(4,1,10,'','','这是聊天消息 #4','','text','[]',0,'none','','2026-07-09 17:39:53'),
(5,1,6,'','','这是聊天消息 #5','','text','[]',0,'none','','2026-07-10 13:39:53'),
(6,1,6,'','','这是聊天消息 #6','','text','[]',0,'none','','2026-07-09 11:39:53'),
(7,1,16,'','','这是聊天消息 #7','','text','[]',0,'none','','2026-07-10 22:39:53'),
(8,2,10,'','','这是聊天消息 #1','','text','[]',0,'none','','2026-07-10 15:39:53'),
(9,2,4,'','','这是聊天消息 #2','','text','[]',0,'none','','2026-07-09 22:39:53'),
(10,2,13,'','','这是聊天消息 #3','','text','[]',0,'none','','2026-07-09 18:39:53'),
(11,2,11,'','','这是聊天消息 #4','','text','[]',0,'none','','2026-07-10 13:39:53'),
(12,2,6,'','','这是聊天消息 #5','','text','[]',0,'none','','2026-07-09 23:39:53'),
(13,2,8,'','','这是聊天消息 #6','','text','[]',0,'none','','2026-07-10 18:39:53'),
(14,2,11,'','','这是聊天消息 #7','','text','[]',0,'none','','2026-07-10 01:39:53'),
(15,2,6,'','','这是聊天消息 #8','','text','[]',0,'none','','2026-07-10 12:39:53'),
(16,2,4,'','','这是聊天消息 #9','','text','[]',0,'none','','2026-07-09 04:39:53'),
(17,3,14,'','','这是聊天消息 #1','','text','[]',0,'none','','2026-07-09 10:39:53'),
(18,3,2,'','','这是聊天消息 #2','','text','[]',0,'none','','2026-07-09 10:39:53'),
(19,3,14,'','','这是聊天消息 #3','','text','[]',0,'none','','2026-07-10 01:39:53'),
(20,3,8,'','','这是聊天消息 #4','','text','[]',0,'none','','2026-07-09 10:39:53'),
(21,3,5,'','','这是聊天消息 #5','','text','[]',0,'none','','2026-07-09 12:39:53'),
(22,3,7,'','','这是聊天消息 #6','','text','[]',0,'none','','2026-07-10 22:39:53'),
(23,3,12,'','','这是聊天消息 #7','','text','[]',0,'none','','2026-07-10 05:39:53'),
(24,4,5,'','','这是聊天消息 #1','','text','[]',0,'none','','2026-07-10 08:39:53'),
(25,4,14,'','','这是聊天消息 #2','','text','[]',0,'none','','2026-07-10 18:39:53'),
(26,4,4,'','','这是聊天消息 #3','','text','[]',0,'none','','2026-07-10 19:39:53'),
(27,4,11,'','','这是聊天消息 #4','','text','[]',0,'none','','2026-07-10 12:39:53'),
(28,4,5,'','','这是聊天消息 #5','','text','[]',0,'none','','2026-07-10 22:39:53'),
(29,4,9,'','','这是聊天消息 #6','','text','[]',0,'none','','2026-07-10 00:39:53'),
(30,4,16,'','','这是聊天消息 #7','','text','[]',0,'none','','2026-07-10 14:39:53'),
(31,4,13,'','','这是聊天消息 #8','','text','[]',0,'none','','2026-07-09 06:39:53'),
(32,4,7,'','','这是聊天消息 #9','','text','[]',0,'none','','2026-07-09 22:39:53'),
(33,4,16,'','','这是聊天消息 #10','','text','[]',0,'none','','2026-07-09 20:39:53'),
(34,4,5,'','','这是聊天消息 #11','','text','[]',0,'none','','2026-07-09 10:39:53');
/*!40000 ALTER TABLE `chat_room_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_rooms`
--

DROP TABLE IF EXISTS `chat_rooms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_rooms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `description` text DEFAULT '',
  `avatar` varchar(500) DEFAULT '',
  `owner_id` int(11) NOT NULL,
  `password` varchar(100) DEFAULT '',
  `max_members` int(11) DEFAULT 500,
  `member_limit` int(11) DEFAULT 50,
  `join_mode` varchar(20) DEFAULT 'public',
  `status` varchar(20) DEFAULT 'active',
  `chat_enabled` tinyint(1) DEFAULT 1,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_rooms`
--

LOCK TABLES `chat_rooms` WRITE;
/*!40000 ALTER TABLE `chat_rooms` DISABLE KEYS */;
INSERT INTO `chat_rooms` VALUES
(1,'设计交流群','','',4,'',200,50,'public','1',1,'2026-07-10 22:39:53'),
(2,'技术讨论组','','',5,'',200,50,'public','1',1,'2026-07-10 22:39:53'),
(3,'综合聊天室','','',2,'',200,50,'public','1',1,'2026-07-10 22:39:53'),
(4,'AI爱好者','','',13,'',200,50,'public','1',1,'2026-07-10 22:39:53');
/*!40000 ALTER TABLE `chat_rooms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `checkin_groups`
--

DROP TABLE IF EXISTS `checkin_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `checkin_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `level_id` int(11) DEFAULT 0,
  `icon` varchar(100) DEFAULT '',
  `icon_color` varchar(20) DEFAULT '#409EFF',
  `points` int(11) DEFAULT 5,
  `experience` int(11) DEFAULT 2,
  `balance` decimal(10,2) DEFAULT 0.00,
  `points_consecutive` int(11) DEFAULT 2,
  `experience_consecutive` int(11) DEFAULT 1,
  `balance_consecutive` decimal(10,2) DEFAULT 0.00,
  `sort_order` int(11) DEFAULT 0,
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `checkin_groups`
--

LOCK TABLES `checkin_groups` WRITE;
/*!40000 ALTER TABLE `checkin_groups` DISABLE KEYS */;
INSERT INTO `checkin_groups` VALUES
(1,'默认分组',0,'S','#409EFF',10,2,0.00,2,1,0.00,0,'1','2026-07-10 22:39:54','2026-07-11 17:17:44');
/*!40000 ALTER TABLE `checkin_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `checkin_milestones`
--

DROP TABLE IF EXISTS `checkin_milestones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `checkin_milestones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL DEFAULT 0,
  `days` int(11) NOT NULL DEFAULT 3,
  `points` int(11) DEFAULT 0,
  `experience` int(11) DEFAULT 0,
  `balance` decimal(10,2) DEFAULT 0.00,
  `card_key_type` varchar(20) DEFAULT '',
  `card_key_value` int(11) DEFAULT 0,
  `card_key_duration` int(11) DEFAULT 0,
  `card_key_duration_unit` varchar(10) DEFAULT '',
  `card_key_extra_points` int(11) DEFAULT 0,
  `card_key_extra_experience` int(11) DEFAULT 0,
  `card_key_extra_balance` decimal(10,2) DEFAULT 0.00,
  `sort_order` int(11) DEFAULT 0,
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `checkin_milestones`
--

LOCK TABLES `checkin_milestones` WRITE;
/*!40000 ALTER TABLE `checkin_milestones` DISABLE KEYS */;
/*!40000 ALTER TABLE `checkin_milestones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `checkin_records`
--

DROP TABLE IF EXISTS `checkin_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `checkin_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `checkin_date` date NOT NULL,
  `consecutive_days` int(11) DEFAULT 1,
  `points_earned` int(11) DEFAULT 0,
  `experience_earned` int(11) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`checkin_date`),
  KEY `idx_checkin_records_user_date` (`user_id`,`checkin_date`)
) ENGINE=InnoDB AUTO_INCREMENT=137 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `checkin_records`
--

LOCK TABLES `checkin_records` WRITE;
/*!40000 ALTER TABLE `checkin_records` DISABLE KEYS */;
INSERT INTO `checkin_records` VALUES
(1,3,'','2026-07-10',2,18,0,'2026-07-10 22:39:53'),
(2,7,'','2026-07-10',14,17,0,'2026-07-10 22:39:53'),
(3,9,'','2026-07-10',2,16,0,'2026-07-10 22:39:53'),
(4,6,'','2026-07-10',7,21,0,'2026-07-10 22:39:53'),
(5,10,'','2026-07-10',7,7,0,'2026-07-10 22:39:53'),
(6,14,'','2026-07-09',13,6,0,'2026-07-09 22:39:53'),
(7,11,'','2026-07-09',12,20,0,'2026-07-09 22:39:53'),
(8,12,'','2026-07-09',8,13,0,'2026-07-09 22:39:53'),
(9,2,'','2026-07-09',7,9,0,'2026-07-09 22:39:53'),
(10,8,'','2026-07-08',2,11,0,'2026-07-08 22:39:53'),
(11,11,'','2026-07-08',12,12,0,'2026-07-08 22:39:53'),
(12,2,'','2026-07-08',14,17,0,'2026-07-08 22:39:53'),
(13,6,'','2026-07-07',11,18,0,'2026-07-07 22:39:53'),
(14,13,'','2026-07-07',5,6,0,'2026-07-07 22:39:53'),
(15,8,'','2026-07-07',1,11,0,'2026-07-07 22:39:53'),
(16,2,'','2026-07-07',5,6,0,'2026-07-07 22:39:53'),
(17,5,'','2026-07-06',15,6,0,'2026-07-06 22:39:53'),
(18,12,'','2026-07-06',14,8,0,'2026-07-06 22:39:53'),
(19,13,'','2026-07-06',13,11,0,'2026-07-06 22:39:53'),
(20,10,'','2026-07-06',11,15,0,'2026-07-06 22:39:53'),
(21,9,'','2026-07-06',2,23,0,'2026-07-06 22:39:53'),
(22,4,'','2026-07-06',7,12,0,'2026-07-06 22:39:53'),
(23,11,'','2026-07-05',4,5,0,'2026-07-05 22:39:53'),
(24,13,'','2026-07-05',7,18,0,'2026-07-05 22:39:53'),
(25,6,'','2026-07-05',15,7,0,'2026-07-05 22:39:53'),
(26,3,'','2026-07-05',1,10,0,'2026-07-05 22:39:53'),
(27,11,'','2026-07-04',1,18,0,'2026-07-04 22:39:53'),
(28,2,'','2026-07-04',7,20,0,'2026-07-04 22:39:53'),
(29,4,'','2026-07-04',12,20,0,'2026-07-04 22:39:53'),
(30,12,'','2026-07-04',1,12,0,'2026-07-04 22:39:53'),
(31,12,'','2026-07-03',14,15,0,'2026-07-03 22:39:53'),
(32,14,'','2026-07-03',15,13,0,'2026-07-03 22:39:53'),
(33,2,'','2026-07-03',14,11,0,'2026-07-03 22:39:53'),
(34,13,'','2026-07-03',1,12,0,'2026-07-03 22:39:53'),
(35,3,'','2026-07-03',8,5,0,'2026-07-03 22:39:53'),
(36,15,'','2026-07-02',12,13,0,'2026-07-02 22:39:53'),
(37,4,'','2026-07-02',14,13,0,'2026-07-02 22:39:53'),
(38,2,'','2026-07-02',11,7,0,'2026-07-02 22:39:53'),
(39,11,'','2026-07-01',10,16,0,'2026-07-01 22:39:53'),
(40,8,'','2026-07-01',9,12,0,'2026-07-01 22:39:53'),
(41,7,'','2026-07-01',6,6,0,'2026-07-01 22:39:53'),
(42,5,'','2026-07-01',10,24,0,'2026-07-01 22:39:53'),
(43,14,'','2026-06-30',6,17,0,'2026-06-30 22:39:53'),
(44,2,'','2026-06-30',10,21,0,'2026-06-30 22:39:53'),
(45,7,'','2026-06-30',1,14,0,'2026-06-30 22:39:53'),
(46,13,'','2026-06-30',2,9,0,'2026-06-30 22:39:53'),
(47,11,'','2026-06-29',5,22,0,'2026-06-29 22:39:53'),
(48,14,'','2026-06-29',5,19,0,'2026-06-29 22:39:53'),
(49,10,'','2026-06-29',11,24,0,'2026-06-29 22:39:53'),
(50,8,'','2026-06-29',10,24,0,'2026-06-29 22:39:53'),
(51,11,'','2026-06-28',15,18,0,'2026-06-28 22:39:53'),
(52,14,'','2026-06-28',7,19,0,'2026-06-28 22:39:53'),
(53,7,'','2026-06-28',6,5,0,'2026-06-28 22:39:53'),
(54,8,'','2026-06-28',9,24,0,'2026-06-28 22:39:53'),
(55,12,'','2026-06-28',15,12,0,'2026-06-28 22:39:53'),
(56,2,'','2026-06-28',9,20,0,'2026-06-28 22:39:53'),
(57,15,'','2026-06-27',1,5,0,'2026-06-27 22:39:53'),
(58,2,'','2026-06-27',6,9,0,'2026-06-27 22:39:53'),
(59,4,'','2026-06-27',14,18,0,'2026-06-27 22:39:53'),
(60,13,'','2026-06-26',1,5,0,'2026-06-26 22:39:53'),
(61,9,'','2026-06-26',15,20,0,'2026-06-26 22:39:53'),
(62,2,'','2026-06-26',5,11,0,'2026-06-26 22:39:53'),
(63,5,'','2026-06-25',5,10,0,'2026-06-25 22:39:53'),
(64,10,'','2026-06-25',7,5,0,'2026-06-25 22:39:53'),
(65,15,'','2026-06-25',15,15,0,'2026-06-25 22:39:53'),
(66,5,'','2026-06-24',8,24,0,'2026-06-24 22:39:53'),
(67,6,'','2026-06-24',7,24,0,'2026-06-24 22:39:53'),
(68,15,'','2026-06-24',8,23,0,'2026-06-24 22:39:53'),
(69,2,'','2026-06-24',12,12,0,'2026-06-24 22:39:53'),
(70,14,'','2026-06-23',12,18,0,'2026-06-23 22:39:53'),
(71,15,'','2026-06-23',1,19,0,'2026-06-23 22:39:53'),
(72,6,'','2026-06-23',13,20,0,'2026-06-23 22:39:53'),
(73,5,'','2026-06-23',5,22,0,'2026-06-23 22:39:53'),
(74,2,'','2026-06-23',1,23,0,'2026-06-23 22:39:53'),
(75,14,'','2026-06-22',5,21,0,'2026-06-22 22:39:53'),
(76,5,'','2026-06-22',10,16,0,'2026-06-22 22:39:53'),
(77,9,'','2026-06-22',5,5,0,'2026-06-22 22:39:53'),
(78,10,'','2026-06-22',6,10,0,'2026-06-22 22:39:53'),
(79,15,'','2026-06-22',14,17,0,'2026-06-22 22:39:53'),
(80,8,'','2026-06-22',1,17,0,'2026-06-22 22:39:53'),
(81,6,'','2026-06-21',8,15,0,'2026-06-21 22:39:53'),
(82,4,'','2026-06-21',8,22,0,'2026-06-21 22:39:53'),
(83,14,'','2026-06-21',8,8,0,'2026-06-21 22:39:53'),
(84,10,'','2026-06-21',6,21,0,'2026-06-21 22:39:53'),
(85,7,'','2026-06-21',6,5,0,'2026-06-21 22:39:53'),
(86,12,'','2026-06-21',8,20,0,'2026-06-21 22:39:53'),
(87,9,'','2026-06-21',5,8,0,'2026-06-21 22:39:53'),
(88,8,'','2026-06-21',11,21,0,'2026-06-21 22:39:53'),
(89,4,'','2026-06-20',14,22,0,'2026-06-20 22:39:53'),
(90,5,'','2026-06-20',5,23,0,'2026-06-20 22:39:53'),
(91,15,'','2026-06-20',6,22,0,'2026-06-20 22:39:53'),
(92,6,'','2026-06-20',2,11,0,'2026-06-20 22:39:53'),
(93,7,'','2026-06-20',7,7,0,'2026-06-20 22:39:53'),
(94,9,'','2026-06-20',12,23,0,'2026-06-20 22:39:53'),
(95,14,'','2026-06-20',3,12,0,'2026-06-20 22:39:53'),
(96,14,'','2026-06-19',12,7,0,'2026-06-19 22:39:53'),
(97,7,'','2026-06-19',2,21,0,'2026-06-19 22:39:53'),
(98,15,'','2026-06-19',15,10,0,'2026-06-19 22:39:53'),
(99,2,'','2026-06-19',12,7,0,'2026-06-19 22:39:53'),
(100,12,'','2026-06-19',1,15,0,'2026-06-19 22:39:53'),
(101,9,'','2026-06-18',1,19,0,'2026-06-18 22:39:53'),
(102,6,'','2026-06-18',10,6,0,'2026-06-18 22:39:53'),
(103,3,'','2026-06-18',4,10,0,'2026-06-18 22:39:53'),
(104,10,'','2026-06-18',6,11,0,'2026-06-18 22:39:53'),
(105,2,'','2026-06-17',6,9,0,'2026-06-17 22:39:53'),
(106,7,'','2026-06-17',11,24,0,'2026-06-17 22:39:53'),
(107,9,'','2026-06-17',6,11,0,'2026-06-17 22:39:53'),
(108,15,'','2026-06-17',7,16,0,'2026-06-17 22:39:53'),
(109,5,'','2026-06-17',6,22,0,'2026-06-17 22:39:53'),
(110,8,'','2026-06-16',3,10,0,'2026-06-16 22:39:53'),
(111,15,'','2026-06-16',6,21,0,'2026-06-16 22:39:53'),
(112,10,'','2026-06-16',6,18,0,'2026-06-16 22:39:53'),
(113,2,'','2026-06-16',14,14,0,'2026-06-16 22:39:53'),
(114,4,'','2026-06-15',15,24,0,'2026-06-15 22:39:53'),
(115,11,'','2026-06-15',12,17,0,'2026-06-15 22:39:53'),
(116,13,'','2026-06-15',11,10,0,'2026-06-15 22:39:53'),
(117,8,'','2026-06-15',6,8,0,'2026-06-15 22:39:53'),
(118,13,'','2026-06-14',6,23,0,'2026-06-14 22:39:53'),
(119,5,'','2026-06-14',12,6,0,'2026-06-14 22:39:53'),
(120,12,'','2026-06-14',13,6,0,'2026-06-14 22:39:53'),
(121,9,'','2026-06-14',10,10,0,'2026-06-14 22:39:53'),
(122,11,'','2026-06-14',6,10,0,'2026-06-14 22:39:53'),
(123,7,'','2026-06-13',4,22,0,'2026-06-13 22:39:53'),
(124,6,'','2026-06-13',8,12,0,'2026-06-13 22:39:53'),
(125,5,'','2026-06-13',9,11,0,'2026-06-13 22:39:53'),
(126,2,'','2026-06-13',1,7,0,'2026-06-13 22:39:53'),
(127,13,'','2026-06-13',5,11,0,'2026-06-13 22:39:53'),
(128,13,'','2026-06-12',14,19,0,'2026-06-12 22:39:53'),
(129,2,'','2026-06-12',14,7,0,'2026-06-12 22:39:53'),
(130,6,'','2026-06-12',3,9,0,'2026-06-12 22:39:53'),
(131,8,'','2026-06-12',4,22,0,'2026-06-12 22:39:53'),
(132,15,'','2026-06-12',1,17,0,'2026-06-12 22:39:53'),
(133,7,'','2026-06-12',8,12,0,'2026-06-12 22:39:53'),
(134,15,'','2026-06-11',11,14,0,'2026-06-11 22:39:53'),
(135,4,'','2026-06-11',15,5,0,'2026-06-11 22:39:53'),
(136,7,'','2026-06-11',14,17,0,'2026-06-11 22:39:53');
/*!40000 ALTER TABLE `checkin_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comment_likes`
--

DROP TABLE IF EXISTS `comment_likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `comment_likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `comment_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `comment_id` (`comment_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment_likes`
--

LOCK TABLES `comment_likes` WRITE;
/*!40000 ALTER TABLE `comment_likes` DISABLE KEYS */;
/*!40000 ALTER TABLE `comment_likes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commission_records`
--

DROP TABLE IF EXISTS `commission_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `commission_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) DEFAULT 0,
  `order_type` varchar(30) DEFAULT '',
  `order_amount` decimal(10,2) DEFAULT 0.00,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `referrer_id` int(11) NOT NULL,
  `referrer_name` varchar(100) DEFAULT '',
  `rate` decimal(5,2) DEFAULT 0.00,
  `amount` decimal(10,2) DEFAULT 0.00,
  `status` varchar(20) DEFAULT 'pending',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_commission_records_user` (`user_id`),
  KEY `idx_commission_records_referrer` (`referrer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commission_records`
--

LOCK TABLES `commission_records` WRITE;
/*!40000 ALTER TABLE `commission_records` DISABLE KEYS */;
INSERT INTO `commission_records` VALUES
(1,1,'',236.00,9,'user9',10,'user10',0.00,14.81,'completed','2026-07-01 22:39:54'),
(2,2,'',144.00,11,'user11',12,'user12',0.00,11.19,'completed','2026-06-18 22:39:54'),
(3,3,'',165.00,8,'user8',9,'user9',0.00,17.71,'completed','2026-06-24 22:39:54'),
(4,4,'',113.00,8,'user8',9,'user9',0.00,17.55,'completed','2026-06-23 22:39:54'),
(5,5,'',84.00,5,'user5',6,'user6',0.00,14.54,'completed','2026-07-05 22:39:54'),
(6,6,'',182.00,8,'user8',9,'user9',0.00,6.23,'completed','2026-07-08 22:39:54'),
(7,7,'',99.00,12,'user12',13,'user13',0.00,23.75,'completed','2026-07-01 22:39:54'),
(8,8,'',125.00,3,'user3',4,'user4',0.00,20.88,'completed','2026-06-25 22:39:54');
/*!40000 ALTER TABLE `commission_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commission_rules`
--

DROP TABLE IF EXISTS `commission_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `commission_rules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT '',
  `order_type` varchar(30) DEFAULT 'all',
  `rate` decimal(5,2) DEFAULT 0.00,
  `user_level_id` int(11) DEFAULT 0,
  `user_level_name` varchar(100) DEFAULT '',
  `user_id` int(11) DEFAULT 0,
  `invite_code_id` int(11) DEFAULT 0,
  `invite_code_type` varchar(20) DEFAULT '',
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commission_rules`
--

LOCK TABLES `commission_rules` WRITE;
/*!40000 ALTER TABLE `commission_rules` DISABLE KEYS */;
INSERT INTO `commission_rules` VALUES
(1,'一级返佣','all',10.00,1,'',0,0,'','1','2026-07-10 22:39:54'),
(2,'二级返佣','all',5.00,2,'',0,0,'','1','2026-07-10 22:39:54');
/*!40000 ALTER TABLE `commission_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_attach_purchases`
--

DROP TABLE IF EXISTS `community_attach_purchases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_attach_purchases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `attach_url` varchar(500) NOT NULL DEFAULT '',
  `coin_type` varchar(20) NOT NULL DEFAULT 'coin',
  `coin_amount` int(11) NOT NULL DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_attach_purchases`
--

LOCK TABLES `community_attach_purchases` WRITE;
/*!40000 ALTER TABLE `community_attach_purchases` DISABLE KEYS */;
/*!40000 ALTER TABLE `community_attach_purchases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_banned_users`
--

DROP TABLE IF EXISTS `community_banned_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_banned_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `reason` varchar(500) DEFAULT '',
  `banned_until` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `idx_community_banned_users_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_banned_users`
--

LOCK TABLES `community_banned_users` WRITE;
/*!40000 ALTER TABLE `community_banned_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `community_banned_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_coin_logs`
--

DROP TABLE IF EXISTS `community_coin_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_coin_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `from_user_id` int(11) NOT NULL,
  `from_user_name` varchar(100) DEFAULT '',
  `from_user_avatar` varchar(500) DEFAULT '',
  `to_user_id` int(11) NOT NULL DEFAULT 0,
  `amount` int(11) DEFAULT 0,
  `coin_type` varchar(20) DEFAULT 'coin',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_coin_logs`
--

LOCK TABLES `community_coin_logs` WRITE;
/*!40000 ALTER TABLE `community_coin_logs` DISABLE KEYS */;
INSERT INTO `community_coin_logs` VALUES
(1,12,19,'Alex Morgan','',7,1,'coin','2026-07-11 11:39:17');
/*!40000 ALTER TABLE `community_coin_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_comments`
--

DROP TABLE IF EXISTS `community_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `parent_id` int(11) DEFAULT 0,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `user_avatar` varchar(500) DEFAULT '',
  `content` text NOT NULL,
  `images` text DEFAULT '[]',
  `like_count` int(11) DEFAULT 0,
  `reply_count` int(11) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  `is_pinned` tinyint(1) DEFAULT 0,
  `reported` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_community_comments_post_id` (`post_id`),
  KEY `idx_community_comments_parent_id` (`parent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_comments`
--

LOCK TABLES `community_comments` WRITE;
/*!40000 ALTER TABLE `community_comments` DISABLE KEYS */;
INSERT INTO `community_comments` VALUES
(1,6,0,2,'','','这是第1条测试评论，内容非常精彩！','[]',0,0,'2026-07-04 22:39:49',0,0),
(3,7,0,14,'','','这是第3条测试评论，内容非常精彩！','[]',0,0,'2026-06-25 22:39:49',0,0),
(4,7,0,8,'','','这是第4条测试评论，内容非常精彩！','[]',0,0,'2026-06-29 22:39:49',0,0),
(5,10,0,3,'','','这是第5条测试评论，内容非常精彩！','[]',0,0,'2026-06-30 22:39:49',0,0),
(6,9,0,3,'','','这是第6条测试评论，内容非常精彩！','[]',0,0,'2026-06-25 22:39:49',0,0),
(7,1,0,13,'','','这是第7条测试评论，内容非常精彩！','[]',0,0,'2026-07-04 22:39:49',0,0),
(8,10,0,16,'','','这是第8条测试评论，内容非常精彩！','[]',0,0,'2026-07-01 22:39:49',0,0),
(9,2,0,5,'','','这是第9条测试评论，内容非常精彩！','[]',0,0,'2026-07-07 22:39:49',0,0),
(10,8,0,2,'','','这是第10条测试评论，内容非常精彩！','[]',0,0,'2026-07-09 22:39:49',0,0),
(11,10,0,13,'','','这是第11条测试评论，内容非常精彩！','[]',0,0,'2026-06-27 22:39:49',0,0),
(12,7,0,3,'','','这是第12条测试评论，内容非常精彩！','[]',0,0,'2026-06-28 22:39:49',0,0),
(13,3,0,13,'','','这是第13条测试评论，内容非常精彩！','[]',0,0,'2026-07-06 22:39:49',0,0),
(14,10,0,10,'','','这是第14条测试评论，内容非常精彩！','[]',0,0,'2026-07-02 22:39:49',0,0),
(15,6,0,8,'','','这是第15条测试评论，内容非常精彩！','[]',0,0,'2026-06-21 22:39:49',0,0),
(16,4,0,14,'','','这是第16条测试评论，内容非常精彩！','[]',0,0,'2026-07-08 22:39:49',0,0),
(17,2,0,9,'','','这是第17条测试评论，内容非常精彩！','[]',0,0,'2026-06-21 22:39:49',0,0),
(18,1,0,9,'','','这是第18条测试评论，内容非常精彩！','[]',0,0,'2026-06-23 22:39:49',0,0),
(19,9,0,5,'','','这是第19条测试评论，内容非常精彩！','[]',0,0,'2026-06-29 22:39:49',0,0),
(20,10,0,10,'','','这是第20条测试评论，内容非常精彩！','[]',0,0,'2026-07-03 22:39:49',0,0),
(21,5,0,10,'','','这是第21条测试评论，内容非常精彩！','[]',0,0,'2026-06-22 22:39:49',0,0),
(22,10,0,15,'','','这是第22条测试评论，内容非常精彩！','[]',0,0,'2026-07-03 22:39:49',0,0),
(23,10,0,16,'','','这是第23条测试评论，内容非常精彩！','[]',0,0,'2026-06-29 22:39:49',0,0),
(24,12,0,8,'','','这是第24条测试评论，内容非常精彩！','[]',0,0,'2026-07-04 22:39:49',0,0),
(25,7,0,5,'','','这是第25条测试评论，内容非常精彩！','[]',0,0,'2026-07-03 22:39:49',0,0),
(26,5,0,16,'','','这是第26条测试评论，内容非常精彩！','[]',0,0,'2026-06-26 22:39:49',0,0),
(27,8,0,5,'','','这是第27条测试评论，内容非常精彩！','[]',0,0,'2026-06-24 22:39:49',0,0),
(28,5,0,2,'','','这是第28条测试评论，内容非常精彩！','[]',0,0,'2026-06-21 22:39:49',0,0),
(29,1,0,5,'','','这是第29条测试评论，内容非常精彩！','[]',0,0,'2026-07-10 22:39:49',0,0),
(30,11,0,14,'','','这是第30条测试评论，内容非常精彩！','[]',0,0,'2026-06-30 22:39:49',0,0),
(31,8,0,16,'','','这是第31条测试评论，内容非常精彩！','[]',0,0,'2026-06-28 22:39:49',0,0),
(32,6,0,2,'','','这是第32条测试评论，内容非常精彩！','[]',0,0,'2026-06-26 22:39:49',0,0),
(33,6,0,8,'','','这是第33条测试评论，内容非常精彩！','[]',0,0,'2026-06-21 22:39:49',0,0),
(34,6,0,17,'','','这是第34条测试评论，内容非常精彩！','[]',0,0,'2026-07-09 22:39:49',0,0),
(35,9,0,13,'','','这是第35条测试评论，内容非常精彩！','[]',0,0,'2026-07-05 22:39:49',0,0),
(36,7,0,8,'','','这是第36条测试评论，内容非常精彩！','[]',0,0,'2026-07-06 22:39:49',0,0),
(37,11,0,8,'','','这是第37条测试评论，内容非常精彩！','[]',0,0,'2026-07-07 22:39:49',0,0),
(38,7,0,15,'','','这是第38条测试评论，内容非常精彩！','[]',0,0,'2026-06-25 22:39:49',0,0),
(39,10,0,5,'','','这是第39条测试评论，内容非常精彩！','[]',0,0,'2026-07-02 22:39:49',0,0),
(40,9,0,10,'','','这是第40条测试评论，内容非常精彩！','[]',0,0,'2026-07-09 22:39:49',0,0),
(41,12,2,19,'Alex Morgan','','3','[]',0,0,'2026-07-11 11:36:42',0,0),
(43,12,0,19,'Alex Morgan','','8','[]',0,0,'2026-07-11 11:36:50',0,0);
/*!40000 ALTER TABLE `community_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_drafts`
--

DROP TABLE IF EXISTS `community_drafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_drafts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `section_id` int(11) DEFAULT 0,
  `title` varchar(500) DEFAULT '',
  `content` text DEFAULT '',
  `images` text DEFAULT '[]',
  `tags` text DEFAULT '[]',
  `official_tags` text DEFAULT '[]',
  `has_resource` int(11) DEFAULT 0,
  `resource_type` varchar(20) DEFAULT '',
  `resource_url` text DEFAULT '',
  `resource_price` double DEFAULT 0,
  `resource_price_type` varchar(20) DEFAULT 'free',
  `extract_code` varchar(100) DEFAULT '',
  `permission` varchar(20) DEFAULT 'public',
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_community_drafts_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_drafts`
--

LOCK TABLES `community_drafts` WRITE;
/*!40000 ALTER TABLE `community_drafts` DISABLE KEYS */;
/*!40000 ALTER TABLE `community_drafts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_favorites`
--

DROP TABLE IF EXISTS `community_favorites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_favorites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `post_id` (`post_id`,`user_id`),
  KEY `idx_community_favorites_post_user` (`post_id`,`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_favorites`
--

LOCK TABLES `community_favorites` WRITE;
/*!40000 ALTER TABLE `community_favorites` DISABLE KEYS */;
INSERT INTO `community_favorites` VALUES
(1,1,1,'2026-07-10 19:37:24');
/*!40000 ALTER TABLE `community_favorites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_likes`
--

DROP TABLE IF EXISTS `community_likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `post_id` (`post_id`,`user_id`),
  KEY `idx_community_likes_post_user` (`post_id`,`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_likes`
--

LOCK TABLES `community_likes` WRITE;
/*!40000 ALTER TABLE `community_likes` DISABLE KEYS */;
INSERT INTO `community_likes` VALUES
(1,1,9,'2026-07-01 22:39:49'),
(2,1,12,'2026-07-01 22:39:49'),
(3,9,9,'2026-07-02 22:39:49'),
(4,3,6,'2026-07-02 22:39:49'),
(5,3,2,'2026-06-26 22:39:49'),
(6,10,3,'2026-06-26 22:39:49'),
(7,3,12,'2026-06-21 22:39:49'),
(8,4,12,'2026-06-21 22:39:49'),
(9,3,4,'2026-06-28 22:39:49'),
(10,1,2,'2026-07-02 22:39:49'),
(11,11,15,'2026-07-07 22:39:49');
/*!40000 ALTER TABLE `community_likes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_moderators`
--

DROP TABLE IF EXISTS `community_moderators`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_moderators` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `section_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `user_avatar` varchar(500) DEFAULT '',
  `role` varchar(20) DEFAULT '版主',
  `sort_order` int(11) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `section_id` (`section_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_moderators`
--

LOCK TABLES `community_moderators` WRITE;
/*!40000 ALTER TABLE `community_moderators` DISABLE KEYS */;
/*!40000 ALTER TABLE `community_moderators` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_post_topics`
--

DROP TABLE IF EXISTS `community_post_topics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_post_topics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `topic_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `post_id` (`post_id`,`topic_id`),
  KEY `idx_post_topics_post` (`post_id`),
  KEY `idx_post_topics_topic` (`topic_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_post_topics`
--

LOCK TABLES `community_post_topics` WRITE;
/*!40000 ALTER TABLE `community_post_topics` DISABLE KEYS */;
/*!40000 ALTER TABLE `community_post_topics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_posts`
--

DROP TABLE IF EXISTS `community_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `section_id` int(11) NOT NULL DEFAULT 0,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `user_avatar` varchar(500) DEFAULT '',
  `title` varchar(500) DEFAULT '',
  `content` text DEFAULT '',
  `device` varchar(100) DEFAULT '',
  `tags` text DEFAULT '[]',
  `official_tags` text DEFAULT '[]',
  `images` text DEFAULT '[]',
  `has_resource` int(11) DEFAULT 0,
  `resource_type` varchar(20) DEFAULT '',
  `resource_url` text DEFAULT '',
  `resource_price` double DEFAULT 0,
  `resource_price_type` varchar(20) DEFAULT 'free',
  `extract_code` varchar(100) DEFAULT '',
  `permission` varchar(20) DEFAULT 'public',
  `is_pinned` int(11) DEFAULT 0,
  `is_essence` int(11) DEFAULT 0,
  `is_hot` int(11) DEFAULT 0,
  `hot_manually_disabled` tinyint(1) DEFAULT 0,
  `is_global_pinned` tinyint(1) DEFAULT 0,
  `custom_badge` varchar(50) DEFAULT '',
  `status` varchar(20) DEFAULT 'published',
  `like_count` int(11) DEFAULT 0,
  `comment_count` int(11) DEFAULT 0,
  `coin_count` int(11) DEFAULT 0,
  `view_count` int(11) DEFAULT 0,
  `favorite_count` int(11) DEFAULT 0,
  `topic_id` int(11) DEFAULT 0,
  `content_permission` varchar(20) DEFAULT 'public',
  `content_price` decimal(10,2) DEFAULT 0.00,
  `content_price_type` varchar(20) DEFAULT 'free',
  `access_password` varchar(100) DEFAULT '',
  `access_password_tips` varchar(500) DEFAULT '',
  `cover_url` varchar(500) DEFAULT '',
  `is_edited` int(11) DEFAULT 0,
  `edited_at` datetime DEFAULT NULL,
  `avatar_frame` varchar(500) DEFAULT '',
  `name_color` varchar(20) DEFAULT '',
  `is_anonymous` int(11) DEFAULT 0,
  `is_deleted` tinyint(1) DEFAULT 0,
  `deleted_at` datetime DEFAULT NULL,
  `edition` int(11) DEFAULT 1,
  `community_id` int(11) DEFAULT 0,
  `community_name` varchar(100) DEFAULT '',
  `community_icon` varchar(500) DEFAULT '',
  `review_status` varchar(20) DEFAULT 'approved',
  `reviewed_at` datetime DEFAULT NULL,
  `reviewed_by` varchar(100) DEFAULT '',
  `review_reason` text DEFAULT NULL,
  `reject_reason` text DEFAULT NULL,
  `locked` int(11) DEFAULT 0,
  `is_locked` int(11) DEFAULT 0,
  `locked_at` datetime DEFAULT NULL,
  `locked_by` int(11) DEFAULT 0,
  `locked_reason` varchar(500) DEFAULT '',
  `share_count` int(11) DEFAULT 0,
  `content_type` varchar(20) DEFAULT 'text',
  `attachment_urls` text DEFAULT NULL,
  `hidden_content` text DEFAULT NULL,
  `hidden_attachment_urls` text DEFAULT NULL,
  `free_read` int(11) DEFAULT 0,
  `free_count` int(11) DEFAULT 500,
  `cover_width` int(11) DEFAULT 0,
  `cover_height` int(11) DEFAULT 0,
  `duration_us` int(11) DEFAULT 0,
  `size_mb` decimal(10,2) DEFAULT 0.00,
  `mime_type` varchar(100) DEFAULT '',
  `voice_url` varchar(500) DEFAULT '',
  `voice_duration` int(11) DEFAULT 0,
  `video_width` int(11) DEFAULT 0,
  `video_height` int(11) DEFAULT 0,
  `original_lang` varchar(10) DEFAULT '',
  `translations` text DEFAULT NULL,
  `is_sticky_global` tinyint(1) DEFAULT 0,
  `sticky_order` int(11) DEFAULT 0,
  `sticky_section_id` int(11) DEFAULT 0,
  `sticky_until` datetime DEFAULT NULL,
  `post_uid` varchar(36) DEFAULT '',
  `summary` varchar(200) DEFAULT '',
  `sort_weight` decimal(10,2) DEFAULT 0.00,
  `scheduled_time` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_community_posts_section_id` (`section_id`),
  KEY `idx_community_posts_user_id` (`user_id`),
  KEY `idx_community_posts_status` (`status`),
  KEY `idx_community_posts_is_pinned` (`is_pinned`),
  KEY `idx_community_posts_is_essence` (`is_essence`),
  KEY `idx_community_posts_is_hot` (`is_hot`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_posts`
--

LOCK TABLES `community_posts` WRITE;
/*!40000 ALTER TABLE `community_posts` DISABLE KEYS */;
INSERT INTO `community_posts` VALUES
(1,1,2,'','','分享我的设计作品集','<p>花了一个月时间整理的作品集，包含平面设计、UI设计和品牌设计作品</p>','','[]','[]','[]',0,'','',0,'free','','public',1,0,0,0,0,'','published',45,12,0,150,0,0,'public',0.00,'free','','','',0,NULL,'','',0,0,NULL,1,0,'','','approved',NULL,'',NULL,NULL,0,0,NULL,0,'',0,'text',NULL,NULL,NULL,0,500,0,0,0,0.00,'','',0,0,0,'',NULL,0,0,0,NULL,'','',0.00,NULL,'2026-06-24 22:39:49','2026-07-10 22:39:49'),
(2,2,3,'','','AI绘画入门指南','<p>从零开始学习AI绘画，介绍主流工具和使用技巧</p>','','[]','[]','[]',0,'','',0,'free','','public',0,0,0,0,0,'','published',88,25,0,320,0,0,'public',0.00,'free','','','',0,NULL,'','',0,0,NULL,1,0,'','','approved',NULL,'',NULL,NULL,0,0,NULL,0,'',0,'text',NULL,NULL,NULL,0,500,0,0,0,0.00,'','',0,0,0,'',NULL,0,0,0,NULL,'','',0.00,NULL,'2026-06-14 22:39:49','2026-07-10 22:39:49'),
(3,3,5,'','','React 19 新特性解读','<p>React 19带来了很多令人兴奋的新特性，让我们一起看看</p>','','[]','[]','[]',0,'','',0,'free','','public',1,1,0,0,1,'','published',55,18,0,200,0,0,'public',0.00,'free','','','',0,NULL,'','',0,0,NULL,1,0,'','','approved',NULL,'',NULL,NULL,0,0,NULL,0,'',0,'text',NULL,NULL,NULL,0,500,0,0,0,0.00,'','',0,0,0,'',NULL,0,0,0,NULL,'','',0.00,NULL,'2026-06-16 22:39:49','2026-07-10 22:39:49'),
(4,4,2,'','','我的应用开发历程','<p>从想法到上线，分享我的独立开发经历</p>','','[]','[]','[]',0,'','',0,'free','','public',0,0,0,0,0,'','published',30,8,0,90,0,0,'public',0.00,'free','','','',0,NULL,'','',0,0,NULL,1,0,'','','approved',NULL,'',NULL,NULL,0,0,NULL,0,'',0,'text',NULL,NULL,NULL,0,500,0,0,0,0.00,'','',0,0,0,'',NULL,0,0,0,NULL,'','',0.00,NULL,'2026-07-08 22:39:49','2026-07-10 22:39:49'),
(5,5,8,'','','Vue3 + TypeScript 实战','<p>结合项目实战讲解Vue3 Composition API和TypeScript</p>','','[]','[]','[]',0,'','',0,'free','','public',1,0,0,0,0,'','published',42,15,0,180,0,0,'public',0.00,'free','','','',0,NULL,'','',0,0,NULL,1,0,'','','approved',NULL,'',NULL,NULL,0,0,NULL,0,'',0,'text',NULL,NULL,NULL,0,500,0,0,0,0.00,'','',0,0,0,'',NULL,0,0,0,NULL,'','',0.00,NULL,'2026-07-05 22:39:49','2026-07-10 22:39:49'),
(6,6,14,'','','设计师如何提升审美','<p>分享一些提升设计审美的方法和资源</p>','','[]','[]','[]',0,'','',0,'free','','public',1,1,0,0,1,'','published',60,20,0,250,0,0,'public',0.00,'free','','','',0,NULL,'','',0,0,NULL,1,0,'','','approved',NULL,'',NULL,NULL,0,0,NULL,0,'',0,'text',NULL,NULL,NULL,0,500,0,0,0,0.00,'','',0,0,0,'',NULL,0,0,0,NULL,'','',0.00,NULL,'2026-06-22 22:39:49','2026-07-10 22:39:49'),
(7,7,10,'','','Cloud Native架构实践','<p>微服务、容器化、K8s等云原生技术的最佳实践</p>','','[]','[]','[]',0,'','',0,'free','','public',0,1,0,0,1,'','published',35,10,0,130,0,0,'public',0.00,'free','','','',0,NULL,'','',0,0,NULL,1,0,'','','approved',NULL,'',NULL,NULL,0,0,NULL,0,'',0,'text',NULL,NULL,NULL,0,500,0,0,0,0.00,'','',0,0,0,'',NULL,0,0,0,NULL,'','',0.00,NULL,'2026-07-02 22:39:49','2026-07-10 22:39:49'),
(8,8,13,'','','移动开发趋势2026','<p>Flutter、React Native、SwiftUI等跨平台框架对比</p>','','[]','[]','[]',0,'','',0,'free','','public',0,0,0,0,0,'','published',40,14,0,160,0,0,'public',0.00,'free','','','',0,NULL,'','',0,0,NULL,1,0,'','','approved',NULL,'',NULL,NULL,0,0,NULL,0,'',0,'text',NULL,NULL,NULL,0,500,0,0,0,0.00,'','',0,0,0,'',NULL,0,0,0,NULL,'','',0.00,NULL,'2026-06-16 22:39:49','2026-07-10 22:39:49'),
(9,9,6,'','','像素艺术创作技巧','<p>分享一些像素画创作的实用技巧和工具推荐</p>','','[]','[]','[]',0,'','',0,'free','','public',0,0,0,0,1,'','published',28,9,0,110,0,0,'public',0.00,'free','','','',0,NULL,'','',0,0,NULL,1,0,'','','approved',NULL,'',NULL,NULL,0,0,NULL,0,'',0,'text',NULL,NULL,NULL,0,500,0,0,0,0.00,'','',0,0,0,'',NULL,0,0,0,NULL,'','',0.00,NULL,'2026-06-27 22:39:49','2026-07-10 22:39:49'),
(10,10,3,'','','面试经历分享','<p>最近面了几家大厂，分享一些经验和教训</p>','','[]','[]','[]',0,'','',0,'free','','public',0,1,0,0,0,'','published',70,22,0,280,0,0,'public',0.00,'free','','','',0,NULL,'','',0,0,NULL,1,0,'','','approved',NULL,'',NULL,NULL,0,0,NULL,0,'',0,'text',NULL,NULL,NULL,0,500,0,0,0,0.00,'','',0,0,0,'',NULL,0,0,0,NULL,'','',0.00,NULL,'2026-06-19 22:39:49','2026-07-10 22:39:49'),
(11,11,9,'','','独立游戏开发日记','<p>记录我的第一款独立游戏的开发过程</p>','','[]','[]','[]',0,'','',0,'free','','public',0,0,0,0,1,'','published',20,6,0,75,0,0,'public',0.00,'free','','','',0,NULL,'','',0,0,NULL,1,0,'','','approved',NULL,'',NULL,NULL,0,0,NULL,0,'',0,'text',NULL,NULL,NULL,0,500,0,0,0,0.00,'','',0,0,0,'',NULL,0,0,0,NULL,'','',0.00,NULL,'2026-06-27 22:39:49','2026-07-10 22:39:49'),
(12,12,7,'','','开源项目推荐合集','<p>整理了一些高质量的2026年值得关注的开源项目</p>','','[]','[]','[]',0,'','',0,'free','','public',1,1,1,0,1,'#','deleted',110,38,1,412,3,0,'public',0.00,'free','','','',0,NULL,'','',0,0,NULL,1,0,'','','approved',NULL,'',NULL,NULL,0,0,NULL,0,'',0,'text',NULL,NULL,NULL,0,500,0,0,0,0.00,'','',0,0,0,'',NULL,0,0,0,NULL,'','',0.00,NULL,'2026-06-27 22:39:49','2026-07-11 11:39:29');
/*!40000 ALTER TABLE `community_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_reports`
--

DROP TABLE IF EXISTS `community_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reporter_id` int(11) NOT NULL,
  `reporter_name` varchar(100) DEFAULT '',
  `target_type` varchar(20) NOT NULL,
  `target_id` int(11) NOT NULL,
  `report_reason` varchar(100) DEFAULT '其他',
  `report_detail` text DEFAULT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_reports`
--

LOCK TABLES `community_reports` WRITE;
/*!40000 ALTER TABLE `community_reports` DISABLE KEYS */;
INSERT INTO `community_reports` VALUES
(1,7,'用户8','post',5,'垃圾广告',NULL,'ignored','2026-06-28 22:39:49'),
(2,9,'用户15','post',5,'违规内容',NULL,'resolved','2026-07-01 22:39:49'),
(3,14,'用户8','post',2,'人身攻击',NULL,'ignored','2026-07-10 22:39:49'),
(4,3,'用户14','post',6,'版权侵权',NULL,'ignored','2026-06-27 22:39:49'),
(5,5,'用户15','post',3,'垃圾广告',NULL,'resolved','2026-06-28 22:39:49'),
(6,4,'用户15','post',5,'违规内容',NULL,'ignored','2026-07-07 22:39:49'),
(7,9,'用户6','post',12,'人身攻击',NULL,'ignored','2026-07-04 22:39:49'),
(8,2,'用户13','post',7,'版权侵权',NULL,'resolved','2026-07-04 22:39:49'),
(9,19,'alexmorgan','comment',2,'垃圾广告','评论','ignored','2026-07-11 11:36:59'),
(10,19,'alexmorgan','app_comment',13,'6','','pending','2026-07-11 11:51:00');
/*!40000 ALTER TABLE `community_reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_sections`
--

DROP TABLE IF EXISTS `community_sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `icon` varchar(500) DEFAULT '',
  `icon_bg_color` varchar(20) DEFAULT '#00BFA5',
  `description` text DEFAULT '',
  `today_heat` int(11) DEFAULT 0,
  `total_heat` int(11) DEFAULT 0,
  `post_count` int(11) DEFAULT 0,
  `view_count` int(11) DEFAULT 0,
  `sort_order` int(11) DEFAULT 0,
  `status` varchar(20) DEFAULT 'active',
  `visibility` varchar(20) DEFAULT 'public',
  `post_permission` varchar(20) DEFAULT 'all',
  `view_permission` varchar(20) DEFAULT 'all',
  `view_level_required` int(11) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_sections`
--

LOCK TABLES `community_sections` WRITE;
/*!40000 ALTER TABLE `community_sections` DISABLE KEYS */;
INSERT INTO `community_sections` VALUES
(1,'综合讨论','','#00BFA5','综合讨论版块',0,0,0,0,1,'active','public','all','all',0,'2026-07-10 22:39:49'),
(2,'技术交流','','#00BFA5','技术交流版块',0,0,0,0,2,'active','public','all','all',0,'2026-07-10 22:39:49'),
(3,'设计创作','','#00BFA5','设计创作版块',0,0,0,0,3,'active','public','all','all',0,'2026-07-10 22:39:49'),
(4,'资源分享','','#00BFA5','资源分享版块',0,0,0,0,4,'active','public','all','all',0,'2026-07-10 22:39:49'),
(5,'反馈建议','','#00BFA5','反馈建议版块',0,0,0,0,5,'active','public','all','all',0,'2026-07-10 22:39:49');
/*!40000 ALTER TABLE `community_sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_topics`
--

DROP TABLE IF EXISTS `community_topics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_topics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `icon` varchar(500) DEFAULT '',
  `description` text DEFAULT '',
  `creator_id` int(11) DEFAULT 0,
  `creator_name` varchar(100) DEFAULT '',
  `sort_order` int(11) DEFAULT 0,
  `post_count` int(11) DEFAULT 0,
  `view_count` int(11) DEFAULT 0,
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_topics`
--

LOCK TABLES `community_topics` WRITE;
/*!40000 ALTER TABLE `community_topics` DISABLE KEYS */;
INSERT INTO `community_topics` VALUES
(1,'AI绘画','','AI绘画相关话题讨论区',0,'',0,0,0,'1','2026-07-10 22:39:49'),
(2,'前端开发','','前端开发相关话题讨论区',0,'',0,0,0,'1','2026-07-10 22:39:49'),
(3,'设计灵感','','设计灵感相关话题讨论区',0,'',0,0,0,'1','2026-07-10 22:39:49'),
(4,'独立开发','','独立开发相关话题讨论区',0,'',0,0,0,'1','2026-07-10 22:39:49'),
(5,'UI/UX','','UI/UX相关话题讨论区',0,'',0,0,0,'1','2026-07-10 22:39:49'),
(6,'科技资讯','','科技资讯相关话题讨论区',0,'',0,0,0,'1','2026-07-10 22:39:49'),
(7,'摄影分享','','摄影分享相关话题讨论区',0,'',0,0,0,'1','2026-07-10 22:39:49'),
(8,'生活记录','','生活记录相关话题讨论区',0,'',0,0,0,'1','2026-07-10 22:39:49'),
(9,'test_bob_1783772379','','',1,'bobwang',0,0,0,'1','2026-07-11 20:19:39'),
(10,'test_tech_1783772379','','',3,'tech_guru',0,0,0,'1','2026-07-11 20:19:39');
/*!40000 ALTER TABLE `community_topics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_unlock_requests`
--

DROP TABLE IF EXISTS `community_unlock_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_unlock_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `reason` text DEFAULT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `admin_reply` varchar(500) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_unlock_requests`
--

LOCK TABLES `community_unlock_requests` WRITE;
/*!40000 ALTER TABLE `community_unlock_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `community_unlock_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `content_access_passwords`
--

DROP TABLE IF EXISTS `content_access_passwords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `content_access_passwords` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content_type` varchar(20) DEFAULT 'post',
  `content_id` int(11) NOT NULL,
  `password` varchar(100) NOT NULL,
  `tips` varchar(200) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_content_access_passwords_content` (`content_type`,`content_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `content_access_passwords`
--

LOCK TABLES `content_access_passwords` WRITE;
/*!40000 ALTER TABLE `content_access_passwords` DISABLE KEYS */;
/*!40000 ALTER TABLE `content_access_passwords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `content_purchases`
--

DROP TABLE IF EXISTS `content_purchases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `content_purchases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `content_type` varchar(20) DEFAULT 'post',
  `content_id` int(11) NOT NULL,
  `author_id` int(11) DEFAULT 0,
  `amount` decimal(10,2) DEFAULT 0.00,
  `pay_type` varchar(20) DEFAULT 'balance',
  `commission_amount` decimal(10,2) DEFAULT 0.00,
  `commission_rate` decimal(5,2) DEFAULT 0.00,
  `block_index` int(11) DEFAULT -1,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_content_purchases_user` (`user_id`),
  KEY `idx_content_purchases_content` (`content_type`,`content_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `content_purchases`
--

LOCK TABLES `content_purchases` WRITE;
/*!40000 ALTER TABLE `content_purchases` DISABLE KEYS */;
INSERT INTO `content_purchases` VALUES
(1,14,'app',2,0,17.20,'balance',0.00,0.00,-1,'2026-07-03 22:39:54'),
(2,5,'app',2,0,20.34,'balance',0.00,0.00,-1,'2026-06-26 22:39:54'),
(3,5,'app',10,0,15.60,'balance',0.00,0.00,-1,'2026-06-16 22:39:54'),
(4,8,'app',6,0,20.23,'balance',0.00,0.00,-1,'2026-06-16 22:39:54'),
(5,9,'app',2,0,15.88,'balance',0.00,0.00,-1,'2026-06-16 22:39:54'),
(6,10,'app',2,0,50.01,'balance',0.00,0.00,-1,'2026-06-25 22:39:54'),
(7,13,'app',8,0,36.22,'balance',0.00,0.00,-1,'2026-06-26 22:39:54'),
(8,13,'app',9,0,11.34,'balance',0.00,0.00,-1,'2026-06-25 22:39:54');
/*!40000 ALTER TABLE `content_purchases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coupon_usage_logs`
--

DROP TABLE IF EXISTS `coupon_usage_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `coupon_usage_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_coupon_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `coupon_id` int(11) NOT NULL,
  `coupon_name` varchar(200) DEFAULT '',
  `use_scene` varchar(50) DEFAULT '',
  `use_amount` decimal(10,2) DEFAULT 0.00,
  `before_remaining` decimal(10,2) DEFAULT NULL,
  `after_remaining` decimal(10,2) DEFAULT NULL,
  `order_desc` varchar(500) DEFAULT '',
  `use_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coupon_usage_logs`
--

LOCK TABLES `coupon_usage_logs` WRITE;
/*!40000 ALTER TABLE `coupon_usage_logs` DISABLE KEYS */;
INSERT INTO `coupon_usage_logs` VALUES
(1,38,19,'alexmorgan',1,'新人专享券','membership_buy',5.00,NULL,NULL,'购买 1个月 原价¥15.00 余额减¥5.00','2026-07-12 08:11:10');
/*!40000 ALTER TABLE `coupon_usage_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coupons`
--

DROP TABLE IF EXISTS `coupons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `coupons` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `description` text DEFAULT '',
  `type` varchar(20) NOT NULL DEFAULT 'fixed',
  `value` decimal(10,2) NOT NULL DEFAULT 0.00,
  `min_order` decimal(10,2) NOT NULL DEFAULT 0.00,
  `max_discount` decimal(10,2) DEFAULT 0.00,
  `scope` varchar(20) NOT NULL DEFAULT 'all',
  `target_ids` text DEFAULT '',
  `target_names` text DEFAULT '',
  `total_count` int(11) DEFAULT 0,
  `claimed_count` int(11) NOT NULL DEFAULT 0,
  `per_user_limit` int(11) NOT NULL DEFAULT 1,
  `start_time` datetime DEFAULT NULL,
  `expire_time` datetime DEFAULT NULL,
  `valid_days` int(11) DEFAULT 0,
  `category` varchar(20) DEFAULT 'general',
  `is_recommend` tinyint(1) DEFAULT 0,
  `is_new_user` tinyint(1) DEFAULT 0,
  `is_rush` tinyint(1) DEFAULT 0,
  `required_level_ids` text DEFAULT '',
  `required_level_names` text DEFAULT '',
  `is_multi_use` tinyint(1) DEFAULT 0,
  `sort_order` int(11) DEFAULT 0,
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_coupons_status` (`status`),
  KEY `idx_coupons_scope` (`scope`),
  KEY `idx_coupons_category` (`category`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coupons`
--

LOCK TABLES `coupons` WRITE;
/*!40000 ALTER TABLE `coupons` DISABLE KEYS */;
INSERT INTO `coupons` VALUES
(1,'新人专享券','','fixed',5.00,10.00,100.00,'all','','',100,22,1,NULL,NULL,0,'general',0,0,0,'','',0,0,'1','2026-07-10 22:39:53'),
(2,'满减优惠券','','fixed',10.00,50.00,200.00,'all','','',100,21,1,NULL,NULL,0,'general',0,0,0,'','',0,0,'1','2026-07-10 22:39:53'),
(3,'VIP折扣券','','percentage',15.00,0.00,0.00,'all','','',100,8,1,NULL,NULL,0,'general',0,0,0,'','',0,0,'1','2026-07-10 22:39:53'),
(4,'节日特惠券','','fixed',20.00,30.00,500.00,'all','','',100,29,1,NULL,NULL,0,'general',0,0,0,'','',0,0,'1','2026-07-10 22:39:53'),
(5,'限时体验券','','percentage',8.00,0.00,0.00,'all','','',100,23,1,NULL,NULL,0,'general',0,0,0,'','',0,0,'1','2026-07-10 22:39:53'),
(6,'黄金会员','','percent',10.00,1.00,10.00,'all','','',99,1,1,'2026-07-12 04:42:00','2030-07-12 04:42:00',30,'general',0,0,0,'2','',0,5,'1','2026-07-11 20:42:43');
/*!40000 ALTER TABLE `coupons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_tasks`
--

DROP TABLE IF EXISTS `custom_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `custom_tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `description` text DEFAULT '',
  `icon` varchar(500) DEFAULT '',
  `task_type` varchar(30) NOT NULL DEFAULT 'daily',
  `action_type` varchar(30) NOT NULL DEFAULT 'post',
  `target_count` int(11) DEFAULT 1,
  `section_id` int(11) DEFAULT 0,
  `section_limit` int(11) DEFAULT 0,
  `points_reward` int(11) DEFAULT 0,
  `exp_reward` int(11) DEFAULT 0,
  `balance_reward` decimal(10,2) DEFAULT 0.00,
  `card_key_type` varchar(20) DEFAULT '',
  `card_key_value` int(11) DEFAULT 0,
  `card_key_duration` int(11) DEFAULT 0,
  `title_id` int(11) DEFAULT 0,
  `status` varchar(2) DEFAULT '1',
  `sort_order` int(11) DEFAULT 0,
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_tasks`
--

LOCK TABLES `custom_tasks` WRITE;
/*!40000 ALTER TABLE `custom_tasks` DISABLE KEYS */;
INSERT INTO `custom_tasks` VALUES
(1,'每日签到','','','daily','post',1,0,0,10,0,0.00,'',0,0,0,'1',0,NULL,NULL,'2026-07-10 22:39:53'),
(2,'发帖奖励','','','post','post',1,0,0,20,0,0.00,'',0,0,0,'1',0,NULL,NULL,'2026-07-10 22:39:53'),
(3,'评论互动','','','comment','post',1,0,0,5,0,0.00,'',0,0,0,'1',0,NULL,NULL,'2026-07-10 22:39:53'),
(4,'邀请好友','','','invite','post',1,0,0,50,0,0.00,'',0,0,0,'1',0,NULL,NULL,'2026-07-10 22:39:54'),
(5,'完善资料','','','profile','post',1,0,0,30,0,0.00,'',0,0,0,'0',0,NULL,NULL,'2026-07-10 22:39:54');
/*!40000 ALTER TABLE `custom_tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_titles`
--

DROP TABLE IF EXISTS `custom_titles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `custom_titles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `icon` varchar(500) DEFAULT '',
  `color` varchar(20) DEFAULT '#409EFF',
  `bg_color` varchar(20) DEFAULT '#ecf5ff',
  `description` varchar(500) DEFAULT '',
  `condition_type` varchar(20) DEFAULT 'manual',
  `condition_value` varchar(200) DEFAULT '',
  `sort_order` int(11) DEFAULT 0,
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_titles`
--

LOCK TABLES `custom_titles` WRITE;
/*!40000 ALTER TABLE `custom_titles` DISABLE KEYS */;
INSERT INTO `custom_titles` VALUES
(1,'设计达人','ri:palette-line','#FF4757','#ecf5ff','','manual','',0,'1','2026-07-10 22:39:54'),
(2,'技术大牛','ri:code-box-line','#0984E3','#ecf5ff','','manual','',0,'1','2026-07-10 22:39:54'),
(3,'社区之星','ri:star-line','#FDCB6E','#ecf5ff','','manual','',0,'1','2026-07-10 22:39:54'),
(4,'创作先锋','ri:quill-pen-line','#00B894','#ecf5ff','','manual','',0,'1','2026-07-10 22:39:54'),
(5,'活跃分子','ri:flashlight-line','#6C5CE7','#ecf5ff','','manual','',0,'1','2026-07-10 22:39:54'),
(6,'分享达人','ri:share-line','#E17055','#ecf5ff','','manual','',0,'1','2026-07-10 22:39:54'),
(7,'至尊会员','','#FFD700','#FFF8E1','会员专属称号','manual','',0,'1','2026-07-11 21:07:13'),
(8,'铂金达人','','#E5E4E2','#F5F5F5','高级会员称号','manual','',0,'1','2026-07-11 21:07:13'),
(9,'钻石王者','','#00CED1','#E0FFFF','顶级会员称号','manual','',0,'1','2026-07-11 21:07:13');
/*!40000 ALTER TABLE `custom_titles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_config`
--

DROP TABLE IF EXISTS `email_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `host` varchar(200) NOT NULL DEFAULT '',
  `port` int(11) NOT NULL DEFAULT 465,
  `secure` tinyint(1) DEFAULT 1,
  `user` varchar(200) NOT NULL DEFAULT '',
  `password` varchar(200) NOT NULL DEFAULT '',
  `from_name` varchar(100) DEFAULT '',
  `from_address` varchar(200) DEFAULT '',
  `test_address` varchar(200) DEFAULT '',
  `register_verify` tinyint(1) DEFAULT 0,
  `enabled` tinyint(1) DEFAULT 1,
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_config`
--

LOCK TABLES `email_config` WRITE;
/*!40000 ALTER TABLE `email_config` DISABLE KEYS */;
INSERT INTO `email_config` VALUES
(1,'smtp.qq.com',465,1,'3020451981@qq.com','leqrhfulklqtdhdc','ArtDesignPro','3020451981@qq.com','844991059@qq.com',0,1,'2026-07-11 16:04:44');
/*!40000 ALTER TABLE `email_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_push_config`
--

DROP TABLE IF EXISTS `email_push_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_push_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(50) DEFAULT '',
  `name` varchar(100) DEFAULT '',
  `subject` varchar(200) DEFAULT '',
  `template` text DEFAULT NULL,
  `enabled` tinyint(1) DEFAULT 0,
  `user_group` varchar(20) DEFAULT 'all',
  `level_ids` text DEFAULT NULL,
  `sort_order` int(11) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  `description` varchar(500) DEFAULT '',
  `target` varchar(100) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_push_config`
--

LOCK TABLES `email_push_config` WRITE;
/*!40000 ALTER TABLE `email_push_config` DISABLE KEYS */;
INSERT INTO `email_push_config` VALUES
(1,'user_register','用户注册','',NULL,1,'all',NULL,0,'2026-07-10 22:39:54','2026-07-10 22:39:54','',''),
(2,'order_create','订单创建','',NULL,1,'all',NULL,0,'2026-07-10 22:39:54','2026-07-10 22:39:54','','');
/*!40000 ALTER TABLE `email_push_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_templates`
--

DROP TABLE IF EXISTS `email_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT '',
  `code` varchar(50) DEFAULT '',
  `subject` varchar(200) DEFAULT '',
  `html_content` text DEFAULT NULL,
  `description` varchar(500) DEFAULT '',
  `sort_order` int(11) DEFAULT 0,
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_templates`
--

LOCK TABLES `email_templates` WRITE;
/*!40000 ALTER TABLE `email_templates` DISABLE KEYS */;
INSERT INTO `email_templates` VALUES
(1,'注册验证','','注册验证邮件','<p>注册验证邮件模板内容</p>','',0,'1','2026-07-10 22:39:54','2026-07-10 22:39:54'),
(2,'密码重置','','密码重置邮件','<p>密码重置邮件模板内容</p>','',0,'1','2026-07-10 22:39:54','2026-07-10 22:39:54'),
(3,'订单通知','','订单通知邮件','<p>订单通知邮件模板内容</p>','',0,'1','2026-07-10 22:39:54','2026-07-10 22:39:54'),
(4,'活动推送','','活动推送邮件','<p>活动推送邮件模板内容</p>','',0,'1','2026-07-10 22:39:54','2026-07-10 22:39:54');
/*!40000 ALTER TABLE `email_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_verifications`
--

DROP TABLE IF EXISTS `email_verifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_verifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(200) NOT NULL,
  `code` varchar(10) NOT NULL,
  `type` varchar(20) DEFAULT 'register',
  `used` tinyint(1) DEFAULT 0,
  `expires_at` datetime NOT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_email_verifications_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_verifications`
--

LOCK TABLES `email_verifications` WRITE;
/*!40000 ALTER TABLE `email_verifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_verifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `experience_levels`
--

DROP TABLE IF EXISTS `experience_levels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `experience_levels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `level` int(11) NOT NULL DEFAULT 0,
  `exp_required` int(11) NOT NULL DEFAULT 0,
  `icon` varchar(100) DEFAULT '',
  `icon_color` varchar(20) DEFAULT '#00BFA5',
  `text_color` varchar(20) DEFAULT '#FFFFFF',
  `bg_color` varchar(20) DEFAULT '#508DFF',
  `benefits` text DEFAULT NULL,
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `experience_levels`
--

LOCK TABLES `experience_levels` WRITE;
/*!40000 ALTER TABLE `experience_levels` DISABLE KEYS */;
INSERT INTO `experience_levels` VALUES
(1,'Lv.1',1,0,'ri:star-line','#00BFA5','#FFFFFF','#508DFF','基础等级','1','2026-07-10 22:42:45'),
(2,'Lv.2',2,100,'ri:star-line','#42A5F5','#FFFFFF','#508DFF','解锁评论功能','1','2026-07-10 22:42:45'),
(3,'Lv.3',3,500,'ri:star-half-line','#7C4DFF','#FFFFFF','#508DFF','解锁发帖功能','1','2026-07-10 22:42:45'),
(4,'Lv.4',4,1000,'ri:star-half-fill','#FFB74D','#FFFFFF','#508DFF','解锁自定义头像','1','2026-07-10 22:42:45'),
(5,'Lv.5',5,2000,'ri:star-fill','#FF6B6B','#FFFFFF','#508DFF','解锁高级搜索','1','2026-07-10 22:42:45'),
(6,'Lv.6',6,5000,'ri:vip-crown-line','#FFD700','#FFFFFF','#508DFF','专属标识,优先客服','1','2026-07-10 22:42:45'),
(7,'Lv.7',7,10000,'ri:vip-crown-fill','#FF4081','#FFFFFF','#508DFF','全部权益,年度礼品','1','2026-07-10 22:42:45');
/*!40000 ALTER TABLE `experience_levels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `experience_records`
--

DROP TABLE IF EXISTS `experience_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `experience_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `amount` int(11) NOT NULL DEFAULT 0,
  `source` varchar(100) DEFAULT '',
  `description` varchar(500) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_experience_records_user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `experience_records`
--

LOCK TABLES `experience_records` WRITE;
/*!40000 ALTER TABLE `experience_records` DISABLE KEYS */;
INSERT INTO `experience_records` VALUES
(1,7,'',70,'daily','经验值增加','2026-06-16 22:39:54'),
(2,12,'',14,'post','经验值增加','2026-07-03 22:39:54'),
(3,12,'',37,'comment','经验值增加','2026-07-06 22:39:54'),
(4,10,'',10,'checkin','经验值增加','2026-06-12 22:39:54'),
(5,3,'',100,'daily','经验值增加','2026-06-11 22:39:54'),
(6,9,'',107,'post','经验值增加','2026-06-16 22:39:54'),
(7,4,'',40,'comment','经验值增加','2026-07-05 22:39:54'),
(8,10,'',73,'checkin','经验值增加','2026-06-12 22:39:54'),
(9,7,'',94,'daily','经验值增加','2026-06-19 22:39:54'),
(10,8,'',19,'post','经验值增加','2026-07-02 22:39:54'),
(11,14,'',107,'comment','经验值增加','2026-06-18 22:39:54'),
(12,12,'',43,'checkin','经验值增加','2026-06-22 22:39:54'),
(13,2,'',74,'daily','经验值增加','2026-07-08 22:39:54'),
(14,4,'',87,'post','经验值增加','2026-07-08 22:39:54'),
(15,12,'',51,'comment','经验值增加','2026-06-30 22:39:54'),
(16,5,'',52,'checkin','经验值增加','2026-06-26 22:39:54'),
(17,6,'',97,'daily','经验值增加','2026-07-10 22:39:54'),
(18,4,'',96,'post','经验值增加','2026-06-15 22:39:54'),
(19,3,'',99,'comment','经验值增加','2026-07-07 22:39:54'),
(20,5,'',31,'checkin','经验值增加','2026-07-10 22:39:54'),
(21,19,'alexmorgan',2000,'卡密兑换','使用卡密 CDKEY-MRG47L1VS1EE 额外获得2000经验值','2026-07-11 08:41:23');
/*!40000 ALTER TABLE `experience_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file_policies`
--

DROP TABLE IF EXISTS `file_policies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `file_policies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT '',
  `user_level_id` int(11) DEFAULT 0,
  `user_level_name` varchar(100) DEFAULT '',
  `role_code` varchar(100) DEFAULT '',
  `user_id` int(11) DEFAULT 0,
  `max_file_size_mb` int(11) DEFAULT 10,
  `allowed_types` text DEFAULT '',
  `banned_types` text DEFAULT '',
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file_policies`
--

LOCK TABLES `file_policies` WRITE;
/*!40000 ALTER TABLE `file_policies` DISABLE KEYS */;
INSERT INTO `file_policies` VALUES
(1,'默认策略',0,'','',0,10,'jpg,png,gif,pdf,zip,apk,APK','','1','2026-07-10 22:39:54'),
(2,'图片策略',0,'','',0,5,'jpg,png,gif,webp','','1','2026-07-10 22:39:54'),
(3,'会员用户其他',0,'','*',0,35,'jpg,png,gif,pdf,zip,apk,APK','','1','2026-07-12 00:50:07');
/*!40000 ALTER TABLE `file_policies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file_repository`
--

DROP TABLE IF EXISTS `file_repository`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `file_repository` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT 0,
  `user_name` varchar(100) DEFAULT '',
  `file_name` varchar(500) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_size` bigint(20) DEFAULT 0,
  `file_type` varchar(100) DEFAULT '',
  `mime_type` varchar(200) DEFAULT '',
  `category` varchar(50) DEFAULT 'other',
  `ref_id` int(11) DEFAULT 0,
  `ref_type` varchar(50) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_file_repository_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file_repository`
--

LOCK TABLES `file_repository` WRITE;
/*!40000 ALTER TABLE `file_repository` DISABLE KEYS */;
INSERT INTO `file_repository` VALUES
(1,9,'','avatar1.png','uploads/avatar1.png',102400,'avatar','image/png','other',0,'','2026-07-10 22:39:53'),
(2,6,'','design.psd','uploads/design.psd',2048000,'design','application/psd','other',0,'','2026-07-10 22:39:53'),
(3,13,'','report.pdf','uploads/report.pdf',512000,'document','application/pdf','other',0,'','2026-07-10 22:39:53'),
(4,12,'','video.mp4','uploads/video.mp4',10485760,'video','video/mp4','other',0,'','2026-07-10 22:39:53'),
(5,9,'','config.json','uploads/config.json',2048,'data','application/json','other',0,'','2026-07-10 22:39:53'),
(6,3,'','image1.jpg','uploads/image1.jpg',307200,'image','image/jpeg','other',0,'','2026-07-10 22:39:53'),
(7,13,'','icon.svg','uploads/icon.svg',8192,'icon','image/svg+xml','other',0,'','2026-07-10 22:39:53'),
(11,0,'','ç¾åå¼æ_13.7.07.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783816158227-389590747.apk',20441606,'.apk','application/vnd.android.package-archive','apk',0,'','2026-07-12 00:30:00'),
(12,0,'','ç¾åå¼æ_13.7.07.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783816251341-825401419.apk',20441606,'.apk','application/vnd.android.package-archive','apk',0,'','2026-07-12 00:31:33'),
(13,0,'','Native Test ++_Mean Minotaur.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783816652499-733720586.apk',1017527,'.apk','application/vnd.android.package-archive','apk',0,'','2026-07-12 00:37:33'),
(14,0,'','Native Test ++_Mean Minotaur.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783816659877-185207292.apk',1017527,'.apk','application/vnd.android.package-archive','apk',0,'','2026-07-12 00:37:40'),
(15,0,'','Native Test ++_Mean Minotaur.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783816771159-579246254.apk',1017527,'.apk','application/vnd.android.package-archive','apk',0,'','2026-07-12 00:39:32'),
(16,0,'','MTç®¡çå¨_2.26.6.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783816711324-481531705.apk',31414066,'.apk','application/vnd.android.package-archive','apk',0,'','2026-07-12 00:39:37'),
(17,0,'','Native Test ++_Mean Minotaur.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783816784424-968471270.apk',1017527,'.apk','application/vnd.android.package-archive','apk',0,'','2026-07-12 00:39:45'),
(18,0,'','ç¾åå¼æ_13.7.07.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783816799301-792055094.apk',20441606,'.apk','application/vnd.android.package-archive','apk',0,'','2026-07-12 00:40:41'),
(19,0,'','Native Test ++_Mean Minotaur.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783816970054-799912081.apk',1017527,'.apk','application/vnd.android.package-archive','apk',0,'','2026-07-12 00:42:51'),
(20,0,'','Native Test ++_Mean Minotaur.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783816976685-749847013.apk',1017527,'.apk','application/vnd.android.package-archive','apk',0,'','2026-07-12 00:42:57'),
(21,0,'','Native Test ++_Mean Minotaur.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783816985168-866030178.apk',1017527,'.apk','application/vnd.android.package-archive','apk',0,'','2026-07-12 00:43:06'),
(22,0,'','ç¾åå¼æ_13.7.07.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783817033491-439544914.apk',20441606,'.apk','application/vnd.android.package-archive','apk',0,'','2026-07-12 00:44:35'),
(23,0,'','ç¾åå¼æ_13.7.07.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783817269817-937137091.apk',20441606,'.apk','application/vnd.android.package-archive','apk',0,'','2026-07-12 00:48:32'),
(24,0,'','Native Test ++_Mean Minotaur.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783817314376-129449829.apk',1017527,'.apk','application/vnd.android.package-archive','apk',0,'','2026-07-12 00:48:35'),
(25,0,'','Native Test ++_Mean Minotaur.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783817319693-373748131.apk',1017527,'.apk','application/vnd.android.package-archive','apk',0,'','2026-07-12 00:48:40'),
(26,0,'','Native Test ++_Mean Minotaur.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783817326869-670938906.apk',1017527,'.apk','application/vnd.android.package-archive','apk',0,'','2026-07-12 00:48:48'),
(28,0,'','ç¾åå¼æ_13.7.07.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783817455681-789179466.apk',20441606,'.apk','application/vnd.android.package-archive','apk',0,'','2026-07-12 00:51:38'),
(29,0,'','Native Test ++_Mean Minotaur.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783817623730-286001040.apk',1017527,'.apk','application/vnd.android.package-archive','apk',0,'','2026-07-12 00:53:45'),
(30,0,'','ç¾åå¼æ_13.7.07.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783817660872-274220246.apk',20441606,'.apk','application/vnd.android.package-archive','apk',0,'','2026-07-12 00:55:03'),
(31,0,'','ç¾åå¼æ_13.7.07.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783817740986-155422684.apk',20441606,'.apk','application/vnd.android.package-archive','apk',0,'','2026-07-12 00:56:23'),
(32,0,'','Native Test ++_Mean Minotaur.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783818420129-251029883.apk',1017527,'.apk','application/vnd.android.package-archive','apk',0,'','2026-07-12 01:07:01'),
(34,0,'','Native Test ++_Mean Minotaur.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783818537796-569073154.apk',1017527,'.apk','application/vnd.android.package-archive','apk',0,'','2026-07-12 01:08:59'),
(35,0,'','Native Test ++_Mean Minotaur.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783818543195-841509947.apk',1017527,'.apk','application/vnd.android.package-archive','apk',0,'','2026-07-12 01:09:04'),
(36,0,'','Native Test ++_Mean Minotaur.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783818558713-835884504.apk',1017527,'.apk','application/vnd.android.package-archive','apk',0,'','2026-07-12 01:09:20'),
(37,0,'','Native Test ++_Mean Minotaur.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783818705199-567193380.apk',1017527,'.apk','application/vnd.android.package-archive','apk',0,'','2026-07-12 01:11:46'),
(39,0,'','ç¾åå¼æ_13.7.07.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783818935431-807162032.apk',20441606,'.apk','application/vnd.android.package-archive','apk',0,'','2026-07-12 01:16:18'),
(42,0,'','å¾å½¢å¢å¼ºæå¡_16.1.24.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783820609464-226654906.apk',8632,'.apk','application/vnd.android.package-archive','apk',0,'','2026-07-12 01:43:30'),
(43,0,'','å¾å½¢å¢å¼ºæå¡_16.1.24.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783820663960-40996847.apk',8632,'.apk','application/vnd.android.package-archive','apk',0,'','2026-07-12 01:44:24'),
(44,0,'','ç¾åå¼æ_13.7.07.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783821050883-644610594.apk',20441606,'.apk','application/vnd.android.package-archive','apk',0,'','2026-07-12 01:51:33'),
(45,0,'','ç¾åå¼æ_13.7.07.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783821067093-396406745.apk',20441606,'.apk','application/vnd.android.package-archive','apk',0,'','2026-07-12 01:51:49'),
(46,0,'','ç¾åå¼æ_13.7.07.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783821246989-906727894.apk',20441606,'.apk','application/vnd.android.package-archive','apk',0,'','2026-07-12 01:54:49'),
(49,1,'','test_data.zip','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/1/zip/1783825047961-519417035.zip',4096,'.zip','application/octet-stream','general',0,'','2026-07-12 02:57:28'),
(51,2,'','test_data.zip','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/2/zip/1783825048216-30936901.zip',4096,'.zip','application/octet-stream','general',0,'','2026-07-12 02:57:28'),
(52,1,'','test_pic.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/1/img/1783825238553-78505961.png',2048,'.png','image/png','general',0,'','2026-07-12 03:00:38'),
(53,1,'','a.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/img/1783825451126-852761551.png',2048,'.png','image/png','general',0,'','2026-07-12 03:04:11'),
(54,1,'','u.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/1/img/1783825518358-740133764.png',2048,'.png','image/png','general',0,'','2026-07-12 03:05:18'),
(57,0,'','4503.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/0/img/1783826122044-556763102.jpg',168623,'.jpg','image/jpeg','avatar',0,'','2026-07-12 03:15:22'),
(58,0,'','4502.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/0/img/1783826123131-672728729.jpg',536774,'.jpg','image/jpeg','avatar',0,'','2026-07-12 03:15:23'),
(59,0,'','4498.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/0/img/1783826123510-169510965.jpg',112423,'.jpg','image/jpeg','avatar',0,'','2026-07-12 03:15:23'),
(60,0,'','4500.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/0/img/1783826124195-863883180.jpg',1008134,'.jpg','image/jpeg','avatar',0,'','2026-07-12 03:15:25'),
(61,0,'','u2.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/0/img/1783826182866-214372467.png',2048,'.png','image/png','avatar',0,'','2026-07-12 03:16:23'),
(62,1,'','u2.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/1/img/1783826183133-507876490.png',2048,'.png','image/png','avatar',0,'','2026-07-12 03:16:23');
/*!40000 ALTER TABLE `file_repository` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_configs`
--

DROP TABLE IF EXISTS `game_configs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_configs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `game_type` varchar(30) NOT NULL,
  `config_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`config_data`)),
  `enabled` tinyint(4) DEFAULT 1,
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `game_type` (`game_type`),
  KEY `idx_game_configs_type` (`game_type`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_configs`
--

LOCK TABLES `game_configs` WRITE;
/*!40000 ALTER TABLE `game_configs` DISABLE KEYS */;
INSERT INTO `game_configs` VALUES
(1,'card_guess','{\"costPerFlip\":10,\"pityCount\":10,\"winMultiplier\":2,\"cards\":[{\"name\":\"A\",\"label\":\"奖\",\"isWin\":true,\"probability\":30},{\"name\":\"B\",\"label\":\"空\",\"isWin\":false,\"probability\":35},{\"name\":\"C\",\"label\":\"空\",\"isWin\":false,\"probability\":35}],\"memberDiscounts\":[]}',1,'2026-07-11 09:42:54','2026-07-11 11:23:53'),
(2,'dice','{\"costPerBet\":10,\"maxNumber\":6,\"threshold\":4,\"winMultiplier\":2,\"memberDiscounts\":[]}',1,'2026-07-11 09:43:31','2026-07-11 11:23:53'),
(3,'rps','{\"costPerPlay\":10,\"winMultiplier\":2,\"drawRefund\":true,\"memberDiscounts\":[]}',1,'2026-07-11 09:43:43','2026-07-11 11:23:54'),
(4,'lottery','{\"costPerDraw\":10,\"costPerDraw10\":100,\"pityCount\":0,\"pityGridIndex\":0,\"grids\":[{\"index\":0,\"name\":\"\",\"type\":\"points\",\"value\":10,\"probability\":11},{\"index\":1,\"name\":\"\",\"type\":\"points\",\"value\":10,\"probability\":11},{\"index\":2,\"name\":\"\",\"type\":\"points\",\"value\":10,\"probability\":11},{\"index\":3,\"name\":\"\",\"type\":\"points\",\"value\":10,\"probability\":11},{\"index\":4,\"name\":\"\",\"type\":\"points\",\"value\":10,\"probability\":11},{\"index\":5,\"name\":\"\",\"type\":\"points\",\"value\":10,\"probability\":11},{\"index\":6,\"name\":\"\",\"type\":\"points\",\"value\":10,\"probability\":11},{\"index\":7,\"name\":\"\",\"type\":\"points\",\"value\":10,\"probability\":11},{\"index\":8,\"name\":\"\",\"type\":\"points\",\"value\":10,\"probability\":11}],\"memberDiscounts\":[]}',1,'2026-07-11 09:45:49','2026-07-11 11:23:53');
/*!40000 ALTER TABLE `game_configs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_records`
--

DROP TABLE IF EXISTS `game_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `game_type` varchar(30) NOT NULL,
  `result` varchar(20) NOT NULL,
  `points_spent` int(11) DEFAULT 0,
  `points_won` int(11) DEFAULT 0,
  `detail` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`detail`)),
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_game_records_user` (`user_id`),
  KEY `idx_game_records_type` (`game_type`),
  KEY `idx_game_records_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_records`
--

LOCK TABLES `game_records` WRITE;
/*!40000 ALTER TABLE `game_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hidden_conversations`
--

DROP TABLE IF EXISTS `hidden_conversations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `hidden_conversations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `partner_id` int(11) NOT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`partner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hidden_conversations`
--

LOCK TABLES `hidden_conversations` WRITE;
/*!40000 ALTER TABLE `hidden_conversations` DISABLE KEYS */;
/*!40000 ALTER TABLE `hidden_conversations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invite_codes`
--

DROP TABLE IF EXISTS `invite_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `invite_codes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL,
  `created_by` int(11) DEFAULT 0,
  `created_by_name` varchar(100) DEFAULT '',
  `used_by` int(11) DEFAULT 0,
  `used_by_name` varchar(100) DEFAULT '',
  `max_uses` int(11) DEFAULT 1,
  `use_count` int(11) DEFAULT 0,
  `status` varchar(2) DEFAULT '1',
  `used_at` datetime DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  `created_by_user_id` int(11) DEFAULT 0,
  `type` varchar(50) DEFAULT 'one_time',
  `reward_type` varchar(50) DEFAULT '',
  `reward_value` int(11) DEFAULT 0,
  `reward_duration` int(11) DEFAULT 0,
  `reward_duration_unit` varchar(10) DEFAULT 'day',
  `reward_target_id` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `idx_invite_codes_code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invite_codes`
--

LOCK TABLES `invite_codes` WRITE;
/*!40000 ALTER TABLE `invite_codes` DISABLE KEYS */;
INSERT INTO `invite_codes` VALUES
(1,'INV-3MYOYW',1,'',0,'',10,2,'1',NULL,NULL,'2026-07-10 22:39:54',0,'admin','',0,0,'day',0),
(2,'INV-TKFVLJ',1,'',0,'',10,0,'1',NULL,NULL,'2026-07-10 22:39:54',0,'admin','',0,0,'day',0),
(3,'INV-DZQ79K',1,'',0,'',10,2,'1',NULL,NULL,'2026-07-10 22:39:54',0,'admin','',0,0,'day',0),
(4,'INV-UAZKH9',1,'',0,'',10,1,'1',NULL,NULL,'2026-07-10 22:39:54',0,'admin','',0,0,'day',0),
(5,'INV-P3V7UN',1,'',0,'',10,2,'1',NULL,NULL,'2026-07-10 22:39:54',0,'admin','',0,0,'day',0),
(6,'INV-5LP1N0',1,'',0,'',10,4,'1',NULL,NULL,'2026-07-10 22:39:54',0,'admin','',0,0,'day',0),
(7,'INV-NL5F3Y',1,'',0,'',10,10,'0',NULL,NULL,'2026-07-10 22:39:54',0,'admin','',0,0,'day',0),
(8,'INV-GL49GY',1,'',0,'',10,10,'0',NULL,NULL,'2026-07-10 22:39:54',0,'admin','',0,0,'day',0),
(9,'INV-XBL1IK',1,'',0,'',10,10,'0',NULL,NULL,'2026-07-10 22:39:54',0,'admin','',0,0,'day',0),
(10,'INV-HZYLX9',1,'',0,'',10,10,'0',NULL,NULL,'2026-07-10 22:39:54',0,'admin','',0,0,'day',0);
/*!40000 ALTER TABLE `invite_codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_after_sales`
--

DROP TABLE IF EXISTS `mall_after_sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_after_sales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `order_item_id` int(11) DEFAULT 0,
  `user_id` int(11) NOT NULL,
  `type` varchar(20) DEFAULT 'refund',
  `reason` text DEFAULT '',
  `description` text DEFAULT '',
  `images` text DEFAULT '[]',
  `amount` double DEFAULT 0,
  `status` varchar(20) DEFAULT 'pending',
  `seller_reply` text DEFAULT '',
  `seller_reply_time` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_mall_after_sales_order` (`order_id`),
  KEY `idx_mall_after_sales_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_after_sales`
--

LOCK TABLES `mall_after_sales` WRITE;
/*!40000 ALTER TABLE `mall_after_sales` DISABLE KEYS */;
/*!40000 ALTER TABLE `mall_after_sales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_cart_items`
--

DROP TABLE IF EXISTS `mall_cart_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_cart_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `option_id` int(11) DEFAULT 0,
  `quantity` int(11) DEFAULT 1,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`product_id`,`option_id`),
  KEY `idx_mall_cart_items_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_cart_items`
--

LOCK TABLES `mall_cart_items` WRITE;
/*!40000 ALTER TABLE `mall_cart_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `mall_cart_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_categories`
--

DROP TABLE IF EXISTS `mall_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT 0,
  `name` varchar(100) NOT NULL,
  `icon` varchar(200) DEFAULT '',
  `sort_order` int(11) DEFAULT 0,
  `status` varchar(20) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_categories`
--

LOCK TABLES `mall_categories` WRITE;
/*!40000 ALTER TABLE `mall_categories` DISABLE KEYS */;
INSERT INTO `mall_categories` VALUES
(1,0,'education','',1,'1','2026-07-10 22:39:53'),
(2,0,'design','',2,'1','2026-07-10 22:39:53'),
(3,0,'dev','',3,'1','2026-07-10 22:39:53'),
(4,0,'service','',4,'1','2026-07-10 22:39:53');
/*!40000 ALTER TABLE `mall_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_order_items`
--

DROP TABLE IF EXISTS `mall_order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_order_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `option_id` int(11) DEFAULT 0,
  `product_name` varchar(200) DEFAULT '',
  `option_name` varchar(200) DEFAULT '',
  `price` double DEFAULT 0,
  `quantity` int(11) DEFAULT 1,
  `image` varchar(500) DEFAULT '',
  `virtual_content` text DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `idx_mall_order_items_order` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_order_items`
--

LOCK TABLES `mall_order_items` WRITE;
/*!40000 ALTER TABLE `mall_order_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `mall_order_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_order_logistics`
--

DROP TABLE IF EXISTS `mall_order_logistics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_order_logistics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `company` varchar(100) DEFAULT '',
  `tracking_no` varchar(100) DEFAULT '',
  `status` varchar(20) DEFAULT 'pending',
  `details` text DEFAULT '[]',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_mall_order_logistics_order` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_order_logistics`
--

LOCK TABLES `mall_order_logistics` WRITE;
/*!40000 ALTER TABLE `mall_order_logistics` DISABLE KEYS */;
/*!40000 ALTER TABLE `mall_order_logistics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_orders`
--

DROP TABLE IF EXISTS `mall_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_no` varchar(32) NOT NULL,
  `user_id` int(11) NOT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `total_amount` double DEFAULT 0,
  `discount_amount` double DEFAULT 0,
  `freight` double DEFAULT 0,
  `payment_method` varchar(20) DEFAULT '',
  `payment_time` datetime DEFAULT NULL,
  `receiver_name` varchar(100) DEFAULT '',
  `receiver_phone` varchar(20) DEFAULT '',
  `receiver_address` varchar(500) DEFAULT '',
  `logistics_company` varchar(100) DEFAULT '',
  `logistics_no` varchar(100) DEFAULT '',
  `user_custom_fields` text DEFAULT '{}',
  `remark` varchar(500) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_no` (`order_no`),
  KEY `idx_mall_orders_status` (`status`),
  KEY `idx_mall_orders_user` (`user_id`),
  KEY `idx_mall_orders_order_no` (`order_no`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_orders`
--

LOCK TABLES `mall_orders` WRITE;
/*!40000 ALTER TABLE `mall_orders` DISABLE KEYS */;
INSERT INTO `mall_orders` VALUES
(1,'MAL17837231930',2,'paid',417,0,0,'wechat',NULL,'','','','','','{}','','2026-06-17 22:39:53','2026-07-10 22:39:53'),
(2,'MAL17837231931',11,'paid',465,0,0,'alipay',NULL,'','','','','','{}','','2026-07-08 22:39:53','2026-07-10 22:39:53'),
(3,'MAL17837231932',10,'paid',169,0,0,'wechat',NULL,'','','','','','{}','','2026-06-21 22:39:53','2026-07-10 22:39:53'),
(4,'MAL17837231933',2,'shipped',141,0,0,'alipay',NULL,'','','','','','{}','','2026-07-09 22:39:53','2026-07-10 22:39:53'),
(5,'MAL17837231934',9,'completed',194,0,0,'wechat',NULL,'','','','','','{}','','2026-07-09 22:39:53','2026-07-10 22:39:53'),
(6,'MAL17837231935',6,'cancelled',110,0,0,'alipay',NULL,'','','','','','{}','','2026-07-10 22:39:53','2026-07-10 22:39:53'),
(7,'MAL17837231936',5,'paid',175,0,0,'wechat',NULL,'','','','','','{}','','2026-06-17 22:39:53','2026-07-10 22:39:53'),
(8,'MAL17837231937',2,'paid',429,0,0,'alipay',NULL,'','','','','','{}','','2026-06-14 22:39:53','2026-07-10 22:39:53'),
(9,'MAL17837231938',14,'paid',440,0,0,'wechat',NULL,'','','','','','{}','','2026-06-25 22:39:53','2026-07-10 22:39:53'),
(10,'MAL17837231939',11,'shipped',329,0,0,'alipay',NULL,'','','','','','{}','','2026-07-10 22:39:53','2026-07-10 22:39:53'),
(11,'MAL178372319310',13,'completed',333,0,0,'wechat',NULL,'','','','','','{}','','2026-07-07 22:39:53','2026-07-10 22:39:53'),
(12,'MAL178372319311',2,'cancelled',396,0,0,'alipay',NULL,'','','','','','{}','','2026-07-01 22:39:53','2026-07-10 22:39:53'),
(13,'MAL178372319312',15,'paid',23,0,0,'wechat',NULL,'','','','','','{}','','2026-06-13 22:39:53','2026-07-10 22:39:53'),
(14,'MAL178372319313',11,'paid',496,0,0,'alipay',NULL,'','','','','','{}','','2026-06-12 22:39:53','2026-07-10 22:39:53'),
(15,'MAL178372319314',7,'paid',375,0,0,'wechat',NULL,'','','','','','{}','','2026-06-28 22:39:53','2026-07-10 22:39:53');
/*!40000 ALTER TABLE `mall_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_product_images`
--

DROP TABLE IF EXISTS `mall_product_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_product_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `url` varchar(500) NOT NULL,
  `sort_order` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_mall_product_images_product` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_product_images`
--

LOCK TABLES `mall_product_images` WRITE;
/*!40000 ALTER TABLE `mall_product_images` DISABLE KEYS */;
/*!40000 ALTER TABLE `mall_product_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_product_options`
--

DROP TABLE IF EXISTS `mall_product_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_product_options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `spec_name` varchar(200) DEFAULT '',
  `price` double DEFAULT 0,
  `original_price` double DEFAULT 0,
  `points_price` double DEFAULT 0,
  `stock` int(11) DEFAULT 0,
  `image` varchar(500) DEFAULT '',
  `sort_order` int(11) DEFAULT 0,
  `card_config` text DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `idx_mall_product_options_product` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_product_options`
--

LOCK TABLES `mall_product_options` WRITE;
/*!40000 ALTER TABLE `mall_product_options` DISABLE KEYS */;
/*!40000 ALTER TABLE `mall_product_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_products`
--

DROP TABLE IF EXISTS `mall_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) DEFAULT 0,
  `name` varchar(200) NOT NULL,
  `subtitle` varchar(200) DEFAULT '',
  `description` text DEFAULT '',
  `cover_image` varchar(500) DEFAULT '',
  `cover_video` varchar(500) DEFAULT '',
  `price_type` varchar(20) DEFAULT 'balance',
  `price` double DEFAULT 0,
  `original_price` double DEFAULT 0,
  `stock` int(11) DEFAULT 0,
  `product_type` varchar(20) DEFAULT 'virtual_auto',
  `virtual_content` text DEFAULT '',
  `status` varchar(20) DEFAULT 'draft',
  `sales_count` int(11) DEFAULT 0,
  `is_recommended` int(11) DEFAULT 0,
  `sort_order` int(11) DEFAULT 0,
  `freight` double DEFAULT 0,
  `services` text DEFAULT '[]',
  `purchase_limit_config` text DEFAULT '[]',
  `commission_config` text DEFAULT '[]',
  `custom_fields` text DEFAULT '[]',
  `after_sales_config` text DEFAULT '{}',
  `tags` text DEFAULT '[]',
  `product_params` text DEFAULT '[]',
  `payment_methods` text DEFAULT '["balance"]',
  `sale_end_time` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  `created_by` int(11) DEFAULT 0,
  `created_by_name` varchar(100) DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `idx_mall_products_category` (`category_id`),
  KEY `idx_mall_products_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_products`
--

LOCK TABLES `mall_products` WRITE;
/*!40000 ALTER TABLE `mall_products` DISABLE KEYS */;
INSERT INTO `mall_products` VALUES
(1,1,'AI绘画大师课程','高级','','','','balance',199,299,0,'virtual_auto','','1',68,0,0,0,'[]','[]','[]','[]','{}','[\"热门\"]','[]','[\"balance\"]',NULL,'2026-07-10 22:39:53','2026-07-10 22:39:53',0,''),
(2,1,'Vue3实战视频教程','中级','','','','balance',79,99,0,'virtual_auto','','1',74,0,0,0,'[]','[]','[]','[]','{}','[\"推荐\"]','[]','[\"balance\"]',NULL,'2026-07-10 22:39:53','2026-07-10 22:39:53',0,''),
(3,2,'设计素材大礼包','基础','','','','balance',39,49,0,'virtual_auto','','1',50,0,0,0,'[]','[]','[]','[]','{}','[\"精品\"]','[]','[\"balance\"]',NULL,'2026-07-10 22:39:53','2026-07-10 22:39:53',0,''),
(4,4,'代码审查服务','高级','','','','balance',149,199,0,'virtual_auto','','1',30,0,0,0,'[]','[]','[]','[]','{}','[\"热门\"]','[]','[\"balance\"]',NULL,'2026-07-10 22:39:53','2026-07-10 22:39:53',0,''),
(5,2,'UI Kit Pro','中级','','','','balance',99,129,0,'virtual_auto','','1',87,0,0,0,'[]','[]','[]','[]','{}','[\"推荐\"]','[]','[\"balance\"]',NULL,'2026-07-10 22:39:53','2026-07-10 22:39:53',0,''),
(6,2,'图标合集 5000+','基础','','','','balance',19,29,0,'virtual_auto','','1',75,0,0,0,'[]','[]','[]','[]','{}','[\"新品\"]','[]','[\"balance\"]',NULL,'2026-07-10 22:39:53','2026-07-10 22:39:53',0,''),
(7,3,'API接口开放平台','高级','','','','balance',799,999,0,'virtual_auto','','1',42,0,0,0,'[]','[]','[]','[]','{}','[\"精品\"]','[]','[\"balance\"]',NULL,'2026-07-10 22:39:53','2026-07-10 22:39:53',0,''),
(8,3,'移动端组件库','中级','','','','balance',149,199,0,'virtual_auto','','published',54,0,0,0,'[]','[]','[]','[]','{\"enableRefund\":false,\"enableReturn\":false,\"enablePrice\":false,\"validDays\":7}','[\"推荐\"]','[]','[\"balance\"]',NULL,'2026-07-10 22:39:53','2026-07-11 16:41:46',0,'');
/*!40000 ALTER TABLE `mall_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_promotion_gifts`
--

DROP TABLE IF EXISTS `mall_promotion_gifts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_promotion_gifts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `promotion_id` int(11) NOT NULL,
  `gift_type` varchar(20) DEFAULT 'points',
  `gift_value` double DEFAULT 0,
  `gift_detail` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '{}' CHECK (json_valid(`gift_detail`)),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_promotion_gifts`
--

LOCK TABLES `mall_promotion_gifts` WRITE;
/*!40000 ALTER TABLE `mall_promotion_gifts` DISABLE KEYS */;
/*!40000 ALTER TABLE `mall_promotion_gifts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_promotion_products`
--

DROP TABLE IF EXISTS `mall_promotion_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_promotion_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `promotion_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `promotion_id` (`promotion_id`,`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_promotion_products`
--

LOCK TABLES `mall_promotion_products` WRITE;
/*!40000 ALTER TABLE `mall_promotion_products` DISABLE KEYS */;
/*!40000 ALTER TABLE `mall_promotion_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_promotions`
--

DROP TABLE IF EXISTS `mall_promotions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_promotions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `type` varchar(20) DEFAULT 'discount',
  `discount_value` double DEFAULT 0,
  `min_amount` double DEFAULT 0,
  `user_types` text DEFAULT '[]',
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `status` varchar(20) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_promotions`
--

LOCK TABLES `mall_promotions` WRITE;
/*!40000 ALTER TABLE `mall_promotions` DISABLE KEYS */;
INSERT INTO `mall_promotions` VALUES
(1,'666','discount',2,10,'[]','2026-07-12 00:42:00','2026-08-12 00:42:00','1','2026-07-11 16:42:26');
/*!40000 ALTER TABLE `mall_promotions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_review_likes`
--

DROP TABLE IF EXISTS `mall_review_likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_review_likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `review_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `review_id` (`review_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_review_likes`
--

LOCK TABLES `mall_review_likes` WRITE;
/*!40000 ALTER TABLE `mall_review_likes` DISABLE KEYS */;
/*!40000 ALTER TABLE `mall_review_likes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_reviews`
--

DROP TABLE IF EXISTS `mall_reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_reviews` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `rating` int(11) DEFAULT 5,
  `content` text DEFAULT '',
  `images` text DEFAULT '[]',
  `reply` text DEFAULT '',
  `reply_time` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  `dim_product_rating` decimal(2,1) DEFAULT 0.0,
  `dim_service_rating` decimal(2,1) DEFAULT 0.0,
  `dim_logistics_rating` decimal(2,1) DEFAULT 0.0,
  PRIMARY KEY (`id`),
  KEY `idx_mall_reviews_product` (`product_id`),
  KEY `idx_mall_reviews_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_reviews`
--

LOCK TABLES `mall_reviews` WRITE;
/*!40000 ALTER TABLE `mall_reviews` DISABLE KEYS */;
INSERT INTO `mall_reviews` VALUES
(1,6,4,1,5,'质量不错，第1次购买了！','[]','',NULL,'2026-07-10 22:39:53',0.0,0.0,0.0),
(2,2,8,2,4,'质量不错，第2次购买了！','[]','',NULL,'2026-07-10 22:39:53',0.0,0.0,0.0),
(3,8,8,3,4,'质量不错，第3次购买了！','[]','',NULL,'2026-07-10 22:39:53',0.0,0.0,0.0),
(4,7,10,4,5,'质量不错，第4次购买了！','[]','',NULL,'2026-07-10 22:39:53',0.0,0.0,0.0),
(5,4,2,5,5,'质量不错，第5次购买了！','[]','',NULL,'2026-07-10 22:39:53',0.0,0.0,0.0),
(6,5,12,6,5,'质量不错，第6次购买了！','[]','',NULL,'2026-07-10 22:39:53',0.0,0.0,0.0),
(7,7,6,7,5,'质量不错，第7次购买了！','[]','',NULL,'2026-07-10 22:39:53',0.0,0.0,0.0),
(8,6,3,8,5,'质量不错，第8次购买了！','[]','',NULL,'2026-07-10 22:39:53',0.0,0.0,0.0),
(9,2,8,9,5,'质量不错，第9次购买了！','[]','',NULL,'2026-07-10 22:39:53',0.0,0.0,0.0),
(10,2,5,10,5,'质量不错，第10次购买了！','[]','',NULL,'2026-07-10 22:39:53',0.0,0.0,0.0);
/*!40000 ALTER TABLE `mall_reviews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `membership_levels`
--

DROP TABLE IF EXISTS `membership_levels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `membership_levels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `level` int(11) NOT NULL DEFAULT 0,
  `tier` int(11) DEFAULT 1,
  `parent_level_id` int(11) DEFAULT 0,
  `price` decimal(10,2) DEFAULT 0.00,
  `points_required` int(11) DEFAULT 0,
  `discount_rate` decimal(3,1) DEFAULT 1.0,
  `points_multiplier` decimal(3,1) DEFAULT 1.0,
  `points_discount_rate` decimal(3,1) DEFAULT 1.0,
  `text_color` varchar(20) DEFAULT '#FFFFFF',
  `bg_color` varchar(20) DEFAULT '#508DFF',
  `benefits` text DEFAULT NULL,
  `icon` varchar(100) DEFAULT '',
  `icon_color` varchar(20) DEFAULT '#909399',
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  `data_limit_mb` int(11) DEFAULT 0,
  `file_limit_mb` int(11) DEFAULT 0,
  `file_policy_ids` text DEFAULT NULL,
  `gift_points` int(11) DEFAULT 0,
  `gift_balance` decimal(10,2) DEFAULT 0.00,
  `gift_experience` int(11) DEFAULT 0,
  `gift_coupon_ids` text DEFAULT NULL,
  `perks` text DEFAULT NULL,
  `title_id` int(11) DEFAULT 0,
  `frame_id` int(11) DEFAULT 0,
  `daily_gift_enabled` tinyint(1) DEFAULT 0,
  `daily_gift_interval_days` int(11) DEFAULT 1,
  `daily_gift_points` int(11) DEFAULT 0,
  `daily_gift_balance` decimal(10,2) DEFAULT 0.00,
  `daily_gift_experience` int(11) DEFAULT 0,
  `daily_gift_coupon_ids` text DEFAULT NULL,
  `birthday_gift_points` int(11) DEFAULT 0,
  `birthday_gift_balance` decimal(10,2) DEFAULT 0.00,
  `birthday_gift_experience` int(11) DEFAULT 0,
  `birthday_gift_coupon_ids` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `membership_levels`
--

LOCK TABLES `membership_levels` WRITE;
/*!40000 ALTER TABLE `membership_levels` DISABLE KEYS */;
INSERT INTO `membership_levels` VALUES
(1,'普通会员',0,1,0,0.00,0,1.0,1.0,1.0,'#FFFFFF','#508DFF','基础权益','ri:user-line','#909399','1','2026-07-10 22:42:45',50,100,'1',0,0.00,0,NULL,NULL,0,0,0,1,0,0.00,0,NULL,0,0.00,0,NULL),
(2,'黄金会员',1,1,0,299.00,0,0.9,1.5,1.0,'#FFFFFF','#508DFF','9折优惠,1.5倍积分,专属客服','','','1','2026-07-10 22:42:45',50,50,'',100,5.00,200,'[{\"name\":\"黄金专享券\",\"type\":\"fixed\",\"value\":20,\"minOrder\":30,\"maxDiscount\":0,\"scope\":\"membership\",\"category\":\"member\",\"validDays\":30}]','生日礼包|年度礼包',1,1,1,1,10,1.00,50,'[{\"name\":\"每日签到券\",\"type\":\"percent\",\"value\":5,\"minOrder\":0,\"maxDiscount\":20,\"scope\":\"all\",\"category\":\"general\",\"validDays\":7}]',500,50.00,1000,'[{\"name\":\"生日专属券\",\"type\":\"fixed\",\"value\":100,\"minOrder\":0,\"maxDiscount\":0,\"scope\":\"all\",\"category\":\"member\",\"validDays\":30}]'),
(3,'钻石会员',2,1,0,599.00,0,0.8,2.0,1.0,'#FFFFFF','#508DFF','8折优惠,2倍积分,专属客服,优先发货,生日礼包','ri:vip-diamond-line','#377dff','0','2026-07-10 22:42:45',0,0,'',0,0.00,0,'[]','',0,0,0,1,0,0.00,0,'[]',0,0.00,0,'[]'),
(4,'至尊会员',3,1,0,999.00,0,0.7,3.0,3.0,'#FFFFFF','#508DFF','7折优惠,3倍积分,专属客服,优先发货,生日礼包,年度礼品','ri:star-line','#ff6b6b','1','2026-07-10 22:42:45',200,200,'',200,0.00,200,'[]','',1,1,1,7,50,0.00,50,'[]',500,0.00,500,'[]'),
(5,'测试会员',5,5,0,10.00,0,6.0,5.0,5.0,'#FFFFFF','#508DFF','','','','0','2026-07-11 22:39:44',500,500,'2,1',500,5.00,500,'[]','',1,1,1,3,10,0.00,30,'[]',500,0.00,500,'[]');
/*!40000 ALTER TABLE `membership_levels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `membership_products`
--

DROP TABLE IF EXISTS `membership_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `membership_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `level_id` int(11) NOT NULL DEFAULT 0,
  `name` varchar(100) DEFAULT '',
  `price` decimal(10,2) DEFAULT 0.00,
  `original_price` decimal(10,2) DEFAULT 0.00,
  `points_price` decimal(10,2) DEFAULT 0.00,
  `points_original_price` decimal(10,2) DEFAULT 0.00,
  `duration_days` int(11) DEFAULT 30,
  `is_promo` tinyint(1) DEFAULT 0,
  `promo_end_time` datetime DEFAULT NULL,
  `gift_points` int(11) DEFAULT 0,
  `gift_balance` decimal(10,2) DEFAULT 0.00,
  `gift_experience` int(11) DEFAULT 0,
  `gift_coupon_ids` text DEFAULT NULL,
  `gift_data_limit_mb` int(11) DEFAULT 0,
  `gift_file_limit_mb` int(11) DEFAULT 0,
  `purchase_limit` int(11) DEFAULT 0,
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `membership_products`
--

LOCK TABLES `membership_products` WRITE;
/*!40000 ALTER TABLE `membership_products` DISABLE KEYS */;
INSERT INTO `membership_products` VALUES
(5,2,'1个月',10.00,12.00,1300.00,0.00,31,1,NULL,50,3.00,100,'[{\"name\":\"月度续费券\",\"type\":\"percent\",\"value\":10,\"minOrder\":0,\"maxDiscount\":50,\"scope\":\"all\",\"category\":\"general\",\"validDays\":14}]',10,10,3,'1','2026-07-11 21:07:13'),
(7,5,'30天会员',30.00,35.00,3500.00,3600.00,30,1,NULL,100,0.00,200,'[]',10,10,0,'1','2026-07-11 23:02:32'),
(8,4,'月度会员',20.00,25.00,2500.00,3000.00,31,1,NULL,0,0.00,500,'[]',10,10,0,'1','2026-07-11 23:07:22'),
(9,4,'季度会员',48.00,60.00,5800.00,6000.00,96,1,NULL,120,0.00,2000,'[]',20,20,0,'1','2026-07-11 23:07:22');
/*!40000 ALTER TABLE `membership_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `membership_purchases`
--

DROP TABLE IF EXISTS `membership_purchases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `membership_purchases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT 0,
  `level_id` int(11) DEFAULT 0,
  `level_name` varchar(100) DEFAULT '',
  `amount` decimal(10,2) DEFAULT 0.00,
  `pay_type` varchar(20) DEFAULT 'balance',
  `purchase_type` varchar(20) DEFAULT 'buy',
  `duration_days` int(11) DEFAULT 0,
  `expire_time` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_membership_purchases_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `membership_purchases`
--

LOCK TABLES `membership_purchases` WRITE;
/*!40000 ALTER TABLE `membership_purchases` DISABLE KEYS */;
INSERT INTO `membership_purchases` VALUES
(1,14,0,2,'黄金会员',299.00,'balance','buy',0,'2027-07-10 22:39:54','2026-06-23 22:39:54'),
(2,14,0,3,'钻石会员',599.00,'balance','buy',0,'2027-07-10 22:39:54','2026-05-29 22:39:54'),
(3,4,0,2,'至尊会员',999.00,'balance','buy',0,'2027-07-10 22:39:54','2026-05-28 22:39:54'),
(4,11,0,4,'黄金会员',299.00,'balance','buy',0,'2027-07-10 22:39:54','2026-05-29 22:39:54'),
(5,11,0,4,'钻石会员',599.00,'balance','buy',0,'2027-07-10 22:39:54','2026-05-19 22:39:54'),
(6,7,0,4,'至尊会员',999.00,'balance','buy',0,'2027-07-10 22:39:54','2026-06-16 22:39:54'),
(7,19,1,2,'黄金会员',1300.00,'points','buy',31,'2026-08-11 09:08:18','2026-07-11 09:08:18'),
(8,19,1,2,'黄金会员',10.00,'balance','renew',31,'2026-09-11 01:08:18','2026-07-11 09:14:35'),
(9,19,1,2,'黄金会员',10.00,'balance','renew',31,'2026-10-11 17:08:18','2026-07-11 09:14:38'),
(10,1,3,2,'黄金会员',10.00,'balance','buy',31,'2026-08-11 20:37:08','2026-07-11 20:37:08'),
(11,4,3,2,'黄金会员',10.00,'balance','buy',31,'2026-08-11 20:38:36','2026-07-11 20:38:36'),
(18,19,5,2,'黄金会员',10.00,'balance','renew',31,'2026-11-11 09:08:18','2026-07-12 00:11:10');
/*!40000 ALTER TABLE `membership_purchases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menus`
--

DROP TABLE IF EXISTS `menus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `menus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT 0,
  `name` varchar(100) NOT NULL,
  `path` varchar(200) NOT NULL DEFAULT '',
  `component` varchar(200) DEFAULT '',
  `redirect` varchar(200) DEFAULT '',
  `title` varchar(100) NOT NULL,
  `icon` varchar(100) DEFAULT '',
  `sort_order` int(11) DEFAULT 0,
  `is_hidden` tinyint(1) DEFAULT 0,
  `is_full_page` tinyint(1) DEFAULT 0,
  `is_keep_alive` tinyint(1) DEFAULT 1,
  `is_fixed_tab` tinyint(1) DEFAULT 0,
  `auth_list` text DEFAULT NULL,
  `roles` text DEFAULT NULL,
  `enabled` tinyint(1) DEFAULT 1,
  `mobile_path` varchar(200) DEFAULT '',
  `icon_bg` varchar(20) DEFAULT '#4ECDC4',
  `icon_svg` text DEFAULT NULL,
  `category` varchar(50) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menus`
--

LOCK TABLES `menus` WRITE;
/*!40000 ALTER TABLE `menus` DISABLE KEYS */;
INSERT INTO `menus` VALUES
(1,0,'Dashboard','/dashboard','/index/index','/dashboard/console','仪表盘','ri:pie-chart-line',1,0,0,0,0,NULL,'[\"R_SUPER\",\"R_ADMIN\"]',1,'','#4ECDC4',NULL,'','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(2,0,'Operation','/operation','/index/index','','运营管理','ri:settings-3-line',3,0,0,0,0,NULL,'[\"R_SUPER\",\"R_ADMIN\"]',1,'','#4ECDC4','','','2026-07-10 22:42:45','2026-07-11 16:09:19'),
(3,0,'System','/system','/index/index','','系统管理','ri:user-3-line',2,0,0,0,0,NULL,'[\"R_SUPER\",\"R_ADMIN\"]',1,'','#4ECDC4','','','2026-07-10 22:42:45','2026-07-11 16:09:15'),
(4,0,'Result','/result','/index/index','','结果页面','ri:checkbox-circle-line',6,0,0,0,0,NULL,NULL,1,'','#4ECDC4','','','2026-07-10 22:42:45','2026-07-11 16:09:30'),
(5,0,'Exception','/exception','/index/index','','异常页面','ri:error-warning-line',7,0,0,0,0,NULL,NULL,1,'','#4ECDC4','','','2026-07-10 22:42:45','2026-07-11 16:09:36'),
(6,0,'AppStore','/appstore','/index/index','','应用商店','ri:apps-2-line',4,0,0,0,0,NULL,'[\"R_SUPER\",\"R_ADMIN\",\"R_USER\"]',1,'','#4ECDC4',NULL,'','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(7,1,'Console','console','/dashboard/console','','工作台','',1,0,0,1,1,NULL,NULL,1,'/appstore/mobile-console','#6366F1','M3 13h8V3H3v10zm0 8h8v-6H3v6zm10 0h8V11h-8v10zm0-18v6h8V3h-8z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(8,2,'CardKey','cardkey','/operation/cardkey/index','','卡密管理','',1,0,0,1,0,'[{\"title\":\"生成\",\"authMark\":\"add\"},{\"title\":\"删除\",\"authMark\":\"delete\"},{\"title\":\"导入\",\"authMark\":\"import\"}]',NULL,1,'/appstore/cardkey-manage','#F59E0B','M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 14H4v-6h16v6zm0-10H4V6h16v2z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(9,2,'Membership','membership','/operation/membership/index','','会员管理','',2,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]',NULL,1,'/appstore/operation/membership','#F59E0B','M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(10,2,'Coupon','coupon','/operation/coupon/index','','优惠券管理','',3,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"},{\"title\":\"启停\",\"authMark\":\"toggle\"}]',NULL,1,'/appstore/operation/coupon','#F59E0B','M20 12v6H4v-6c1.1 0 2-.9 2-2s-.9-2-2-2V4h16v4c-1.1 0-2 .9-2 2s.9 2 2 2zm-6 4h2v-2h-2v2zm-4 0h2v-2h-2v2zm0-4h2v-2h-2v2z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(11,2,'Points','points','/operation/points/index','','积分管理','',4,0,0,1,0,'[{\"title\":\"调整\",\"authMark\":\"adjust\"},{\"title\":\"导出\",\"authMark\":\"export\"}]',NULL,1,'/appstore/operation/points','#F59E0B','M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1.41 16.09V20h-2.67v-1.93c-1.71-.36-3.16-1.46-3.27-3.4h1.96c.1 1.05.82 1.87 2.65 1.87 1.96 0 2.4-.98 2.4-1.59 0-.83-.44-1.61-2.67-2.14-2.48-.6-4.18-1.62-4.18-3.67 0-1.72 1.39-2.84 3.11-3.21V4h2.67v1.95c1.86.45 2.79 1.86 2.85 3.39H14.3c-.05-1.11-.64-1.87-2.22-1.87-1.5 0-2.4.68-2.4 1.64 0 .84.65 1.39 2.67 1.91s4.18 1.39 4.18 3.91c-.01 1.83-1.38 2.83-3.12 3.16z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(12,2,'ExperienceLevel','experience','/operation/experience/index','','经验等级','',5,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]',NULL,1,'/appstore/experience-manage','#F59E0B','M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(13,2,'Plugins','plugins','/operation/plugins/index','','插件管理','',6,0,0,1,0,'[{\"title\":\"上传\",\"authMark\":\"upload\"},{\"title\":\"启停\",\"authMark\":\"toggle\"},{\"title\":\"配置\",\"authMark\":\"config\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]',NULL,1,'/appstore/plugin-manage','#F59E0B','M20.5 11H19V7c0-1.1-.9-2-2-2h-4V3.5C13 2.12 11.88 1 10.5 1S8 2.12 8 3.5V5H4c-1.1 0-2 .9-2 2v3.8H3.5c1.49 0 2.7 1.21 2.7 2.7s-1.21 2.7-2.7 2.7H2V20c0 1.1.9 2 2 2h3.8v-1.5c0-1.49 1.21-2.7 2.7-2.7s2.7 1.21 2.7 2.7V22H17c1.1 0 2-.9 2-2v-4h1.5c1.38 0 2.5-1.12 2.5-2.5S21.88 11 20.5 11z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(14,2,'TitleManage','title','/operation/title/index','','称号管理','',7,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]',NULL,1,'/appstore/title-manage','#F59E0B','M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm3.5-9c.83 0 1.5-.67 1.5-1.5S16.33 8 15.5 8 14 8.67 14 9.5s.67 1.5 1.5 1.5zm-7 0c.83 0 1.5-.67 1.5-1.5S9.33 8 8.5 8 7 8.67 7 9.5 7.67 11 8.5 11zm3.5 6.5c2.33 0 4.31-1.46 5.11-3.5H6.89c.8 2.04 2.78 3.5 5.11 3.5z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(15,2,'CommissionManage','commission','/operation/commission/index','','推广返佣','',8,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"},{\"title\":\"配置\",\"authMark\":\"config\"}]',NULL,1,'/appstore/commission-manage','#F59E0B','M20 7h-4V4c0-1.1-.9-2-2-2h-4c-1.1 0-2 .9-2 2v3H4c-1.1 0-2 .9-2 2v11c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V9c0-1.1-.9-2-2-2zm-6 0h-4V4h4v3z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(16,54,'FilePolicyManage','filepolicy','/operation/filepolicy/index','','文件上传策略','',9,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]',NULL,1,'/appstore/file-policy-manage','#3B82F6','M20 6h-8l-2-2H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2zm0 12H4V6h5.17l2 2H20v10z','','2026-07-10 22:42:45','2026-07-10 23:26:58'),
(17,2,'Settlement','settlement','/operation/settlement/index','','结算规则','ri:exchange-funds-line',10,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"},{\"title\":\"启停\",\"authMark\":\"toggle\"}]',NULL,1,'/appstore/operation/settlement','#F59E0B','M21 3H3v18h18V3zm-2 16H5V5h14v14zM17 7h-4v4h4V7zm-6 0H7v4h4V7zm6 6h-4v4h4v-4zm-6 0H7v4h4v-4z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(18,2,'MembershipProducts','membership-products','/operation/membership-products/index','','会员商品','',11,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"},{\"title\":\"启停\",\"authMark\":\"toggle\"}]',NULL,1,'/appstore/operation/membership-products','#F59E0B','M20 6h-2.18c.11-.31.18-.65.18-1 0-1.66-1.34-3-3-3-1.05 0-1.96.54-2.5 1.35l-.5.67-.5-.68C10.96 2.54 10.05 2 9 2 7.34 2 6 3.34 6 5c0 .35.07.69.18 1H4c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2zm-5 0c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zM9 4c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zm11 14H4v-2h16v2zm0-5H4V8h16v5z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(19,2,'MembershipPurchases','membership-purchases','/operation/membership-purchases/index','','购买记录','',12,0,0,1,0,'[{\"title\":\"导出\",\"authMark\":\"export\"}]',NULL,1,'/appstore/operation/purchase-records','#F59E0B','M11 17h2v-1h1c.55 0 1-.45 1-1v-3c0-.55-.45-1-1-1h-3v-1h4V8h-2V7h-2v1h-1c-.55 0-1 .45-1 1v3c0 .55.45 1 1 1h3v1H9v2h2v1zm9-13H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 14H4V6h16v12z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(20,2,'ContentPurchases','content-purchases','/operation/content-purchases/index','','付费内容订单','',13,0,0,1,0,'[{\"title\":\"导出\",\"authMark\":\"export\"}]',NULL,1,'/appstore/operation/content-purchases','#F59E0B','M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 15l-4-4 1.41-1.41L11 14.17l6.59-6.59L19 9l-8 8z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(21,3,'User','user','/system/user','','用户管理','',1,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"},{\"title\":\"启停\",\"authMark\":\"toggle\"},{\"title\":\"重置密码\",\"authMark\":\"reset\"}]',NULL,1,'/appstore/user-manage','#10B981','M12 12c2.7 0 4.8-2.1 4.8-4.8S14.7 2.4 12 2.4 7.2 4.5 7.2 7.2 9.3 12 12 12zm0 2.4c-3.2 0-9.6 1.6-9.6 4.8v2.4h19.2v-2.4c0-3.2-6.4-4.8-9.6-4.8z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(22,3,'Role','role','/system/role','','角色管理','',2,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]',NULL,1,'/appstore/role-manage','#10B981','M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm0 10.99h7c-.53 4.12-3.28 7.79-7 8.94V12H5V6.3l7-3.11v8.8z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(23,3,'UserCenter','user-center','/system/user-center','','个人中心','',3,1,0,1,1,NULL,NULL,1,'','#10B981',NULL,'','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(24,3,'Menus','menu','/system/menu','','菜单管理','',4,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]',NULL,1,'/appstore/menu-manage','#10B981','M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(25,3,'DeleteReview','delete-review','/system/user/delete-review','','注销审核','',5,0,0,1,0,'[{\"title\":\"通过\",\"authMark\":\"approve\"},{\"title\":\"拒绝\",\"authMark\":\"reject\"}]',NULL,1,'/appstore/delete-review','#10B981','M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(26,3,'Verification','verification','/system/verification/index','','蓝V认证审核','',6,0,0,1,0,'[{\"title\":\"通过\",\"authMark\":\"approve\"},{\"title\":\"拒绝\",\"authMark\":\"reject\"}]',NULL,1,'/appstore/verification-manage','#10B981','M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm-2 16l-4-4 1.41-1.41L10 14.17l6.59-6.59L18 9l-8 8z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(27,3,'InviteManage','invite','/system/invite/index','','邀请码管理','',7,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"生成\",\"authMark\":\"generate\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]',NULL,1,'/appstore/invite-manage','#10B981','M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5C6.34 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(28,3,'EmailConfig','email','/system/email/index','','邮件配置','',9,0,0,1,0,'[{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"测试\",\"authMark\":\"test\"}]',NULL,1,'/appstore/email-config','#10B981','M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z','','2026-07-10 22:42:45','2026-07-10 23:24:27'),
(29,54,'FileRepository','filerepo','/system/filerepo/index','','文件仓库','',8,0,0,1,0,'[{\"title\":\"删除\",\"authMark\":\"delete\"}]',NULL,1,'/appstore/file-repo-manage','#3B82F6','M20 6h-8l-2-2H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2zm0 12H4V6h5.17l2 2H20v10z','','2026-07-10 22:42:45','2026-07-10 23:27:10'),
(30,3,'RecycleBin','recycle','/system/recycle/index','','回收站','',10,0,0,1,0,'[{\"title\":\"恢复\",\"authMark\":\"restore\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]',NULL,1,'/appstore/recycle','#10B981','M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(31,3,'SystemLog','syslog','/system/syslog/index','','系统日志','',11,0,0,1,0,'[{\"title\":\"导出\",\"authMark\":\"export\"},{\"title\":\"清空\",\"authMark\":\"clear\"}]',NULL,1,'/appstore/syslog','#10B981','M19 3h-4.18C14.4 1.84 13.3 1 12 1c-1.3 0-2.4.84-2.82 2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-7 0c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zm2 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(32,3,'SysConfig','sysconfig','/system/sysconfig/index','','系统配置','',12,0,0,1,0,'[{\"title\":\"编辑\",\"authMark\":\"edit\"}]',NULL,1,'/appstore/site-config','#10B981','M19.14 12.94c.04-.3.06-.61.06-.94 0-.33-.02-.64-.06-.94l2.02-1.58c.18-.14.23-.38.12-.56l-1.89-3.28c-.12-.19-.36-.26-.56-.18l-2.38.96c-.5-.38-1.06-.68-1.66-.88L14.45 3.5c-.04-.2-.2-.34-.4-.34h-3.78c-.2 0-.36.14-.4.34l-.3 2.52c-.6.2-1.16.5-1.66.88l-2.38-.96c-.2-.08-.44-.01-.56.18L3.28 9.52c-.12.19-.06.42.12.56l2.02 1.58c-.04.3-.06.61-.06.94s.02.64.06.94l-2.02 1.58c-.18.14-.23.38-.12.56l1.89 3.28c.12.19.36.26.56.18l2.38-.96c.5.38 1.06.68 1.66.88l.3 2.52c.04.2.2.34.4.34h3.78c.2 0 .36-.14.4-.34l.3-2.52c.6-.2 1.16-.5 1.66-.88l2.38.96c.2.08.44.01.56-.18l1.89-3.28c.12-.19.06-.42-.12-.56l-2.02-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(33,3,'CustomTask','task','/system/task/index','','任务管理','',13,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"},{\"title\":\"启停\",\"authMark\":\"toggle\"}]',NULL,1,'/appstore/task-manage','#10B981','M19 3h-4.18C14.4 1.84 13.3 1 12 1c-1.3 0-2.4.84-2.82 2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-7 0c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zm-2 14l-4-4 1.41-1.41L10 14.17l6.59-6.59L18 9l-8 8z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(34,3,'EmailTemplates','email-templates','/appstore/email-templates','','邮件卡片','',14,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"},{\"title\":\"启停\",\"authMark\":\"toggle\"}]',NULL,1,'/appstore/email-templates','#10B981','M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(35,3,'EmailPush','email-push','/appstore/email-push','','邮件推送','',15,0,0,1,0,'[{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"启停\",\"authMark\":\"toggle\"}]',NULL,1,'/appstore/email-push','#10B981','M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5C6.34 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(36,54,'StorageConfig','storage-config','/appstore/storage-config','','对象存储','',16,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"},{\"title\":\"启停\",\"authMark\":\"toggle\"},{\"title\":\"测试\",\"authMark\":\"test\"}]',NULL,1,'/appstore/storage-config','#3B82F6','M14 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8l-6-6zm-1 7V3.5L18.5 9H13zM6 20V4h5v7h7v9H6z','','2026-07-10 22:42:45','2026-07-10 23:27:43'),
(37,6,'AppStoreList','list','/appstore/list','','应用管理','',1,0,0,1,0,'[{\"title\":\"通过\",\"authMark\":\"approve\"},{\"title\":\"拒绝\",\"authMark\":\"reject\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"},{\"title\":\"启停\",\"authMark\":\"toggle\"}]',NULL,1,'/appstore/list','#EC4899','M19 5v14H5V5h14m0-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-4.86 8.86l-3 3.87L9 13.14 6 17h12l-3.86-5.14z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(38,6,'AppStoreDetail','detail/:id','/appstore/detail','','应用详情','',2,1,0,0,0,NULL,NULL,1,'','#EC4899',NULL,'','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(39,6,'AppCategory','category-manage','/appstore/category','','应用分类','ri:apps-2-line',3,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]','[\"R_SUPER\",\"R_ADMIN\"]',1,'/appstore/category-manage','#EC4899','M21.41 11.58l-9-9C12.05 2.22 11.55 2 11 2H4c-1.1 0-2 .9-2 2v7c0 .55.22 1.05.59 1.42l9 9c.36.36.86.58 1.41.58s1.05-.22 1.41-.59l7-7c.37-.36.59-.86.59-1.41 0-.55-.23-1.06-.59-1.42zM5.5 7C4.67 7 4 6.33 4 5.5S4.67 4 5.5 4 7 4.67 7 5.5 6.33 7 5.5 7z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(40,6,'AppReports','reports','/appstore/reports','','举报列表','ri:apps-2-line',4,0,0,1,0,'[{\"title\":\"处理\",\"authMark\":\"handle\"},{\"title\":\"忽略\",\"authMark\":\"ignore\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]','[\"R_SUPER\",\"R_ADMIN\"]',1,'/appstore/reports','#EC4899','M15.73 3H8.27L3 8.27v7.46L8.27 21h7.46L21 15.73V8.27L15.73 3zM12 17.3c-.72 0-1.3-.58-1.3-1.3s.58-1.3 1.3-1.3 1.3.58 1.3 1.3-.58 1.3-1.3 1.3zm1-4.3h-2V7h2v6z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(44,6,'OfficialTags','official-tags','/appstore/official-tags','','官方标签','',8,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]','[\"R_SUPER\",\"R_ADMIN\"]',1,'/appstore/official-tags','#EC4899','M21.41 11.58l-9-9C12.05 2.22 11.55 2 11 2H4c-1.1 0-2 .9-2 2v7c0 .55.22 1.05.59 1.42l9 9c.36.36.86.58 1.41.58s1.05-.22 1.41-.59l7-7c.37-.36.59-.86.59-1.41 0-.55-.23-1.06-.59-1.42z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(45,6,'SectionManage','section-manage','','','板块管理','',9,1,0,0,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"},{\"title\":\"管理版主\",\"authMark\":\"moderate\"},{\"title\":\"启停\",\"authMark\":\"toggle\"},{\"title\":\"处理解锁\",\"authMark\":\"unlock\"}]','[\"R_SUPER\",\"R_ADMIN\"]',1,'/appstore/section-manage','#EC4899','M3 15h8v-2H3v2zm0 4h8v-2H3v2zm0-8h8V9H3v2zm0-6v2h8V5H3zm10 0h8v14h-8V5z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(46,6,'CommunityPostManage','community-posts','','','帖子管理','',10,1,0,0,0,'[{\"title\":\"置顶\",\"authMark\":\"pin\"},{\"title\":\"加精\",\"authMark\":\"essence\"},{\"title\":\"热帖\",\"authMark\":\"boost\"},{\"title\":\"锁定\",\"authMark\":\"lock\"},{\"title\":\"审核\",\"authMark\":\"approve\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]','[\"R_SUPER\",\"R_ADMIN\"]',1,'','#EC4899',NULL,'','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(47,6,'CommunityReportManage','community-reports','','','举报管理','',11,1,0,0,0,'[{\"title\":\"处理\",\"authMark\":\"handle\"},{\"title\":\"忽略\",\"authMark\":\"ignore\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]','[\"R_SUPER\",\"R_ADMIN\"]',1,'','#EC4899',NULL,'','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(48,6,'CommunityCommentManage','community-comments','','','评论管理','',12,1,0,0,0,'[{\"title\":\"置顶\",\"authMark\":\"pin\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]','[\"R_SUPER\",\"R_ADMIN\"]',1,'','#EC4899',NULL,'','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(49,4,'Success','success','/result/success/index','','成功页','',1,0,1,0,0,NULL,NULL,1,'','#EF4444',NULL,'','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(50,4,'Fail','fail','/result/fail/index','','失败页','',2,0,1,0,0,NULL,NULL,1,'','#EF4444',NULL,'','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(51,5,'Exception403','403','/exception/403/index','','403','',1,0,1,0,0,NULL,NULL,1,'','#8B5CF6',NULL,'','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(52,5,'Exception404','404','/exception/404/index','','404','',2,0,1,0,0,NULL,NULL,1,'','#8B5CF6',NULL,'','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(53,5,'Exception500','500','/exception/500/index','','500','',3,0,1,0,0,NULL,NULL,1,'','#8B5CF6',NULL,'','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(54,0,'文件管理','/awsdb','/index/index','','文件管理','',4,0,0,1,0,'[{\"title\":\"上传\",\"authMark\":\"upload\"},{\"title\":\"删除\",\"authMark\":\"delete\"},{\"title\":\"下载\",\"authMark\":\"download\"}]',NULL,1,'','#4ECDC4','','','2026-07-10 23:24:00','2026-07-10 23:29:37'),
(55,2,'GameCenter','/operation/game-center','','','游戏中心','ri:gamepad-line',19,0,0,1,0,NULL,'[\"R_SUPER\",\"R_ADMIN\"]',1,'/appstore/operation/game-center','#F59E0B','M21 6H3c-1.1 0-2 .9-2 2v8c0 1.1.9 2 2 2h18c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2zm-10 7H8v2H6v-2H4v-2h2V9h2v2h3v2zm7 0h-3v2h-2v-2h-3V9h3V7h2v2h3v2z','','2026-07-11 09:41:21','2026-07-11 09:41:21'),
(56,0,'商城管理','/etnfd','','','商城管理','',5,0,0,1,0,NULL,NULL,1,'','#4ECDC4','','','2026-07-11 16:08:50','2026-07-11 16:09:24'),
(57,56,'MallManage','/appstore/mall-manage','/appstore/admin/mall/mall-manage','','商品管理','ri:shopping-bag-3-line',1,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"},{\"title\":\"上下架\",\"authMark\":\"toggle\"}]','[\"R_SUPER\",\"R_ADMIN\"]',1,'/appstore/mall-manage','#8B5CF6','M20 6h-2.18c.11-.31.18-.65.18-1 0-1.66-1.34-3-3-3-1.05 0-1.96.54-2.5 1.35l-.5.67-.5-.68C10.96 2.54 10.05 2 9 2 7.34 2 6 3.34 6 5c0 .35.07.69.18 1H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2zm-8 4c0 .55-.45 1-1 1s-1-.45-1-1V8h2v2zm4-1c.55 0 1-.45 1-1V8h-2v2c0 .55.45 1 1 1z','','2026-07-11 16:15:17','2026-07-11 16:15:17'),
(58,56,'MallOrders','/appstore/mall-orders','/appstore/admin/mall/mall-orders','','订单管理','ri:file-list-3-line',2,0,0,1,0,'[{\"title\":\"处理\",\"authMark\":\"edit\"},{\"title\":\"导出\",\"authMark\":\"export\"}]','[\"R_SUPER\",\"R_ADMIN\"]',1,'/appstore/mall-orders','#8B5CF6','M14 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8l-6-6zm-1 7V3.5L18.5 9H13zM7 13h10v2H7v-2zm0 4h7v2H7v-2z','','2026-07-11 16:15:17','2026-07-11 16:15:17'),
(59,56,'MallCategories','/appstore/mall-categories','/appstore/admin/mall/mall-categories','','分类管理','ri:price-tag-3-line',3,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]','[\"R_SUPER\",\"R_ADMIN\"]',1,'/appstore/mall-categories','#8B5CF6','M21.41 11.58l-9-9C12.05 2.22 11.55 2 11 2H4c-1.1 0-2 .9-2 2v7c0 .55.22 1.05.59 1.42l9 9c.36.36.86.58 1.41.58.55 0 1.05-.22 1.41-.59l7-7c.37-.36.59-.86.59-1.41 0-.55-.22-1.05-.59-1.42zM5.5 7C4.67 7 4 6.33 4 5.5S4.67 4 5.5 4 7 4.67 7 5.5 6.33 7 5.5 7z','','2026-07-11 16:15:17','2026-07-11 16:15:17'),
(60,56,'MallAfterSales','/appstore/mall-after-sales','/appstore/admin/mall/mall-after-sales','','售后服务','ri:customer-service-2-line',4,0,0,1,0,'[{\"title\":\"处理\",\"authMark\":\"edit\"}]','[\"R_SUPER\",\"R_ADMIN\"]',1,'/appstore/mall-after-sales','#8B5CF6','M11 18h2v-2h-2v2zm1-16C6.48 2 2 6.48 2 12c0 5.32 3.36 9.82 8.03 11.49.63.23 1.29.4 1.97.52.68.12 1.34.12 2.03 0 .68-.12 1.34-.29 1.97-.52C20.64 21.82 24 17.32 24 12 24 6.48 19.52 2 14 2zm-2 15h4v2h-4v-2zm4-4H8c0-3.31 2.69-6 6-6s6 2.69 6 6h-4z','','2026-07-11 16:15:17','2026-07-11 16:15:17'),
(61,56,'MallPromotions','/appstore/mall-promotions','/appstore/admin/mall/mall-promotions','','优惠活动','ri:gift-line',5,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"},{\"title\":\"启停\",\"authMark\":\"toggle\"}]','[\"R_SUPER\",\"R_ADMIN\"]',1,'/appstore/mall-promotions','#8B5CF6','M20 12v6H4v-6c1.1 0 2-.9 2-2s-.9-2-2-2V4h16v4c-1.1 0-2 .9-2 2s.9 2 2 2zm-4-4h-2V6h-2v2h-2v2h2v2h2v-2h2V8z','','2026-07-11 16:15:17','2026-07-11 16:15:17'),
(62,2,'CheckinManage','/operation/checkin','/operation/checkin/index','','签到管理','ri:calendar-check-line',21,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"},{\"title\":\"启停\",\"authMark\":\"toggle\"}]','[\"R_SUPER\",\"R_ADMIN\"]',1,'/appstore/operation/checkin','#F59E0B','M19 3h-1V1h-2v2H8V1H6v2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-6.67 11.93l-3.89 3.89-2.11-2.11 1.41-1.41 1.12 1.12 2.47-2.47 1.51 1.41.04.04z','','2026-07-11 16:19:02','2026-07-11 16:19:02'),
(63,2,'ThemesManage','/operation/themes','/operation/themes/index','','主题管理','ri:palette-line',22,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]','[\"R_SUPER\",\"R_ADMIN\"]',1,'/appstore/operation/themes','#F59E0B','M12 3c-4.97 0-9 4.03-9 9s4.03 9 9 9c.83 0 1.5-.67 1.5-1.5 0-.39-.15-.74-.39-1.01-.23-.26-.38-.61-.38-.99 0-.83.67-1.5 1.5-1.5H16c2.76 0 5-2.24 5-5 0-4.42-4.03-8-9-8zm-4.5 8c-.83 0-1.5-.67-1.5-1.5S6.67 8 7.5 8 9 8.67 9 9.5 8.33 11 7.5 11zm9 0c-.83 0-1.5-.67-1.5-1.5S15.67 8 16.5 8s1.5.67 1.5 1.5-.67 1.5-1.5 1.5z','','2026-07-11 16:19:02','2026-07-11 16:19:02'),
(64,2,'AvatarFrameManage','/operation/avatar-frame','/operation/avatar-frame/index','','头像框管理','ri:user-smile-line',23,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]','[\"R_SUPER\",\"R_ADMIN\"]',1,'/appstore/operation/avatar-frame','#F59E0B','M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm3.5-9c.83 0 1.5-.67 1.5-1.5S16.33 8 15.5 8 14 8.67 14 9.5s.67 1.5 1.5 1.5zm-7 0c.83 0 1.5-.67 1.5-1.5S9.33 8 8.5 8 7 8.67 7 9.5 7.67 11 8.5 11zm3.5 6.5c2.33 0 4.31-1.46 5.11-3.5H6.89c.8 2.04 2.78 3.5 5.11 3.5z','','2026-07-11 16:19:02','2026-07-11 16:19:02'),
(65,2,'PaymentConfig','/operation/payment-config','/operation/payment-config/index','','支付配置','ri:bank-card-line',24,0,0,1,0,'[{\"title\":\"编辑\",\"authMark\":\"edit\"}]','[\"R_SUPER\",\"R_ADMIN\"]',1,'/appstore/operation/payment-config','#F59E0B','M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4H4V6h16v2zm-8 4H7v2h5v-2zm3 0h2v2h-2v-2z','','2026-07-11 16:19:02','2026-07-11 16:19:02'),
(66,2,'RechargeAmounts','/operation/recharge-amounts','/operation/recharge-amounts/index','','充值金额配置','ri:money-cny-circle-line',25,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]','[\"R_SUPER\",\"R_ADMIN\"]',1,'/appstore/operation/recharge-amounts','#F59E0B','M11.8 10.9c-2.27-.59-3-1.2-3-2.15 0-1.09 1.01-1.85 2.7-1.85 1.78 0 2.44.85 2.5 2.1h2.21c-.07-1.72-1.12-3.3-3.21-3.81V3h-3v2.16c-1.94.42-3.5 1.68-3.5 3.61 0 2.31 1.91 3.46 4.7 4.13 2.5.6 3 1.48 3 2.41 0 .69-.49 1.79-2.7 1.79-2.06 0-2.87-.92-2.98-2.1h-2.2c.12 2.19 1.76 3.42 3.68 3.83V21h3v-2.15c1.95-.37 3.5-1.5 3.5-3.55 0-2.84-2.43-3.81-4.7-4.4z','','2026-07-11 16:19:02','2026-07-11 16:19:02'),
(67,6,'SubmissionReview','/appstore/review','/appstore/review','','投稿审核','ri:audit-line',7,0,0,1,0,'[{\"title\":\"审核\",\"authMark\":\"edit\"}]','[\"R_SUPER\",\"R_ADMIN\"]',1,'/appstore/review-mobile','#EC4899','M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm-2 16l-4-4 1.41-1.41L10 14.17l6.59-6.59L18 9l-8 8z','','2026-07-11 16:19:02','2026-07-11 16:19:02'),
(68,54,'StorageFiles','/system/storage-files','/system/storage-files','','存储文件','ri:hard-drive-3-line',4,0,0,1,0,'[{\"title\":\"上传\",\"authMark\":\"add\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]','[\"R_SUPER\",\"R_ADMIN\"]',1,'/appstore/storage-files','#3B82F6','M14 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8l-6-6zm-1 7V3.5L18.5 9H13zM7 13h10v2H7v-2zm0 4h7v2H7v-2z','','2026-07-11 17:31:24','2026-07-11 17:31:24');
/*!40000 ALTER TABLE `menus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_no` varchar(50) NOT NULL,
  `buyer_id` int(11) NOT NULL,
  `buyer_name` varchar(100) DEFAULT '',
  `seller_id` int(11) DEFAULT 0,
  `seller_name` varchar(100) DEFAULT '',
  `order_type` varchar(30) NOT NULL,
  `order_desc` varchar(500) DEFAULT '',
  `ref_id` int(11) DEFAULT 0,
  `ref_table` varchar(50) DEFAULT '',
  `pay_type` varchar(20) DEFAULT 'balance',
  `total_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `coupon_id` int(11) DEFAULT 0,
  `coupon_discount` decimal(10,2) DEFAULT 0.00,
  `paid_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `status` varchar(20) DEFAULT 'shipped',
  `confirm_days` int(11) DEFAULT 7,
  `confirm_deadline` datetime DEFAULT NULL,
  `shipped_at` datetime DEFAULT NULL,
  `confirmed_at` datetime DEFAULT NULL,
  `refund_reason` varchar(500) DEFAULT '',
  `refund_requested_at` datetime DEFAULT NULL,
  `refund_responded_at` datetime DEFAULT NULL,
  `refund_reviewed_by` int(11) DEFAULT 0,
  `refund_reviewed_by_name` varchar(100) DEFAULT '',
  `reviewed_at` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_no` (`order_no`),
  KEY `idx_orders_buyer` (`buyer_id`),
  KEY `idx_orders_seller` (`seller_id`),
  KEY `idx_orders_status` (`status`),
  KEY `idx_orders_no` (`order_no`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES
(1,'ORD17837231940',2,'',0,'','purchase','',0,'','balance',92.69,0,0.00,0.00,'paid',7,NULL,NULL,NULL,'',NULL,NULL,0,'',NULL,'2026-07-02 22:39:54'),
(2,'ORD17837231941',2,'',0,'','purchase','',0,'','balance',191.11,0,0.00,0.00,'paid',7,NULL,NULL,NULL,'',NULL,NULL,0,'',NULL,'2026-06-24 22:39:54'),
(3,'ORD17837231942',11,'',0,'','purchase','',0,'','balance',112.15,0,0.00,0.00,'completed',7,NULL,NULL,NULL,'',NULL,NULL,0,'',NULL,'2026-06-17 22:39:54'),
(4,'ORD17837231943',10,'',0,'','purchase','',0,'','balance',210.01,0,0.00,0.00,'cancelled',7,NULL,NULL,NULL,'',NULL,NULL,0,'',NULL,'2026-06-29 22:39:54'),
(5,'ORD17837231944',7,'',0,'','purchase','',0,'','balance',213.23,0,0.00,0.00,'paid',7,NULL,NULL,NULL,'',NULL,NULL,0,'',NULL,'2026-06-27 22:39:54'),
(6,'ORD17837231945',4,'',0,'','purchase','',0,'','balance',84.35,0,0.00,0.00,'paid',7,NULL,NULL,NULL,'',NULL,NULL,0,'',NULL,'2026-07-10 22:39:54'),
(7,'ORD17837231946',11,'',0,'','purchase','',0,'','balance',20.66,0,0.00,0.00,'completed',7,NULL,NULL,NULL,'',NULL,NULL,0,'',NULL,'2026-06-28 22:39:54'),
(8,'ORD17837231947',4,'',0,'','purchase','',0,'','balance',88.74,0,0.00,0.00,'cancelled',7,NULL,NULL,NULL,'',NULL,NULL,0,'',NULL,'2026-07-05 22:39:54'),
(9,'ORD17837231948',7,'',0,'','purchase','',0,'','balance',137.37,0,0.00,0.00,'paid',7,NULL,NULL,NULL,'',NULL,NULL,0,'',NULL,'2026-06-29 22:39:54'),
(10,'ORD17837231949',13,'',0,'','purchase','',0,'','balance',125.98,0,0.00,0.00,'paid',7,NULL,NULL,NULL,'',NULL,NULL,0,'',NULL,'2026-06-13 22:39:54'),
(11,'MOMRG56M0YZHEW',19,'alexmorgan',0,'','membership','购买黄金会员',0,'','points',1300.00,0,0.00,1300.00,'completed',7,'2026-07-18 09:08:18','2026-07-11 09:08:18','2026-07-11 09:15:07','',NULL,NULL,0,'',NULL,'2026-07-11 09:08:18'),
(12,'MOMRG5EOSU5FWW',19,'alexmorgan',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'completed',7,'2026-07-18 09:14:35','2026-07-11 09:14:35','2026-07-11 09:15:06','',NULL,NULL,0,'',NULL,'2026-07-11 09:14:35'),
(13,'MOMRG5ER54XYLJ',19,'alexmorgan',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'completed',7,'2026-07-18 09:14:38','2026-07-11 09:14:38','2026-07-11 09:15:03','',NULL,NULL,0,'',NULL,'2026-07-11 09:14:38'),
(14,'MOMRGTSGBB9TLF',1,'bobwang',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'shipped',7,'2026-07-18 20:37:08','2026-07-11 20:37:08',NULL,'',NULL,NULL,0,'',NULL,'2026-07-11 20:37:08'),
(15,'MOMRGTUCDK3DNE',4,'design_master',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'shipped',7,'2026-07-18 20:38:36','2026-07-11 20:38:36',NULL,'',NULL,NULL,0,'',NULL,'2026-07-11 20:38:36'),
(16,'MOMRGTUU7OFOKT',20,'testgift',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'shipped',7,'2026-07-18 20:38:59','2026-07-11 20:38:59',NULL,'',NULL,NULL,0,'',NULL,'2026-07-11 20:38:59'),
(17,'MOMRGTV0LR3ZZX',20,'testgift',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'shipped',7,'2026-07-18 20:39:07','2026-07-11 20:39:07',NULL,'',NULL,NULL,0,'',NULL,'2026-07-11 20:39:07'),
(18,'MOMRGU8MPOFVJ9',21,'testcoupon',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'shipped',7,'2026-07-18 20:49:43','2026-07-11 20:49:43',NULL,'',NULL,NULL,0,'',NULL,'2026-07-11 20:49:43'),
(19,'MOMRGU8UU8DEZE',21,'testcoupon',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'shipped',7,'2026-07-18 20:49:53','2026-07-11 20:49:53',NULL,'',NULL,NULL,0,'',NULL,'2026-07-11 20:49:53'),
(20,'MOMRGUVIXAUQ35',22,'titletest',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'shipped',7,'2026-07-18 21:07:31','2026-07-11 21:07:31',NULL,'',NULL,NULL,0,'',NULL,'2026-07-11 21:07:31'),
(21,'MOMRGUWL8VTG0N',23,'birthdaytest',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'shipped',7,'2026-07-18 21:08:21','2026-07-11 21:08:21',NULL,'',NULL,NULL,0,'',NULL,'2026-07-11 21:08:21'),
(22,'MOMRH1FPH8CYRU',19,'alexmorgan',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,5.00,'shipped',7,'2026-07-19 00:11:10','2026-07-12 00:11:10',NULL,'',NULL,NULL,0,'',NULL,'2026-07-12 00:11:10');
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plugins`
--

DROP TABLE IF EXISTS `plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `plugins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `version` varchar(50) DEFAULT '1.0.0',
  `author` varchar(100) DEFAULT '',
  `icon` varchar(500) DEFAULT '',
  `entry_url` varchar(500) DEFAULT '',
  `component_name` varchar(200) DEFAULT '',
  `plugin_dir` varchar(100) DEFAULT '',
  `manifest` text DEFAULT NULL,
  `enabled` int(11) DEFAULT 1,
  `sort_order` int(11) DEFAULT 0,
  `points` int(11) DEFAULT 0,
  `points_name` varchar(20) DEFAULT '金币',
  `tags` text DEFAULT NULL,
  `format` varchar(20) DEFAULT 'package',
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plugins`
--

LOCK TABLES `plugins` WRITE;
/*!40000 ALTER TABLE `plugins` DISABLE KEYS */;
INSERT INTO `plugins` VALUES
(1,'SEO优化','内置SEO优化工具','1.0.0','','','','','',NULL,1,0,0,'金币',NULL,'package','1','2026-07-10 22:39:54'),
(2,'数据统计','网站数据统计分析','1.2.0','','','','','',NULL,1,0,0,'金币',NULL,'package','1','2026-07-10 22:39:54'),
(3,'广告管理','广告位管理插件','0.9.0','','','','','',NULL,1,0,0,'金币',NULL,'package','1','2026-07-10 22:39:54'),
(4,'第三方登录','支持微信/QQ/微博登录','2.0.1','','','','','',NULL,0,0,0,'金币',NULL,'package','1','2026-07-10 22:39:54'),
(5,'地图组件','集成高德地图组件','1.1.0','','','','','',NULL,1,0,0,'金币',NULL,'package','1','2026-07-10 22:39:54');
/*!40000 ALTER TABLE `plugins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `points_records`
--

DROP TABLE IF EXISTS `points_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `points_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `type` varchar(20) NOT NULL DEFAULT 'earn',
  `points` int(11) NOT NULL DEFAULT 0,
  `balance` int(11) DEFAULT 0,
  `source` varchar(200) DEFAULT '',
  `description` text DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  `ref_id` int(11) DEFAULT 0,
  `ref_type` varchar(50) DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `idx_points_records_user_id` (`user_id`),
  KEY `idx_points_records_type` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `points_records`
--

LOCK TABLES `points_records` WRITE;
/*!40000 ALTER TABLE `points_records` DISABLE KEYS */;
INSERT INTO `points_records` VALUES
(1,13,'','checkin',53,0,'','获得积分 +53','2026-06-22 22:39:54',0,''),
(2,5,'','post',14,0,'','获得积分 +14','2026-06-11 22:39:54',0,''),
(3,13,'','comment',43,0,'','获得积分 +43','2026-07-08 22:39:54',0,''),
(4,8,'','invite',11,0,'','获得积分 +11','2026-07-08 22:39:54',0,''),
(5,15,'','purchase',21,0,'','获得积分 +21','2026-06-21 22:39:54',0,''),
(6,12,'','checkin',55,0,'','获得积分 +55','2026-06-11 22:39:54',0,''),
(7,15,'','post',11,0,'','获得积分 +11','2026-06-29 22:39:54',0,''),
(8,2,'','comment',19,0,'','获得积分 +19','2026-07-05 22:39:54',0,''),
(9,15,'','invite',23,0,'','获得积分 +23','2026-06-22 22:39:54',0,''),
(10,10,'','purchase',55,0,'','获得积分 +55','2026-07-10 22:39:54',0,''),
(11,15,'','checkin',34,0,'','获得积分 +34','2026-06-28 22:39:54',0,''),
(12,5,'','post',55,0,'','获得积分 +55','2026-06-12 22:39:54',0,''),
(13,5,'','comment',43,0,'','获得积分 +43','2026-06-13 22:39:54',0,''),
(14,10,'','invite',14,0,'','获得积分 +14','2026-06-19 22:39:54',0,''),
(15,11,'','purchase',47,0,'','获得积分 +47','2026-06-13 22:39:54',0,''),
(16,7,'','checkin',34,0,'','获得积分 +34','2026-06-23 22:39:54',0,''),
(17,2,'','post',22,0,'','获得积分 +22','2026-06-19 22:39:54',0,''),
(18,6,'','comment',11,0,'','获得积分 +11','2026-06-24 22:39:54',0,''),
(19,15,'','invite',12,0,'','获得积分 +12','2026-06-25 22:39:54',0,''),
(20,14,'','purchase',23,0,'','获得积分 +23','2026-06-26 22:39:54',0,''),
(21,3,'','checkin',15,0,'','获得积分 +15','2026-06-16 22:39:54',0,''),
(22,8,'','post',24,0,'','获得积分 +24','2026-06-14 22:39:54',0,''),
(23,6,'','comment',13,0,'','获得积分 +13','2026-06-19 22:39:54',0,''),
(24,13,'','invite',13,0,'','获得积分 +13','2026-07-01 22:39:54',0,''),
(25,4,'','purchase',19,0,'','获得积分 +19','2026-06-18 22:39:54',0,''),
(26,5,'','checkin',22,0,'','获得积分 +22','2026-07-04 22:39:54',0,''),
(27,12,'','post',44,0,'','获得积分 +44','2026-06-17 22:39:54',0,''),
(28,13,'','comment',44,0,'','获得积分 +44','2026-07-01 22:39:54',0,''),
(29,4,'','invite',53,0,'','获得积分 +53','2026-07-01 22:39:54',0,''),
(30,15,'','purchase',27,0,'','获得积分 +27','2026-06-22 22:39:54',0,''),
(31,19,'alexmorgan','earn',99999,99999,'卡密兑换','使用卡密 CDKEY-MRG47L1VS1EE 额外获得99999积分','2026-07-11 08:41:23',0,''),
(32,19,'alexmorgan','expense',1300,98699,'会员购买','购买黄金会员','2026-07-11 09:04:46',0,''),
(33,19,'alexmorgan','expense',1300,97399,'会员购买','购买黄金会员','2026-07-11 09:08:18',0,''),
(34,1,'bobwang','earn',50,1550,'会员开通赠送','开通黄金会员赠送积分','2026-07-11 20:37:08',0,''),
(35,4,'design_master','earn',50,350,'会员开通赠送','开通黄金会员赠送积分','2026-07-11 20:38:36',0,''),
(38,21,'testcoupon','earn',150,650,'会员开通赠送','开通黄金会员赠送积分','2026-07-11 20:49:43',0,''),
(39,21,'testcoupon','earn',50,700,'会员开通赠送','开通黄金会员赠送积分','2026-07-11 20:49:53',0,''),
(40,22,'titletest','earn',150,650,'会员开通赠送','开通黄金会员赠送积分','2026-07-11 21:07:31',0,''),
(41,23,'birthdaytest','earn',150,650,'会员开通赠送','开通黄金会员赠送积分','2026-07-11 21:08:20',0,''),
(42,19,'alexmorgan','earn',50,96819,'会员开通赠送','开通黄金会员赠送积分','2026-07-12 00:11:10',0,'');
/*!40000 ALTER TABLE `points_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `points_transfer_records`
--

DROP TABLE IF EXISTS `points_transfer_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `points_transfer_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from_user_id` int(11) NOT NULL,
  `from_user_name` varchar(100) DEFAULT '',
  `to_user_id` int(11) NOT NULL,
  `to_user_name` varchar(100) DEFAULT '',
  `amount` int(11) NOT NULL DEFAULT 0,
  `fee` int(11) DEFAULT 0,
  `remark` varchar(300) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `points_transfer_records`
--

LOCK TABLES `points_transfer_records` WRITE;
/*!40000 ALTER TABLE `points_transfer_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `points_transfer_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post_favorites`
--

DROP TABLE IF EXISTS `post_favorites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `post_favorites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`post_id`),
  KEY `idx_post_favorites_user` (`user_id`),
  KEY `idx_post_favorites_post` (`post_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_favorites`
--

LOCK TABLES `post_favorites` WRITE;
/*!40000 ALTER TABLE `post_favorites` DISABLE KEYS */;
/*!40000 ALTER TABLE `post_favorites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `private_messages`
--

DROP TABLE IF EXISTS `private_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `private_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from_user_id` int(11) NOT NULL,
  `from_user_name` varchar(100) DEFAULT '',
  `from_user_avatar` varchar(20) DEFAULT '#448AFF',
  `to_user_id` int(11) NOT NULL,
  `content` text DEFAULT '',
  `is_read` tinyint(1) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  `image_url` varchar(500) DEFAULT '',
  `message_type` varchar(20) DEFAULT 'text',
  `order_card` text DEFAULT NULL,
  `is_recalled` tinyint(1) DEFAULT 0,
  `report_status` varchar(20) DEFAULT 'none',
  PRIMARY KEY (`id`),
  KEY `idx_private_messages_from` (`from_user_id`),
  KEY `idx_private_messages_to` (`to_user_id`),
  KEY `idx_private_messages_conversation` (`from_user_id`,`to_user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `private_messages`
--

LOCK TABLES `private_messages` WRITE;
/*!40000 ALTER TABLE `private_messages` DISABLE KEYS */;
INSERT INTO `private_messages` VALUES
(1,12,'','#448AFF',15,'你好，这是私信消息 #1',0,'2026-07-10 22:39:53','','text',NULL,0,'none'),
(2,7,'','#448AFF',15,'你好，这是私信消息 #2',0,'2026-07-04 22:39:53','','text',NULL,0,'none'),
(3,6,'','#448AFF',6,'你好，这是私信消息 #3',0,'2026-07-05 22:39:53','','text',NULL,0,'none'),
(4,14,'','#448AFF',15,'你好，这是私信消息 #4',0,'2026-07-05 22:39:53','','text',NULL,0,'none'),
(5,5,'','#448AFF',15,'你好，这是私信消息 #5',0,'2026-07-07 22:39:53','','text',NULL,0,'none'),
(6,7,'','#448AFF',13,'你好，这是私信消息 #6',0,'2026-07-04 22:39:53','','text',NULL,0,'none'),
(7,5,'','#448AFF',9,'你好，这是私信消息 #7',0,'2026-07-08 22:39:53','','text',NULL,0,'none'),
(8,13,'','#448AFF',3,'你好，这是私信消息 #8',0,'2026-07-04 22:39:53','','text',NULL,0,'none'),
(9,14,'','#448AFF',13,'你好，这是私信消息 #9',0,'2026-07-07 22:39:53','','text',NULL,0,'none'),
(10,12,'','#448AFF',15,'你好，这是私信消息 #10',0,'2026-07-07 22:39:53','','text',NULL,0,'none'),
(11,2,'','#448AFF',6,'你好，这是私信消息 #11',0,'2026-07-05 22:39:53','','text',NULL,0,'none'),
(12,5,'','#448AFF',13,'你好，这是私信消息 #12',0,'2026-07-08 22:39:53','','text',NULL,0,'none'),
(13,5,'','#448AFF',6,'你好，这是私信消息 #13',0,'2026-07-08 22:39:53','','text',NULL,0,'none'),
(14,5,'','#448AFF',6,'你好，这是私信消息 #14',0,'2026-07-09 22:39:53','','text',NULL,0,'none'),
(15,3,'','#448AFF',13,'你好，这是私信消息 #15',0,'2026-07-08 22:39:53','','text',NULL,0,'none'),
(16,19,'alexmorgan','#448AFF',5,'您的应用\"Weather AI\"已被管理员置顶',0,'2026-07-11 11:42:47','','text','',0,'none'),
(17,19,'alexmorgan','#448AFF',5,'您的应用\"Weather AI\"已被管理员设为官方认证',0,'2026-07-11 11:42:48','','text','',0,'none'),
(18,19,'alexmorgan','#448AFF',5,'您的应用\"Weather AI\"已被管理员设为精品推荐',0,'2026-07-11 11:42:50','','text','',0,'none'),
(19,19,'alexmorgan','#448AFF',12,'https://3333-fe31014d9fefaa9c.monkeycode-ai.online/#/u/12',0,'2026-07-11 11:47:07','','text','',0,'none'),
(20,19,'alexmorgan','#448AFF',12,'6',0,'2026-07-11 11:47:09','','text','',0,'none'),
(21,19,'alexmorgan','#448AFF',12,'[订单]',0,'2026-07-11 11:47:12','','order_card','{\"id\":13,\"orderNo\":\"MOMRG5ER54XYLJ\",\"orderType\":\"membership\",\"orderDesc\":\"购买黄金会员\",\"totalAmount\":\"10.00\",\"paidAmount\":\"10.00\",\"payType\":\"balance\",\"status\":\"completed\",\"createTime\":\"2026-07-11T01:14:38.000Z\"}',0,'none'),
(22,19,'alexmorgan','#448AFF',12,'',0,'2026-07-11 11:47:25','/uploads/chat_1783770445534_8120.jpg','text','',0,'none');
/*!40000 ALTER TABLE `private_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recharge_amounts`
--

DROP TABLE IF EXISTS `recharge_amounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `recharge_amounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `label` varchar(100) DEFAULT '',
  `discount` varchar(100) DEFAULT '',
  `status` tinyint(1) DEFAULT 1,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recharge_amounts`
--

LOCK TABLES `recharge_amounts` WRITE;
/*!40000 ALTER TABLE `recharge_amounts` DISABLE KEYS */;
INSERT INTO `recharge_amounts` VALUES
(5,10.00,'CRUD Test 10','',1,'2026-07-10 20:17:40');
/*!40000 ALTER TABLE `recharge_amounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recharge_orders`
--

DROP TABLE IF EXISTS `recharge_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `recharge_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_no` varchar(64) NOT NULL,
  `user_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `pay_method` varchar(20) DEFAULT 'epay',
  `status` varchar(20) DEFAULT 'pending',
  `trade_no` varchar(100) DEFAULT '',
  `paid_time` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_recharge_orders_user` (`user_id`),
  KEY `idx_recharge_orders_order_no` (`order_no`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recharge_orders`
--

LOCK TABLES `recharge_orders` WRITE;
/*!40000 ALTER TABLE `recharge_orders` DISABLE KEYS */;
INSERT INTO `recharge_orders` VALUES
(1,'RCH17837231939640',9,10.00,'epay','paid','','2026-07-09 22:39:53','2026-06-13 22:39:53'),
(2,'RCH17837231939651',5,30.00,'epay','paid','','2026-07-02 22:39:53','2026-06-21 22:39:53'),
(3,'RCH17837231939652',2,50.00,'epay','paid','','2026-07-09 22:39:53','2026-06-16 22:39:53'),
(4,'RCH17837231939663',6,98.00,'epay','paid','','2026-06-20 22:39:53','2026-06-26 22:39:53'),
(5,'RCH17837231939664',15,198.00,'epay','paid','','2026-07-06 22:39:53','2026-06-27 22:39:53'),
(6,'RCH17837231939665',8,298.00,'epay','paid','','2026-07-03 22:39:53','2026-07-04 22:39:53'),
(7,'RCH17837231939676',9,10.00,'epay','paid','','2026-06-24 22:39:53','2026-07-07 22:39:53'),
(8,'RCH17837231939677',6,30.00,'epay','paid','','2026-06-20 22:39:53','2026-06-14 22:39:53'),
(9,'RCH17837231939678',14,50.00,'epay','paid','','2026-07-06 22:39:53','2026-06-28 22:39:53'),
(10,'RCH17837231939689',15,98.00,'epay','pending','',NULL,'2026-06-24 22:39:53'),
(11,'RCH178372319396810',14,198.00,'epay','pending','',NULL,'2026-07-04 22:39:53'),
(12,'RCH178372319396911',4,298.00,'epay','pending','',NULL,'2026-06-21 22:39:53');
/*!40000 ALTER TABLE `recharge_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recycle_bin`
--

DROP TABLE IF EXISTS `recycle_bin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `recycle_bin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `original_table` varchar(100) NOT NULL,
  `original_id` int(11) NOT NULL,
  `data_json` text NOT NULL,
  `deleted_by` int(11) DEFAULT 0,
  `deleted_by_name` varchar(100) DEFAULT '',
  `delete_reason` varchar(500) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_recycle_bin_table` (`original_table`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recycle_bin`
--

LOCK TABLES `recycle_bin` WRITE;
/*!40000 ALTER TABLE `recycle_bin` DISABLE KEYS */;
/*!40000 ALTER TABLE `recycle_bin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `referral_links`
--

DROP TABLE IF EXISTS `referral_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `referral_links` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `code` varchar(32) NOT NULL,
  `mode` varchar(20) DEFAULT 'purchase',
  `discount` decimal(5,2) DEFAULT 0.00,
  `click_count` int(11) DEFAULT 0,
  `register_count` int(11) DEFAULT 0,
  `purchase_count` int(11) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  UNIQUE KEY `code` (`code`),
  KEY `idx_referral_links_code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `referral_links`
--

LOCK TABLES `referral_links` WRITE;
/*!40000 ALTER TABLE `referral_links` DISABLE KEYS */;
INSERT INTO `referral_links` VALUES
(1,4,'REF-965vi41','purchase',0.00,0,0,0,'2026-07-10 22:39:54'),
(2,9,'REF-t0omukq','purchase',0.00,0,0,0,'2026-07-10 22:39:54'),
(4,14,'REF-rnrw7sk','purchase',0.00,0,0,0,'2026-07-10 22:39:54'),
(5,15,'REF-bjco7s0','purchase',0.00,0,0,0,'2026-07-10 22:39:54');
/*!40000 ALTER TABLE `referral_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_permissions`
--

DROP TABLE IF EXISTS `role_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `auth_mark` varchar(100) DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_menu_auth` (`role_id`,`menu_id`,`auth_mark`)
) ENGINE=InnoDB AUTO_INCREMENT=882 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_permissions`
--

LOCK TABLES `role_permissions` WRITE;
/*!40000 ALTER TABLE `role_permissions` DISABLE KEYS */;
INSERT INTO `role_permissions` VALUES
(761,20,1,NULL),
(687,20,2,NULL),
(688,20,3,NULL),
(689,20,4,NULL),
(690,20,5,NULL),
(691,20,6,NULL),
(762,20,7,NULL),
(692,20,8,NULL),
(693,20,9,NULL),
(694,20,10,NULL),
(695,20,11,NULL),
(696,20,12,NULL),
(697,20,13,NULL),
(698,20,14,NULL),
(699,20,15,NULL),
(700,20,16,NULL),
(701,20,17,NULL),
(702,20,18,NULL),
(703,20,19,NULL),
(704,20,20,NULL),
(705,20,21,NULL),
(706,20,22,NULL),
(707,20,23,NULL),
(708,20,24,NULL),
(709,20,24,'add'),
(710,20,24,'delete'),
(711,20,24,'edit'),
(712,20,25,NULL),
(713,20,26,NULL),
(714,20,27,NULL),
(715,20,28,NULL),
(716,20,29,NULL),
(717,20,30,NULL),
(718,20,31,NULL),
(719,20,32,NULL),
(720,20,33,NULL),
(721,20,34,NULL),
(722,20,35,NULL),
(723,20,36,NULL),
(724,20,37,NULL),
(725,20,38,NULL),
(726,20,39,NULL),
(727,20,40,NULL),
(731,20,44,NULL),
(732,20,45,NULL),
(733,20,45,'add'),
(734,20,45,'delete'),
(735,20,45,'edit'),
(736,20,45,'moderate'),
(737,20,45,'toggle'),
(738,20,45,'unlock'),
(739,20,46,NULL),
(740,20,46,'approve'),
(741,20,46,'boost'),
(742,20,46,'delete'),
(743,20,46,'edit'),
(744,20,46,'essence'),
(745,20,46,'lock'),
(746,20,46,'pin'),
(747,20,47,NULL),
(748,20,47,'delete'),
(749,20,47,'handle'),
(750,20,47,'ignore'),
(751,20,48,NULL),
(752,20,48,'delete'),
(753,20,48,'pin'),
(754,20,49,NULL),
(755,20,50,NULL),
(756,20,51,NULL),
(757,20,52,NULL),
(758,20,53,NULL),
(759,20,54,NULL),
(760,20,55,NULL),
(839,20,57,NULL),
(844,20,57,'add'),
(846,20,57,'delete'),
(845,20,57,'edit'),
(847,20,57,'toggle'),
(840,20,58,NULL),
(848,20,58,'edit'),
(849,20,58,'export'),
(841,20,59,NULL),
(850,20,59,'add'),
(852,20,59,'delete'),
(851,20,59,'edit'),
(842,20,60,NULL),
(853,20,60,'edit'),
(843,20,61,NULL),
(854,20,61,'add'),
(856,20,61,'delete'),
(855,20,61,'edit'),
(857,20,61,'toggle'),
(858,20,62,NULL),
(864,20,62,'add'),
(866,20,62,'delete'),
(865,20,62,'edit'),
(867,20,62,'toggle'),
(859,20,63,NULL),
(868,20,63,'add'),
(870,20,63,'delete'),
(869,20,63,'edit'),
(860,20,64,NULL),
(871,20,64,'add'),
(873,20,64,'delete'),
(872,20,64,'edit'),
(861,20,65,NULL),
(874,20,65,'edit'),
(862,20,66,NULL),
(875,20,66,'add'),
(877,20,66,'delete'),
(876,20,66,'edit'),
(863,20,67,NULL),
(878,20,67,'edit'),
(879,20,68,NULL),
(880,20,68,'add'),
(881,20,68,'delete'),
(763,22,1,NULL),
(764,22,2,NULL),
(765,22,3,NULL),
(766,22,4,NULL),
(767,22,5,NULL),
(768,22,6,NULL),
(769,22,7,NULL),
(770,22,8,NULL),
(771,22,9,NULL),
(772,22,10,NULL),
(773,22,11,NULL),
(774,22,12,NULL),
(775,22,13,NULL),
(776,22,14,NULL),
(777,22,15,NULL),
(778,22,16,NULL),
(779,22,17,NULL),
(780,22,18,NULL),
(781,22,19,NULL),
(782,22,20,NULL),
(783,22,21,NULL),
(784,22,22,NULL),
(785,22,23,NULL),
(786,22,24,NULL),
(787,22,24,'add'),
(789,22,24,'delete'),
(788,22,24,'edit'),
(790,22,25,NULL),
(791,22,26,NULL),
(792,22,27,NULL),
(793,22,28,NULL),
(794,22,29,NULL),
(795,22,30,NULL),
(796,22,31,NULL),
(797,22,32,NULL),
(798,22,33,NULL),
(799,22,34,NULL),
(800,22,35,NULL),
(801,22,36,NULL),
(802,22,37,NULL),
(803,22,38,NULL),
(804,22,39,NULL),
(805,22,40,NULL),
(809,22,44,NULL),
(810,22,45,NULL),
(811,22,45,'add'),
(813,22,45,'delete'),
(812,22,45,'edit'),
(814,22,45,'moderate'),
(815,22,45,'toggle'),
(816,22,45,'unlock'),
(817,22,46,NULL),
(822,22,46,'approve'),
(820,22,46,'boost'),
(824,22,46,'delete'),
(823,22,46,'edit'),
(819,22,46,'essence'),
(821,22,46,'lock'),
(818,22,46,'pin'),
(825,22,47,NULL),
(828,22,47,'delete'),
(826,22,47,'handle'),
(827,22,47,'ignore'),
(829,22,48,NULL),
(831,22,48,'delete'),
(830,22,48,'pin'),
(832,22,49,NULL),
(833,22,50,NULL),
(834,22,51,NULL),
(835,22,52,NULL),
(836,22,53,NULL),
(837,22,54,NULL),
(838,22,55,NULL);
/*!40000 ALTER TABLE `role_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(100) NOT NULL,
  `role_code` varchar(100) NOT NULL,
  `description` varchar(500) DEFAULT '',
  `enabled` tinyint(1) DEFAULT 1,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_code` (`role_code`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES
(20,'管理员','R_ADMIN','系统管理员',1,'2026-07-10 22:42:45'),
(21,'普通用户','R_USER','普通用户',1,'2026-07-10 22:42:45'),
(22,'系统超级管理员','R_SUPER','',1,'2026-07-11 12:47:10');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `section_moderators`
--

DROP TABLE IF EXISTS `section_moderators`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `section_moderators` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `section_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `section_id` (`section_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `section_moderators`
--

LOCK TABLES `section_moderators` WRITE;
/*!40000 ALTER TABLE `section_moderators` DISABLE KEYS */;
/*!40000 ALTER TABLE `section_moderators` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sensitive_words`
--

DROP TABLE IF EXISTS `sensitive_words`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sensitive_words` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `word` varchar(100) NOT NULL,
  `category` varchar(20) DEFAULT 'general',
  `enabled` tinyint(1) DEFAULT 1,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sensitive_words`
--

LOCK TABLES `sensitive_words` WRITE;
/*!40000 ALTER TABLE `sensitive_words` DISABLE KEYS */;
INSERT INTO `sensitive_words` VALUES
(1,'广告推广','text',1,'2026-07-10 22:39:54'),
(2,'虚假信息','text',1,'2026-07-10 22:39:54'),
(3,'恶意攻击','text',1,'2026-07-10 22:39:54'),
(4,'非法内容','text',1,'2026-07-10 22:39:54'),
(5,'侵权内容','text',1,'2026-07-10 22:39:54');
/*!40000 ALTER TABLE `sensitive_words` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `token` varchar(100) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `roles` text DEFAULT '[]',
  `created_at` bigint(20) NOT NULL,
  PRIMARY KEY (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES
('tk-mrfk5okg-129851np',19,'alexmorgan','[\"R_SUPER\"]',1783725583264),
('tk-mrg46qdb-szhx7sqc',19,'alexmorgan','[\"R_SUPER\"]',1783759224575),
('tk-mrgad3qw-rnrp4va8',19,'alexmorgan','[\"R_SUPER\"]',1783769599544),
('tk-mrgc0orx-p0nsa89s',1,'bobwang','[\"R_USER\"]',1783772379501),
('tk-mrgc0ow4-uotcfq2l',3,'tech_guru','[\"R_USER\"]',1783772379652),
('tk-mrgc0p08-pqa1qoo4',4,'design_master','[\"R_USER\"]',1783772379800),
('tk-mrgchwgo-dz58oa1n',19,'alexmorgan','[\"R_SUPER\"]',1783773182616),
('tk-mrgcjyhh-sja3mo7z',19,'alexmorgan','[\"R_SUPER\"]',1783773278549),
('tk-mrgcnsb3-t3h6lw3t',19,'alexmorgan','[\"R_SUPER\"]',1783773457167),
('tk-mrgcpony-68g949q2',19,'alexmorgan','[\"R_SUPER\"]',1783773545758),
('tk-mrgcpzf7-n662s75k',19,'alexmorgan','[\"R_SUPER\"]',1783773559699),
('tk-mrgcq6mv-8z38m2ei',19,'alexmorgan','[\"R_SUPER\"]',1783773569047),
('tk-mrgcsjbk-m4hsv33u',19,'alexmorgan','[\"R_SUPER\"]',1783773678800),
('tk-mrgd3k5l-hmyipn7o',19,'alexmorgan','[\"R_SUPER\"]',1783774193097),
('tk-mrgd6163-xfdq1u97',19,'alexmorgan','[\"R_SUPER\"]',1783774308459),
('tk-mrgjd87i-58ot74sd',19,'alexmorgan','[\"R_SUPER\"]',1783784721870),
('tk-mrgjdea1-cpg9s9kk',19,'alexmorgan','[\"R_SUPER\"]',1783784729737),
('tk-mrgje0bo-4vdtv9wd',19,'alexmorgan','[\"R_SUPER\"]',1783784758308),
('tk-mrgskq3c-h4w2r8p4',19,'alexmorgan','[\"R_SUPER\"]',1783800188184),
('tk-mrgstn55-tt0eerxs',1,'bobwang','[\"R_USER\"]',1783800604265),
('tk-mrgsvtp9-tgtvzqn3',19,'alexmorgan','[\"R_SUPER\"]',1783800706077),
('tk-mrgtrv11-a5zppgie',19,'alexmorgan','[\"R_SUPER\"]',1783802200789),
('tk-mrgts99p-vma1ciui',1,'bobwang','[\"R_USER\"]',1783802219245),
('tk-mrgtucc7-1xz6xtv9',4,'design_master','[\"R_USER\"]',1783802316535),
('tk-mrgtuu63-8c5iku9t',20,'testgift','[]',1783802339643),
('tk-mrgu69ep-98uq3tzm',19,'alexmorgan','[\"R_SUPER\"]',1783802872609),
('tk-mrgu6lr1-5roepkbp',21,'testcoupon','[]',1783802888605),
('tk-mrgu6xgw-746zygcl',21,'testcoupon','[]',1783802903792),
('tk-mrgu8mog-a4nbvjy0',21,'testcoupon','[]',1783802983120),
('tk-mrgu8usw-rh8mlgoa',21,'testcoupon','[]',1783802993648),
('tk-mrguv54m-whr72x3e',19,'alexmorgan','[\"R_SUPER\"]',1783804033462),
('tk-mrguvbql-q0tsuz5j',22,'titletest','[]',1783804042029),
('tk-mrguvivz-6iwhngeh',22,'titletest','[]',1783804051295),
('tk-mrguwd7a-9ktuzfyp',22,'titletest','[]',1783804090582),
('tk-mrguwl7b-gv9tg7jt',23,'birthdaytest','[]',1783804100951),
('tk-mrguzcqy-esg4s3id',23,'birthdaytest','[]',1783804229962),
('tk-mrgvakky-j0i1gyj2',19,'alexmorgan','[\"R_SUPER\"]',1783804753330),
('tk-mrgwwogp-n5paqkpk',19,'alexmorgan','[\"R_SUPER\"]',1783807464409),
('tk-mrh16338-qbd0g9g6',19,'alexmorgan','[\"R_SUPER\"]',1783814621732),
('tk-mrh185ch-oayzmdi1',1,'bobwang','[\"R_USER\"]',1783814717969),
('tk-mrh23uv4-5cohapg8',19,'alexmorgan','[\"R_SUPER\"]',1783816197377),
('tk-mrh711lj-pz1iqkbe',19,'alexmorgan','[\"R_SUPER\"]',1783824464215),
('tk-mrh7czzy-rykk5w4b',1,'bobwang','[\"R_USER\"]',1783825022014),
('tk-mrh7d98a-t5h0d143',1,'bobwang','[\"R_USER\"]',1783825033978),
('tk-mrh7d9bd-a1u7de3u',2,'lisa_chen','[\"R_USER\"]',1783825034089),
('tk-mrh7hn20-d0hoxp4d',1,'bobwang','[\"R_USER\"]',1783825238520),
('tk-mrh7m729-gnizj7pl',1,'bobwang','[\"R_USER\"]',1783825451073),
('tk-mrh7nmyb-y8xdvqbk',1,'bobwang','[\"R_USER\"]',1783825518323),
('tk-mrh81vp3-hkvdsmuj',1,'bobwang','[\"R_USER\"]',1783826182839),
('tk-mrh86kp3-8v7j3txx',1,'bobwang','[\"R_USER\"]',1783826401863),
('tk-mrhijcil-ua6l9ulj',1,'bobwang','[\"R_USER\"]',1783843793949),
('tk-mrhjkkut-2b2wzuzy',1,'bobwang','[\"R_USER\"]',1783845531029),
('tk-mrhjkvhl-7ckkrp8w',1,'bobwang','[\"R_USER\"]',1783845544809),
('tk-mrhjl91d-2fa2mclr',1,'bobwang','[\"R_USER\"]',1783845562369),
('tk-mrhjll17-b1rzt2b3',1,'bobwang','[\"R_USER\"]',1783845577915),
('tk-mrhjm8qq-zhs97kcl',1,'bobwang','[\"R_USER\"]',1783845608642),
('tk-mrhjmi96-gldyh1nq',19,'alexmorgan','[\"R_SUPER\"]',1783845620970),
('tk-mrhjn32t-x8vws6e5',1,'bobwang','[\"R_USER\"]',1783845647957),
('tk-mrhjnc9f-i0w4l3on',19,'alexmorgan','[\"R_SUPER\"]',1783845659859),
('tk-mrhjncgs-n2b1u8aw',1,'bobwang','[\"R_USER\"]',1783845660124),
('tk-mrhjnp9e-w0v3odoc',1,'bobwang','[\"R_USER\"]',1783845676706),
('tk-mrhjnzbq-9uzv4am0',19,'alexmorgan','[\"R_SUPER\"]',1783845689750),
('tk-mrhjohmz-7trp2ig3',1,'bobwang','[\"R_USER\"]',1783845713484),
('tk-mrhjvyfw-j46vyzta',1,'bobwang','[\"R_USER\"]',1783846061852),
('tk-mrhjwobr-j7t1d8xm',1,'bobwang','[\"R_USER\"]',1783846095399);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settlement_config`
--

DROP TABLE IF EXISTS `settlement_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `settlement_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `level_id` int(11) DEFAULT 0,
  `level_name` varchar(100) DEFAULT '普通用户',
  `confirm_days` int(11) DEFAULT 7,
  `enabled` int(11) DEFAULT 1,
  `balance_transfer_enabled` int(11) DEFAULT 1,
  `points_transfer_enabled` int(11) DEFAULT 1,
  `single_min_balance` decimal(10,2) DEFAULT 0.00,
  `single_max_balance` decimal(10,2) DEFAULT 0.00,
  `single_min_points` int(11) DEFAULT 0,
  `single_max_points` int(11) DEFAULT 0,
  `daily_limit_balance_amount` decimal(10,2) DEFAULT 0.00,
  `daily_limit_points_amount` int(11) DEFAULT 0,
  `daily_limit_times` int(11) DEFAULT 0,
  `weekly_limit_times` int(11) DEFAULT 0,
  `yearly_limit_times` int(11) DEFAULT 0,
  `balance_transfer_fee` decimal(5,2) DEFAULT 0.00,
  `points_transfer_fee` decimal(5,2) DEFAULT 0.00,
  `balance_to_points_rate` decimal(10,2) DEFAULT 1.00,
  `points_to_balance_rate` decimal(10,2) DEFAULT 1.00,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settlement_config`
--

LOCK TABLES `settlement_config` WRITE;
/*!40000 ALTER TABLE `settlement_config` DISABLE KEYS */;
INSERT INTO `settlement_config` VALUES
(1,0,'默认结算',7,1,1,1,0.00,0.00,0,0,0.00,0,0,0,0,0.00,0.00,1.00,1.00,'2026-07-10 22:39:54');
/*!40000 ALTER TABLE `settlement_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `storage_configs`
--

DROP TABLE IF EXISTS `storage_configs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `storage_configs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(50) DEFAULT 'local',
  `name` varchar(100) DEFAULT '',
  `config` text DEFAULT NULL,
  `is_default` tinyint(1) DEFAULT 0,
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  `endpoint` varchar(500) DEFAULT '',
  `region` varchar(100) DEFAULT '',
  `bucket` varchar(200) DEFAULT '',
  `access_key` varchar(500) DEFAULT '',
  `secret_key` varchar(500) DEFAULT '',
  `local_dir` varchar(500) DEFAULT '',
  `remote_dir` varchar(500) DEFAULT '',
  `expiry_seconds` int(11) DEFAULT 0,
  `base_url` varchar(500) DEFAULT '',
  `applicable_roles` text DEFAULT NULL,
  `applicable_levels` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `storage_configs`
--

LOCK TABLES `storage_configs` WRITE;
/*!40000 ALTER TABLE `storage_configs` DISABLE KEYS */;
INSERT INTO `storage_configs` VALUES
(1,'local','默认存储',NULL,0,'1','2026-07-10 22:39:54','2026-07-10 22:39:54','','','uploads','','','','',0,'',NULL,NULL),
(2,'oss','用户-阿里云OSS',NULL,1,'1','2026-07-11 17:38:58','2026-07-12 03:08:16','oss-cn-hongkong.aliyuncs.com','cn-hongkong','appiapp','LTAI5t6oq445VTWdqXpkw1ud','26V7K8ml5mSSsOR7FDy31LrOCqlG4M','','user/{userId}',3600,'','','all'),
(3,'oss','后台-阿里云OSS',NULL,0,'1','2026-07-11 17:40:44','2026-07-12 03:06:16','oss-cn-hongkong.aliyuncs.com','cn-hongkong','appiapp','LTAI5t6oq445VTWdqXpkw1ud','26V7K8ml5mSSsOR7FDy31LrOCqlG4M','','admin',0,'','','backend');
/*!40000 ALTER TABLE `storage_configs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_config`
--

DROP TABLE IF EXISTS `sys_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `config_key` varchar(100) NOT NULL,
  `config_value` text DEFAULT '',
  `description` varchar(200) DEFAULT '',
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `config_key` (`config_key`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_config`
--

LOCK TABLES `sys_config` WRITE;
/*!40000 ALTER TABLE `sys_config` DISABLE KEYS */;
INSERT INTO `sys_config` VALUES
(1,'system_log_enabled','true','系统日志总开关','2026-07-10 22:42:45'),
(2,'log_enabled_login','true','登录日志开关','2026-07-10 22:42:45'),
(3,'log_enabled_user','true','用户操作日志开关','2026-07-10 22:42:45'),
(4,'log_enabled_operation','true','运营管理日志开关','2026-07-10 22:42:45'),
(5,'log_enabled_content','true','内容管理日志开关','2026-07-10 22:42:45'),
(6,'log_enabled_system','true','系统配置日志开关','2026-07-10 22:42:45'),
(7,'invite_user_enabled','false','用户生成邀请码开关','2026-07-10 22:42:45'),
(8,'invite_user_max','5','用户最大可生成邀请码数','2026-07-10 22:42:45'),
(9,'register_invite_required','false','注册必须邀请码','2026-07-10 22:42:45'),
(10,'commission_enabled','false','推广返佣开关','2026-07-10 22:42:45'),
(11,'commission_mode','purchase','返佣模式','2026-07-10 22:42:45'),
(12,'points_transfer_enabled','false','积分转账开关','2026-07-10 22:42:45'),
(13,'points_transfer_fee','0','积分转账手续费比例%','2026-07-10 22:42:45'),
(14,'balance_transfer_enabled','false','余额转账开关','2026-07-10 22:42:45'),
(15,'balance_transfer_fee','0','余额转账手续费比例%','2026-07-10 22:42:45'),
(16,'points_purchase_enabled','false','积分购买开关','2026-07-10 22:42:45'),
(17,'points_purchase_rate','1','1元等于多少积分','2026-07-10 22:42:45'),
(18,'content_split_enabled','true','创作分成开关','2026-07-10 22:42:45'),
(19,'content_split_global_rate','70','创作分成全局比例%','2026-07-10 22:42:45'),
(20,'checkin_enabled','true','签到功能开关','2026-07-10 22:42:45'),
(21,'topic_create_min_exp_level','3','话题创建最低经验等级','2026-07-11 12:17:24'),
(22,'topic_create_allowed_levels','2,3','允许创建话题的会员等级ID列表','2026-07-11 12:17:24'),
(23,'payment_epay_pid','','','2026-07-11 16:28:08'),
(24,'payment_epay_key','','','2026-07-11 16:28:08'),
(25,'payment_epay_api_url','','','2026-07-11 16:28:08'),
(26,'payment_epay_notify_url','','','2026-07-11 16:28:08'),
(27,'payment_epay_enabled','true','','2026-07-11 16:28:08'),
(28,'payment_alipay_app_id','','','2026-07-11 16:28:08'),
(29,'payment_alipay_private_key','','','2026-07-11 16:28:08'),
(30,'payment_alipay_public_key','','','2026-07-11 16:28:08'),
(31,'payment_alipay_enabled','false','','2026-07-11 16:28:08'),
(32,'payment_wechat_app_id','','','2026-07-11 16:28:08'),
(33,'payment_wechat_mch_id','','','2026-07-11 16:28:08'),
(34,'payment_wechat_api_key','','','2026-07-11 16:28:08'),
(35,'payment_wechat_enabled','false','','2026-07-11 16:28:08');
/*!40000 ALTER TABLE `sys_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_notifications`
--

DROP TABLE IF EXISTS `sys_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `content` text DEFAULT '',
  `type` varchar(20) DEFAULT 'system',
  `target_user_id` int(11) DEFAULT 0,
  `from_user_id` int(11) DEFAULT 0,
  `from_user_name` varchar(100) DEFAULT '',
  `from_user_avatar` varchar(200) DEFAULT '',
  `is_read` tinyint(1) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_sys_notifications_target_user` (`target_user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_notifications`
--

LOCK TABLES `sys_notifications` WRITE;
/*!40000 ALTER TABLE `sys_notifications` DISABLE KEYS */;
INSERT INTO `sys_notifications` VALUES
(1,'系统通知 #1','这是一条重要的系统通知内容。','system',0,0,'','',1,'2026-07-01 22:39:54'),
(2,'系统通知 #2','这是一条重要的系统通知内容。','announcement',0,0,'','',0,'2026-07-06 22:39:54'),
(3,'系统通知 #3','这是一条重要的系统通知内容。','update',0,0,'','',0,'2026-07-08 22:39:54'),
(4,'系统通知 #4','这是一条重要的系统通知内容。','system',0,0,'','',1,'2026-06-29 22:39:54'),
(5,'系统通知 #5','这是一条重要的系统通知内容。','announcement',0,0,'','',0,'2026-06-29 22:39:54'),
(6,'系统通知 #6','这是一条重要的系统通知内容。','update',0,0,'','',0,'2026-07-08 22:39:54'),
(7,'系统通知 #7','这是一条重要的系统通知内容。','system',0,0,'','',1,'2026-06-27 22:39:54'),
(8,'系统通知 #8','这是一条重要的系统通知内容。','announcement',0,0,'','',0,'2026-07-09 22:39:54'),
(9,'卡密兑换成功','您使用卡密 CDKEY-MRG47L1VS1EE 兑换成功，获得：5000元余额、额外99999积分、额外2000经验值','system',19,0,'管理员','',1,'2026-07-11 08:41:23'),
(10,'打赏通知','Alex Morgan 打赏了您的帖子「开源项目推荐合集」1余额','system',7,19,'Alex Morgan','',0,'2026-07-11 11:39:17'),
(11,'打赏成功','您成功打赏了 用户 的帖子「开源项目推荐合集」1余额','system',19,0,'管理员','',0,'2026-07-11 11:39:17'),
(12,'新粉丝','Alex Morgan 关注了您','system',7,19,'Alex Morgan','',0,'2026-07-11 11:39:21'),
(13,'帖子被加精','您的帖子《开源项目推荐合集》已被管理员设为精华','system',7,19,'alexmorgan','',0,'2026-07-11 11:39:23'),
(14,'帖子被设为热帖','您的帖子《开源项目推荐合集》已被管理员设为热帖','system',7,19,'alexmorgan','',0,'2026-07-11 11:39:24'),
(15,'帖子被锁定','您的帖子《开源项目推荐合集》已被管理员锁定','system',7,19,'alexmorgan','',0,'2026-07-11 11:39:26'),
(16,'帖子已解锁','您的帖子《开源项目推荐合集》已被管理员解除锁定','system',7,19,'alexmorgan','',0,'2026-07-11 11:40:52'),
(17,'新粉丝','Alex Morgan 关注了您','system',12,19,'Alex Morgan','',0,'2026-07-11 11:46:49'),
(18,'应用审核通过','您的应用《百变引擎》已通过审核，现在可以在应用商店中查看了','system',19,0,'alexmorgan','',0,'2026-07-11 11:50:41');
/*!40000 ALTER TABLE `sys_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_logs`
--

DROP TABLE IF EXISTS `system_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT 0,
  `user_name` varchar(100) DEFAULT 'system',
  `type` varchar(30) NOT NULL,
  `target_type` varchar(50) DEFAULT '',
  `target_id` int(11) DEFAULT 0,
  `detail` text DEFAULT '',
  `ip` varchar(50) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_system_logs_user` (`user_id`),
  KEY `idx_system_logs_type` (`type`),
  KEY `idx_system_logs_create` (`create_time`)
) ENGINE=InnoDB AUTO_INCREMENT=460 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_logs`
--

LOCK TABLES `system_logs` WRITE;
/*!40000 ALTER TABLE `system_logs` DISABLE KEYS */;
INSERT INTO `system_logs` VALUES
(254,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.208.169','2026-07-10 22:45:06'),
(255,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.209.169','2026-07-10 22:45:13'),
(256,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.208.169','2026-07-10 22:51:10'),
(257,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.208.169','2026-07-10 22:51:38'),
(258,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.209.169','2026-07-10 22:57:02'),
(259,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.208.169','2026-07-10 23:19:43'),
(260,0,'admin','create','menu',54,'新建菜单\"文件管理\"，路径:','223.160.209.169','2026-07-10 23:24:00'),
(261,0,'admin','update','menu',29,'更新菜单\"文件仓库\"。旧数据:{\"id\":29,\"parent_id\":3,\"name\":\"FileRepository\",\"path\":\"filerepo\",\"component\":\"/system/filerepo/index\",\"redirect\":\"\",\"title\":\"文件仓库\",\"icon\":\"\",\"sort_order\":9,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":null,\"enabled\":1,\"mobile_path\":\"/appstore/file-repo-manage\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":null,\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T14:42:45.000Z\"}','223.160.209.169','2026-07-10 23:24:27'),
(262,0,'admin','update','menu',28,'更新菜单\"邮件配置\"。旧数据:{\"id\":28,\"parent_id\":3,\"name\":\"EmailConfig\",\"path\":\"email\",\"component\":\"/system/email/index\",\"redirect\":\"\",\"title\":\"邮件配置\",\"icon\":\"\",\"sort_order\":8,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":null,\"enabled\":1,\"mobile_path\":\"/appstore/email-config\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":null,\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T14:42:45.000Z\"}','223.160.209.169','2026-07-10 23:24:27'),
(263,0,'admin','update','menu',16,'更新菜单\"文件上传策略\"。旧数据:{\"id\":16,\"parent_id\":2,\"name\":\"FilePolicyManage\",\"path\":\"filepolicy\",\"component\":\"/operation/filepolicy/index\",\"redirect\":\"\",\"title\":\"文件上传策略\",\"icon\":\"\",\"sort_order\":9,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":null,\"enabled\":1,\"mobile_path\":\"/appstore/file-policy-manage\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":null,\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T14:42:45.000Z\"}','223.160.208.169','2026-07-10 23:26:58'),
(264,0,'admin','update','menu',29,'更新菜单\"文件仓库\"。旧数据:{\"id\":29,\"parent_id\":3,\"name\":\"FileRepository\",\"path\":\"filerepo\",\"component\":\"/system/filerepo/index\",\"redirect\":\"\",\"title\":\"文件仓库\",\"icon\":\"\",\"sort_order\":8,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":null,\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T15:24:27.000Z\"}','223.160.208.169','2026-07-10 23:27:10'),
(265,0,'admin','update','menu',36,'更新菜单\"对象存储\"。旧数据:{\"id\":36,\"parent_id\":3,\"name\":\"StorageConfig\",\"path\":\"storage-config\",\"component\":\"/appstore/storage-config\",\"redirect\":\"\",\"title\":\"对象存储\",\"icon\":\"\",\"sort_order\":16,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":null,\"enabled\":1,\"mobile_path\":\"/appstore/storage-config\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":null,\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T14:42:45.000Z\"}','223.160.208.169','2026-07-10 23:27:43'),
(266,0,'admin','update','menu',54,'更新菜单\"文件管理\"。旧数据:{\"id\":54,\"parent_id\":0,\"name\":\"文件管理\",\"path\":\"\",\"component\":\"\",\"redirect\":\"\",\"title\":\"文件管理\",\"icon\":\"\",\"sort_order\":4,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":null,\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"\",\"create_time\":\"2026-07-10T15:24:00.000Z\",\"update_time\":\"2026-07-10T15:24:00.000Z\"}','223.160.208.169','2026-07-10 23:28:21'),
(267,0,'admin','update','menu',2,'更新菜单\"运营管理\"。旧数据:{\"id\":2,\"parent_id\":0,\"name\":\"Operation\",\"path\":\"/operation\",\"component\":\"/index/index\",\"redirect\":\"\",\"title\":\"运营管理\",\"icon\":\"ri:settings-3-line\",\"sort_order\":2,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":0,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":\"[\\\"R_SUPER\\\",\\\"R_ADMIN\\\"]\",\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":null,\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T14:42:45.000Z\"}','223.160.208.169','2026-07-10 23:28:46'),
(268,0,'admin','update','menu',54,'更新菜单\"文件管理\"。旧数据:{\"id\":54,\"parent_id\":0,\"name\":\"文件管理\",\"path\":\"/a\",\"component\":\"/index/index\",\"redirect\":\"\",\"title\":\"文件管理\",\"icon\":\"\",\"sort_order\":4,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":null,\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"\",\"create_time\":\"2026-07-10T15:24:00.000Z\",\"update_time\":\"2026-07-10T15:28:21.000Z\"}','223.160.208.169','2026-07-10 23:29:37'),
(269,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.215.198','2026-07-11 08:40:24'),
(270,19,'alexmorgan','create','cardkey',21,'生成1张卡密(5000元余额)','223.160.215.198','2026-07-11 08:41:04'),
(271,19,'alexmorgan','redeem','cardkey',21,'兑换卡密 CDKEY-MRG47L1VS1EE: 5000元余额、额外99999积分、额外2000经验值','','2026-07-11 08:41:23'),
(272,19,'alexmorgan','update','membership',2,'更新会员等级\"黄金会员\"','223.160.215.198','2026-07-11 08:42:32'),
(273,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.213.229','2026-07-11 11:33:19'),
(274,19,'alexmorgan','set_badge','post',12,'设置自定义徽章《开源项目推荐合集》：#','','2026-07-11 11:35:23'),
(275,19,'alexmorgan','essence','post',12,'设为精华帖子《开源项目推荐合集》','','2026-07-11 11:39:23'),
(276,19,'alexmorgan','hot','post',12,'设为热帖帖子《开源项目推荐合集》','','2026-07-11 11:39:24'),
(277,19,'alexmorgan','lock','post',12,'锁定帖子《开源项目推荐合集》','','2026-07-11 11:39:26'),
(278,19,'alexmorgan','unlock','post',12,'解锁帖子《开源项目推荐合集》','','2026-07-11 11:40:52'),
(279,0,'anonymous','update','app',8,'置顶应用ID:8','223.160.213.229','2026-07-11 11:42:47'),
(280,0,'anonymous','update','app',8,'官方认证应用ID:8','223.160.213.229','2026-07-11 11:42:48'),
(281,0,'anonymous','update','app',8,'精品推荐应用ID:8','223.160.213.229','2026-07-11 11:42:49'),
(282,0,'anonymous','delete','app',8,'删除应用ID:8','223.160.213.229','2026-07-11 11:42:53'),
(283,0,'anonymous','delete','app',6,'删除应用ID:6','223.160.213.229','2026-07-11 11:43:05'),
(284,0,'anonymous','delete','app',9,'删除应用ID:9','223.160.213.229','2026-07-11 11:43:27'),
(285,0,'anonymous','update','submission',8,'审核投稿ID:8 通过','223.160.213.229','2026-07-11 11:50:41'),
(286,0,'anonymous','report','app_comment',13,'用户举报评论ID:13, 原因:6','223.160.213.229','2026-07-11 11:51:00'),
(287,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-11 12:19:39'),
(288,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-11 12:19:39'),
(289,0,'anonymous','login','user',4,'用户 design_master 登录','::ffff:127.0.0.1','2026-07-11 12:19:39'),
(290,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-11 12:33:02'),
(291,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-11 12:34:38'),
(292,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-11 12:37:37'),
(293,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-11 12:39:05'),
(294,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-11 12:39:19'),
(295,0,'anonymous','login','user',19,'用户 alexmorgan 登录','117.136.111.145','2026-07-11 12:39:29'),
(296,0,'anonymous','login','user',19,'用户 alexmorgan 登录','117.136.111.145','2026-07-11 12:41:18'),
(297,0,'anonymous','update','role_permission',19,'更新角色权限','117.136.111.145','2026-07-11 12:46:26'),
(298,0,'anonymous','update','role_permission',19,'更新角色权限','117.136.111.145','2026-07-11 12:46:30'),
(299,0,'anonymous','update','role_permission',19,'更新角色权限','117.136.111.145','2026-07-11 12:46:33'),
(300,0,'anonymous','update','role_permission',20,'更新角色权限','117.136.111.145','2026-07-11 12:46:49'),
(301,0,'anonymous','delete','role',19,'删除角色\"超级管理员\"','117.136.111.145','2026-07-11 12:47:04'),
(302,0,'anonymous','create','role',22,'新建角色\"系统超级管理员\"','117.136.111.145','2026-07-11 12:47:10'),
(303,0,'anonymous','update','role_permission',22,'更新角色权限','117.136.111.145','2026-07-11 12:47:15'),
(304,0,'anonymous','update','role_permission',22,'更新角色权限','117.136.111.145','2026-07-11 12:47:40'),
(305,0,'anonymous','update','role_permission',22,'更新角色权限','117.136.111.145','2026-07-11 12:47:55'),
(306,0,'anonymous','update','role_permission',20,'更新角色权限','117.136.111.145','2026-07-11 12:48:21'),
(307,0,'anonymous','update','role_permission',20,'更新角色权限','117.136.111.145','2026-07-11 12:48:26'),
(308,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-11 12:49:53'),
(309,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-11 12:51:48'),
(310,0,'anonymous','update','role_permission',22,'更新角色权限','::ffff:127.0.0.1','2026-07-11 12:51:48'),
(311,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-11 15:45:21'),
(312,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-11 15:45:29'),
(313,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-11 15:45:58'),
(314,19,'alexmorgan','config','email',0,'更新邮件服务配置','117.136.111.145','2026-07-11 15:55:08'),
(315,19,'alexmorgan','config','email',0,'更新邮件服务配置','117.136.111.145','2026-07-11 15:55:24'),
(316,19,'alexmorgan','config','email',0,'更新邮件服务配置','117.136.111.145','2026-07-11 15:55:45'),
(317,19,'alexmorgan','config','email',0,'更新邮件服务配置','117.136.111.145','2026-07-11 15:55:56'),
(318,0,'anonymous','update','custom_task',4,'更新自定义任务\"邀请好友\"','117.136.111.145','2026-07-11 16:02:03'),
(319,19,'alexmorgan','config','email',0,'更新邮件服务配置','117.136.111.145','2026-07-11 16:03:35'),
(320,19,'alexmorgan','config','email',0,'更新邮件服务配置','117.136.111.145','2026-07-11 16:03:49'),
(321,19,'alexmorgan','config','email',0,'更新邮件服务配置','117.136.111.145','2026-07-11 16:04:44'),
(322,0,'admin','delete','menu',42,'删除菜单\"投稿审核\"。被删除数据:{\"id\":42,\"parent_id\":6,\"name\":\"SubmissionReview\",\"path\":\"review\",\"component\":\"/appstore/review\",\"redirect\":\"\",\"title\":\"投稿审核\",\"icon\":\"\",\"sort_order\":6,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":\"[{\\\"title\\\":\\\"通过\\\",\\\"authMark\\\":\\\"approve\\\"},{\\\"title\\\":\\\"拒绝\\\",\\\"authMark\\\":\\\"reject\\\"}]\",\"roles\":\"[\\\"R_SUPER\\\",\\\"R_ADMIN\\\"]\",\"enabled\":1,\"mobile_path\":\"/appstore/review-mobile\",\"icon_bg\":\"#EC4899\",\"icon_svg\":\"M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 15l-4-4 1.41-1.41L11 14.17l6.59-6.59L19 9l-8 8z\",\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T14:42:45.000Z\"}','117.136.111.145','2026-07-11 16:06:23'),
(323,0,'admin','create','menu',56,'新建菜单\"商城管理\"，路径:/etnfd','117.136.111.145','2026-07-11 16:08:50'),
(324,0,'admin','update','menu',56,'更新菜单\"商城管理\"。旧数据:{\"id\":56,\"parent_id\":0,\"name\":\"商城管理\",\"path\":\"/etnfd\",\"component\":\"\",\"redirect\":\"\",\"title\":\"商城管理\",\"icon\":\"\",\"sort_order\":1,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":null,\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"\",\"create_time\":\"2026-07-11T08:08:50.000Z\",\"update_time\":\"2026-07-11T08:08:50.000Z\"}','117.136.111.145','2026-07-11 16:08:57'),
(325,0,'admin','update','menu',56,'更新菜单\"商城管理\"。旧数据:{\"id\":56,\"parent_id\":0,\"name\":\"商城管理\",\"path\":\"/etnfd\",\"component\":\"\",\"redirect\":\"\",\"title\":\"商城管理\",\"icon\":\"\",\"sort_order\":5,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":null,\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"\",\"create_time\":\"2026-07-11T08:08:50.000Z\",\"update_time\":\"2026-07-11T08:08:57.000Z\"}','117.136.111.145','2026-07-11 16:09:04'),
(326,0,'admin','update','menu',3,'更新菜单\"系统管理\"。旧数据:{\"id\":3,\"parent_id\":0,\"name\":\"System\",\"path\":\"/system\",\"component\":\"/index/index\",\"redirect\":\"\",\"title\":\"系统管理\",\"icon\":\"ri:user-3-line\",\"sort_order\":3,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":0,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":\"[\\\"R_SUPER\\\",\\\"R_ADMIN\\\"]\",\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":null,\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T14:42:45.000Z\"}','117.136.111.145','2026-07-11 16:09:15'),
(327,0,'admin','update','menu',2,'更新菜单\"运营管理\"。旧数据:{\"id\":2,\"parent_id\":0,\"name\":\"Operation\",\"path\":\"/operation\",\"component\":\"/index/index\",\"redirect\":\"\",\"title\":\"运营管理\",\"icon\":\"ri:settings-3-line\",\"sort_order\":4,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":0,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":\"[\\\"R_SUPER\\\",\\\"R_ADMIN\\\"]\",\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T15:28:46.000Z\"}','117.136.111.145','2026-07-11 16:09:19'),
(328,0,'admin','update','menu',56,'更新菜单\"商城管理\"。旧数据:{\"id\":56,\"parent_id\":0,\"name\":\"商城管理\",\"path\":\"/etnfd\",\"component\":\"\",\"redirect\":\"\",\"title\":\"商城管理\",\"icon\":\"\",\"sort_order\":4,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":null,\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"\",\"create_time\":\"2026-07-11T08:08:50.000Z\",\"update_time\":\"2026-07-11T08:09:04.000Z\"}','117.136.111.145','2026-07-11 16:09:24'),
(329,0,'admin','update','menu',4,'更新菜单\"结果页面\"。旧数据:{\"id\":4,\"parent_id\":0,\"name\":\"Result\",\"path\":\"/result\",\"component\":\"/index/index\",\"redirect\":\"\",\"title\":\"结果页面\",\"icon\":\"ri:checkbox-circle-line\",\"sort_order\":5,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":0,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":null,\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":null,\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T14:42:45.000Z\"}','117.136.111.145','2026-07-11 16:09:30'),
(330,0,'admin','update','menu',5,'更新菜单\"异常页面\"。旧数据:{\"id\":5,\"parent_id\":0,\"name\":\"Exception\",\"path\":\"/exception\",\"component\":\"/index/index\",\"redirect\":\"\",\"title\":\"异常页面\",\"icon\":\"ri:error-warning-line\",\"sort_order\":6,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":0,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":null,\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":null,\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T14:42:45.000Z\"}','117.136.111.145','2026-07-11 16:09:36'),
(331,19,'alexmorgan','update','avatar_frame',2,'更新头像框\"炫彩边框\"','117.136.111.145','2026-07-11 16:28:24'),
(332,19,'alexmorgan','update','checkin_group',1,'更新签到规则《默认分组》','','2026-07-11 16:43:20'),
(333,19,'alexmorgan','update','checkin_group',1,'更新签到规则《默认分组》','','2026-07-11 16:43:20'),
(334,19,'alexmorgan','create','checkin_group',2,'新建签到规则《》','','2026-07-11 16:43:20'),
(335,19,'alexmorgan','update','checkin_group',1,'更新签到规则《默认分组》','','2026-07-11 16:43:21'),
(336,19,'alexmorgan','update','checkin_group',1,'更新签到规则《默认分组》','','2026-07-11 16:43:21'),
(337,19,'alexmorgan','delete','checkin_group',2,'删除签到规则《2》','','2026-07-11 16:43:35'),
(338,0,'system','create','checkin_milestone',1,'新增阶梯奖励(第7天)','','2026-07-11 16:47:34'),
(339,0,'system','create','checkin_milestone',2,'新增阶梯奖励(第7天)','','2026-07-11 16:47:34'),
(340,0,'system','create','checkin_milestone',3,'新增阶梯奖励(第7天)','','2026-07-11 16:47:35'),
(341,0,'system','create','checkin_milestone',4,'新增阶梯奖励(第7天)','','2026-07-11 16:47:35'),
(342,0,'system','create','checkin_milestone',5,'新增阶梯奖励(第7天)','','2026-07-11 16:47:36'),
(343,0,'system','create','checkin_milestone',6,'新增阶梯奖励(第7天)','','2026-07-11 16:47:36'),
(344,0,'system','create','checkin_milestone',7,'新增阶梯奖励(第7天)','','2026-07-11 16:47:38'),
(345,0,'system','create','checkin_milestone',8,'新增阶梯奖励(第7天)','','2026-07-11 16:47:38'),
(346,0,'system','create','checkin_milestone',9,'新增阶梯奖励(第7天)','','2026-07-11 16:47:38'),
(347,0,'system','create','checkin_milestone',10,'新增阶梯奖励(第7天)','','2026-07-11 16:47:39'),
(348,0,'system','create','checkin_milestone',11,'新增阶梯奖励(第7天)','','2026-07-11 16:47:39'),
(349,0,'system','create','checkin_milestone',12,'新增阶梯奖励(第7天)','','2026-07-11 16:47:39'),
(350,0,'system','create','checkin_milestone',13,'新增阶梯奖励(第7天)','','2026-07-11 16:47:39'),
(351,0,'system','create','checkin_milestone',14,'新增阶梯奖励(第7天)','','2026-07-11 16:47:39'),
(352,0,'system','delete','checkin_milestone',14,'删除阶梯奖励(第7天)','','2026-07-11 16:47:45'),
(353,0,'system','delete','checkin_milestone',14,'删除阶梯奖励(id=14)','','2026-07-11 16:47:47'),
(354,0,'system','delete','checkin_milestone',14,'删除阶梯奖励(id=14)','','2026-07-11 16:47:49'),
(355,0,'system','delete','checkin_milestone',5,'删除阶梯奖励(第7天)','','2026-07-11 16:47:52'),
(356,0,'system','delete','checkin_milestone',5,'删除阶梯奖励(id=5)','','2026-07-11 16:47:53'),
(357,0,'system','delete','checkin_milestone',1,'删除阶梯奖励(第7天)','','2026-07-11 16:47:55'),
(358,0,'system','delete','checkin_milestone',13,'删除阶梯奖励(第7天)','','2026-07-11 16:53:24'),
(359,0,'system','delete','checkin_milestone',13,'删除阶梯奖励(id=13)','','2026-07-11 16:53:28'),
(360,0,'system','update','checkin_milestone',6,'更新阶梯奖励(第7天)','','2026-07-11 16:53:31'),
(361,0,'system','delete','checkin_milestone',6,'删除阶梯奖励(第7天)','','2026-07-11 16:53:32'),
(362,0,'system','update','checkin_group',1,'更新签到规则《默认分组》','','2026-07-11 16:53:35'),
(363,0,'system','update','checkin_group',1,'更新签到规则《默认分组》','','2026-07-11 16:53:36'),
(364,0,'system','create','checkin_group',3,'新建签到规则《test》','','2026-07-11 16:54:50'),
(365,0,'system','create','checkin_milestone',15,'新增阶梯奖励(第30天)','','2026-07-11 16:55:50'),
(366,0,'system','delete','checkin_group',3,'删除签到规则《test》','','2026-07-11 16:58:46'),
(367,0,'system','delete','checkin_group',3,'删除签到规则《3》','','2026-07-11 16:58:49'),
(368,0,'system','delete','checkin_milestone',15,'删除阶梯奖励(第30天)','','2026-07-11 16:58:54'),
(369,0,'system','delete','checkin_milestone',15,'删除阶梯奖励(id=15)','','2026-07-11 16:58:56'),
(370,0,'system','delete','checkin_milestone',15,'删除阶梯奖励(id=15)','','2026-07-11 16:58:58'),
(371,0,'system','delete','checkin_milestone',12,'删除阶梯奖励(第7天)','','2026-07-11 17:02:13'),
(372,0,'system','delete','checkin_milestone',11,'删除阶梯奖励(第7天)','','2026-07-11 17:06:04'),
(373,0,'system','delete','checkin_milestone',10,'删除阶梯奖励(第7天)','','2026-07-11 17:06:12'),
(374,0,'system','delete','checkin_milestone',9,'删除阶梯奖励(第7天)','','2026-07-11 17:06:14'),
(375,0,'system','delete','checkin_milestone',8,'删除阶梯奖励(第7天)','','2026-07-11 17:06:16'),
(376,0,'system','delete','checkin_group',3,'删除签到规则《3》','','2026-07-11 17:07:01'),
(377,19,'alexmorgan','delete','checkin_milestone',4,'删除阶梯奖励(第7天)','','2026-07-11 17:12:00'),
(378,19,'alexmorgan','create','checkin_group',4,'新建签到规则《666》','','2026-07-11 17:12:09'),
(379,19,'alexmorgan','delete','checkin_group',4,'删除签到规则《666》','','2026-07-11 17:12:29'),
(380,19,'alexmorgan','delete','checkin_milestone',7,'删除阶梯奖励(第7天)','','2026-07-11 17:17:38'),
(381,19,'alexmorgan','update','checkin_group',1,'更新签到规则《默认分组》','','2026-07-11 17:17:44'),
(382,19,'alexmorgan','delete','checkin_milestone',3,'删除阶梯奖励(第7天)','','2026-07-11 17:30:18'),
(383,19,'alexmorgan','delete','checkin_milestone',2,'删除阶梯奖励(第7天)','','2026-07-11 17:30:35'),
(384,19,'alexmorgan','create','checkin_group',5,'新建签到规则《》','','2026-07-11 17:30:39'),
(385,19,'alexmorgan','delete','checkin_group',5,'删除签到规则《5》','','2026-07-11 17:30:42'),
(386,0,'admin','delete','menu',43,'删除菜单\"投稿审核\"。被删除数据:{\"id\":43,\"parent_id\":6,\"name\":\"SubmissionReviewMobile\",\"path\":\"review-mobile\",\"component\":\"/appstore/review/mobile\",\"redirect\":\"\",\"title\":\"投稿审核\",\"icon\":\"\",\"sort_order\":7,\"is_hidden\":1,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":\"[{\\\"title\\\":\\\"通过\\\",\\\"authMark\\\":\\\"approve\\\"},{\\\"title\\\":\\\"拒绝\\\",\\\"authMark\\\":\\\"reject\\\"}]\",\"roles\":\"[\\\"R_SUPER\\\",\\\"R_ADMIN\\\"]\",\"enabled\":1,\"mobile_path\":\"/appstore/review-mobile\",\"icon_bg\":\"#EC4899\",\"icon_svg\":\"M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 15l-4-4 1.41-1.41L11 14.17l6.59-6.59L19 9l-8 8z\",\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T14:42:45.000Z\"}','223.160.208.192','2026-07-11 17:41:55'),
(387,0,'anonymous','delete','comment',13,'管理员删除评论ID:13','223.160.208.192','2026-07-11 17:53:17'),
(388,0,'anonymous','update','category',7,'更新分类\"社交\"','223.160.208.192','2026-07-11 17:53:34'),
(389,0,'anonymous','update','official_tag',1,'更新官方标签\"热门\"','223.160.208.192','2026-07-11 17:53:46'),
(390,0,'admin','delete','menu',41,'删除菜单\"我的投稿\"。被删除数据:{\"id\":41,\"parent_id\":6,\"name\":\"MySubmissions\",\"path\":\"my-submissions\",\"component\":\"/appstore/submissions\",\"redirect\":\"\",\"title\":\"我的投稿\",\"icon\":\"\",\"sort_order\":5,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":\"[\\\"R_SUPER\\\",\\\"R_ADMIN\\\",\\\"R_USER\\\"]\",\"enabled\":1,\"mobile_path\":\"/appstore/my-submissions\",\"icon_bg\":\"#EC4899\",\"icon_svg\":\"M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-5 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z\",\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T14:42:45.000Z\"}','223.160.208.192','2026-07-11 17:54:35'),
(391,0,'anonymous','update','app',12,'置顶应用ID:12','223.160.208.192','2026-07-11 18:43:31'),
(392,0,'anonymous','update','app',12,'取消置顶应用ID:12','223.160.208.192','2026-07-11 18:43:35'),
(393,0,'anonymous','update','app',12,'置顶应用ID:12','223.160.208.192','2026-07-11 18:43:35'),
(394,0,'anonymous','update','app',12,'取消置顶应用ID:12','223.160.208.192','2026-07-11 18:43:37'),
(395,0,'anonymous','update','app',12,'置顶应用ID:12','223.160.208.192','2026-07-11 18:48:40'),
(396,0,'anonymous','update','app',12,'取消置顶应用ID:12','223.160.208.192','2026-07-11 18:48:42'),
(397,0,'anonymous','update','app',12,'置顶应用ID:12','223.160.208.192','2026-07-11 18:49:13'),
(398,0,'anonymous','update','app',12,'取消置顶应用ID:12','223.160.208.192','2026-07-11 18:49:15'),
(399,0,'anonymous','update','app',12,'置顶应用ID:12','223.160.208.192','2026-07-11 18:49:17'),
(400,0,'anonymous','update','app',12,'取消置顶应用ID:12','223.160.208.192','2026-07-11 18:49:18'),
(401,0,'anonymous','update','membership',1,'更新会员等级\"普通会员\"','223.160.215.167','2026-07-11 19:50:04'),
(402,0,'anonymous','update','membership',2,'更新会员等级\"黄金会员\"','223.160.215.167','2026-07-11 19:55:16'),
(403,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.215.167','2026-07-11 20:03:08'),
(404,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-11 20:10:04'),
(405,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-11 20:11:46'),
(406,19,'alexmorgan','update','membership',1,'更新会员等级\"普通会员\"','223.160.215.167','2026-07-11 20:15:21'),
(407,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-11 20:36:40'),
(408,19,'alexmorgan','update','membership',2,'更新会员等级\"黄金会员\"','::ffff:127.0.0.1','2026-07-11 20:36:40'),
(409,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-11 20:36:59'),
(410,0,'anonymous','login','user',4,'用户 design_master 登录','::ffff:127.0.0.1','2026-07-11 20:38:36'),
(411,0,'anonymous','login','user',20,'用户 testgift 登录','::ffff:127.0.0.1','2026-07-11 20:38:59'),
(412,0,'anonymous','create','coupon',6,'创建优惠券:黄金会员','223.160.215.167','2026-07-11 20:42:43'),
(413,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-11 20:47:52'),
(414,19,'alexmorgan','update','membership',2,'更新会员等级\"黄金会员\"','::ffff:127.0.0.1','2026-07-11 20:47:52'),
(415,0,'anonymous','login','user',21,'用户 testcoupon 登录','::ffff:127.0.0.1','2026-07-11 20:48:08'),
(416,0,'anonymous','login','user',21,'用户 testcoupon 登录','::ffff:127.0.0.1','2026-07-11 20:48:23'),
(417,0,'anonymous','login','user',21,'用户 testcoupon 登录','::ffff:127.0.0.1','2026-07-11 20:49:43'),
(418,0,'anonymous','login','user',21,'用户 testcoupon 登录','::ffff:127.0.0.1','2026-07-11 20:49:53'),
(419,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-11 21:07:13'),
(420,19,'alexmorgan','update','membership',2,'更新会员等级\"黄金会员\"','::ffff:127.0.0.1','2026-07-11 21:07:13'),
(421,0,'anonymous','login','user',22,'用户 titletest 登录','::ffff:127.0.0.1','2026-07-11 21:07:22'),
(422,0,'anonymous','login','user',22,'用户 titletest 登录','::ffff:127.0.0.1','2026-07-11 21:07:31'),
(423,0,'anonymous','login','user',22,'用户 titletest 登录','::ffff:127.0.0.1','2026-07-11 21:08:10'),
(424,0,'anonymous','login','user',23,'用户 birthdaytest 登录','::ffff:127.0.0.1','2026-07-11 21:08:20'),
(425,0,'anonymous','login','user',23,'用户 birthdaytest 登录','::ffff:127.0.0.1','2026-07-11 21:10:29'),
(426,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-11 21:19:13'),
(427,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.211.247','2026-07-11 22:04:24'),
(428,19,'alexmorgan','create','membership',5,'新增会员等级\"测试会员\"','223.160.211.247','2026-07-11 22:39:44'),
(429,19,'alexmorgan','update','membership',3,'更新会员等级\"钻石会员\"','39.144.124.125','2026-07-11 23:02:15'),
(430,19,'alexmorgan','update','membership',3,'更新会员等级\"钻石会员\"','39.144.124.125','2026-07-11 23:02:27'),
(431,19,'alexmorgan','update','membership',5,'更新会员等级\"测试会员\"','39.144.124.125','2026-07-11 23:02:32'),
(432,19,'alexmorgan','update','membership',4,'更新会员等级\"至尊会员\"','39.144.124.125','2026-07-11 23:07:22'),
(433,0,'anonymous','login','user',19,'用户 alexmorgan 登录','39.144.124.64','2026-07-12 00:03:41'),
(434,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 00:05:17'),
(435,0,'anonymous','login','user',19,'用户 alexmorgan 登录','39.144.124.64','2026-07-12 00:29:57'),
(436,0,'anonymous','login','user',19,'用户 alexmorgan 登录','39.144.124.162','2026-07-12 02:47:44'),
(437,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 02:57:02'),
(438,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 02:57:13'),
(439,0,'anonymous','login','user',2,'用户 lisa_chen 登录','::ffff:127.0.0.1','2026-07-12 02:57:14'),
(440,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 03:00:38'),
(441,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 03:04:11'),
(442,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 03:05:18'),
(443,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 03:16:22'),
(444,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 03:20:01'),
(445,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 08:09:53'),
(446,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 08:38:51'),
(447,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 08:39:04'),
(448,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 08:39:22'),
(449,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 08:39:37'),
(450,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 08:40:08'),
(451,0,'anonymous','login','user',19,'用户 alexmorgan 登录','39.144.124.162','2026-07-12 08:40:20'),
(452,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 08:40:47'),
(453,0,'anonymous','login','user',19,'用户 alexmorgan 登录','39.144.124.162','2026-07-12 08:40:59'),
(454,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 08:41:00'),
(455,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 08:41:16'),
(456,0,'anonymous','login','user',19,'用户 alexmorgan 登录','39.144.124.162','2026-07-12 08:41:29'),
(457,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 08:41:53'),
(458,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 08:47:41'),
(459,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 08:48:15');
/*!40000 ALTER TABLE `system_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `task_records`
--

DROP TABLE IF EXISTS `task_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `task_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `task_id` int(11) NOT NULL,
  `task_name` varchar(200) DEFAULT '',
  `progress` int(11) DEFAULT 0,
  `target_count` int(11) DEFAULT 1,
  `status` varchar(20) DEFAULT 'pending',
  `completed_at` datetime DEFAULT NULL,
  `period_key` varchar(20) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_task_records_user` (`user_id`),
  KEY `idx_task_records_period` (`period_key`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `task_records`
--

LOCK TABLES `task_records` WRITE;
/*!40000 ALTER TABLE `task_records` DISABLE KEYS */;
INSERT INTO `task_records` VALUES
(1,7,'',1,'',0,1,'pending',NULL,'','2026-07-08 22:39:54'),
(2,5,'',4,'',0,1,'pending',NULL,'','2026-07-06 22:39:54'),
(3,3,'',3,'',0,1,'pending',NULL,'','2026-07-04 22:39:54'),
(4,7,'',5,'',0,1,'pending',NULL,'','2026-06-29 22:39:54'),
(5,2,'',3,'',0,1,'pending',NULL,'','2026-07-08 22:39:54'),
(6,5,'',4,'',0,1,'pending',NULL,'','2026-07-09 22:39:54'),
(7,4,'',2,'',0,1,'pending',NULL,'','2026-06-29 22:39:54'),
(8,3,'',3,'',0,1,'pending',NULL,'','2026-07-05 22:39:54'),
(9,7,'',2,'',0,1,'pending',NULL,'','2026-07-01 22:39:54'),
(10,12,'',5,'',0,1,'pending',NULL,'','2026-06-30 22:39:54'),
(11,6,'',3,'',0,1,'pending',NULL,'','2026-06-28 22:39:54'),
(12,8,'',5,'',0,1,'pending',NULL,'','2026-07-09 22:39:54'),
(13,9,'',3,'',0,1,'pending',NULL,'','2026-06-29 22:39:54'),
(14,10,'',3,'',0,1,'pending',NULL,'','2026-07-05 22:39:54'),
(15,5,'',5,'',0,1,'pending',NULL,'','2026-07-08 22:39:54'),
(16,11,'',3,'',0,1,'pending',NULL,'','2026-07-10 22:39:54'),
(17,5,'',4,'',0,1,'pending',NULL,'','2026-07-04 22:39:54'),
(18,8,'',5,'',0,1,'pending',NULL,'','2026-07-08 22:39:54'),
(19,2,'',5,'',0,1,'pending',NULL,'','2026-06-27 22:39:54'),
(20,15,'',2,'',0,1,'pending',NULL,'','2026-07-07 22:39:54');
/*!40000 ALTER TABLE `task_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `themes`
--

DROP TABLE IF EXISTS `themes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `themes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT '',
  `thumbnail` varchar(500) DEFAULT '',
  `vars` text DEFAULT '{}',
  `vars_dark` text DEFAULT '{}',
  `vars_mobile` text DEFAULT '{}',
  `vars_mobile_dark` text DEFAULT '{}',
  `is_preset` tinyint(1) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `themes`
--

LOCK TABLES `themes` WRITE;
/*!40000 ALTER TABLE `themes` DISABLE KEYS */;
INSERT INTO `themes` VALUES
(1,'默认主题','','','{}','{}','{}','{}',0,1,'2026-07-10 22:39:54','2026-07-10 22:39:54');
/*!40000 ALTER TABLE `themes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `topic_follows`
--

DROP TABLE IF EXISTS `topic_follows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `topic_follows` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `topic_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `topic_id` (`topic_id`,`user_id`),
  KEY `idx_topic_follows_topic` (`topic_id`),
  KEY `idx_topic_follows_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `topic_follows`
--

LOCK TABLES `topic_follows` WRITE;
/*!40000 ALTER TABLE `topic_follows` DISABLE KEYS */;
/*!40000 ALTER TABLE `topic_follows` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_avatar_frames`
--

DROP TABLE IF EXISTS `user_avatar_frames`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_avatar_frames` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `frame_id` int(11) NOT NULL,
  `is_active` tinyint(1) DEFAULT 0,
  `obtain_type` varchar(20) DEFAULT 'manual',
  `obtain_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`frame_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_avatar_frames`
--

LOCK TABLES `user_avatar_frames` WRITE;
/*!40000 ALTER TABLE `user_avatar_frames` DISABLE KEYS */;
INSERT INTO `user_avatar_frames` VALUES
(1,8,1,0,'manual','2026-07-10 22:39:54'),
(2,8,3,0,'manual','2026-07-10 22:39:54'),
(3,2,1,0,'manual','2026-07-10 22:39:54'),
(4,9,4,0,'manual','2026-07-10 22:39:54'),
(5,9,2,0,'manual','2026-07-10 22:39:54'),
(8,19,1,0,'membership','2026-07-12 00:11:10');
/*!40000 ALTER TABLE `user_avatar_frames` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_blocks`
--

DROP TABLE IF EXISTS `user_blocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_blocks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `blocker_id` int(11) NOT NULL,
  `blocked_id` int(11) NOT NULL,
  `reason` text DEFAULT '',
  `status` varchar(20) DEFAULT 'active',
  `reviewed` tinyint(1) DEFAULT 0,
  `review_notes` text DEFAULT '',
  `reviewer_id` int(11) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `blocker_id` (`blocker_id`,`blocked_id`),
  KEY `idx_user_blocks_blocker` (`blocker_id`),
  KEY `idx_user_blocks_blocked` (`blocked_id`),
  KEY `idx_user_blocks_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_blocks`
--

LOCK TABLES `user_blocks` WRITE;
/*!40000 ALTER TABLE `user_blocks` DISABLE KEYS */;
INSERT INTO `user_blocks` VALUES
(1,2,10,'','active',0,'',0,'2026-07-10 22:39:53'),
(2,3,11,'','active',0,'',0,'2026-07-10 22:39:53'),
(3,4,12,'','active',0,'',0,'2026-07-10 22:39:53'),
(4,5,13,'','active',0,'',0,'2026-07-10 22:39:53'),
(5,6,14,'','active',0,'',0,'2026-07-10 22:39:53'),
(6,19,12,'666','cancelled',0,'',0,'2026-07-11 11:46:43');
/*!40000 ALTER TABLE `user_blocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_coupons`
--

DROP TABLE IF EXISTS `user_coupons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_coupons` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `coupon_id` int(11) NOT NULL,
  `status` varchar(10) NOT NULL DEFAULT 'unused',
  `coupon_data` text NOT NULL,
  `expire_time` datetime NOT NULL,
  `use_time` datetime DEFAULT NULL,
  `use_scene` varchar(50) DEFAULT '',
  `use_order_id` int(11) DEFAULT 0,
  `use_amount` decimal(10,2) DEFAULT 0.00,
  `remaining_value` decimal(10,2) DEFAULT NULL,
  `receive_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user_coupons_user` (`user_id`),
  KEY `idx_user_coupons_status` (`status`),
  KEY `idx_user_coupons_coupon` (`coupon_id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_coupons`
--

LOCK TABLES `user_coupons` WRITE;
/*!40000 ALTER TABLE `user_coupons` DISABLE KEYS */;
INSERT INTO `user_coupons` VALUES
(1,12,5,'used','{}','2026-08-09 22:39:53',NULL,'',0,0.00,NULL,'2026-07-10 22:39:53'),
(2,10,5,'unused','{}','2026-08-09 22:39:53',NULL,'',0,0.00,NULL,'2026-07-10 22:39:53'),
(3,6,3,'unused','{}','2026-08-09 22:39:53',NULL,'',0,0.00,NULL,'2026-07-10 22:39:53'),
(4,6,4,'used','{}','2026-08-09 22:39:53',NULL,'',0,0.00,NULL,'2026-07-10 22:39:53'),
(5,2,1,'unused','{}','2026-08-09 22:39:53',NULL,'',0,0.00,NULL,'2026-07-10 22:39:53'),
(6,9,5,'unused','{}','2026-08-09 22:39:53',NULL,'',0,0.00,NULL,'2026-07-10 22:39:53'),
(7,2,5,'used','{}','2026-08-09 22:39:53',NULL,'',0,0.00,NULL,'2026-07-10 22:39:53'),
(8,12,5,'unused','{}','2026-08-09 22:39:53',NULL,'',0,0.00,NULL,'2026-07-10 22:39:53'),
(9,11,1,'unused','{}','2026-08-09 22:39:53',NULL,'',0,0.00,NULL,'2026-07-10 22:39:53'),
(10,4,4,'used','{}','2026-08-09 22:39:53',NULL,'',0,0.00,NULL,'2026-07-10 22:39:53'),
(11,10,4,'unused','{}','2026-08-09 22:39:53',NULL,'',0,0.00,NULL,'2026-07-10 22:39:53'),
(12,5,5,'unused','{}','2026-08-09 22:39:53',NULL,'',0,0.00,NULL,'2026-07-10 22:39:53'),
(13,14,4,'used','{}','2026-08-09 22:39:53',NULL,'',0,0.00,NULL,'2026-07-10 22:39:53'),
(14,7,2,'unused','{}','2026-08-09 22:39:53',NULL,'',0,0.00,NULL,'2026-07-10 22:39:53'),
(15,10,2,'unused','{}','2026-08-09 22:39:53',NULL,'',0,0.00,NULL,'2026-07-10 22:39:53'),
(16,9,2,'used','{}','2026-08-09 22:39:53',NULL,'',0,0.00,NULL,'2026-07-10 22:39:53'),
(17,15,1,'unused','{}','2026-08-09 22:39:53',NULL,'',0,0.00,NULL,'2026-07-10 22:39:53'),
(18,15,1,'unused','{}','2026-08-09 22:39:53',NULL,'',0,0.00,NULL,'2026-07-10 22:39:53'),
(19,12,2,'used','{}','2026-08-09 22:39:53',NULL,'',0,0.00,NULL,'2026-07-10 22:39:53'),
(20,7,2,'unused','{}','2026-08-09 22:39:53',NULL,'',0,0.00,NULL,'2026-07-10 22:39:53'),
(21,19,5,'unused','{\"name\":\"限时体验券\",\"type\":\"percentage\",\"value\":8,\"minOrder\":0,\"maxDiscount\":0,\"scope\":\"all\",\"targetIds\":\"\",\"category\":\"general\"}','2026-08-10 19:49:32',NULL,'',0,0.00,NULL,'2026-07-11 11:49:32'),
(22,1,3,'unused','{\"name\":\"VIP折扣券\",\"type\":\"percentage\",\"value\":15,\"minOrder\":0,\"maxDiscount\":0,\"scope\":\"all\",\"targetIds\":\"\",\"category\":\"general\"}','2026-08-10 20:37:08',NULL,'',0,0.00,NULL,'2026-07-11 20:37:08'),
(23,4,3,'unused','{\"name\":\"VIP折扣券\",\"type\":\"percentage\",\"value\":15,\"minOrder\":0,\"maxDiscount\":0,\"scope\":\"all\",\"targetIds\":\"\",\"category\":\"general\"}','2026-08-10 20:38:36',NULL,'',0,0.00,NULL,'2026-07-11 20:38:36'),
(37,19,6,'unused','{\"name\":\"黄金会员\",\"type\":\"percent\",\"value\":10,\"minOrder\":1,\"maxDiscount\":10,\"scope\":\"all\",\"targetIds\":\"\",\"category\":\"general\"}','2030-07-12 04:42:00',NULL,'',0,0.00,NULL,'2026-07-11 23:42:22'),
(38,19,1,'used','{\"name\":\"新人专享券\",\"type\":\"fixed\",\"value\":5,\"minOrder\":10,\"maxDiscount\":100,\"scope\":\"all\",\"targetIds\":\"\",\"category\":\"general\"}','2026-08-11 07:51:45','2026-07-12 08:11:10','membership_buy',0,5.00,NULL,'2026-07-11 23:51:45'),
(39,19,0,'unused','{\"name\":\"月度续费券\",\"type\":\"percent\",\"value\":10,\"minOrder\":0,\"maxDiscount\":50,\"scope\":\"all\",\"targetIds\":\"\",\"category\":\"general\"}','2026-07-26 00:11:10',NULL,'',0,0.00,NULL,'2026-07-12 00:11:10');
/*!40000 ALTER TABLE `user_coupons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_delete_requests`
--

DROP TABLE IF EXISTS `user_delete_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_delete_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `username` varchar(100) DEFAULT '',
  `admin_id` int(11) DEFAULT 0,
  `admin_note` varchar(500) DEFAULT '',
  `status` varchar(20) DEFAULT 'pending',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_delete_requests`
--

LOCK TABLES `user_delete_requests` WRITE;
/*!40000 ALTER TABLE `user_delete_requests` DISABLE KEYS */;
INSERT INTO `user_delete_requests` VALUES
(1,13,'',0,'不再使用','pending','2026-07-09 22:39:54'),
(2,7,'',0,'隐私原因','approved','2026-07-02 22:39:54'),
(3,7,'',0,'账号太多','rejected','2026-07-10 22:39:54');
/*!40000 ALTER TABLE `user_delete_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_follows`
--

DROP TABLE IF EXISTS `user_follows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_follows` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `follower_id` int(11) NOT NULL,
  `following_id` int(11) NOT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `follower_id` (`follower_id`,`following_id`),
  KEY `idx_user_follows_follower` (`follower_id`),
  KEY `idx_user_follows_following` (`following_id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_follows`
--

LOCK TABLES `user_follows` WRITE;
/*!40000 ALTER TABLE `user_follows` DISABLE KEYS */;
INSERT INTO `user_follows` VALUES
(1,7,8,'2026-07-10 22:39:53'),
(2,12,2,'2026-07-10 22:39:53'),
(3,7,14,'2026-07-10 22:39:53'),
(4,4,15,'2026-07-10 22:39:53'),
(5,12,10,'2026-07-10 22:39:53'),
(6,8,9,'2026-07-10 22:39:53'),
(7,10,14,'2026-07-10 22:39:53'),
(8,10,6,'2026-07-10 22:39:53'),
(9,3,7,'2026-07-10 22:39:53'),
(10,2,14,'2026-07-10 22:39:53'),
(11,7,5,'2026-07-10 22:39:53'),
(12,11,8,'2026-07-10 22:39:53'),
(13,15,4,'2026-07-10 22:39:53'),
(14,16,6,'2026-07-10 22:39:53'),
(15,5,15,'2026-07-10 22:39:53'),
(16,5,7,'2026-07-10 22:39:53'),
(17,13,15,'2026-07-10 22:39:53'),
(18,2,11,'2026-07-10 22:39:53'),
(19,9,7,'2026-07-10 22:39:53'),
(20,6,13,'2026-07-10 22:39:53'),
(21,14,5,'2026-07-10 22:39:53'),
(22,3,14,'2026-07-10 22:39:53'),
(23,16,5,'2026-07-10 22:39:53'),
(24,2,3,'2026-07-10 22:39:53'),
(25,7,13,'2026-07-10 22:39:53'),
(26,19,7,'2026-07-11 11:39:21'),
(27,19,12,'2026-07-11 11:46:49');
/*!40000 ALTER TABLE `user_follows` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_gift_claims`
--

DROP TABLE IF EXISTS `user_gift_claims`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_gift_claims` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `level_id` int(11) NOT NULL,
  `gift_type` varchar(20) NOT NULL,
  `claim_date` date NOT NULL,
  `claim_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uix_user_level_type_date` (`user_id`,`level_id`,`gift_type`,`claim_date`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_gift_claims`
--

LOCK TABLES `user_gift_claims` WRITE;
/*!40000 ALTER TABLE `user_gift_claims` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_gift_claims` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_titles`
--

DROP TABLE IF EXISTS `user_titles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_titles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `title_id` int(11) NOT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `grant_by` varchar(100) DEFAULT '',
  `grant_time` datetime DEFAULT current_timestamp(),
  `expire_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`title_id`),
  KEY `idx_user_titles_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_titles`
--

LOCK TABLES `user_titles` WRITE;
/*!40000 ALTER TABLE `user_titles` DISABLE KEYS */;
INSERT INTO `user_titles` VALUES
(1,13,3,1,'','2026-07-10 22:39:54',NULL),
(2,7,3,1,'','2026-07-10 22:39:54',NULL),
(3,3,4,1,'','2026-07-10 22:39:54',NULL),
(4,12,1,1,'','2026-07-10 22:39:54',NULL),
(5,6,4,1,'','2026-07-10 22:39:54',NULL),
(6,15,2,1,'','2026-07-10 22:39:54',NULL),
(7,13,4,1,'','2026-07-10 22:39:54',NULL),
(8,7,1,1,'','2026-07-10 22:39:54',NULL),
(11,19,1,1,'membership','2026-07-12 00:11:10',NULL);
/*!40000 ALTER TABLE `user_titles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(200) NOT NULL DEFAULT '123456',
  `password_hash` varchar(200) DEFAULT '',
  `phone` varchar(20) DEFAULT '',
  `email` varchar(100) DEFAULT '',
  `nickname` varchar(100) DEFAULT '',
  `bio` text DEFAULT NULL,
  `balance` decimal(10,2) DEFAULT 0.00,
  `experience` int(11) DEFAULT 0,
  `gender` varchar(10) DEFAULT '男',
  `avatar` varchar(500) DEFAULT '',
  `bg_url` varchar(500) DEFAULT '',
  `signature` varchar(300) DEFAULT '',
  `qq` varchar(20) DEFAULT '',
  `show_coin` int(11) DEFAULT 1,
  `follow_count` int(11) DEFAULT 0,
  `fans_count` int(11) DEFAULT 0,
  `status` varchar(2) DEFAULT '1',
  `points` int(11) DEFAULT 0,
  `level_id` int(11) DEFAULT 0,
  `level_name` varchar(100) DEFAULT '普通会员',
  `expire_time` datetime DEFAULT NULL,
  `ban_until` datetime DEFAULT NULL,
  `is_verified` tinyint(1) DEFAULT 0,
  `verified_org` varchar(200) DEFAULT '',
  `active_title_id` int(11) DEFAULT 0,
  `active_title_name` varchar(100) DEFAULT '',
  `last_checkin_date` date DEFAULT NULL,
  `consecutive_checkins` int(11) DEFAULT 0,
  `referrer_id` int(11) DEFAULT 0,
  `referrer_code` varchar(32) DEFAULT '',
  `age` int(11) DEFAULT 0,
  `birthday` date DEFAULT NULL,
  `hide_birthday` tinyint(1) DEFAULT 0,
  `hide_qq` tinyint(1) DEFAULT 0,
  `hide_email` tinyint(1) DEFAULT 0,
  `hide_address` tinyint(1) DEFAULT 0,
  `register_address` varchar(200) DEFAULT '',
  `deleted_at` datetime DEFAULT NULL,
  `roles` text DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  `active_frame_id` int(11) DEFAULT 0,
  `active_frame_url` varchar(500) DEFAULT '',
  `used_bytes` bigint(20) DEFAULT 0,
  `bonus_data_limit_mb` int(11) DEFAULT 0,
  `bonus_file_limit_mb` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `idx_users_username` (`username`),
  KEY `idx_users_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'bobwang','123456','$2b$10$b4DEkmaSpCgSDhXxU5QgKOzxHQs11JMbx8HqtLexLveBMmtdLB7Qa','13800138001','bob@test.com','bob123',NULL,81.50,3300,'1','','','','',1,0,0,'1',1550,2,'黄金会员','2026-08-11 20:37:08',NULL,0,'',0,'',NULL,0,0,'',0,'1998-03-15',0,0,0,0,'',NULL,'[\"R_USER\"]','2026-06-09 22:39:49','2026-07-11 21:29:49',0,'',12288,10,10),
(2,'lisa_chen','$2b$10$aFA/Waln/adFPLLhhPjbbOGMjYf3WFy6oYqr29gI2mWTLScsizKga','$2b$10$b4DEkmaSpCgSDhXxU5QgKOzxHQs11JMbx8HqtLexLveBMmtdLB7Qa','13800138002','lisa@test.com','lisa123',NULL,25.00,1500,'0','','','','',1,0,0,'1',800,1,'普通会员',NULL,NULL,0,'',0,'',NULL,0,0,'',0,NULL,0,0,0,0,'',NULL,'[\"R_USER\"]','2026-06-09 22:39:49','2026-07-10 22:39:49',0,'',4096,0,0),
(3,'tech_guru','123456','$2b$10$8r/5zSf2iGxjGVCZNA8N4.6jerTYYcrIggzbgTkXGn7zyuanlN9rm','13800138003','tech@test.com','tech123',NULL,200.00,8000,'1','','','','',1,0,0,'1',5000,3,'钻石会员',NULL,NULL,0,'',0,'',NULL,0,0,'',0,NULL,0,0,0,0,'',NULL,'[\"R_USER\"]','2026-07-05 22:39:49','2026-07-10 22:39:49',0,'',0,0,0),
(4,'design_master','123456','$2b$10$8r/5zSf2iGxjGVCZNA8N4.6jerTYYcrIggzbgTkXGn7zyuanlN9rm','13800138004','dm@test.com','dm123',NULL,3.00,700,'0','','','','',1,0,0,'1',350,2,'黄金会员','2026-08-11 20:38:36',NULL,0,'',0,'',NULL,0,0,'',0,NULL,0,0,0,0,'',NULL,'[\"R_USER\"]','2026-06-18 22:39:49','2026-07-10 22:39:49',0,'',0,10,10),
(5,'code_ninja','$2b$10$aFA/Waln/adFPLLhhPjbbOGMjYf3WFy6oYqr29gI2mWTLScsizKga','Code Ninja','13800138005','code@test.com','cn123',NULL,150.00,4500,'1','','','','',1,0,0,'1',2200,2,'黄金会员',NULL,NULL,0,'',0,'',NULL,0,0,'',0,NULL,0,0,0,0,'',NULL,'[\"R_USER\"]','2026-06-03 22:39:49','2026-07-10 22:39:49',0,'',0,0,0),
(6,'pixel_art','$2b$10$aFA/Waln/adFPLLhhPjbbOGMjYf3WFy6oYqr29gI2mWTLScsizKga','Pixel Art','13800138006','pixel@test.com','pa123',NULL,30.00,900,'0','','','','',1,0,0,'1',450,1,'普通会员',NULL,NULL,0,'',0,'',NULL,0,0,'',0,NULL,0,0,0,0,'',NULL,'[\"R_USER\"]','2026-05-26 22:39:49','2026-07-10 22:39:49',0,'',0,0,0),
(7,'ui_lover','$2b$10$aFA/Waln/adFPLLhhPjbbOGMjYf3WFy6oYqr29gI2mWTLScsizKga','UI Lover','13800138007','ui@test.com','ui123',NULL,500.00,12000,'0','','','','',1,0,1,'1',12000,4,'至尊会员',NULL,NULL,0,'',0,'',NULL,0,0,'',0,NULL,0,0,0,0,'',NULL,'[\"R_USER\"]','2026-06-27 22:39:49','2026-07-10 22:39:49',0,'',0,0,0),
(8,'frontend_dev','$2b$10$aFA/Waln/adFPLLhhPjbbOGMjYf3WFy6oYqr29gI2mWTLScsizKga','Frontend Dev','13800138008','fd@test.com','fd123',NULL,180.00,6000,'1','','','','',1,0,0,'1',6000,3,'钻石会员',NULL,NULL,0,'',0,'',NULL,0,0,'',0,NULL,0,0,0,0,'',NULL,'[\"R_USER\"]','2026-05-12 22:39:49','2026-07-10 22:39:49',0,'',0,0,0),
(9,'backend_guru','$2b$10$aFA/Waln/adFPLLhhPjbbOGMjYf3WFy6oYqr29gI2mWTLScsizKga','Backend Guru','13800138009','bg@test.com','bg123',NULL,95.00,3500,'1','','','','',1,0,0,'1',3500,2,'黄金会员',NULL,NULL,0,'',0,'',NULL,0,0,'',0,NULL,0,0,0,0,'',NULL,'[\"R_USER\"]','2026-06-22 22:39:49','2026-07-10 22:39:49',0,'',0,0,0),
(10,'data_wizard','$2b$10$aFA/Waln/adFPLLhhPjbbOGMjYf3WFy6oYqr29gI2mWTLScsizKga','Data Wizard','13800138010','dw@test.com','dw123',NULL,42.00,780,'1','','','','',1,0,0,'1',780,1,'普通会员',NULL,NULL,0,'',0,'',NULL,0,0,'',0,NULL,0,0,0,0,'',NULL,'[\"R_USER\"]','2026-05-27 22:39:49','2026-07-10 22:39:49',0,'',0,0,0),
(11,'mobile_dev','$2b$10$aFA/Waln/adFPLLhhPjbbOGMjYf3WFy6oYqr29gI2mWTLScsizKga','Mobile Dev','13800138011','md@test.com','md123',NULL,5.00,200,'1','','','','',1,0,0,'1',200,1,'普通会员',NULL,NULL,0,'',0,'',NULL,0,0,'',0,NULL,0,0,0,0,'',NULL,'[\"R_USER\"]','2026-05-27 22:39:49','2026-07-10 22:39:49',0,'',0,0,0),
(12,'cloud_arch','$2b$10$aFA/Waln/adFPLLhhPjbbOGMjYf3WFy6oYqr29gI2mWTLScsizKga','Cloud Arch','13800138012','ca@test.com','ca123',NULL,350.00,9500,'1','','','','',1,0,1,'1',9500,3,'钻石会员',NULL,NULL,0,'',0,'',NULL,0,0,'',0,NULL,0,0,0,0,'',NULL,'[\"R_USER\"]','2026-07-07 22:39:49','2026-07-10 22:39:49',0,'',0,0,0),
(13,'ai_explorer','$2b$10$aFA/Waln/adFPLLhhPjbbOGMjYf3WFy6oYqr29gI2mWTLScsizKga','AI Explorer','13800138013','ai@test.com','ai123',NULL,120.00,3000,'0','','','','',1,0,0,'1',3000,2,'黄金会员',NULL,NULL,0,'',0,'',NULL,0,0,'',0,NULL,0,0,0,0,'',NULL,'[\"R_USER\"]','2026-05-16 22:39:49','2026-07-10 22:39:49',0,'',0,0,0),
(14,'game_dev','$2b$10$aFA/Waln/adFPLLhhPjbbOGMjYf3WFy6oYqr29gI2mWTLScsizKga','Game Dev','13800138014','gd@test.com','gd123',NULL,66.00,1800,'1','','','','',1,0,0,'1',1800,1,'普通会员',NULL,NULL,0,'',0,'',NULL,0,0,'',0,NULL,0,0,0,0,'',NULL,'[\"R_USER\"]','2026-06-22 22:39:49','2026-07-10 22:39:49',0,'',0,0,0),
(15,'security_pro','$2b$10$aFA/Waln/adFPLLhhPjbbOGMjYf3WFy6oYqr29gI2mWTLScsizKga','Security Pro','13800138015','sp@test.com','sp123',NULL,155.00,4200,'1','','','','',1,0,0,'1',4200,2,'黄金会员',NULL,NULL,0,'',0,'',NULL,0,0,'',0,NULL,0,0,0,0,'',NULL,'[\"R_USER\"]','2026-07-10 22:39:49','2026-07-10 22:39:49',0,'',0,0,0),
(16,'deleted1','x','x','','','Deleted1',NULL,0.00,0,'男','','','','',1,0,0,'4',0,0,'普通会员',NULL,NULL,0,'',0,'',NULL,0,0,'',0,NULL,0,0,0,0,'',NULL,'[\"R_USER\"]','2026-06-10 22:39:49','2026-07-10 22:39:49',0,'',0,0,0),
(17,'deleted2','x','x','','','Deleted2',NULL,0.00,0,'男','','','','',1,0,0,'4',0,0,'普通会员',NULL,NULL,0,'',0,'',NULL,0,0,'',0,NULL,0,0,0,0,'',NULL,'[\"R_USER\"]','2026-06-20 22:39:49','2026-07-10 22:39:49',0,'',0,0,0),
(18,'deleted3','x','x','','','Deleted3',NULL,0.00,0,'男','','','','',1,0,0,'4',0,0,'普通会员',NULL,NULL,0,'',0,'',NULL,0,0,'',0,NULL,0,0,0,0,'',NULL,'[\"R_USER\"]','2026-06-30 22:39:49','2026-07-10 22:39:49',0,'',0,0,0),
(19,'alexmorgan','123456','$2b$10$RxSguXB.VDgevEuwqYwIWO7twebFLr4C3.BHC.blABc9vzHfifcD.','18670001591','alexmorgan@company.com','Alex Morgan',NULL,4967.00,2100,'男','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/1783825711273-855569135.jpg','','','',1,2,0,'1',96819,2,'黄金会员','2026-11-11 09:08:18',NULL,0,'',1,'设计达人',NULL,0,0,'',0,'2013-07-12',0,0,0,0,'',NULL,'[\"R_SUPER\"]','2026-07-10 22:44:56','2026-07-12 03:08:31',1,'',0,10,10);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `verification_config`
--

DROP TABLE IF EXISTS `verification_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `verification_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `condition_type` varchar(50) NOT NULL,
  `threshold` int(11) DEFAULT 0,
  `is_active` int(11) DEFAULT 0,
  `logic_type` varchar(20) DEFAULT 'any',
  `logic_count` int(11) DEFAULT 1,
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `verification_config`
--

LOCK TABLES `verification_config` WRITE;
/*!40000 ALTER TABLE `verification_config` DISABLE KEYS */;
INSERT INTO `verification_config` VALUES
(3,'follower_count',100,1,'AND',2,'2026-07-10 20:17:40','2026-07-10 20:17:40');
/*!40000 ALTER TABLE `verification_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `verification_requests`
--

DROP TABLE IF EXISTS `verification_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `verification_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `real_name` varchar(100) DEFAULT '',
  `id_card` varchar(50) DEFAULT '',
  `organization` varchar(200) DEFAULT '',
  `reason` text DEFAULT NULL,
  `proof_urls` text DEFAULT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `review_comment` text DEFAULT NULL,
  `review_by` varchar(100) DEFAULT '',
  `review_time` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  `selected_condition` varchar(50) DEFAULT '',
  `selected_app_id` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_verification_requests_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `verification_requests`
--

LOCK TABLES `verification_requests` WRITE;
/*!40000 ALTER TABLE `verification_requests` DISABLE KEYS */;
INSERT INTO `verification_requests` VALUES
(1,2,'','用户1','440137500550','科技有限公司','申请蓝V认证',NULL,'pending',NULL,'',NULL,'2026-07-06 22:39:54','',0),
(2,3,'','用户2','440126591708','网络科技公司','申请蓝V认证',NULL,'approved',NULL,'',NULL,'2026-07-09 22:39:54','',0),
(3,4,'','用户3','440134963635','设计工作室','申请蓝V认证',NULL,'approved',NULL,'',NULL,'2026-07-05 22:39:54','',0),
(4,5,'','用户4','440147897279','科技有限公司','申请蓝V认证',NULL,'rejected',NULL,'',NULL,'2026-07-08 22:39:54','',0),
(5,6,'','用户5','440183856527','网络科技公司','申请蓝V认证',NULL,'pending',NULL,'',NULL,'2026-06-21 22:39:54','',0);
/*!40000 ALTER TABLE `verification_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `withdraw_records`
--

DROP TABLE IF EXISTS `withdraw_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `withdraw_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `amount` decimal(10,2) NOT NULL,
  `method` varchar(30) DEFAULT 'alipay',
  `account` varchar(200) DEFAULT '',
  `real_name` varchar(50) DEFAULT '',
  `status` varchar(20) DEFAULT 'pending',
  `remark` text DEFAULT '',
  `reviewed_by` int(11) DEFAULT 0,
  `reviewed_by_name` varchar(100) DEFAULT '',
  `reviewed_at` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_withdraw_records_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `withdraw_records`
--

LOCK TABLES `withdraw_records` WRITE;
/*!40000 ALTER TABLE `withdraw_records` DISABLE KEYS */;
INSERT INTO `withdraw_records` VALUES
(1,5,'user5',12.64,'alipay','','','pending','',0,'',NULL,'2026-07-10 22:39:54'),
(2,5,'user5',96.40,'wechat','','','completed','',0,'',NULL,'2026-06-26 22:39:54'),
(3,4,'user4',90.32,'alipay','','','rejected','',0,'',NULL,'2026-06-30 22:39:54'),
(4,7,'user7',87.49,'wechat','','','pending','',0,'',NULL,'2026-06-30 22:39:54'),
(5,8,'user8',15.46,'alipay','','','completed','',0,'',NULL,'2026-06-25 22:39:54'),
(6,9,'user9',32.49,'wechat','','','rejected','',0,'',NULL,'2026-06-28 22:39:54'),
(7,8,'user8',84.19,'alipay','','','pending','',0,'',NULL,'2026-07-07 22:39:54'),
(8,8,'user8',38.85,'wechat','','','completed','',0,'',NULL,'2026-06-23 22:39:54');
/*!40000 ALTER TABLE `withdraw_records` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-12  8:48:20
