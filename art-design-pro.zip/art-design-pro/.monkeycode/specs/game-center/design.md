# 游戏中心

Feature Name: game-center
Updated: 2026-07-11

## 描述

在社区"游戏大厅"入口基础上，实现完整游戏中心：前台游戏大厅列表 + 4款游戏 + 后台配置管理。所有游戏消耗系统现有积分，按会员等级折扣。

## 架构

```mermaid
graph TD
    A["社区发现更多-游戏大厅入口"] --> B["游戏大厅列表页"]
    B --> C1["金币抽奖"]
    B --> C2["卡片字母竞猜"]
    B --> C3["大小点数竞猜"]
    B --> C4["剪刀石头布"]
    D["运营管理-游戏中心"] --> E1["游戏配置管理"]
    D --> E2["参与记录查看"]
    D --> E3["统计数据"]
    E1 --> F1["game_configs表"]
    E2 --> F2["game_records表"]
```

## 组件与接口

### 前台路由

| 路径 | 组件 | 说明 |
|------|------|------|
| `/community/game-hall` | `community/game-hall.vue` | 游戏大厅列表 |
| `/community/game-hall/lottery` | `community/game-lottery.vue` | 金币抽奖 |
| `/community/game-hall/card-guess` | `community/game-card-guess.vue` | 卡片字母竞猜 |
| `/community/game-hall/dice` | `community/game-dice.vue` | 大小点数竞猜 |
| `/community/game-hall/rps` | `community/game-rps.vue` | 剪刀石头布 |

### 后台路由（运营管理子菜单）

| 路径 | 组件 | 说明 |
|------|------|------|
| `/operation/game-center` | `operation/game-center/index.vue` | 游戏配置列表 |
| `/operation/game-center/config/:gameType` | `operation/game-center/config.vue` | 单游戏配置编辑 |

### API 接口

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/api/game/list` | 获取游戏列表 |
| GET | `/api/game/config/:gameType` | 获取游戏配置 |
| POST | `/api/game/config/:gameType` | 保存游戏配置 |
| POST | `/api/game/lottery/draw` | 金币抽奖单抽 |
| POST | `/api/game/lottery/draw10` | 金币抽奖10连抽 |
| POST | `/api/game/card-guess/flip` | 卡片竞猜翻牌 |
| POST | `/api/game/dice/bet` | 大小竞猜下注 |
| POST | `/api/game/rps/play` | 剪刀石头布出拳 |
| GET | `/api/game/records` | 查询参与记录 |
| GET | `/api/game/stats` | 游戏统计数据 |

### 后端路由文件

`server/routes/game.cjs`

## 数据模型

### game_configs 表

```sql
id INTEGER PRIMARY KEY AUTO_INCREMENT
game_type VARCHAR(30) NOT NULL           -- lottery / card_guess / dice / rps
config_data JSON NOT NULL                -- 完整游戏配置
enabled TINYINT DEFAULT 1
create_time DATETIME DEFAULT NOW()
update_time DATETIME DEFAULT NOW()
```

### game_records 表

```sql
id INTEGER PRIMARY KEY AUTO_INCREMENT
user_id INTEGER NOT NULL
game_type VARCHAR(30) NOT NULL
result VARCHAR(20) NOT NULL              -- win / lose / draw
points_spent INTEGER DEFAULT 0
points_won INTEGER DEFAULT 0
detail JSON                             -- 抽奖格位/卡片/点数/手势等详情
create_time DATETIME DEFAULT NOW()
```

### game_configs.config_data 结构（金币抽奖示例）

```json
{
  "enabled": true,
  "costPerDraw": 100,
  "costPerDraw10": 900,
  "pityCount": 50,
  "pityGridIndex": 5,
  "grids": [
    { "index": 0, "name": "100积分", "type": "points", "value": 100, "probability": 30 },
    { "index": 1, "name": "50积分", "type": "points", "value": 50, "probability": 25 },
    ...
  ],
  "memberDiscounts": [
    { "levelId": 2, "levelName": "黄金会员", "discount": 0.9 },
    { "levelId": 3, "levelName": "钻石会员", "discount": 0.8 }
  ]
}
```

## 正确性约束

- 概率总和不超过 100%
- 10连抽优惠价必须低于单抽x10
- 保底次数必须 >= 1
- 抽奖扣积分前必须校验余额充足
- 会员折扣仅限有有效会员的用户

## 错误处理

- 积分不足返回 400 "积分不足"
- 游戏已停用返回 400 "游戏已停用"
- 配置数据校验失败返回 400 并说明原因
- 未登录返回 401

## 测试策略

- 后端 API 用 curl 手动验证
- 前端页面用浏览器 DevTools 验证
- 概率分布用多次调用验证大致符合配置
- 保底机制用客户端连续调用验证

## 参考资料

[^1]: `server/routes/operation.cjs` -- 运营管理 API 参考
[^2]: `src/router/modules/operation.ts` -- 运营管理路由配置
[^3]: `server/database.cjs` -- 数据库表创建模式
