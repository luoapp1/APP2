# 主题系统 — 技术设计文档

Feature Name: theme-system
Updated: 2026-07-06

## 描述

预设主题管理系统，每个主题包含 **PC 版** 和 **手机版** 两套设计令牌。系统通过 User-Agent 自动检测设备类型并应用对应版本。管理员可创建、编辑、删除主题；用户可在设置面板切换主题。

## 架构

```mermaid
graph TD
    A["用户访问网页"] --> B{"User-Agent 检测"}
    B -->|PC| C["应用 vars + varsDark"]
    B -->|Mobile| D["应用 varsMobile + varsMobileDark"]
    C --> E["PC 版界面渲染"]
    D --> F["手机版界面渲染"]

    G["App.vue 启动"] --> H["GET /api/themes/active"]
    H --> I["返回 {vars, varsDark, varsMobile, varsMobileDark}"]
    I --> J["detectDevice() → 'pc' | 'mobile'"]
    J --> K["applyThemeVars(deviceVars, deviceVarsDark)"]
    K --> L["注入 CSS 变量到 :root 和 .dark"]

    M["设置面板切换主题"] --> N["PUT /api/themes/:id/activate"]
    N --> O["重新获取 active 主题 → applyThemeVars"]
```

## 组件与接口

### 1. 后端 — 数据库表 `themes`

```sql
CREATE TABLE themes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name VARCHAR(100) NOT NULL,
  description TEXT DEFAULT '',
  is_preset INTEGER DEFAULT 0,
  is_active INTEGER DEFAULT 0,
  thumbnail TEXT DEFAULT '',
  vars TEXT NOT NULL,
  vars_dark TEXT NOT NULL,
  vars_mobile TEXT NOT NULL,
  vars_mobile_dark TEXT NOT NULL,
  create_time DATETIME DEFAULT (datetime('now','localtime')),
  update_time DATETIME DEFAULT (datetime('now','localtime'))
);
```

### 2. 设备检测

服务端 `GET /api/themes/active` 根据请求 `User-Agent` 判断设备类型，返回字段中增加 `device: 'pc' | 'mobile'`。前端据此选择要应用哪套令牌。

### 3. 后端 — API 路由 (`server/routes/themes.cjs`)

| 方法 | 路径 | 认证 | 说明 |
|------|------|------|------|
| GET | `/api/themes` | 否 | 获取所有主题名称列表 |
| GET | `/api/themes/active` | 否 | 获取激活主题完整数据（含 device 标识） |
| GET | `/api/themes/:id` | 是 | 获取单个主题详情 |
| POST | `/api/themes` | 是 | 创建新主题 |
| PUT | `/api/themes/:id` | 是 | 更新主题 |
| DELETE | `/api/themes/:id` | 是 | 删除主题（不可删预设） |
| PUT | `/api/themes/:id/activate` | 否 | 激活指定主题 |

### 4. 设计令牌定义 (28 个，每套主题 × 4 组 = 112 个值)

| 令牌 key | CSS 变量 | 说明 |
|----------|----------|------|
| mainColor | `--main-color` | 主题色 |
| primary | `--art-primary` | 主色 OKLCH |
| secondary | `--art-secondary` | 辅色 |
| gray100~gray900 | `--art-gray-100`~`--art-gray-900` | 9 级灰阶 |
| bgColor | `--default-bg-color` | 页面背景 |
| boxColor | `--default-box-color` | 组件背景 |
| hoverColor | `--art-hover-color` | 悬停态 |
| activeColor | `--art-active-color` | 激活态 |
| elActiveColor | `--art-el-active-color` | 组件激活态 |
| defaultBorder | `--default-border` | 默认边框 |
| dashedBorder | `--default-border-dashed` | 虚线边框 |
| cardBorder | `--art-card-border` | 卡片边框 |
| error | `--art-error` | 错误色 |
| info | `--art-info` | 信息色 |
| success | `--art-success` | 成功色 |
| warning | `--art-warning` | 警告色 |
| danger | `--art-danger` | 危险色 |
| borderRadius | `--custom-radius` | 圆角 |
| shadowColor | `--art-shadow-color` | 阴影色 |
| fontFamily | `--art-font-family` | 字体 |

每组 vars 包含 28 个 `{ key: value }` 键值对。4 组分别为：`vars`(PC亮)、`varsDark`(PC暗)、`varsMobile`(手机亮)、`varsMobileDark`(手机暗)。

### 5. 前端 — `useTheme.ts` 新增

- `applyThemeVars(vars, target)` — 遍历 JSON 注入 CSS 变量
- `fetchActiveTheme()` — `GET /api/themes/active` → 根据 `device` 字段选择 vars
- `switchPresetTheme(id)` — `PUT /api/themes/:id/activate` → 重新 fetch + apply
- `detectDevice()` — 通过 `navigator.userAgent` 判断 `pc` | `mobile`

### 6. 前端 — 主题管理页 `src/views/operation/themes/index.vue`

表格 + 编辑弹窗，弹窗内含 4 个 Tab：PC 亮色、PC 暗色、手机亮色、手机暗色，每个 Tab 渲染 28 个设计令牌的编辑控件。

### 7. 路由注册

`src/router/modules/operation.ts` 添加 `/operation/themes` → `Themes` 组件。

### 8. 种子数据

启动时检查 `themes` 表为空则插入 4 套预设，每套含 4 组令牌。

## 预设主题

| 名称 | PC 主色 | 手机主色 | 风格 |
|------|---------|----------|------|
| 经典蓝 | `#5D87FF` | `#5D87FF` | 清爽专业（当前默认） |
| 墨玉黑 | `#6366F1` | `#7C3AED` | 深沉科技风 |
| 森林绿 | `#059669` | `#10B981` | 清新自然 |
| 樱桃粉 | `#EC4899` | `#F472B6` | 柔和温暖 |

## 数据流

```
页面加载
  → fetchActiveTheme()
    → GET /api/themes/active (UA: Mozilla/5.0 ...)
    → 服务端: isMobileUA(ua) → device = 'mobile'
    → 返回 { vars, varsDark, varsMobile, varsMobileDark, device: 'mobile' }
  → applyThemeVars(varsMobile, ':root') + applyThemeVars(varsMobileDark, '.dark')
  → 手机版主题生效
```
