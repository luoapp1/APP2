# 主题系统 — 需求文档

## 引言

预设主题管理系统，每套主题包含 PC 版和手机版两套设计令牌。管理员创建和管理主题，用户切换主题。系统自动检测设备类型并应用对应版本。

## 术语表

- **主题（Theme）**：一套完整视觉风格，包含 PC 版和手机版各 28 个设计令牌（× 亮/暗两模式 = 每主题 112 个值）。
- **设备检测（Device Detection）**：通过 User-Agent 自动识别 PC/手机，应用对应版本的令牌。
- **设计令牌（Design Token）**：CSS 自定义属性键值对。

## 需求

### 需求 1：主题 CRUD 管理

1. WHEN 管理员访问主题管理页，the 系统 SHALL 展示所有主题列表（名称、是否激活、是否预设、创建时间）。
2. WHEN 管理员新建/编辑主题，the 系统 SHALL 提供 4 个 Tab 编辑区：PC 亮色、PC 暗色、手机亮色、手机暗色，每个 Tab 含 28 个令牌表单项。
3. WHEN 管理员保存主题，the 系统 SHALL 将 4 组令牌持久化到 `themes` 表。
4. WHEN 管理员删除主题，IF 该主题为预设主题，the 系统 SHALL 拒绝删除。

### 需求 2：设备自动识别

1. WHEN 用户访问网站，the 系统 SHALL 根据 User-Agent 自动判断设备类型。
2. IF 设备为 PC，the 系统 SHALL 应用主题的 `vars` + `varsDark`。
3. IF 设备为手机，the 系统 SHALL 应用主题的 `varsMobile` + `varsMobileDark`。

### 需求 3：主题切换

1. WHEN 用户在设置面板选择新主题，the 系统 SHALL 激活该主题，所有在线用户立即应用新主题的对应设备版本。
2. 暗色/亮色切换 SHALL 在主题内切换 `vars` ↔ `varsDark`（PC）或 `varsMobile` ↔ `varsMobileDark`（手机）。

### 需求 4：API

| 方法 | 路径 | 认证 | 说明 |
|------|------|------|------|
| GET | `/api/themes` | 否 | 所有主题列表 |
| GET | `/api/themes/active` | 否 | 激活主题（含 device 字段） |
| GET | `/api/themes/:id` | 是 | 主题详情 |
| POST | `/api/themes` | 是 | 新建 |
| PUT | `/api/themes/:id` | 是 | 更新 |
| DELETE | `/api/themes/:id` | 是 | 删除 |
| PUT | `/api/themes/:id/activate` | 否 | 激活 |

### 需求 5：前端初始化

1. WHEN `App.vue` 启动，the 系统 SHALL 从服务端获取激活主题并应用对应设备版本的令牌。
2. IF 服务端不可达，the 系统 SHALL 使用 localStorage 缓存的主题。
3. IF 无缓存，the 系统 SHALL 使用硬编码默认令牌。

### 需求 6：预设主题

系统首次初始化自动创建 4 套预设主题（经典蓝/墨玉黑/森林绿/樱桃粉），经典蓝为默认激活主题。每套包含 PC 亮/暗 + 手机亮/暗 共 4 组令牌。
