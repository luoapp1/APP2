const path = require('path')
const config = require('./config.cjs')

const dbType = config.dbType || 'sqlite'
let pool

function getPool() {
  if (pool) return pool

  if (dbType === 'sqlite') {
    const Database = require('better-sqlite3')
    const dbPath = path.resolve(__dirname, config.sqlite.filePath || './data.db')
    const db = new Database(dbPath)
    db.pragma('journal_mode = WAL')
    db.pragma('foreign_keys = ON')
    pool = db
  } else if (dbType === 'mysql') {
    const mysql = require('mysql2')
    const { host, port, user, password, database } = config.mysql
    pool = mysql.createPool({
      host, port, user, password, database,
      waitForConnections: true,
      connectionLimit: 10,
      charset: 'utf8mb4'
    })
  } else {
    throw new Error(`不支持的数据库类型: ${dbType}`)
  }

  initTables()
  return pool
}

function query(sql, params = []) {
  if (dbType === 'sqlite') {
    const db = getPool()
    const stmt = db.prepare(sql)
    if (/^\s*SELECT|PRAGMA/i.test(sql)) return Promise.resolve(stmt.all(...params))
    return Promise.resolve(stmt.run(...params))
  } else {
    return new Promise((resolve, reject) => {
      getPool().query(sql, params, (err, results) => {
        if (err) return reject(err)
        if (/^\s*SELECT|SHOW/i.test(sql)) return resolve(results)
        resolve({ lastInsertRowid: results.insertId, changes: results.affectedRows })
      })
    })
  }
}

function initTables() {
  const engine = dbType === 'mysql' ? ' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci' : ''
  const autoInc = dbType === 'mysql' ? 'AUTO_INCREMENT' : 'AUTOINCREMENT'
  const now = dbType === 'mysql' ? 'NOW()' : "(datetime('now','localtime'))"

  const tables = [
    `CREATE TABLE IF NOT EXISTS roles (
      id INTEGER PRIMARY KEY ${autoInc},
      role_name VARCHAR(100) NOT NULL,
      role_code VARCHAR(100) UNIQUE NOT NULL,
      description VARCHAR(500) DEFAULT '',
      enabled TINYINT(1) DEFAULT 1,
      create_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS menus (
      id INTEGER PRIMARY KEY ${autoInc},
      parent_id INTEGER DEFAULT 0,
      name VARCHAR(100) NOT NULL,
      path VARCHAR(200) NOT NULL DEFAULT '',
      component VARCHAR(200) DEFAULT '',
      redirect VARCHAR(200) DEFAULT '',
      title VARCHAR(100) NOT NULL,
      icon VARCHAR(100) DEFAULT '',
      sort_order INTEGER DEFAULT 0,
      is_hidden TINYINT(1) DEFAULT 0,
      is_full_page TINYINT(1) DEFAULT 0,
      is_keep_alive TINYINT(1) DEFAULT 1,
      is_fixed_tab TINYINT(1) DEFAULT 0,
      auth_list TEXT,
      roles TEXT,
      enabled TINYINT(1) DEFAULT 1,
      create_time DATETIME DEFAULT ${now},
      update_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS role_permissions (
      id INTEGER PRIMARY KEY ${autoInc},
      role_id INTEGER NOT NULL,
      menu_id INTEGER NOT NULL,
      UNIQUE(role_id, menu_id)
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS membership_levels (
      id INTEGER PRIMARY KEY ${autoInc},
      name VARCHAR(100) NOT NULL,
      level INTEGER NOT NULL DEFAULT 0,
      price DECIMAL(10,2) DEFAULT 0,
      points_required INTEGER DEFAULT 0,
      discount_rate DECIMAL(3,1) DEFAULT 1.0,
      points_multiplier DECIMAL(3,1) DEFAULT 1.0,
      benefits TEXT,
      icon VARCHAR(100) DEFAULT '',
      icon_color VARCHAR(20) DEFAULT '#909399',
      status VARCHAR(2) DEFAULT '1',
      create_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY ${autoInc},
      username VARCHAR(100) UNIQUE NOT NULL,
      password VARCHAR(200) NOT NULL DEFAULT '123456',
      phone VARCHAR(20) DEFAULT '',
      email VARCHAR(100) DEFAULT '',
      nickname VARCHAR(100) DEFAULT '',
      bio TEXT,
      balance DECIMAL(10,2) DEFAULT 0,
      experience INTEGER DEFAULT 0,
      gender VARCHAR(10) DEFAULT '男',
      avatar VARCHAR(500) DEFAULT '',
      bg_url VARCHAR(500) DEFAULT '',
      signature VARCHAR(300) DEFAULT '',
      qq VARCHAR(20) DEFAULT '',
      show_coin INTEGER DEFAULT 1,
      follow_count INTEGER DEFAULT 0,
      fans_count INTEGER DEFAULT 0,
      status VARCHAR(2) DEFAULT '1',
      points INTEGER DEFAULT 0,
      level_id INTEGER DEFAULT 0,
      level_name VARCHAR(100) DEFAULT '普通会员',
      expire_time DATETIME NULL,
      roles TEXT,
      create_time DATETIME DEFAULT ${now},
      update_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS card_keys (
      id INTEGER PRIMARY KEY ${autoInc},
      card_no VARCHAR(100) UNIQUE NOT NULL,
      password VARCHAR(100) NOT NULL,
      type VARCHAR(20) NOT NULL DEFAULT 'membership',
      target_id INTEGER DEFAULT 0,
      target_name VARCHAR(100) DEFAULT '',
      value INTEGER DEFAULT 0,
      extra_points INTEGER DEFAULT 0,
      extra_experience INTEGER DEFAULT 0,
      duration INTEGER DEFAULT 0,
      duration_unit VARCHAR(10) DEFAULT '',
      status VARCHAR(2) DEFAULT '0',
      create_by VARCHAR(100) DEFAULT '管理员',
      create_time DATETIME DEFAULT ${now},
      redeem_by VARCHAR(100) DEFAULT '',
      redeem_time DATETIME NULL
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS points_records (
      id INTEGER PRIMARY KEY ${autoInc},
      user_id INTEGER NOT NULL,
      user_name VARCHAR(100) DEFAULT '',
      type VARCHAR(20) NOT NULL DEFAULT 'earn',
      points INTEGER NOT NULL DEFAULT 0,
      balance INTEGER DEFAULT 0,
      source VARCHAR(200) DEFAULT '',
      description TEXT,
      create_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS experience_levels (
      id INTEGER PRIMARY KEY ${autoInc},
      name VARCHAR(100) NOT NULL,
      level INTEGER NOT NULL DEFAULT 0,
      exp_required INTEGER NOT NULL DEFAULT 0,
      icon VARCHAR(100) DEFAULT '',
      icon_color VARCHAR(20) DEFAULT '#00BFA5',
      benefits TEXT,
      status VARCHAR(2) DEFAULT '1',
      create_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS plugins (
      id INTEGER PRIMARY KEY ${autoInc},
      name VARCHAR(100) NOT NULL,
      description TEXT,
      version VARCHAR(50) DEFAULT '1.0.0',
      author VARCHAR(100) DEFAULT '',
      icon VARCHAR(500) DEFAULT '',
      entry_url VARCHAR(500) DEFAULT '',
      component_name VARCHAR(200) DEFAULT '',
      status VARCHAR(2) DEFAULT '1',
      create_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS app_store (
      id INTEGER PRIMARY KEY ${autoInc},
      name VARCHAR(200) NOT NULL,
      package_name VARCHAR(200) DEFAULT '',
      version VARCHAR(50) DEFAULT '1.0.0',
      version_code VARCHAR(50) DEFAULT '100',
      icon VARCHAR(500) DEFAULT '',
      icon_bg_color VARCHAR(20) DEFAULT '#00BFA5',
      size_mb DECIMAL(10,1) DEFAULT 0,
      downloads INTEGER DEFAULT 0,
      rating DECIMAL(2,1) DEFAULT 0,
      description TEXT,
      update_content TEXT,
      screenshots TEXT,
      tags TEXT,
      download_url VARCHAR(500) DEFAULT '',
      coin_count INTEGER DEFAULT 0,
      coin_people INTEGER DEFAULT 0,
      developer VARCHAR(100) DEFAULT '',
      category VARCHAR(100) DEFAULT '工具',
      categories TEXT,
      category_id INTEGER DEFAULT 0,
      status VARCHAR(2) DEFAULT '1',
      is_pinned TINYINT(1) DEFAULT 0,
      user_id INTEGER DEFAULT 0,
      create_time DATETIME DEFAULT ${now},
      update_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS app_comments (
      id INTEGER PRIMARY KEY ${autoInc},
      app_id INTEGER NOT NULL,
      parent_id INTEGER DEFAULT 0,
      user_id INTEGER DEFAULT 0,
      user_name VARCHAR(100) DEFAULT '',
      user_avatar VARCHAR(20) DEFAULT '#FF5777',
      device VARCHAR(200) DEFAULT '',
      version VARCHAR(50) DEFAULT '',
      content TEXT,
      likes INTEGER DEFAULT 0,
      replies INTEGER DEFAULT 0,
      reported INTEGER DEFAULT 0,
      is_pinned TINYINT(1) DEFAULT 0,
      rating DECIMAL(2,1) DEFAULT 0,
      create_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS app_versions (
      id INTEGER PRIMARY KEY ${autoInc},
      app_id INTEGER NOT NULL,
      version VARCHAR(50) NOT NULL,
      version_code VARCHAR(50) DEFAULT '',
      size_mb DECIMAL(10,1) DEFAULT 0,
      downloads INTEGER DEFAULT 0,
      rating DECIMAL(2,1) DEFAULT 0,
      update_content TEXT,
      tags TEXT,
      download_url VARCHAR(500) DEFAULT '',
      is_current TINYINT(1) DEFAULT 0,
      user_id INTEGER DEFAULT 0,
      user_name VARCHAR(100) DEFAULT '',
      status VARCHAR(2) DEFAULT '1',
      create_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS app_uploads (
      id INTEGER PRIMARY KEY ${autoInc},
      app_id INTEGER DEFAULT 0,
      user_id INTEGER NOT NULL,
      user_name VARCHAR(100) DEFAULT '',
      name VARCHAR(200) NOT NULL,
      package_name VARCHAR(200) DEFAULT '',
      category VARCHAR(100) DEFAULT '工具',
      description TEXT,
      icon VARCHAR(500) DEFAULT '',
      icon_bg_color VARCHAR(20) DEFAULT '#00BFA5',
      version VARCHAR(50) DEFAULT '1.0.0',
      version_code VARCHAR(50) DEFAULT '100',
      size_mb DECIMAL(10,1) DEFAULT 0,
      download_url VARCHAR(500) DEFAULT '',
      screenshots TEXT,
      tags TEXT,
      version_type VARCHAR(20) DEFAULT '',
      has_ads INTEGER DEFAULT 0,
      requires_network INTEGER DEFAULT 1,
      has_paid_content INTEGER DEFAULT 0,
      is_free INTEGER DEFAULT 1,
      downloads INTEGER DEFAULT 0,
      rating DECIMAL(2,1) DEFAULT 0,
      coin_count INTEGER DEFAULT 0,
      coin_people INTEGER DEFAULT 0,
      review_count INTEGER DEFAULT 0,
      five_star_count INTEGER DEFAULT 0,
      status VARCHAR(2) DEFAULT '0',
      submission_status VARCHAR(20) DEFAULT 'draft',
      review_comment TEXT,
      review_by VARCHAR(100) DEFAULT '',
      review_time DATETIME NULL,
      create_time DATETIME DEFAULT ${now},
      update_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS app_categories (
      id INTEGER PRIMARY KEY ${autoInc},
      name VARCHAR(64) NOT NULL,
      icon VARCHAR(255) DEFAULT '',
      sort_order INTEGER DEFAULT 0,
      status CHAR(1) DEFAULT '1',
      create_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS app_tips (
      id INTEGER PRIMARY KEY ${autoInc},
      app_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      user_name VARCHAR(64) DEFAULT '',
      amount DECIMAL(10,2) NOT NULL DEFAULT 0,
      tip_type VARCHAR(20) DEFAULT 'balance',
      message VARCHAR(255) DEFAULT '',
      create_time DATETIME DEFAULT ${now}
    )${engine}`,
 
    `CREATE TABLE IF NOT EXISTS comment_likes (
      id INTEGER PRIMARY KEY ${autoInc},
      comment_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      UNIQUE(comment_id, user_id)
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS app_official_tags (
      id INTEGER PRIMARY KEY ${autoInc},
      name VARCHAR(64) NOT NULL,
      color VARCHAR(20) DEFAULT '#2563eb',
      bg_color VARCHAR(20) DEFAULT '#dbeafe',
      sort_order INTEGER DEFAULT 0,
      status VARCHAR(2) DEFAULT '1',
      create_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS sys_notifications (
      id INTEGER PRIMARY KEY ${autoInc},
      title VARCHAR(200) NOT NULL,
      content TEXT DEFAULT '',
      type VARCHAR(20) DEFAULT 'system',
      target_user_id INTEGER DEFAULT 0,
      is_read TINYINT(1) DEFAULT 0,
      create_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS private_messages (
      id INTEGER PRIMARY KEY ${autoInc},
      from_user_id INTEGER NOT NULL,
      from_user_name VARCHAR(100) DEFAULT '',
      from_user_avatar VARCHAR(20) DEFAULT '#448AFF',
      to_user_id INTEGER NOT NULL,
      content TEXT DEFAULT '',
      is_read TINYINT(1) DEFAULT 0,
      create_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS hidden_conversations (
      id INTEGER PRIMARY KEY ${autoInc},
      user_id INTEGER NOT NULL,
      partner_id INTEGER NOT NULL,
      create_time DATETIME DEFAULT ${now},
      UNIQUE(user_id, partner_id)
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS app_purchases (
      id INTEGER PRIMARY KEY ${autoInc},
      app_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      user_name VARCHAR(100) DEFAULT '',
      price_type VARCHAR(20) DEFAULT 'free',
      original_price DECIMAL(10,2) DEFAULT 0,
      paid_price DECIMAL(10,2) DEFAULT 0,
      discount_rate DECIMAL(3,1) DEFAULT 1.0,
      create_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS sessions (
      token VARCHAR(100) PRIMARY KEY,
      user_id INTEGER NOT NULL,
      user_name VARCHAR(100) NOT NULL,
      roles TEXT DEFAULT '[]',
      created_at INTEGER NOT NULL
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS community_attach_purchases (
      id INTEGER PRIMARY KEY ${autoInc},
      post_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      attach_url VARCHAR(500) NOT NULL DEFAULT '',
      coin_type VARCHAR(20) NOT NULL DEFAULT 'coin',
      coin_amount INTEGER NOT NULL DEFAULT 0,
      create_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS community_sections (
      id INTEGER PRIMARY KEY ${autoInc},
      name VARCHAR(100) NOT NULL,
      icon VARCHAR(500) DEFAULT '',
      icon_bg_color VARCHAR(20) DEFAULT '#00BFA5',
      description TEXT DEFAULT '',
      today_heat INTEGER DEFAULT 0,
      total_heat INTEGER DEFAULT 0,
      post_count INTEGER DEFAULT 0,
      view_count INTEGER DEFAULT 0,
      sort_order INTEGER DEFAULT 0,
      status VARCHAR(20) DEFAULT 'active',
      visibility VARCHAR(20) DEFAULT 'public',
      post_permission VARCHAR(20) DEFAULT 'all',
      view_permission VARCHAR(20) DEFAULT 'all',
      view_level_required INTEGER DEFAULT 0,
      create_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS community_posts (
      id INTEGER PRIMARY KEY ${autoInc},
      section_id INTEGER NOT NULL DEFAULT 0,
      user_id INTEGER NOT NULL,
      user_name VARCHAR(100) DEFAULT '',
      user_avatar VARCHAR(500) DEFAULT '',
      title VARCHAR(500) DEFAULT '',
      content TEXT DEFAULT '',
      device VARCHAR(100) DEFAULT '',
      tags TEXT DEFAULT '[]',
      official_tags TEXT DEFAULT '[]',
      images TEXT DEFAULT '[]',
      has_resource INTEGER DEFAULT 0,
      resource_type VARCHAR(20) DEFAULT '',
      resource_url TEXT DEFAULT '',
      resource_price REAL DEFAULT 0,
      resource_price_type VARCHAR(20) DEFAULT 'free',
      extract_code VARCHAR(100) DEFAULT '',
      permission VARCHAR(20) DEFAULT 'public',
      is_pinned INTEGER DEFAULT 0,
      is_essence INTEGER DEFAULT 0,
      is_hot INTEGER DEFAULT 0,
      hot_manually_disabled TINYINT(1) DEFAULT 0,
      status VARCHAR(20) DEFAULT 'published',
      like_count INTEGER DEFAULT 0,
      comment_count INTEGER DEFAULT 0,
      coin_count INTEGER DEFAULT 0,
      view_count INTEGER DEFAULT 0,
      favorite_count INTEGER DEFAULT 0,
      scheduled_time DATETIME DEFAULT NULL,
      create_time DATETIME DEFAULT ${now},
      update_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS community_comments (
      id INTEGER PRIMARY KEY ${autoInc},
      post_id INTEGER NOT NULL,
      parent_id INTEGER DEFAULT 0,
      user_id INTEGER NOT NULL,
      user_name VARCHAR(100) DEFAULT '',
      user_avatar VARCHAR(500) DEFAULT '',
      content TEXT NOT NULL,
      like_count INTEGER DEFAULT 0,
      reply_count INTEGER DEFAULT 0,
      create_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS community_likes (
      id INTEGER PRIMARY KEY ${autoInc},
      post_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      create_time DATETIME DEFAULT ${now},
      UNIQUE(post_id, user_id)
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS community_favorites (
      id INTEGER PRIMARY KEY ${autoInc},
      post_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      create_time DATETIME DEFAULT ${now},
      UNIQUE(post_id, user_id)
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS community_drafts (
      id INTEGER PRIMARY KEY ${autoInc},
      user_id INTEGER NOT NULL,
      section_id INTEGER DEFAULT 0,
      title VARCHAR(500) DEFAULT '',
      content TEXT DEFAULT '',
      images TEXT DEFAULT '[]',
      tags TEXT DEFAULT '[]',
      official_tags TEXT DEFAULT '[]',
      has_resource INTEGER DEFAULT 0,
      resource_type VARCHAR(20) DEFAULT '',
      resource_url TEXT DEFAULT '',
      resource_price REAL DEFAULT 0,
      resource_price_type VARCHAR(20) DEFAULT 'free',
      extract_code VARCHAR(100) DEFAULT '',
      permission VARCHAR(20) DEFAULT 'public',
      create_time DATETIME DEFAULT ${now},
      update_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS community_banned_users (
      id INTEGER PRIMARY KEY ${autoInc},
      user_id INTEGER NOT NULL UNIQUE,
      user_name VARCHAR(100) DEFAULT '',
      reason VARCHAR(500) DEFAULT '',
      banned_until DATETIME DEFAULT NULL,
      create_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS community_coin_logs (
      id INTEGER PRIMARY KEY ${autoInc},
      post_id INTEGER NOT NULL,
      from_user_id INTEGER NOT NULL,
      from_user_name VARCHAR(100) DEFAULT '',
      from_user_avatar VARCHAR(500) DEFAULT '',
      to_user_id INTEGER NOT NULL DEFAULT 0,
      amount INTEGER DEFAULT 0,
      coin_type VARCHAR(20) DEFAULT 'coin',
      create_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS community_moderators (
      id INTEGER PRIMARY KEY ${autoInc},
      section_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      user_name VARCHAR(100) DEFAULT '',
      user_avatar VARCHAR(500) DEFAULT '',
      role VARCHAR(20) DEFAULT '版主',
      sort_order INTEGER DEFAULT 0,
      create_time DATETIME DEFAULT ${now},
      UNIQUE(section_id, user_id)
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS user_follows (
      id INTEGER PRIMARY KEY ${autoInc},
      follower_id INTEGER NOT NULL,
      following_id INTEGER NOT NULL,
      create_time DATETIME DEFAULT ${now},
      UNIQUE(follower_id, following_id)
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS custom_titles (
      id INTEGER PRIMARY KEY ${autoInc},
      name VARCHAR(100) NOT NULL,
      icon VARCHAR(500) DEFAULT '',
      color VARCHAR(20) DEFAULT '#409EFF',
      bg_color VARCHAR(20) DEFAULT '#ecf5ff',
      description VARCHAR(500) DEFAULT '',
      condition_type VARCHAR(20) DEFAULT 'manual',
      condition_value VARCHAR(200) DEFAULT '',
      sort_order INTEGER DEFAULT 0,
      status VARCHAR(2) DEFAULT '1',
      create_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS user_titles (
      id INTEGER PRIMARY KEY ${autoInc},
      user_id INTEGER NOT NULL,
      title_id INTEGER NOT NULL,
      is_active TINYINT(1) DEFAULT 1,
      grant_by VARCHAR(100) DEFAULT '',
      grant_time DATETIME DEFAULT ${now},
      expire_time DATETIME NULL,
      UNIQUE(user_id, title_id)
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS verification_requests (
      id INTEGER PRIMARY KEY ${autoInc},
      user_id INTEGER NOT NULL,
      user_name VARCHAR(100) DEFAULT '',
      real_name VARCHAR(100) DEFAULT '',
      id_card VARCHAR(50) DEFAULT '',
      organization VARCHAR(200) DEFAULT '',
      reason TEXT,
      proof_urls TEXT,
      status VARCHAR(20) DEFAULT 'pending',
      review_comment TEXT,
      review_by VARCHAR(100) DEFAULT '',
      review_time DATETIME NULL,
      create_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS checkin_records (
      id INTEGER PRIMARY KEY ${autoInc},
      user_id INTEGER NOT NULL,
      user_name VARCHAR(100) DEFAULT '',
      checkin_date DATE NOT NULL,
      consecutive_days INTEGER DEFAULT 1,
      points_earned INTEGER DEFAULT 0,
      experience_earned INTEGER DEFAULT 0,
      create_time DATETIME DEFAULT ${now},
      UNIQUE(user_id, checkin_date)
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS email_config (
      id INTEGER PRIMARY KEY ${autoInc},
      host VARCHAR(200) NOT NULL DEFAULT '',
      port INTEGER NOT NULL DEFAULT 465,
      secure TINYINT(1) DEFAULT 1,
      user VARCHAR(200) NOT NULL DEFAULT '',
      password VARCHAR(200) NOT NULL DEFAULT '',
      from_name VARCHAR(100) DEFAULT '',
      from_address VARCHAR(200) DEFAULT '',
      test_address VARCHAR(200) DEFAULT '',
      register_verify TINYINT(1) DEFAULT 0,
      enabled TINYINT(1) DEFAULT 1,
      update_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS email_verifications (
      id INTEGER PRIMARY KEY ${autoInc},
      email VARCHAR(200) NOT NULL,
      code VARCHAR(10) NOT NULL,
      type VARCHAR(20) DEFAULT 'register',
      used TINYINT(1) DEFAULT 0,
      expires_at DATETIME NOT NULL,
      create_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS invite_codes (
      id INTEGER PRIMARY KEY ${autoInc},
      code VARCHAR(20) UNIQUE NOT NULL,
      created_by INTEGER DEFAULT 0,
      created_by_name VARCHAR(100) DEFAULT '',
      used_by INTEGER DEFAULT 0,
      used_by_name VARCHAR(100) DEFAULT '',
      max_uses INTEGER DEFAULT 1,
      use_count INTEGER DEFAULT 0,
      status VARCHAR(2) DEFAULT '1',
      used_at DATETIME NULL,
      expires_at DATETIME NULL,
      create_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS balance_records (
      id INTEGER PRIMARY KEY ${autoInc},
      user_id INTEGER NOT NULL,
      user_name VARCHAR(100) DEFAULT '',
      type VARCHAR(20) NOT NULL DEFAULT 'earn',
      amount DECIMAL(10,2) NOT NULL DEFAULT 0,
      balance DECIMAL(10,2) DEFAULT 0,
      source VARCHAR(200) DEFAULT '',
      description TEXT,
      ref_id INTEGER DEFAULT 0,
      ref_type VARCHAR(50) DEFAULT '',
      create_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS file_repository (
      id INTEGER PRIMARY KEY ${autoInc},
      user_id INTEGER DEFAULT 0,
      user_name VARCHAR(100) DEFAULT '',
      file_name VARCHAR(500) NOT NULL,
      file_path VARCHAR(500) NOT NULL,
      file_size BIGINT DEFAULT 0,
      file_type VARCHAR(100) DEFAULT '',
      mime_type VARCHAR(200) DEFAULT '',
      category VARCHAR(50) DEFAULT 'other',
      ref_id INTEGER DEFAULT 0,
      ref_type VARCHAR(50) DEFAULT '',
      create_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS recycle_bin (
      id INTEGER PRIMARY KEY ${autoInc},
      original_table VARCHAR(100) NOT NULL,
      original_id INTEGER NOT NULL,
      data_json TEXT NOT NULL,
      deleted_by INTEGER DEFAULT 0,
      deleted_by_name VARCHAR(100) DEFAULT '',
      delete_reason VARCHAR(500) DEFAULT '',
      create_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS system_logs (
      id INTEGER PRIMARY KEY ${autoInc},
      user_id INTEGER DEFAULT 0,
      user_name VARCHAR(100) DEFAULT 'system',
      type VARCHAR(30) NOT NULL,
      target_type VARCHAR(50) DEFAULT '',
      target_id INTEGER DEFAULT 0,
      detail TEXT DEFAULT '',
      ip VARCHAR(50) DEFAULT '',
      create_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS custom_tasks (
      id INTEGER PRIMARY KEY ${autoInc},
      name VARCHAR(200) NOT NULL,
      description TEXT DEFAULT '',
      icon VARCHAR(500) DEFAULT '',
      task_type VARCHAR(30) NOT NULL DEFAULT 'daily',
      action_type VARCHAR(30) NOT NULL DEFAULT 'post',
      target_count INTEGER DEFAULT 1,
      section_id INTEGER DEFAULT 0,
      section_limit INTEGER DEFAULT 0,
      points_reward INTEGER DEFAULT 0,
      exp_reward INTEGER DEFAULT 0,
      balance_reward DECIMAL(10,2) DEFAULT 0,
      card_key_type VARCHAR(20) DEFAULT '',
      card_key_value INTEGER DEFAULT 0,
      card_key_duration INTEGER DEFAULT 0,
      title_id INTEGER DEFAULT 0,
      status VARCHAR(2) DEFAULT '1',
      sort_order INTEGER DEFAULT 0,
      create_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS task_records (
      id INTEGER PRIMARY KEY ${autoInc},
      user_id INTEGER NOT NULL,
      user_name VARCHAR(100) DEFAULT '',
      task_id INTEGER NOT NULL,
      task_name VARCHAR(200) DEFAULT '',
      progress INTEGER DEFAULT 0,
      target_count INTEGER DEFAULT 1,
      status VARCHAR(20) DEFAULT 'pending',
      completed_at DATETIME NULL,
      period_key VARCHAR(20) DEFAULT '',
      create_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS app_favorites (
      id INTEGER PRIMARY KEY ${autoInc},
      user_id INTEGER NOT NULL,
      app_id INTEGER NOT NULL,
      create_time DATETIME DEFAULT ${now},
      UNIQUE(user_id, app_id)
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS post_favorites (
      id INTEGER PRIMARY KEY ${autoInc},
      user_id INTEGER NOT NULL,
      post_id INTEGER NOT NULL,
      create_time DATETIME DEFAULT ${now},
      UNIQUE(user_id, post_id)
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS sys_config (
      id INTEGER PRIMARY KEY ${autoInc},
      config_key VARCHAR(100) UNIQUE NOT NULL,
      config_value TEXT DEFAULT '',
      description VARCHAR(200) DEFAULT '',
      update_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS commission_rules (
      id INTEGER PRIMARY KEY ${autoInc},
      name VARCHAR(100) DEFAULT '',
      order_type VARCHAR(30) DEFAULT 'all',
      rate DECIMAL(5,2) DEFAULT 0,
      user_level_id INTEGER DEFAULT 0,
      user_level_name VARCHAR(100) DEFAULT '',
      user_id INTEGER DEFAULT 0,
      status VARCHAR(2) DEFAULT '1',
      create_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS commission_records (
      id INTEGER PRIMARY KEY ${autoInc},
      order_id INTEGER DEFAULT 0,
      order_type VARCHAR(30) DEFAULT '',
      order_amount DECIMAL(10,2) DEFAULT 0,
      user_id INTEGER NOT NULL,
      user_name VARCHAR(100) DEFAULT '',
      referrer_id INTEGER NOT NULL,
      referrer_name VARCHAR(100) DEFAULT '',
      rate DECIMAL(5,2) DEFAULT 0,
      amount DECIMAL(10,2) DEFAULT 0,
      status VARCHAR(20) DEFAULT 'pending',
      create_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS withdraw_records (
      id INTEGER PRIMARY KEY ${autoInc},
      user_id INTEGER NOT NULL,
      user_name VARCHAR(100) DEFAULT '',
      amount DECIMAL(10,2) NOT NULL,
      method VARCHAR(30) DEFAULT 'alipay',
      account VARCHAR(200) DEFAULT '',
      real_name VARCHAR(50) DEFAULT '',
      status VARCHAR(20) DEFAULT 'pending',
      remark TEXT DEFAULT '',
      reviewed_by INTEGER DEFAULT 0,
      reviewed_by_name VARCHAR(100) DEFAULT '',
      reviewed_at DATETIME NULL,
      create_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS referral_links (
      id INTEGER PRIMARY KEY ${autoInc},
      user_id INTEGER NOT NULL UNIQUE,
      code VARCHAR(32) UNIQUE NOT NULL,
      mode VARCHAR(20) DEFAULT 'purchase',
      discount DECIMAL(5,2) DEFAULT 0,
      click_count INTEGER DEFAULT 0,
      register_count INTEGER DEFAULT 0,
      purchase_count INTEGER DEFAULT 0,
      create_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS points_transfer_records (
      id INTEGER PRIMARY KEY ${autoInc},
      from_user_id INTEGER NOT NULL,
      from_user_name VARCHAR(100) DEFAULT '',
      to_user_id INTEGER NOT NULL,
      to_user_name VARCHAR(100) DEFAULT '',
      amount INTEGER NOT NULL DEFAULT 0,
      fee INTEGER DEFAULT 0,
      remark VARCHAR(300) DEFAULT '',
      create_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS balance_transfer_records (
      id INTEGER PRIMARY KEY ${autoInc},
      from_user_id INTEGER NOT NULL,
      from_user_name VARCHAR(100) DEFAULT '',
      to_user_id INTEGER NOT NULL,
      to_user_name VARCHAR(100) DEFAULT '',
      amount DECIMAL(10,2) NOT NULL DEFAULT 0,
      fee DECIMAL(10,2) DEFAULT 0,
      remark VARCHAR(300) DEFAULT '',
      create_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS file_policies (
      id INTEGER PRIMARY KEY ${autoInc},
      name VARCHAR(100) DEFAULT '',
      user_level_id INTEGER DEFAULT 0,
      user_level_name VARCHAR(100) DEFAULT '',
      role_code VARCHAR(100) DEFAULT '',
      user_id INTEGER DEFAULT 0,
      max_file_size_mb INTEGER DEFAULT 10,
      allowed_types TEXT DEFAULT '',
      banned_types TEXT DEFAULT '',
      status VARCHAR(2) DEFAULT '1',
      create_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS membership_products (
      id INTEGER PRIMARY KEY ${autoInc},
      level_id INTEGER NOT NULL DEFAULT 0,
      name VARCHAR(100) DEFAULT '',
      price DECIMAL(10,2) DEFAULT 0,
      original_price DECIMAL(10,2) DEFAULT 0,
      duration_days INTEGER DEFAULT 30,
      is_promo TINYINT(1) DEFAULT 0,
      promo_end_time DATETIME NULL,
      status VARCHAR(2) DEFAULT '1',
      create_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS membership_purchases (
      id INTEGER PRIMARY KEY ${autoInc},
      user_id INTEGER NOT NULL,
      product_id INTEGER DEFAULT 0,
      level_id INTEGER DEFAULT 0,
      level_name VARCHAR(100) DEFAULT '',
      amount DECIMAL(10,2) DEFAULT 0,
      pay_type VARCHAR(20) DEFAULT 'balance',
      purchase_type VARCHAR(20) DEFAULT 'buy',
      duration_days INTEGER DEFAULT 0,
      expire_time DATETIME NULL,
      create_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS content_purchases (
      id INTEGER PRIMARY KEY ${autoInc},
      user_id INTEGER NOT NULL,
      content_type VARCHAR(20) DEFAULT 'post',
      content_id INTEGER NOT NULL,
      author_id INTEGER DEFAULT 0,
      amount DECIMAL(10,2) DEFAULT 0,
      pay_type VARCHAR(20) DEFAULT 'balance',
      commission_amount DECIMAL(10,2) DEFAULT 0,
      commission_rate DECIMAL(5,2) DEFAULT 0,
      create_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS content_access_passwords (
      id INTEGER PRIMARY KEY ${autoInc},
      content_type VARCHAR(20) DEFAULT 'post',
      content_id INTEGER NOT NULL,
      password VARCHAR(100) NOT NULL,
      tips VARCHAR(200) DEFAULT '',
      create_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS user_delete_requests (
      id INTEGER PRIMARY KEY ${autoInc},
      user_id INTEGER NOT NULL,
      username VARCHAR(100) DEFAULT '',
      admin_id INTEGER DEFAULT 0,
      admin_note VARCHAR(500) DEFAULT '',
      status VARCHAR(20) DEFAULT 'pending',
      create_time DATETIME DEFAULT ${now}
    )${engine}`
  ]

  const indexes = [
    'idx_users_username ON users(username)',
    'idx_users_status ON users(status)',
    'idx_card_keys_card_no ON card_keys(card_no)',
    'idx_card_keys_type ON card_keys(type)',
    'idx_points_records_user_id ON points_records(user_id)',
    'idx_points_records_type ON points_records(type)',
    'idx_app_comments_app_id ON app_comments(app_id)',
    'idx_app_store_status ON app_store(status)',
    'idx_app_versions_app_id ON app_versions(app_id)',
    'idx_app_uploads_user_id ON app_uploads(user_id)',
    'idx_app_tips_app ON app_tips(app_id)',
    'idx_app_tips_user ON app_tips(user_id)',
    'idx_sys_notifications_target_user ON sys_notifications(target_user_id)',
    'idx_private_messages_from ON private_messages(from_user_id)',
    'idx_private_messages_to ON private_messages(to_user_id)',
    'idx_private_messages_conversation ON private_messages(from_user_id, to_user_id)',
    'idx_app_purchases_app ON app_purchases(app_id)',
    'idx_app_purchases_user ON app_purchases(user_id)',
    'idx_app_purchases_user_app ON app_purchases(user_id, app_id)',
    'idx_community_posts_section_id ON community_posts(section_id)',
    'idx_community_posts_user_id ON community_posts(user_id)',
    'idx_community_posts_status ON community_posts(status)',
    'idx_community_posts_is_pinned ON community_posts(is_pinned)',
    'idx_community_posts_is_essence ON community_posts(is_essence)',
    'idx_community_posts_is_hot ON community_posts(is_hot)',
    'idx_community_comments_post_id ON community_comments(post_id)',
    'idx_community_comments_parent_id ON community_comments(parent_id)',
    'idx_community_likes_post_user ON community_likes(post_id, user_id)',
    'idx_community_favorites_post_user ON community_favorites(post_id, user_id)',
    'idx_community_drafts_user_id ON community_drafts(user_id)',
    'idx_community_banned_users_user_id ON community_banned_users(user_id)',
    'idx_user_follows_follower ON user_follows(follower_id)',
    'idx_user_follows_following ON user_follows(following_id)',
    'idx_user_titles_user ON user_titles(user_id)',
    'idx_checkin_records_user_date ON checkin_records(user_id, checkin_date)',
    'idx_verification_requests_user ON verification_requests(user_id)',
    'idx_email_verifications_email ON email_verifications(email)',
    'idx_invite_codes_code ON invite_codes(code)',
    'idx_balance_records_user ON balance_records(user_id)',
    'idx_file_repository_user ON file_repository(user_id)',
    'idx_recycle_bin_table ON recycle_bin(original_table)',
    'idx_system_logs_user ON system_logs(user_id)',
    'idx_system_logs_type ON system_logs(type)',
    'idx_system_logs_create ON system_logs(create_time)',
    'idx_task_records_user ON task_records(user_id)',
    'idx_task_records_period ON task_records(period_key)',
    'idx_app_favorites_user ON app_favorites(user_id)',
    'idx_app_favorites_app ON app_favorites(app_id)',
    'idx_post_favorites_user ON post_favorites(user_id)',
    'idx_post_favorites_post ON post_favorites(post_id)',
    'idx_commission_records_user ON commission_records(user_id)',
    'idx_commission_records_referrer ON commission_records(referrer_id)',
    'idx_withdraw_records_user ON withdraw_records(user_id)',
    'idx_referral_links_code ON referral_links(code)',
    'idx_membership_purchases_user ON membership_purchases(user_id)',
    'idx_content_purchases_user ON content_purchases(user_id)',
    'idx_content_purchases_content ON content_purchases(content_type, content_id)',
    'idx_content_access_passwords_content ON content_access_passwords(content_type, content_id)'
  ]

  if (dbType === 'sqlite') {
    const db = getPool()
    db.exec(tables.join(';\n'))
    indexes.forEach(i => { try { db.exec(`CREATE INDEX IF NOT EXISTS ${i}`) } catch {} })
    // Migration: add new columns for existing databases
    const migrations = [
      `ALTER TABLE app_uploads ADD COLUMN version VARCHAR(50) DEFAULT '1.0.0'`,
      `ALTER TABLE app_uploads ADD COLUMN version_code VARCHAR(50) DEFAULT '100'`,
      `ALTER TABLE app_uploads ADD COLUMN size_mb DECIMAL(10,1) DEFAULT 0`,
      `ALTER TABLE app_uploads ADD COLUMN download_url VARCHAR(500) DEFAULT ''`,
      `ALTER TABLE app_uploads ADD COLUMN screenshots TEXT`,
      `ALTER TABLE app_uploads ADD COLUMN tags TEXT`,
      `ALTER TABLE app_uploads ADD COLUMN downloads INTEGER DEFAULT 0`,
      `ALTER TABLE app_uploads ADD COLUMN rating DECIMAL(2,1) DEFAULT 0`,
      `ALTER TABLE app_uploads ADD COLUMN coin_count INTEGER DEFAULT 0`,
      `ALTER TABLE app_uploads ADD COLUMN coin_people INTEGER DEFAULT 0`,
      `ALTER TABLE app_uploads ADD COLUMN review_count INTEGER DEFAULT 0`,
      `ALTER TABLE app_uploads ADD COLUMN five_star_count INTEGER DEFAULT 0`,
      `ALTER TABLE app_uploads ADD COLUMN submission_status VARCHAR(20) DEFAULT 'draft'`,
      `ALTER TABLE app_uploads ADD COLUMN review_comment TEXT`,
      `ALTER TABLE app_uploads ADD COLUMN review_by VARCHAR(100) DEFAULT ''`,
      `ALTER TABLE app_uploads ADD COLUMN review_time DATETIME NULL`,
      `ALTER TABLE app_uploads ADD COLUMN icon_bg_color VARCHAR(20) DEFAULT '#00BFA5'`,
      `ALTER TABLE app_store ADD COLUMN categories TEXT`,
      `ALTER TABLE app_store ADD COLUMN user_id INTEGER DEFAULT 0`,
      `ALTER TABLE app_comments ADD COLUMN parent_id INTEGER DEFAULT 0`,
      `ALTER TABLE app_comments ADD COLUMN reported INTEGER DEFAULT 0`,
      `ALTER TABLE app_comments ADD COLUMN is_pinned TINYINT(1) DEFAULT 0`,
      `ALTER TABLE users ADD COLUMN bg_url VARCHAR(500) DEFAULT ''`,
      `ALTER TABLE users ADD COLUMN signature VARCHAR(300) DEFAULT ''`,
      `ALTER TABLE users ADD COLUMN qq VARCHAR(20) DEFAULT ''`,
      `ALTER TABLE app_tips ADD COLUMN tip_type VARCHAR(20) DEFAULT 'balance'`,
      `CREATE INDEX IF NOT EXISTS idx_app_uploads_status ON app_uploads(submission_status)`,
      `ALTER TABLE app_store ADD COLUMN official_tags TEXT`,
      `ALTER TABLE app_uploads ADD COLUMN official_tags TEXT`,
      `ALTER TABLE app_versions ADD COLUMN official_tags TEXT`,
      `ALTER TABLE app_versions ADD COLUMN has_ads INTEGER DEFAULT 0`,
      `ALTER TABLE app_versions ADD COLUMN requires_network INTEGER DEFAULT 1`,
      `ALTER TABLE app_versions ADD COLUMN has_paid_content INTEGER DEFAULT 0`,
      `ALTER TABLE app_versions ADD COLUMN is_free INTEGER DEFAULT 1`,
      `ALTER TABLE app_store ADD COLUMN has_ads INTEGER DEFAULT 0`,
      `ALTER TABLE app_store ADD COLUMN requires_network INTEGER DEFAULT 1`,
      `ALTER TABLE app_store ADD COLUMN has_paid_content INTEGER DEFAULT 0`,
      `ALTER TABLE app_store ADD COLUMN is_free INTEGER DEFAULT 1`,
      `ALTER TABLE app_store ADD COLUMN price_type VARCHAR(20) DEFAULT 'free'`,
      `ALTER TABLE app_store ADD COLUMN price_amount DECIMAL(10,2) DEFAULT 0`,
      `ALTER TABLE app_uploads ADD COLUMN price_type VARCHAR(20) DEFAULT 'free'`,
      `ALTER TABLE app_uploads ADD COLUMN price_amount DECIMAL(10,2) DEFAULT 0`,
      `ALTER TABLE membership_levels ADD COLUMN points_discount_rate DECIMAL(3,1) DEFAULT 1.0`,
      `ALTER TABLE community_comments ADD COLUMN is_pinned TINYINT(1) DEFAULT 0`,
      `ALTER TABLE community_posts ADD COLUMN reject_reason VARCHAR(500) DEFAULT ''`,
      `ALTER TABLE community_posts ADD COLUMN reported INTEGER DEFAULT 0`,
      `ALTER TABLE community_comments ADD COLUMN reported INTEGER DEFAULT 0`,

  `ALTER TABLE community_sections ADD COLUMN visibility VARCHAR(20) DEFAULT 'public'`,

  `ALTER TABLE community_posts ADD COLUMN hot_manually_disabled TINYINT(1) DEFAULT 0`,

  `ALTER TABLE users ADD COLUMN is_verified TINYINT(1) DEFAULT 0`,
  `ALTER TABLE users ADD COLUMN verified_org VARCHAR(200) DEFAULT ''`,
  `ALTER TABLE users ADD COLUMN active_title_id INTEGER DEFAULT 0`,
  `ALTER TABLE users ADD COLUMN active_title_name VARCHAR(100) DEFAULT ''`,
  `ALTER TABLE users ADD COLUMN last_checkin_date DATE NULL`,
  `ALTER TABLE users ADD COLUMN consecutive_checkins INTEGER DEFAULT 0`,
  `ALTER TABLE community_posts ADD COLUMN deleted_at DATETIME NULL`,

  `ALTER TABLE users ADD COLUMN password_hash VARCHAR(200) DEFAULT ''`,
  `ALTER TABLE invite_codes ADD COLUMN type VARCHAR(20) DEFAULT 'admin'`,
  `ALTER TABLE invite_codes ADD COLUMN created_by_user_id INTEGER DEFAULT 0`,
  `ALTER TABLE invite_codes ADD COLUMN reward_type VARCHAR(20) DEFAULT ''`,
  `ALTER TABLE invite_codes ADD COLUMN reward_value VARCHAR(300) DEFAULT ''`,
  `ALTER TABLE invite_codes ADD COLUMN reward_duration INTEGER DEFAULT 0`,
  `ALTER TABLE invite_codes ADD COLUMN invited_users TEXT DEFAULT '[]'`,
  `ALTER TABLE users ADD COLUMN referrer_id INTEGER DEFAULT 0`,
  `ALTER TABLE users ADD COLUMN referrer_code VARCHAR(32) DEFAULT ''`,
  `ALTER TABLE community_sections ADD COLUMN post_permission VARCHAR(20) DEFAULT 'all'`,
  `ALTER TABLE community_sections ADD COLUMN view_permission VARCHAR(20) DEFAULT 'all'`,
   `ALTER TABLE community_sections ADD COLUMN view_level_required INTEGER DEFAULT 0`,
      `ALTER TABLE community_posts ADD COLUMN content_permission VARCHAR(20) DEFAULT 'public'`,
      `ALTER TABLE community_posts ADD COLUMN content_price DECIMAL(10,2) DEFAULT 0`,
      `ALTER TABLE community_posts ADD COLUMN content_price_type VARCHAR(20) DEFAULT 'balance'`,
      `ALTER TABLE community_posts ADD COLUMN access_password VARCHAR(100) DEFAULT ''`,
      `ALTER TABLE community_posts ADD COLUMN access_password_tips VARCHAR(200) DEFAULT ''`,
      `ALTER TABLE app_store ADD COLUMN content_permission VARCHAR(20) DEFAULT 'public'`,
      `ALTER TABLE app_store ADD COLUMN content_price DECIMAL(10,2) DEFAULT 0`,
      `ALTER TABLE app_store ADD COLUMN content_price_type VARCHAR(20) DEFAULT 'balance'`,
      `ALTER TABLE app_store ADD COLUMN access_password VARCHAR(100) DEFAULT ''`,
      `ALTER TABLE app_store ADD COLUMN access_password_tips VARCHAR(200) DEFAULT ''`,
       `ALTER TABLE membership_levels ADD COLUMN tier INTEGER DEFAULT 1`,
       `ALTER TABLE membership_levels ADD COLUMN parent_level_id INTEGER DEFAULT 0`,
        `ALTER TABLE file_policies ADD COLUMN role_code VARCHAR(100) DEFAULT ''`,
        `ALTER TABLE commission_rules ADD COLUMN invite_code_id INTEGER DEFAULT 0`,
        `ALTER TABLE custom_tasks ADD COLUMN start_time DATETIME NULL`,
        `ALTER TABLE custom_tasks ADD COLUMN end_time DATETIME NULL`,

        `CREATE TABLE IF NOT EXISTS user_delete_requests (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id INTEGER NOT NULL,
          username VARCHAR(100) DEFAULT '',
          admin_id INTEGER DEFAULT 0,
          admin_note VARCHAR(500) DEFAULT '',
          status VARCHAR(20) DEFAULT 'pending',
          create_time DATETIME DEFAULT (datetime('now','localtime'))
        )`
      ]
    migrations.forEach(m => { try { db.exec(m) } catch {} })

    // 迁移现有明文密码为bcrypt哈希
    try {
      const bcrypt = require('bcryptjs')
      const users = db.prepare("SELECT id, password FROM users WHERE password_hash='' OR password_hash IS NULL").all()
      const updateStmt = db.prepare('UPDATE users SET password_hash=? WHERE id=?')
      for (const u of users) {
        if (u.password) {
          const hash = bcrypt.hashSync(u.password, 10)
          updateStmt.run(hash, u.id)
        }
      }
    } catch (e) { /* 密码迁移跳过 */ }

    // 默认系统配置
    try {
      const cfg = db.prepare("SELECT id FROM sys_config WHERE config_key='system_log_enabled'").all()
      if (!cfg.length) {
        db.prepare("INSERT INTO sys_config (config_key, config_value, description) VALUES ('system_log_enabled','true','系统日志开关'),('invite_user_enabled','false','用户生成邀请码开关'),('invite_user_max','5','用户最大可生成邀请码数'),('register_invite_required','false','注册必须邀请码'),('commission_enabled','false','推广返佣开关'),('commission_mode','purchase','返佣模式: purchase=推荐购买 register=绑定注册'),('points_transfer_enabled','false','积分转账开关'),('points_transfer_fee','0','积分转账手续费比例%'),('balance_transfer_enabled','false','余额转账开关'),('balance_transfer_fee','0','余额转账手续费比例%'),('points_purchase_enabled','false','积分购买开关'),('points_purchase_rate','1','1元等于多少积分'),('content_split_enabled','true','创作分成开关'),('content_split_global_rate','70','创作分成全局比例%')").run()
      }
    } catch (e) { /* 配置跳过 */ }

    // 同步 app_store 已有应用到 app_uploads（审核列表需要）
    try {
      const existing = db.prepare('SELECT app_id FROM app_uploads WHERE app_id > 0').all()
      const syncedIds = new Set(existing.map((r) => r.app_id))
      const apps = db.prepare('SELECT * FROM app_store').all()
      const insertStmt = db.prepare(
        `INSERT INTO app_uploads (app_id, user_id, user_name, name, package_name, category, description,
         icon, icon_bg_color, version, version_code, size_mb, download_url, screenshots, tags,
         submission_status, create_time, update_time)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'approved',datetime('now','localtime'),datetime('now','localtime'))`
      )
      const { nowExpr } = { nowExpr: "datetime('now','localtime')" }
      for (const app of apps) {
        if (syncedIds.has(app.id)) continue
        insertStmt.run(
          app.id,
          app.user_id || 0,
          app.developer || '',
          app.name,
          app.package_name || '',
          app.category || '工具',
          app.description || '',
          app.icon || '',
          app.icon_bg_color || '#00BFA5',
          app.version || '1.0.0',
          app.version_code || '100',
          app.size_mb || 0,
          app.download_url || '',
          app.screenshots || '[]',
          app.tags || '[]'
        )
      }
    } catch (e) { /* 忽略同步错误 */ }
  } else {
    const db = getPool()
    tables.forEach(t => db.query(t, (err) => { if (err) console.error('建表错误:', t.substring(0, 50), err.message) }))
    indexes.forEach(i => {
      try {
        db.query(`CREATE INDEX IF NOT EXISTS ${i}`)
      } catch {}
    })
  }
}

module.exports = { query, dbType }
