const path = require('path')
const config = require('./config.cjs')

const dbType = config.dbType || 'sqlite'
let pool

function getPool() {
  if (pool) return pool

  if (dbType === 'sqlite') {
    const Database = require('better-sqlite3')
    const dbPath = path.resolve(__dirname, config.sqlite.filePath || './data.db')
    const db = new Database(dbPath)
    db.pragma('journal_mode = WAL')
    db.pragma('foreign_keys = ON')
    pool = db
  } else if (dbType === 'mysql') {
    const mysql = require('mysql2')
    const { host, port, user, password, database } = config.mysql
    pool = mysql.createPool({
      host, port, user, password, database,
      waitForConnections: true,
      connectionLimit: 10,
      charset: 'utf8mb4'
    })
  } else {
    throw new Error(`不支持的数据库类型: ${dbType}`)
  }

  initTables()
  return pool
}

function query(sql, params = []) {
  if (dbType === 'sqlite') {
    const db = getPool()
    const stmt = db.prepare(sql)
    if (/^\s*SELECT|PRAGMA/i.test(sql)) return Promise.resolve(stmt.all(...params))
    return Promise.resolve(stmt.run(...params))
  } else {
    return new Promise((resolve, reject) => {
      getPool().query(sql, params, (err, results) => {
        if (err) return reject(err)
        if (/^\s*SELECT|SHOW/i.test(sql)) return resolve(results)
        resolve({ lastInsertRowid: results.insertId, changes: results.affectedRows })
      })
    })
  }
}

function initTables() {
  const engine = dbType === 'mysql' ? ' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci' : ''
  const autoInc = dbType === 'mysql' ? 'AUTO_INCREMENT' : 'AUTOINCREMENT'
  const now = dbType === 'mysql' ? 'NOW()' : "(datetime('now','localtime'))"

  const tables = [
    `CREATE TABLE IF NOT EXISTS roles (
      id INTEGER PRIMARY KEY ${autoInc},
      role_name VARCHAR(100) NOT NULL,
      role_code VARCHAR(100) UNIQUE NOT NULL,
      description VARCHAR(500) DEFAULT '',
      enabled TINYINT(1) DEFAULT 1,
      create_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS menus (
      id INTEGER PRIMARY KEY ${autoInc},
      parent_id INTEGER DEFAULT 0,
      name VARCHAR(100) NOT NULL,
      path VARCHAR(200) NOT NULL DEFAULT '',
      component VARCHAR(200) DEFAULT '',
      redirect VARCHAR(200) DEFAULT '',
      title VARCHAR(100) NOT NULL,
      icon VARCHAR(100) DEFAULT '',
      sort_order INTEGER DEFAULT 0,
      is_hidden TINYINT(1) DEFAULT 0,
      is_full_page TINYINT(1) DEFAULT 0,
      is_keep_alive TINYINT(1) DEFAULT 1,
      is_fixed_tab TINYINT(1) DEFAULT 0,
      auth_list TEXT,
      roles TEXT,
      enabled TINYINT(1) DEFAULT 1,
      create_time DATETIME DEFAULT ${now},
      update_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS role_permissions (
      id INTEGER PRIMARY KEY ${autoInc},
      role_id INTEGER NOT NULL,
      menu_id INTEGER NOT NULL,
      UNIQUE(role_id, menu_id)
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS membership_levels (
      id INTEGER PRIMARY KEY ${autoInc},
      name VARCHAR(100) NOT NULL,
      level INTEGER NOT NULL DEFAULT 0,
      price DECIMAL(10,2) DEFAULT 0,
      points_required INTEGER DEFAULT 0,
      discount_rate DECIMAL(3,1) DEFAULT 1.0,
      points_multiplier DECIMAL(3,1) DEFAULT 1.0,
      benefits TEXT,
      icon VARCHAR(100) DEFAULT '',
      icon_color VARCHAR(20) DEFAULT '#909399',
      status VARCHAR(2) DEFAULT '1',
      create_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY ${autoInc},
      username VARCHAR(100) UNIQUE NOT NULL,
      password VARCHAR(200) NOT NULL DEFAULT '123456',
      phone VARCHAR(20) DEFAULT '',
      email VARCHAR(100) DEFAULT '',
      nickname VARCHAR(100) DEFAULT '',
      bio TEXT,
      balance DECIMAL(10,2) DEFAULT 0,
      experience INTEGER DEFAULT 0,
      gender VARCHAR(10) DEFAULT '男',
      avatar VARCHAR(500) DEFAULT '',
      bg_url VARCHAR(500) DEFAULT '',
      signature VARCHAR(300) DEFAULT '',
      qq VARCHAR(20) DEFAULT '',
      show_coin INTEGER DEFAULT 1,
      follow_count INTEGER DEFAULT 0,
      fans_count INTEGER DEFAULT 0,
      status VARCHAR(2) DEFAULT '1',
      points INTEGER DEFAULT 0,
      level_id INTEGER DEFAULT 0,
      level_name VARCHAR(100) DEFAULT '普通会员',
      expire_time DATETIME NULL,
      roles TEXT,
      create_time DATETIME DEFAULT ${now},
      update_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS card_keys (
      id INTEGER PRIMARY KEY ${autoInc},
      card_no VARCHAR(100) UNIQUE NOT NULL,
      password VARCHAR(100) NOT NULL,
      type VARCHAR(20) NOT NULL DEFAULT 'membership',
      target_id INTEGER DEFAULT 0,
      target_name VARCHAR(100) DEFAULT '',
      value INTEGER DEFAULT 0,
      extra_points INTEGER DEFAULT 0,
      extra_experience INTEGER DEFAULT 0,
      duration INTEGER DEFAULT 0,
      duration_unit VARCHAR(10) DEFAULT '',
      status VARCHAR(2) DEFAULT '0',
      create_by VARCHAR(100) DEFAULT '管理员',
      create_time DATETIME DEFAULT ${now},
      redeem_by VARCHAR(100) DEFAULT '',
      redeem_time DATETIME NULL
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS points_records (
      id INTEGER PRIMARY KEY ${autoInc},
      user_id INTEGER NOT NULL,
      user_name VARCHAR(100) DEFAULT '',
      type VARCHAR(20) NOT NULL DEFAULT 'earn',
      points INTEGER NOT NULL DEFAULT 0,
      balance INTEGER DEFAULT 0,
      source VARCHAR(200) DEFAULT '',
      description TEXT,
      create_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS experience_levels (
      id INTEGER PRIMARY KEY ${autoInc},
      name VARCHAR(100) NOT NULL,
      level INTEGER NOT NULL DEFAULT 0,
      exp_required INTEGER NOT NULL DEFAULT 0,
      icon VARCHAR(100) DEFAULT '',
      icon_color VARCHAR(20) DEFAULT '#00BFA5',
      benefits TEXT,
      status VARCHAR(2) DEFAULT '1',
      create_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS plugins (
      id INTEGER PRIMARY KEY ${autoInc},
      name VARCHAR(100) NOT NULL,
      description TEXT,
      version VARCHAR(50) DEFAULT '1.0.0',
      author VARCHAR(100) DEFAULT '',
      icon VARCHAR(500) DEFAULT '',
      entry_url VARCHAR(500) DEFAULT '',
      component_name VARCHAR(200) DEFAULT '',
      status VARCHAR(2) DEFAULT '1',
      create_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS app_store (
      id INTEGER PRIMARY KEY ${autoInc},
      name VARCHAR(200) NOT NULL,
      package_name VARCHAR(200) DEFAULT '',
      version VARCHAR(50) DEFAULT '1.0.0',
      version_code VARCHAR(50) DEFAULT '100',
      icon VARCHAR(500) DEFAULT '',
      icon_bg_color VARCHAR(20) DEFAULT '#00BFA5',
      size_mb DECIMAL(10,1) DEFAULT 0,
      downloads INTEGER DEFAULT 0,
      rating DECIMAL(2,1) DEFAULT 0,
      description TEXT,
      update_content TEXT,
      screenshots TEXT,
      tags TEXT,
      download_url VARCHAR(500) DEFAULT '',
      coin_count INTEGER DEFAULT 0,
      coin_people INTEGER DEFAULT 0,
      developer VARCHAR(100) DEFAULT '',
      category VARCHAR(100) DEFAULT '工具',
      categories TEXT,
      category_id INTEGER DEFAULT 0,
      status VARCHAR(2) DEFAULT '1',
      is_pinned TINYINT(1) DEFAULT 0,
      user_id INTEGER DEFAULT 0,
      create_time DATETIME DEFAULT ${now},
      update_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS app_comments (
      id INTEGER PRIMARY KEY ${autoInc},
      app_id INTEGER NOT NULL,
      parent_id INTEGER DEFAULT 0,
      user_id INTEGER DEFAULT 0,
      user_name VARCHAR(100) DEFAULT '',
      user_avatar VARCHAR(20) DEFAULT '#FF5777',
      device VARCHAR(200) DEFAULT '',
      version VARCHAR(50) DEFAULT '',
      content TEXT,
      likes INTEGER DEFAULT 0,
      replies INTEGER DEFAULT 0,
      reported INTEGER DEFAULT 0,
      is_pinned TINYINT(1) DEFAULT 0,
      rating DECIMAL(2,1) DEFAULT 0,
      create_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS app_versions (
      id INTEGER PRIMARY KEY ${autoInc},
      app_id INTEGER NOT NULL,
      version VARCHAR(50) NOT NULL,
      version_code VARCHAR(50) DEFAULT '',
      size_mb DECIMAL(10,1) DEFAULT 0,
      downloads INTEGER DEFAULT 0,
      rating DECIMAL(2,1) DEFAULT 0,
      update_content TEXT,
      tags TEXT,
      download_url VARCHAR(500) DEFAULT '',
      is_current TINYINT(1) DEFAULT 0,
      user_id INTEGER DEFAULT 0,
      user_name VARCHAR(100) DEFAULT '',
      status VARCHAR(2) DEFAULT '1',
      create_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS app_uploads (
      id INTEGER PRIMARY KEY ${autoInc},
      app_id INTEGER DEFAULT 0,
      user_id INTEGER NOT NULL,
      user_name VARCHAR(100) DEFAULT '',
      name VARCHAR(200) NOT NULL,
      package_name VARCHAR(200) DEFAULT '',
      category VARCHAR(100) DEFAULT '工具',
      description TEXT,
      icon VARCHAR(500) DEFAULT '',
      icon_bg_color VARCHAR(20) DEFAULT '#00BFA5',
      version VARCHAR(50) DEFAULT '1.0.0',
      version_code VARCHAR(50) DEFAULT '100',
      size_mb DECIMAL(10,1) DEFAULT 0,
      download_url VARCHAR(500) DEFAULT '',
      screenshots TEXT,
      tags TEXT,
      version_type VARCHAR(20) DEFAULT '',
      has_ads INTEGER DEFAULT 0,
      requires_network INTEGER DEFAULT 1,
      has_paid_content INTEGER DEFAULT 0,
      is_free INTEGER DEFAULT 1,
      downloads INTEGER DEFAULT 0,
      rating DECIMAL(2,1) DEFAULT 0,
      coin_count INTEGER DEFAULT 0,
      coin_people INTEGER DEFAULT 0,
      review_count INTEGER DEFAULT 0,
      five_star_count INTEGER DEFAULT 0,
      status VARCHAR(2) DEFAULT '0',
      submission_status VARCHAR(20) DEFAULT 'draft',
      review_comment TEXT,
      review_by VARCHAR(100) DEFAULT '',
      review_time DATETIME NULL,
      create_time DATETIME DEFAULT ${now},
      update_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS app_categories (
      id INTEGER PRIMARY KEY ${autoInc},
      name VARCHAR(64) NOT NULL,
      icon VARCHAR(255) DEFAULT '',
      sort_order INTEGER DEFAULT 0,
      status CHAR(1) DEFAULT '1',
      create_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS app_tips (
      id INTEGER PRIMARY KEY ${autoInc},
      app_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      user_name VARCHAR(64) DEFAULT '',
      amount DECIMAL(10,2) NOT NULL DEFAULT 0,
      tip_type VARCHAR(20) DEFAULT 'balance',
      message VARCHAR(255) DEFAULT '',
      create_time DATETIME DEFAULT ${now}
    )${engine}`,
 
    `CREATE TABLE IF NOT EXISTS comment_likes (
      id INTEGER PRIMARY KEY ${autoInc},
      comment_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      UNIQUE(comment_id, user_id)
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS app_official_tags (
      id INTEGER PRIMARY KEY ${autoInc},
      name VARCHAR(64) NOT NULL,
      color VARCHAR(20) DEFAULT '#2563eb',
      bg_color VARCHAR(20) DEFAULT '#dbeafe',
      sort_order INTEGER DEFAULT 0,
      status VARCHAR(2) DEFAULT '1',
      create_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS sys_notifications (
      id INTEGER PRIMARY KEY ${autoInc},
      title VARCHAR(200) NOT NULL,
      content TEXT DEFAULT '',
      type VARCHAR(20) DEFAULT 'system',
      target_user_id INTEGER DEFAULT 0,
      is_read TINYINT(1) DEFAULT 0,
      create_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS private_messages (
      id INTEGER PRIMARY KEY ${autoInc},
      from_user_id INTEGER NOT NULL,
      from_user_name VARCHAR(100) DEFAULT '',
      from_user_avatar VARCHAR(20) DEFAULT '#448AFF',
      to_user_id INTEGER NOT NULL,
      content TEXT DEFAULT '',
      is_read TINYINT(1) DEFAULT 0,
      create_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS hidden_conversations (
      id INTEGER PRIMARY KEY ${autoInc},
      user_id INTEGER NOT NULL,
      partner_id INTEGER NOT NULL,
      create_time DATETIME DEFAULT ${now},
      UNIQUE(user_id, partner_id)
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS app_purchases (
      id INTEGER PRIMARY KEY ${autoInc},
      app_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      user_name VARCHAR(100) DEFAULT '',
      price_type VARCHAR(20) DEFAULT 'free',
      original_price DECIMAL(10,2) DEFAULT 0,
      paid_price DECIMAL(10,2) DEFAULT 0,
      discount_rate DECIMAL(3,1) DEFAULT 1.0,
      create_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS sessions (
      token VARCHAR(100) PRIMARY KEY,
      user_id INTEGER NOT NULL,
      user_name VARCHAR(100) NOT NULL,
      roles TEXT DEFAULT '[]',
      created_at INTEGER NOT NULL
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS community_attach_purchases (
      id INTEGER PRIMARY KEY ${autoInc},
      post_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      attach_url VARCHAR(500) NOT NULL DEFAULT '',
      coin_type VARCHAR(20) NOT NULL DEFAULT 'coin',
      coin_amount INTEGER NOT NULL DEFAULT 0,
      create_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS community_sections (
      id INTEGER PRIMARY KEY ${autoInc},
      name VARCHAR(100) NOT NULL,
      icon VARCHAR(500) DEFAULT '',
      icon_bg_color VARCHAR(20) DEFAULT '#00BFA5',
      description TEXT DEFAULT '',
      today_heat INTEGER DEFAULT 0,
      total_heat INTEGER DEFAULT 0,
      post_count INTEGER DEFAULT 0,
      view_count INTEGER DEFAULT 0,
      sort_order INTEGER DEFAULT 0,
      status VARCHAR(20) DEFAULT 'active',
      visibility VARCHAR(20) DEFAULT 'public',
      create_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS community_posts (
      id INTEGER PRIMARY KEY ${autoInc},
      section_id INTEGER NOT NULL DEFAULT 0,
      user_id INTEGER NOT NULL,
      user_name VARCHAR(100) DEFAULT '',
      user_avatar VARCHAR(500) DEFAULT '',
      title VARCHAR(500) DEFAULT '',
      content TEXT DEFAULT '',
      device VARCHAR(100) DEFAULT '',
      tags TEXT DEFAULT '[]',
      official_tags TEXT DEFAULT '[]',
      images TEXT DEFAULT '[]',
      has_resource INTEGER DEFAULT 0,
      resource_type VARCHAR(20) DEFAULT '',
      resource_url TEXT DEFAULT '',
      resource_price REAL DEFAULT 0,
      resource_price_type VARCHAR(20) DEFAULT 'free',
      extract_code VARCHAR(100) DEFAULT '',
      permission VARCHAR(20) DEFAULT 'public',
      is_pinned INTEGER DEFAULT 0,
      is_essence INTEGER DEFAULT 0,
      is_hot INTEGER DEFAULT 0,
      hot_manually_disabled TINYINT(1) DEFAULT 0,
      status VARCHAR(20) DEFAULT 'published',
      like_count INTEGER DEFAULT 0,
      comment_count INTEGER DEFAULT 0,
      coin_count INTEGER DEFAULT 0,
      view_count INTEGER DEFAULT 0,
      favorite_count INTEGER DEFAULT 0,
      scheduled_time DATETIME DEFAULT NULL,
      create_time DATETIME DEFAULT ${now},
      update_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS community_comments (
      id INTEGER PRIMARY KEY ${autoInc},
      post_id INTEGER NOT NULL,
      parent_id INTEGER DEFAULT 0,
      user_id INTEGER NOT NULL,
      user_name VARCHAR(100) DEFAULT '',
      user_avatar VARCHAR(500) DEFAULT '',
      content TEXT NOT NULL,
      like_count INTEGER DEFAULT 0,
      reply_count INTEGER DEFAULT 0,
      create_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS community_likes (
      id INTEGER PRIMARY KEY ${autoInc},
      post_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      create_time DATETIME DEFAULT ${now},
      UNIQUE(post_id, user_id)
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS community_favorites (
      id INTEGER PRIMARY KEY ${autoInc},
      post_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      create_time DATETIME DEFAULT ${now},
      UNIQUE(post_id, user_id)
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS community_drafts (
      id INTEGER PRIMARY KEY ${autoInc},
      user_id INTEGER NOT NULL,
      section_id INTEGER DEFAULT 0,
      title VARCHAR(500) DEFAULT '',
      content TEXT DEFAULT '',
      images TEXT DEFAULT '[]',
      tags TEXT DEFAULT '[]',
      official_tags TEXT DEFAULT '[]',
      has_resource INTEGER DEFAULT 0,
      resource_type VARCHAR(20) DEFAULT '',
      resource_url TEXT DEFAULT '',
      resource_price REAL DEFAULT 0,
      resource_price_type VARCHAR(20) DEFAULT 'free',
      extract_code VARCHAR(100) DEFAULT '',
      permission VARCHAR(20) DEFAULT 'public',
      create_time DATETIME DEFAULT ${now},
      update_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS community_banned_users (
      id INTEGER PRIMARY KEY ${autoInc},
      user_id INTEGER NOT NULL UNIQUE,
      user_name VARCHAR(100) DEFAULT '',
      reason VARCHAR(500) DEFAULT '',
      banned_until DATETIME DEFAULT NULL,
      create_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS community_coin_logs (
      id INTEGER PRIMARY KEY ${autoInc},
      post_id INTEGER NOT NULL,
      from_user_id INTEGER NOT NULL,
      from_user_name VARCHAR(100) DEFAULT '',
      from_user_avatar VARCHAR(500) DEFAULT '',
      to_user_id INTEGER NOT NULL DEFAULT 0,
      amount INTEGER DEFAULT 0,
      coin_type VARCHAR(20) DEFAULT 'coin',
      create_time DATETIME DEFAULT ${now}
    )${engine}`,

    `CREATE TABLE IF NOT EXISTS community_moderators (
      id INTEGER PRIMARY KEY ${autoInc},
      section_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      user_name VARCHAR(100) DEFAULT '',
      user_avatar VARCHAR(500) DEFAULT '',
      role VARCHAR(20) DEFAULT '版主',
      sort_order INTEGER DEFAULT 0,
      create_time DATETIME DEFAULT ${now},
      UNIQUE(section_id, user_id)
    )${engine}`
  ]

  const indexes = [
    'idx_users_username ON users(username)',
    'idx_users_status ON users(status)',
    'idx_card_keys_card_no ON card_keys(card_no)',
    'idx_card_keys_type ON card_keys(type)',
    'idx_points_records_user_id ON points_records(user_id)',
    'idx_points_records_type ON points_records(type)',
    'idx_app_comments_app_id ON app_comments(app_id)',
    'idx_app_store_status ON app_store(status)',
    'idx_app_versions_app_id ON app_versions(app_id)',
    'idx_app_uploads_user_id ON app_uploads(user_id)',
    'idx_app_tips_app ON app_tips(app_id)',
    'idx_app_tips_user ON app_tips(user_id)',
    'idx_sys_notifications_target_user ON sys_notifications(target_user_id)',
    'idx_private_messages_from ON private_messages(from_user_id)',
    'idx_private_messages_to ON private_messages(to_user_id)',
    'idx_private_messages_conversation ON private_messages(from_user_id, to_user_id)',
    'idx_app_purchases_app ON app_purchases(app_id)',
    'idx_app_purchases_user ON app_purchases(user_id)',
    'idx_app_purchases_user_app ON app_purchases(user_id, app_id)',
    'idx_community_posts_section_id ON community_posts(section_id)',
    'idx_community_posts_user_id ON community_posts(user_id)',
    'idx_community_posts_status ON community_posts(status)',
    'idx_community_posts_is_pinned ON community_posts(is_pinned)',
    'idx_community_posts_is_essence ON community_posts(is_essence)',
    'idx_community_posts_is_hot ON community_posts(is_hot)',
    'idx_community_comments_post_id ON community_comments(post_id)',
    'idx_community_comments_parent_id ON community_comments(parent_id)',
    'idx_community_likes_post_user ON community_likes(post_id, user_id)',
    'idx_community_favorites_post_user ON community_favorites(post_id, user_id)',
    'idx_community_drafts_user_id ON community_drafts(user_id)',
    'idx_community_banned_users_user_id ON community_banned_users(user_id)'
  ]

  if (dbType === 'sqlite') {
    const db = getPool()
    db.exec(tables.join(';\n'))
    indexes.forEach(i => { try { db.exec(`CREATE INDEX IF NOT EXISTS ${i}`) } catch {} })
    // Migration: add new columns for existing databases
    const migrations = [
      `ALTER TABLE app_uploads ADD COLUMN version VARCHAR(50) DEFAULT '1.0.0'`,
      `ALTER TABLE app_uploads ADD COLUMN version_code VARCHAR(50) DEFAULT '100'`,
      `ALTER TABLE app_uploads ADD COLUMN size_mb DECIMAL(10,1) DEFAULT 0`,
      `ALTER TABLE app_uploads ADD COLUMN download_url VARCHAR(500) DEFAULT ''`,
      `ALTER TABLE app_uploads ADD COLUMN screenshots TEXT`,
      `ALTER TABLE app_uploads ADD COLUMN tags TEXT`,
      `ALTER TABLE app_uploads ADD COLUMN downloads INTEGER DEFAULT 0`,
      `ALTER TABLE app_uploads ADD COLUMN rating DECIMAL(2,1) DEFAULT 0`,
      `ALTER TABLE app_uploads ADD COLUMN coin_count INTEGER DEFAULT 0`,
      `ALTER TABLE app_uploads ADD COLUMN coin_people INTEGER DEFAULT 0`,
      `ALTER TABLE app_uploads ADD COLUMN review_count INTEGER DEFAULT 0`,
      `ALTER TABLE app_uploads ADD COLUMN five_star_count INTEGER DEFAULT 0`,
      `ALTER TABLE app_uploads ADD COLUMN submission_status VARCHAR(20) DEFAULT 'draft'`,
      `ALTER TABLE app_uploads ADD COLUMN review_comment TEXT`,
      `ALTER TABLE app_uploads ADD COLUMN review_by VARCHAR(100) DEFAULT ''`,
      `ALTER TABLE app_uploads ADD COLUMN review_time DATETIME NULL`,
      `ALTER TABLE app_uploads ADD COLUMN icon_bg_color VARCHAR(20) DEFAULT '#00BFA5'`,
      `ALTER TABLE app_store ADD COLUMN categories TEXT`,
      `ALTER TABLE app_store ADD COLUMN user_id INTEGER DEFAULT 0`,
      `ALTER TABLE app_comments ADD COLUMN parent_id INTEGER DEFAULT 0`,
      `ALTER TABLE app_comments ADD COLUMN reported INTEGER DEFAULT 0`,
      `ALTER TABLE app_comments ADD COLUMN is_pinned TINYINT(1) DEFAULT 0`,
      `ALTER TABLE users ADD COLUMN bg_url VARCHAR(500) DEFAULT ''`,
      `ALTER TABLE users ADD COLUMN signature VARCHAR(300) DEFAULT ''`,
      `ALTER TABLE users ADD COLUMN qq VARCHAR(20) DEFAULT ''`,
      `ALTER TABLE app_tips ADD COLUMN tip_type VARCHAR(20) DEFAULT 'balance'`,
      `CREATE INDEX IF NOT EXISTS idx_app_uploads_status ON app_uploads(submission_status)`,
      `ALTER TABLE app_store ADD COLUMN official_tags TEXT`,
      `ALTER TABLE app_uploads ADD COLUMN official_tags TEXT`,
      `ALTER TABLE app_versions ADD COLUMN official_tags TEXT`,
      `ALTER TABLE app_versions ADD COLUMN has_ads INTEGER DEFAULT 0`,
      `ALTER TABLE app_versions ADD COLUMN requires_network INTEGER DEFAULT 1`,
      `ALTER TABLE app_versions ADD COLUMN has_paid_content INTEGER DEFAULT 0`,
      `ALTER TABLE app_versions ADD COLUMN is_free INTEGER DEFAULT 1`,
      `ALTER TABLE app_store ADD COLUMN has_ads INTEGER DEFAULT 0`,
      `ALTER TABLE app_store ADD COLUMN requires_network INTEGER DEFAULT 1`,
      `ALTER TABLE app_store ADD COLUMN has_paid_content INTEGER DEFAULT 0`,
      `ALTER TABLE app_store ADD COLUMN is_free INTEGER DEFAULT 1`,
      `ALTER TABLE app_store ADD COLUMN price_type VARCHAR(20) DEFAULT 'free'`,
      `ALTER TABLE app_store ADD COLUMN price_amount DECIMAL(10,2) DEFAULT 0`,
      `ALTER TABLE app_uploads ADD COLUMN price_type VARCHAR(20) DEFAULT 'free'`,
      `ALTER TABLE app_uploads ADD COLUMN price_amount DECIMAL(10,2) DEFAULT 0`,
      `ALTER TABLE membership_levels ADD COLUMN points_discount_rate DECIMAL(3,1) DEFAULT 1.0`,
      `ALTER TABLE community_comments ADD COLUMN is_pinned TINYINT(1) DEFAULT 0`,
      `ALTER TABLE community_posts ADD COLUMN reject_reason VARCHAR(500) DEFAULT ''`,
      `ALTER TABLE community_posts ADD COLUMN reported INTEGER DEFAULT 0`,
      `ALTER TABLE community_comments ADD COLUMN reported INTEGER DEFAULT 0`,

  `ALTER TABLE community_sections ADD COLUMN visibility VARCHAR(20) DEFAULT 'public'`,

  `ALTER TABLE community_posts ADD COLUMN hot_manually_disabled TINYINT(1) DEFAULT 0`
    ]
    migrations.forEach(m => { try { db.exec(m) } catch {} })

    // 同步 app_store 已有应用到 app_uploads（审核列表需要）
    try {
      const existing = db.prepare('SELECT app_id FROM app_uploads WHERE app_id > 0').all()
      const syncedIds = new Set(existing.map((r) => r.app_id))
      const apps = db.prepare('SELECT * FROM app_store').all()
      const insertStmt = db.prepare(
        `INSERT INTO app_uploads (app_id, user_id, user_name, name, package_name, category, description,
         icon, icon_bg_color, version, version_code, size_mb, download_url, screenshots, tags,
         submission_status, create_time, update_time)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'approved',datetime('now','localtime'),datetime('now','localtime'))`
      )
      const { nowExpr } = { nowExpr: "datetime('now','localtime')" }
      for (const app of apps) {
        if (syncedIds.has(app.id)) continue
        insertStmt.run(
          app.id,
          app.user_id || 0,
          app.developer || '',
          app.name,
          app.package_name || '',
          app.category || '工具',
          app.description || '',
          app.icon || '',
          app.icon_bg_color || '#00BFA5',
          app.version || '1.0.0',
          app.version_code || '100',
          app.size_mb || 0,
          app.download_url || '',
          app.screenshots || '[]',
          app.tags || '[]'
        )
      }
    } catch (e) { /* 忽略同步错误 */ }
  } else {
    const db = getPool()
    tables.forEach(t => db.query(t, (err) => { if (err) console.error('建表错误:', t.substring(0, 50), err.message) }))
    indexes.forEach(i => {
      try {
        db.query(`CREATE INDEX IF NOT EXISTS ${i}`)
      } catch {}
    })
  }
}

module.exports = { query, dbType }
