const { query } = require('../database.cjs')

function sysConfigRoutes(router) {
  router.get('/api/sys-config/list', async (req, res) => {
    try {
      const list = await query('SELECT * FROM sys_config ORDER BY id')
      res.json({ code: 200, data: list })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  router.get('/api/sys-config/:key', async (req, res) => {
    try {
      const rows = await query('SELECT * FROM sys_config WHERE config_key=?', [req.params.key])
      res.json({ code: 200, data: rows[0] || null })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  router.post('/api/sys-config/save', async (req, res) => {
    try {
      const { configs } = req.body
      if (!Array.isArray(configs) || !configs.length) {
        return res.json({ code: 400, msg: '缺少配置数据' })
      }
      for (const cfg of configs) {
        const existing = await query('SELECT id FROM sys_config WHERE config_key=?', [cfg.config_key])
        if (existing && existing.length > 0) {
          await query('UPDATE sys_config SET config_value=?, update_time=datetime(\'now\',\'localtime\') WHERE config_key=?',
            [cfg.config_value, cfg.config_key])
        } else {
          await query('INSERT INTO sys_config (config_key, config_value, description) VALUES (?,?,?)',
            [cfg.config_key, cfg.config_value, cfg.description || ''])
        }
      }
      res.json({ code: 200, msg: '保存成功' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  router.get('/api/sys-config/public/:key', async (req, res) => {
    try {
      const rows = await query('SELECT config_value FROM sys_config WHERE config_key=?', [req.params.key])
      res.json({ code: 200, data: rows[0]?.config_value || '' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })
}

module.exports = sysConfigRoutes
