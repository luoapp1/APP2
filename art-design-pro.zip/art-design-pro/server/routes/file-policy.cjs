const { query } = require('../database.cjs')
const { sessions, SESSION_TTL } = require('./system.cjs')

async function getUserId(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return { userId: 0, roles: [] }
  const session = sessions.get(token)
  if (session) {
    if (Date.now() - session.createdAt > SESSION_TTL) { sessions.delete(token); return { userId: 0, roles: [] } }
    return { userId: Number(session.userId) || 0, roles: session.roles || [] }
  }
  return { userId: 0, roles: [] }
}

module.exports = function filePolicyRoutes(app) {
  app.get('/api/file-policy/list', async (req, res) => {
    try {
      const list = await query('SELECT * FROM file_policies ORDER BY id')
      res.json({ code: 200, data: list })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  app.post('/api/file-policy/save', async (req, res) => {
    try {
      const { id, name, user_level_id, user_level_name, role_code, max_file_size_mb, allowed_types, banned_types, status } = req.body
      const data = [
        name || '', user_level_id || 0, user_level_name || '', role_code || '',
        max_file_size_mb || 10, allowed_types || '', banned_types || '', status || '1'
      ]
      if (id) {
        await query(
          'UPDATE file_policies SET name=?, user_level_id=?, user_level_name=?, role_code=?, max_file_size_mb=?, allowed_types=?, banned_types=?, status=? WHERE id=?',
          [...data, Number(id)]
        )
      } else {
        await query(
          'INSERT INTO file_policies (name, user_level_id, user_level_name, role_code, max_file_size_mb, allowed_types, banned_types, status) VALUES (?,?,?,?,?,?,?,?)',
          data
        )
      }
      res.json({ code: 200, msg: '保存成功' })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  app.post('/api/file-policy/delete', async (req, res) => {
    try {
      await query('DELETE FROM file_policies WHERE id=?', [Number(req.body.id)])
      res.json({ code: 200, msg: '删除成功' })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // 检查用户上传权限（按角色/等级匹配）
  app.get('/api/file-policy/check', async (req, res) => {
    try {
      const { userId, roles } = await getUserId(req)
      if (!userId) return res.json({ code: 200, data: { max_size_mb: 10, allowed_all: true } })

      const user = await query('SELECT level_id, level_name FROM users WHERE id=?', [userId])
      if (!user.length) return res.json({ code: 200, data: { max_size_mb: 10, allowed_all: true } })

      const levelId = user[0].level_id || 0
      let policy = null

      // 优先级: 角色='*'（所有角色）> 具体角色匹配 > 等级匹配 > 默认策略
      const allRolePolicy = await query("SELECT * FROM file_policies WHERE status='1' AND role_code='*' ORDER BY id LIMIT 1")
      if (allRolePolicy.length) policy = allRolePolicy[0]

      if (!policy && roles.length > 0) {
        const placeholders = roles.map(() => '?').join(',')
        const rows = await query(
          `SELECT * FROM file_policies WHERE status='1' AND role_code IN (${placeholders}) ORDER BY id LIMIT 1`,
          roles
        )
        if (rows.length) policy = rows[0]
      }
      if (!policy && levelId) {
        const rows = await query(
          "SELECT * FROM file_policies WHERE status='1' AND role_code='' AND user_level_id=? ORDER BY id LIMIT 1",
          [levelId]
        )
        if (rows.length) policy = rows[0]
      }
      if (!policy) {
        const rows = await query("SELECT * FROM file_policies WHERE status='1' AND user_level_id=0 AND role_code='' ORDER BY id LIMIT 1")
        if (rows.length) policy = rows[0]
      }

      res.json({
        code: 200,
        data: {
          max_size_mb: policy ? policy.max_file_size_mb : 10,
          allowed_types: policy ? policy.allowed_types : '',
          banned_types: policy ? policy.banned_types : '',
          allowed_all: !policy
        }
      })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })
}
