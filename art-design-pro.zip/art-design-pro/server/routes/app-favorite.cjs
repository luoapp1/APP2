const { query } = require('../database.cjs')

function appFavoriteRoutes(router) {
  router.get('/api/app-favorite/list', async (req, res) => {
    try {
      const userId = req.query.userId || req.headers['x-user-id']
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const rows = await query(
        `SELECT f.*, a.name as app_name, a.icon, a.category, a.package_name, a.version
         FROM app_favorites f JOIN app_store a ON f.app_id=a.id
         WHERE f.user_id=? ORDER BY f.create_time DESC`,
        [Number(userId)]
      )
      res.json({ code: 200, data: rows })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  router.post('/api/app-favorite/toggle', async (req, res) => {
    try {
      const { userId, appId } = req.body
      if (!userId || !appId) return res.json({ code: 400, msg: '参数不完整' })

      const existing = await query(
        'SELECT id FROM app_favorites WHERE user_id=? AND app_id=?',
        [Number(userId), Number(appId)]
      )

      if (existing && existing.length > 0) {
        await query('DELETE FROM app_favorites WHERE id=?', [existing[0].id])
        res.json({ code: 200, msg: '已取消收藏', data: { favorited: false } })
      } else {
        await query(
          'INSERT INTO app_favorites (user_id, app_id) VALUES (?,?)',
          [Number(userId), Number(appId)]
        )
        res.json({ code: 200, msg: '收藏成功', data: { favorited: true } })
      }
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  router.get('/api/app-favorite/check', async (req, res) => {
    try {
      const { userId, appId } = req.query
      if (!userId || !appId) return res.json({ code: 400, msg: '参数不完整' })

      const rows = await query(
        'SELECT id FROM app_favorites WHERE user_id=? AND app_id=?',
        [Number(userId), Number(appId)]
      )
      res.json({ code: 200, data: { favorited: rows && rows.length > 0 } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })
}

module.exports = appFavoriteRoutes
