const { query } = require('../database.cjs')
const { authRequired, sessions, SESSION_TTL } = require('./system.cjs')

async function getUserId(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return 0
  const session = sessions.get(token)
  if (session) {
    if (Date.now() - session.createdAt > SESSION_TTL) { sessions.delete(token); return 0 }
    return Number(session.userId) || 0
  }
  try {
    const rows = await query('SELECT user_id, roles, created_at FROM sessions WHERE token=?', [token])
    if (rows.length > 0) {
      const createdAt = typeof rows[0].created_at === 'number' ? rows[0].created_at : new Date(rows[0].created_at).getTime()
      if (Date.now() - createdAt > SESSION_TTL) { return 0 }
      return Number(rows[0].user_id) || 0
    }
  } catch {}
  return 0
}

async function isAdmin(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return false
  const session = sessions.get(token)
  if (session) { const roles = session.roles || []; return roles.includes('R_SUPER') || roles.includes('R_ADMIN') }
  try {
    const rows = await query('SELECT roles FROM sessions WHERE token=?', [token])
    if (rows.length > 0) { const roles = JSON.parse(rows[0].roles || '[]'); return roles.includes('R_SUPER') || roles.includes('R_ADMIN') }
  } catch {}
  return false
}

module.exports = function verificationRoutes(app) {
  app.post('/api/verification/apply', authRequired, async (req, res) => {
    try {
      const userId = await getUserId(req)
      const { realName, idCard, organization, reason, proofUrls } = req.body
      const pending = await query("SELECT id FROM verification_requests WHERE user_id=? AND status='pending'", [userId])
      if (pending.length > 0) return res.json({ code: 400, message: '您已有待审核的认证申请' })
      const user = await query('SELECT is_verified FROM users WHERE id=?', [userId])
      if (user[0] && user[0].is_verified === 1) return res.json({ code: 400, message: '您已是认证用户' })
      await query(`INSERT INTO verification_requests (user_id, user_name, real_name, id_card, organization, reason, proof_urls)
         VALUES (?, (SELECT username FROM users WHERE id=?), ?, ?, ?, ?, ?)`,
        [userId, userId, realName || '', idCard || '', organization || '', reason || '', JSON.stringify(proofUrls || [])])
      res.json({ code: 200, message: '申请已提交，请等待审核' })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.get('/api/verification/status', authRequired, async (req, res) => {
    try {
      const userId = await getUserId(req)
      const user = await query('SELECT is_verified, verified_org FROM users WHERE id=?', [userId])
      const lastReq = await query('SELECT id, status, review_comment FROM verification_requests WHERE user_id=? ORDER BY create_time DESC LIMIT 1', [userId])
      res.json({ code: 200, data: { isVerified: user.length > 0 && user[0].is_verified === 1, verifiedOrg: user.length > 0 ? user[0].verified_org : '', lastRequest: lastReq.length > 0 ? lastReq[0] : null } })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.get('/api/verification/list', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const { status = 'pending', page = 1, pageSize = 20 } = req.query
      const offset = (page - 1) * pageSize
      const list = await query(
        `SELECT vr.*, u.avatar, u.nickname FROM verification_requests vr JOIN users u ON vr.user_id=u.id WHERE vr.status=? ORDER BY vr.create_time DESC LIMIT ? OFFSET ?`,
        [status, parseInt(pageSize), offset])
      const cnt = await query('SELECT COUNT(*) as total FROM verification_requests WHERE status=?', [status])
      res.json({ code: 200, data: { list, total: cnt[0].total } })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.post('/api/verification/:id/review', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const { action, comment } = req.body
      const reqId = parseInt(req.params.id)
      const vReq = await query('SELECT * FROM verification_requests WHERE id=?', [reqId])
      if (vReq.length === 0 || vReq[0].status !== 'pending') return res.json({ code: 400, message: '申请不存在或已处理' })
      const now = new Date().toISOString().replace('T', ' ').substring(0, 19)
      if (action === 'approve') {
        await query("UPDATE verification_requests SET status='approved', review_comment=?, review_time=? WHERE id=?", [comment || '', now, reqId])
        await query('UPDATE users SET is_verified=1, verified_org=? WHERE id=?', [vReq[0].organization || '', vReq[0].user_id])
        await query(`INSERT INTO sys_notifications (title, content, type, target_user_id) VALUES ('认证申请通过','恭喜，您的蓝V认证申请已通过审核！','system',?)`, [vReq[0].user_id])
      } else {
        await query("UPDATE verification_requests SET status='rejected', review_comment=?, review_time=? WHERE id=?", [comment || '', now, reqId])
        await query(`INSERT INTO sys_notifications (title, content, type, target_user_id) VALUES ('认证申请未通过',?,'system',?)`, [comment || '您的蓝V认证申请未通过审核', vReq[0].user_id])
      }
      res.json({ code: 200, message: '操作成功' })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.post('/api/verification/cancel', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      await query('UPDATE users SET is_verified=0, verified_org="" WHERE id=?', [req.body.userId])
      res.json({ code: 200, message: '认证已取消' })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })
}
