const { query } = require('../database.cjs')
const { sessions, SESSION_TTL } = require('./system.cjs')

async function getUserId(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return 0
  const session = sessions.get(token)
  if (session) {
    if (Date.now() - session.createdAt > SESSION_TTL) { sessions.delete(token); return 0 }
    return Number(session.userId) || 0
  }
  return 0
}

async function getConfig(key) {
  try {
    const rows = await query('SELECT config_value FROM sys_config WHERE config_key=?', [key])
    return rows.length > 0 ? rows[0].config_value : 'false'
  } catch { return 'false' }
}

module.exports = function transferRoutes(app) {
  // 获取转账配置
  app.get('/api/transfer/config', async (req, res) => {
    try {
      const keys = ['points_transfer_enabled', 'points_transfer_fee', 'balance_transfer_enabled', 'balance_transfer_fee']
      const rows = await query('SELECT config_key, config_value FROM sys_config WHERE config_key IN (?,?,?,?)', keys)
      const cfg = {}
      for (const r of rows) cfg[r.config_key] = r.config_value
      res.json({ code: 200, data: cfg })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // 积分转账
  app.post('/api/transfer/points', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const enabled = await getConfig('points_transfer_enabled')
      if (enabled !== 'true') return res.json({ code: 403, msg: '积分转账功能未开启' })

      const { toUserId, amount, remark } = req.body
      if (!toUserId || !amount || Number(amount) <= 0) {
        return res.json({ code: 400, msg: '参数不完整' })
      }

      const feeRate = parseFloat(await getConfig('points_transfer_fee')) || 0
      const fee = Math.floor(Number(amount) * feeRate / 100)

      const fromUser = await query('SELECT username, points FROM users WHERE id=?', [userId])
      if (!fromUser.length) return res.json({ code: 404, msg: '用户不存在' })
      if (fromUser[0].points < Number(amount) + fee) {
        return res.json({ code: 400, msg: '积分不足(含手续费)' })
      }

      const toUser = await query('SELECT username FROM users WHERE id=?', [Number(toUserId)])
      if (!toUser.length) return res.json({ code: 404, msg: '目标用户不存在' })

      await query('UPDATE users SET points=points-? WHERE id=?', [Number(amount) + fee, userId])
      await query('UPDATE users SET points=points+? WHERE id=?', [Number(amount), Number(toUserId)])

      await query(
        'INSERT INTO points_transfer_records (from_user_id, from_user_name, to_user_id, to_user_name, amount, fee, remark) VALUES (?,?,?,?,?,?,?)',
        [userId, fromUser[0].username, Number(toUserId), toUser[0].username, Number(amount), fee, remark || '']
      )

      if (fee > 0) {
        await query(
          "INSERT INTO points_records (user_id, user_name, type, amount, source, description) VALUES (?,?,?,?,?,?)",
          [userId, fromUser[0].username, 'expense', fee, 'transfer', '积分转账手续费']
        )
      }

      res.json({ code: 200, msg: '转账成功' })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // 余额转账
  app.post('/api/transfer/balance', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const enabled = await getConfig('balance_transfer_enabled')
      if (enabled !== 'true') return res.json({ code: 403, msg: '余额转账功能未开启' })

      const { toUserId, amount, remark } = req.body
      if (!toUserId || !amount || Number(amount) <= 0) {
        return res.json({ code: 400, msg: '参数不完整' })
      }

      const feeRate = parseFloat(await getConfig('balance_transfer_fee')) || 0
      const fee = (Number(amount) * feeRate / 100).toFixed(2)

      const fromUser = await query('SELECT username, balance FROM users WHERE id=?', [userId])
      if (!fromUser.length) return res.json({ code: 404, msg: '用户不存在' })
      if (fromUser[0].balance < Number(amount) + Number(fee)) {
        return res.json({ code: 400, msg: '余额不足(含手续费)' })
      }

      const toUser = await query('SELECT username FROM users WHERE id=?', [Number(toUserId)])
      if (!toUser.length) return res.json({ code: 404, msg: '目标用户不存在' })

      const totalDeduct = (Number(amount) + Number(fee)).toFixed(2)
      await query('UPDATE users SET balance=balance-? WHERE id=?', [Number(totalDeduct), userId])
      await query('UPDATE users SET balance=balance+? WHERE id=?', [Number(amount), Number(toUserId)])

      await query(
        'INSERT INTO balance_transfer_records (from_user_id, from_user_name, to_user_id, to_user_name, amount, fee, remark) VALUES (?,?,?,?,?,?,?)',
        [userId, fromUser[0].username, Number(toUserId), toUser[0].username, Number(amount), Number(fee), remark || '']
      )

      res.json({ code: 200, msg: '转账成功' })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // 积分购买
  app.post('/api/transfer/points/purchase', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const enabled = await getConfig('points_purchase_enabled')
      if (enabled !== 'true') return res.json({ code: 403, msg: '积分购买功能未开启' })

      const rate = parseInt(await getConfig('points_purchase_rate')) || 1
      const { amount } = req.body
      if (!amount || Number(amount) <= 0) return res.json({ code: 400, msg: '金额无效' })

      const points = Math.floor(Number(amount) * rate)
      await query('UPDATE users SET points=points+? WHERE id=?', [points, userId])
      await query(
        "INSERT INTO points_records (user_id, user_name, type, amount, source, description) VALUES (?,?,?,?,?,?)",
        [userId, '', 'earn', points, 'purchase', `现金购买${points}积分(￥${amount})`]
      )

      res.json({ code: 200, msg: `成功购买${points}积分`, data: { points } })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // 转账记录
  app.get('/api/transfer/records', async (req, res) => {
    try {
      const userId = await getUserId(req)
      const { page = 1, pageSize = 20, type } = req.query
      const offset = (Number(page) - 1) * Number(pageSize)

      let pointTotal, balanceTotal, pointList, balanceList

      if (!type || type === 'points') {
        pointTotal = await query(
          'SELECT COUNT(*) as total FROM points_transfer_records WHERE from_user_id=? OR to_user_id=?',
          [userId, userId]
        )
        pointList = await query(
          'SELECT * FROM points_transfer_records WHERE from_user_id=? OR to_user_id=? ORDER BY create_time DESC LIMIT ? OFFSET ?',
          [userId, userId, Number(pageSize), offset]
        )
      }

      if (!type || type === 'balance') {
        balanceTotal = await query(
          'SELECT COUNT(*) as total FROM balance_transfer_records WHERE from_user_id=? OR to_user_id=?',
          [userId, userId]
        )
        balanceList = await query(
          'SELECT * FROM balance_transfer_records WHERE from_user_id=? OR to_user_id=? ORDER BY create_time DESC LIMIT ? OFFSET ?',
          [userId, userId, Number(pageSize), offset]
        )
      }

      res.json({
        code: 200,
        data: {
          points: { list: pointList || [], total: pointTotal ? pointTotal[0]?.total || 0 : 0 },
          balance: { list: balanceList || [], total: balanceTotal ? balanceTotal[0]?.total || 0 : 0 }
        }
      })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })
}
