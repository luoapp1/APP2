const crypto = require('crypto')
const { query } = require('../database.cjs')
const { authRequired, sessions, SESSION_TTL } = require('./system.cjs')

async function getUserId(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return 0
  const session = sessions.get(token)
  if (session) {
    if (Date.now() - session.createdAt > SESSION_TTL) { sessions.delete(token); return 0 }
    return Number(session.userId) || 0
  }
  return 0
}

async function isAdmin(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return false
  const session = sessions.get(token)
  if (session) { const roles = session.roles || []; return roles.includes('R_SUPER') || roles.includes('R_ADMIN') }
  return false
}

function genCode() { return crypto.randomBytes(4).toString('hex').toUpperCase() }

module.exports = function inviteRoutes(app) {
  app.post('/api/invite/generate', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const { count = 1, maxUses = 1, expiresDays = 0, rewardType, rewardValue, rewardDuration } = req.body
      const codes = []
      for (let i = 0; i < count; i++) {
        const code = genCode()
        const expiresAt = expiresDays > 0 ? new Date(Date.now() + expiresDays * 86400000).toISOString().replace('T', ' ').substring(0, 19) : null
        const userId = await getUserId(req)
        await query(
          'INSERT INTO invite_codes (code, created_by, created_by_name, max_uses, expires_at, type, reward_type, reward_value, reward_duration) VALUES (?,?,?,?,?,"admin",?,?,?)',
          [code, userId, '管理员', maxUses, expiresAt, rewardType || '', rewardValue || '', rewardDuration || 0]
        )
        codes.push(code)
      }
      res.json({ code: 200, data: { codes }, message: `成功生成${count}个邀请码` })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  // 用户自己生成邀请码
  app.post('/api/invite/generate-user', authRequired, async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, message: '请先登录' })

      const cfg = await query("SELECT config_value FROM sys_config WHERE config_key='invite_user_enabled'")
      if (!cfg || !cfg.length || cfg[0].config_value !== 'true') {
        return res.json({ code: 403, message: '暂未开放用户生成邀请码' })
      }

      const maxCfg = await query("SELECT config_value FROM sys_config WHERE config_key='invite_user_max'")
      const maxCount = maxCfg && maxCfg.length ? parseInt(maxCfg[0].config_value) || 5 : 5

      const myCodes = await query(
        "SELECT COUNT(*) as cnt FROM invite_codes WHERE type='user' AND created_by_user_id=? AND status='1' AND use_count < max_uses",
        [userId]
      )
      if (myCodes[0].cnt >= maxCount) {
        return res.json({ code: 400, message: `最多只能生成${maxCount}个邀请码` })
      }

      const code = genCode()
      const user = await query('SELECT username FROM users WHERE id=?', [userId])
      const userName = user && user.length > 0 ? user[0].username : ''
      await query(
        'INSERT INTO invite_codes (code, created_by, created_by_name, type, created_by_user_id, max_uses, expires_at) VALUES (?,?,?,?,?,?,?)',
        [code, userId, userName, 'user', userId, 1, null]
      )
      res.json({ code: 200, data: { code }, message: '邀请码生成成功' })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  // 用户查看自己的邀请码
  app.get('/api/invite/my', authRequired, async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, message: '请先登录' })
      const list = await query(
        "SELECT * FROM invite_codes WHERE created_by_user_id=? ORDER BY create_time DESC",
        [userId]
      )
      res.json({ code: 200, data: { list } })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.get('/api/invite/list', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const { page = 1, pageSize = 20, status } = req.query
      const offset = (page - 1) * pageSize
      let where = '1=1'
      if (status === 'unused') where = "status='1' AND use_count < max_uses"
      else if (status === 'used') where = "status='2' OR use_count >= max_uses"
      const list = await query(`SELECT * FROM invite_codes WHERE ${where} ORDER BY create_time DESC LIMIT ? OFFSET ?`, [parseInt(pageSize), offset])
      const cnt = await query(`SELECT COUNT(*) as total FROM invite_codes WHERE ${where}`)
      res.json({ code: 200, data: { list, total: cnt[0].total } })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.post('/api/invite/verify', async (req, res) => {
    try {
      const { code } = req.body
      if (!code) return res.json({ code: 400, message: '请输入邀请码' })
      const rows = await query('SELECT * FROM invite_codes WHERE code=?', [code.toUpperCase()])
      if (rows.length === 0) return res.json({ code: 400, message: '邀请码不存在' })
      const inv = rows[0]
      if (inv.status !== '1') return res.json({ code: 400, message: '邀请码已失效' })
      if (inv.use_count >= inv.max_uses) return res.json({ code: 400, message: '邀请码已被使用' })
      if (inv.expires_at && new Date(inv.expires_at) < new Date()) return res.json({ code: 400, message: '邀请码已过期' })
      res.json({ code: 200, data: { valid: true, code: inv.code }, message: '邀请码有效' })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.post('/api/invite/use', async (req, res) => {
    try {
      const { code, userId, userName } = req.body
      if (!code || !userId) return res.json({ code: 400, message: '参数不完整' })
      const rows = await query('SELECT * FROM invite_codes WHERE code=?', [code.toUpperCase()])
      if (rows.length === 0) return res.json({ code: 400, message: '邀请码不存在' })
      const inv = rows[0]
      if (inv.use_count >= inv.max_uses) return res.json({ code: 400, message: '邀请码已被使用' })
      const newCount = inv.use_count + 1
      const newStatus = newCount >= inv.max_uses ? '2' : '1'

      // 记录被邀请用户
      let invitedList = []
      try { invitedList = JSON.parse(inv.invited_users || '[]') } catch { invitedList = [] }
      invitedList.push({ userId, userName: userName || '', time: new Date().toISOString() })

      await query(
        'UPDATE invite_codes SET use_count=?, status=?, used_by=?, used_by_name=?, used_at=datetime("now","localtime"), invited_users=? WHERE id=?',
        [newCount, newStatus, userId, userName || '', JSON.stringify(invitedList), inv.id]
      )

      // 发放邀请奖励
      if (inv.reward_type && inv.reward_value) {
        const rewards = JSON.parse(inv.reward_value)
        if (rewards.points && rewards.points > 0) {
          await query('UPDATE users SET points=points+? WHERE id=?', [rewards.points, userId])
          await query("INSERT INTO points_records (user_id, user_name, type, amount, source, description) VALUES (?,?,?,?,?,?)",
            [userId, userName || '', 'earn', rewards.points, 'invite', '邀请码注册奖励'])
        }
        if (rewards.balance && rewards.balance > 0) {
          await query('UPDATE users SET balance=balance+? WHERE id=?', [rewards.balance, userId])
        }
        if (rewards.exp && rewards.exp > 0) {
          await query('UPDATE users SET experience=experience+? WHERE id=?', [rewards.exp, userId])
        }
        if (rewards.levelId && rewards.levelId > 0) {
          const lvs = await query('SELECT id, name FROM membership_levels WHERE id=?', [rewards.levelId])
          if (lvs.length) {
            const duration = inv.reward_duration || 30
            const expireDate = new Date(Date.now() + duration * 86400000).toISOString().slice(0, 19).replace('T', ' ')
            await query('UPDATE users SET level_id=?, level_name=?, expire_time=? WHERE id=?',
              [rewards.levelId, lvs[0].name, expireDate, userId])
          }
        }
      }

      // 如果邀请人是管理员生成的，也奖励邀请人
      if (inv.created_by > 0) {
        await query('UPDATE users SET points=points+10 WHERE id=?', [inv.created_by])
        await query("INSERT INTO points_records (user_id, user_name, type, amount, source, description) VALUES (?,?,?,?,?,?)",
          [inv.created_by, inv.created_by_name || '', 'earn', 10, 'invite', '邀请用户注册奖励'])
      }
      res.json({ code: 200, message: '邀请码使用成功' })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.get('/api/invite/required', async (req, res) => {
    try {
      const cnt = await query("SELECT COUNT(*) as total FROM invite_codes WHERE status='1' AND use_count < max_uses")
      res.json({ code: 200, data: { required: cnt[0].total > 0, availableCount: cnt[0].total } })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.get('/api/invite/config', async (req, res) => {
    try {
      const keys = ['invite_user_enabled', 'invite_user_max', 'register_invite_required']
      const rows = await query("SELECT config_key, config_value FROM sys_config WHERE config_key IN (?,?,?)", keys)
      const config = {}
      for (const r of rows) config[r.config_key] = r.config_value
      res.json({ code: 200, data: config })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })
}
