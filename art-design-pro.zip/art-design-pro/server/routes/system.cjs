const { query, dbType } = require('../database.cjs')

// Simple in-memory token cache: token -> { userId, userName, roles, createdAt }
const sessions = new Map()
const SESSION_TTL = 24 * 60 * 60 * 1000 // 24 hours
const nowExpr = dbType === 'mysql' ? 'NOW()' : "datetime('now','localtime')"

// Clean expired sessions every 5 minutes
setInterval(() => {
  const now = Date.now()
  for (const [token, session] of sessions) {
    if (now - session.createdAt > SESSION_TTL) {
      sessions.delete(token)
    }
  }
}, 5 * 60 * 1000)

// Auth middleware
function authRequired(req, res, next) {
  const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '')
  if (!token) return res.status(401).json({ code: 401, msg: '未登录或登录已过期' })

  // Check in-memory cache first
  let session = sessions.get(token)
  if (session) {
    if (Date.now() - session.createdAt > SESSION_TTL) {
      sessions.delete(token)
      return res.status(401).json({ code: 401, msg: '登录已过期，请重新登录' })
    }
    req.user = session
    return next()
  }

  // Fallback: check database
  query('SELECT * FROM sessions WHERE token=?', [token]).then(rows => {
    const row = rows && rows.length > 0 ? rows[0] : null
    if (!row) return res.status(401).json({ code: 401, msg: '未登录或登录已过期' })
    if (Date.now() - row.created_at > SESSION_TTL) {
      query('DELETE FROM sessions WHERE token=?', [token]).catch(() => {})
      return res.status(401).json({ code: 401, msg: '登录已过期，请重新登录' })
    }
    session = { userId: row.user_id, userName: row.user_name, roles: JSON.parse(row.roles || '[]'), createdAt: row.created_at }
    sessions.set(token, session)
    req.user = session
    next()
  }).catch(() => res.status(500).json({ code: 500, msg: '服务器错误' }))
}

function saveSession(token, userId, userName, roles) {
  const now = Date.now()
  sessions.set(token, { userId, userName, roles, createdAt: now })
  query(
    `INSERT OR REPLACE INTO sessions (token, user_id, user_name, roles, created_at) VALUES (?, ?, ?, ?, ?)`,
    [token, userId, userName, JSON.stringify(roles || []), now]
  ).catch(() => {})
}

function generateToken() {
  return 'tk-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 10)
}

function systemRoutes(router, { query: dbQuery }) {
  // ========== 登录认证 ==========

  // POST /api/auth/login
  router.post('/api/auth/login', async (req, res) => {
    try {
      const { userName, username, password } = req.body
      const name = userName || username
      if (!name || !password) return res.json({ code: 400, msg: '用户名或密码不能为空' })

      const users = await dbQuery('SELECT id, username, password, roles FROM users WHERE username=? AND status!=?', [name, '4'])
      if (!users || users.length === 0) return res.json({ code: 400, msg: '用户名或密码错误' })

      const user = users[0]
      if (user.password !== password) return res.json({ code: 400, msg: '用户名或密码错误' })

      let roles = []
      try { roles = typeof user.roles === 'string' ? JSON.parse(user.roles) : (user.roles || []) } catch { roles = [] }

      const token = generateToken()
      saveSession(token, user.id, user.username, roles)

      res.json({
        code: 200, msg: '登录成功',
        data: { token, refreshToken: token }
      })
    } catch (e) {
      console.error('登录失败:', e.message)
      res.json({ code: 500, msg: '登录失败: ' + e.message })
    }
  })

  // GET /api/user/info
  router.get('/api/user/info', authRequired, async (req, res) => {
    try {
      const user = req.user
      const rows = await dbQuery('SELECT id, username, email, avatar, phone, gender, nickname, bio, points, balance, experience, level_id, level_name, expire_time FROM users WHERE id=?', [user.userId])
      const u = rows && rows.length > 0 ? rows[0] : null
      let discountRate = 1, pointsDiscountRate = 1, levelName = u?.level_name || ''
      if (u && u.level_id > 0) {
        const mlRows = await dbQuery('SELECT discount_rate, points_discount_rate, name FROM membership_levels WHERE id=?', [u.level_id])
        if (mlRows && mlRows.length > 0) {
          discountRate = Number(mlRows[0].discount_rate || 1)
          pointsDiscountRate = Number(mlRows[0].points_discount_rate || 1)
          levelName = mlRows[0].name || levelName
        }
      }
      res.json({
        code: 200, msg: 'success',
        data: {
          buttons: ['add', 'edit', 'delete'],
          roles: user.roles,
          userId: user.userId,
          userName: user.userName,
          email: u ? u.email : '',
          avatar: u ? u.avatar : '',
          phone: u ? u.phone : '',
          gender: u ? u.gender : '',
          nickname: u ? u.nickname : '',
          bio: u ? u.bio : '',
          points: u ? u.points : 0,
          balance: u ? u.balance : 0,
          experience: u ? u.experience : 0,
          levelId: u ? u.level_id : 0,
          levelName,
          expireTime: u ? u.expire_time : null,
          discountRate,
          pointsDiscountRate
        }
      })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ========== 角色管理 ==========

  router.get('/api/role/list', async (req, res) => {
    try {
      const { current = 1, size = 20 } = req.query
      const rows = await dbQuery('SELECT id as roleId, role_name as roleName, role_code as roleCode, description, enabled, create_time as createTime FROM roles ORDER BY id')
      res.json({ code: 200, msg: 'success', data: { records: rows, current: parseInt(current) || 1, size: parseInt(size) || 20, total: rows.length } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  router.post('/api/role/save', async (req, res) => {
    try {
      const { roleId, roleName, roleCode, description, enabled } = req.body
      if (roleId) {
        await dbQuery('UPDATE roles SET role_name=?, role_code=?, description=?, enabled=? WHERE id=?',
          [roleName, roleCode, description, enabled ? 1 : 0, roleId])
        res.json({ code: 200, msg: '更新成功', data: { roleId } })
      } else {
        const result = await dbQuery('INSERT INTO roles (role_name, role_code, description, enabled) VALUES (?, ?, ?, ?)',
          [roleName, roleCode, description, enabled ? 1 : 0])
        res.json({ code: 200, msg: '新增成功', data: { roleId: result.lastInsertRowid || result.insertId } })
      }
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  router.delete('/api/role/:id', async (req, res) => {
    try {
      await dbQuery('DELETE FROM roles WHERE id=?', [req.params.id])
      await dbQuery('DELETE FROM role_permissions WHERE role_id=?', [req.params.id])
      res.json({ code: 200, msg: '删除成功', data: { success: true } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ========== 角色权限 ==========

  router.get('/api/role/:id/permissions', async (req, res) => {
    try {
      const rows = await dbQuery('SELECT menu_id as menuId FROM role_permissions WHERE role_id=?', [req.params.id])
      res.json({ code: 200, msg: 'success', data: rows.map(r => r.menuId) })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  router.post('/api/role/:id/permissions', async (req, res) => {
    try {
      const roleId = req.params.id
      const { menuIds } = req.body
      await dbQuery('DELETE FROM role_permissions WHERE role_id=?', [roleId])
      if (Array.isArray(menuIds) && menuIds.length > 0) {
        const vals = menuIds.map(mid => [roleId, mid])
        for (const v of vals) {
          await dbQuery('INSERT INTO role_permissions (role_id, menu_id) VALUES (?, ?)', v)
        }
      }
      res.json({ code: 200, msg: '保存成功', data: { success: true } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ========== 仪表盘统计 ==========

  router.get('/api/dashboard/stats', async (req, res) => {
    try {
      const [userCount] = await dbQuery("SELECT COUNT(*) as cnt FROM users WHERE status!='4'")
      const [onlineCount] = await dbQuery("SELECT COUNT(*) as cnt FROM users WHERE status='1'")
      const [totalPoints] = await dbQuery("SELECT COALESCE(SUM(points), 0) as cnt FROM users WHERE status!='4'")
      const [cardCount] = await dbQuery("SELECT COUNT(*) as cnt FROM card_keys WHERE status='0'")
      const todayDateFn = dbType === 'mysql' ? 'CURDATE()' : "date('now')"
      const [todayNew] = await dbQuery(
        `SELECT COUNT(*) as cnt FROM users WHERE status!='4' AND DATE(create_time)=${todayDateFn}`)

      res.json({
        code: 200, msg: 'success',
        data: {
          userCount: userCount.cnt,
          onlineCount: onlineCount.cnt,
          totalPoints: totalPoints.cnt,
          cardCount: cardCount.cnt,
          todayNewCount: todayNew.cnt,
          weeklyNewCount: Math.floor(todayNew.cnt * 7 * (1 + Math.random() * 0.5)),
          weeklyActiveCount: Math.floor(onlineCount.cnt * 1.5)
        }
      })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ========== 菜单树 (权限过滤) ==========

  router.get('/api/v3/system/menus/simple', async (req, res) => {
    try {
      const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '')
      const session = sessions.get(token)

      let visibleMenuIds = null
      if (session && !session.roles.includes('R_SUPER')) {
        const perms = await dbQuery(
          'SELECT DISTINCT menu_id FROM role_permissions WHERE role_id IN (SELECT id FROM roles WHERE role_code IN (?))',
          [session.roles]
        )
        visibleMenuIds = new Set(perms.map(p => p.menu_id))
      }

      const rows = await dbQuery(
        `SELECT id, parent_id as parentId, name, path, component, redirect, title, icon,
                sort_order as sortOrder, is_hidden as isHidden, is_full_page as isFullPage,
                is_keep_alive as isKeepAlive, is_fixed_tab as isFixedTab, auth_list as authList,
                roles as menuRoles, enabled, create_time as createTime, update_time as updateTime
         FROM menus WHERE enabled=1 ORDER BY sort_order, id`
      )

      // Filter by role permissions (R_SUPER sees all)
      const filtered = visibleMenuIds
        ? rows.filter(r => visibleMenuIds.has(r.id))
        : rows

      const list = filtered.map(r => {
        try { r.authList = r.authList ? JSON.parse(r.authList) : null } catch { r.authList = null }
        try { r.menuRoles = r.menuRoles ? JSON.parse(r.menuRoles) : null } catch { r.menuRoles = null }
        return r
      })

      // Build tree
      const nodeMap = {}
      const tree = []
      for (const m of list) {
        nodeMap[m.id] = { ...m, children: [] }
      }
      for (const m of list) {
        if (m.parentId && nodeMap[m.parentId]) {
          nodeMap[m.parentId].children.push(nodeMap[m.id])
        } else {
          tree.push(nodeMap[m.id])
        }
      }

      // Convert to frontend format
      function toRoute(node, basePath) {
        const meta = {
          title: node.title,
          icon: node.icon || undefined,
          isHide: !!node.isHidden,
          isFullPage: !!node.isFullPage,
          keepAlive: !!node.isKeepAlive,
          fixedTab: !!node.isFixedTab,
          roles: node.menuRoles || undefined,
          authList: node.authList || undefined
        }
        Object.keys(meta).forEach(k => meta[k] === undefined && delete meta[k])

        const route = {
          id: node.id,
          parentId: node.parentId || 0,
          name: node.name,
          path: node.path,
          component: node.component || undefined,
          redirect: node.redirect || undefined,
          sortOrder: node.sortOrder || 0,
          enabled: !!node.enabled,
          createTime: node.createTime || undefined,
          updateTime: node.updateTime || undefined,
          meta
        }

        route.children = node.children
          ? node.children.map(c => toRoute(c, node.path))
          : []

        Object.keys(route).forEach(k => route[k] === undefined && delete route[k])
        return route
      }

      const menuTree = tree.map(t => toRoute(t, '/'))

      res.json({ code: 200, msg: 'success', data: menuTree })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ========== 插件管理 ==========

  // GET /api/plugins/list (public)
  router.get('/api/plugins/list', async (req, res) => {
    try {
      const records = await dbQuery(
        `SELECT id, name, description, version, author, icon, entry_url as entryUrl,
                component_name as componentName, status, create_time as createTime
         FROM plugins ORDER BY id DESC`
      )
      res.json({ code: 200, msg: 'success', data: { records, current: 1, size: 100, total: records.length } })
    } catch (e) {
      console.error('插件列表查询失败:', e.message)
      res.json({ code: 500, msg: '查询失败: ' + e.message })
    }
  })

  // POST /api/plugins/save (auth required)
  router.post('/api/plugins/save', authRequired, async (req, res) => {
    try {
      const { id, name, description, version, author, icon, entryUrl, componentName, status } = req.body

      if (id) {
        await dbQuery(
          `UPDATE plugins SET name=?, description=?, version=?, author=?, icon=?, entry_url=?, component_name=?, status=? WHERE id=?`,
          [name, description || '', version || '1.0.0', author || '', icon || '', entryUrl || '', componentName || '', status || '1', Number(id)]
        )
        res.json({ code: 200, msg: '更新成功', data: { id: Number(id) } })
      } else {
        const result = await dbQuery(
          `INSERT INTO plugins (name, description, version, author, icon, entry_url, component_name, status)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
          [name, description || '', version || '1.0.0', author || '', icon || '', entryUrl || '', componentName || '', status || '1']
        )
        res.json({ code: 200, msg: '添加成功', data: { id: result.lastInsertRowid || result.insertId } })
      }
    } catch (e) {
      console.error('保存插件失败:', e.message)
      res.json({ code: 500, msg: '保存失败: ' + e.message })
    }
  })

  // DELETE /api/plugins/:id (auth required)
  router.delete('/api/plugins/:id', authRequired, async (req, res) => {
    try {
      await dbQuery('DELETE FROM plugins WHERE id = ?', [Number(req.params.id)])
      res.json({ code: 200, msg: '删除成功', data: { success: true } })
    } catch (e) {
      console.error('删除插件失败:', e.message)
      res.json({ code: 500, msg: '删除失败: ' + e.message })
    }
  })
}

systemRoutes.sessions = sessions
systemRoutes.SESSION_TTL = SESSION_TTL
systemRoutes.authRequired = authRequired

module.exports = systemRoutes
