const { query } = require('../database.cjs')
const bcrypt = require('bcryptjs')
const { logFromReq } = require('../middleware/security.cjs')
const { emitSafe, USER_EVENTS } = require('../plugins/events.cjs')

// Simple in-memory token cache: token -> { userId, userName, roles, createdAt }
const sessions = new Map()
const SESSION_TTL = 24 * 60 * 60 * 1000 // 24 hours
const nowExpr = 'NOW()'

// Clean expired sessions every 5 minutes
setInterval(() => {
  const now = Date.now()
  for (const [token, session] of sessions) {
    if (now - session.createdAt > SESSION_TTL) {
      sessions.delete(token)
    }
  }
}, 5 * 60 * 1000)

// Auth middleware
function authRequired(req, res, next) {
  const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '')
  if (!token) return res.status(401).json({ code: 401, msg: '未登录或登录已过期' })

  // Check in-memory cache first
  let session = sessions.get(token)
  if (session) {
    if (Date.now() - session.createdAt > SESSION_TTL) {
      sessions.delete(token)
      return res.status(401).json({ code: 401, msg: '登录已过期，请重新登录' })
    }
    req.user = session
    return next()
  }

  // Fallback: check database
  query('SELECT * FROM sessions WHERE token=?', [token]).then(rows => {
    const row = rows && rows.length > 0 ? rows[0] : null
    if (!row) return res.status(401).json({ code: 401, msg: '未登录或登录已过期' })
    if (Date.now() - row.created_at > SESSION_TTL) {
      query('DELETE FROM sessions WHERE token=?', [token]).catch(() => {})
      return res.status(401).json({ code: 401, msg: '登录已过期，请重新登录' })
    }
    session = { userId: row.user_id, userName: row.user_name, roles: JSON.parse(row.roles || '[]'), createdAt: row.created_at }
    sessions.set(token, session)
    req.user = session
    next()
  }).catch(() => res.status(500).json({ code: 500, msg: '服务器错误' }))
}

function optionalAuth(req, res, next) {
  const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '')
  if (!token) return next()

  let session = sessions.get(token)
  if (session) {
    if (Date.now() - session.createdAt > SESSION_TTL) {
      sessions.delete(token)
      return next()
    }
    req.user = session
    return next()
  }

  query('SELECT * FROM sessions WHERE token=?', [token]).then(rows => {
    const row = rows && rows.length > 0 ? rows[0] : null
    if (!row) return next()
    if (Date.now() - row.created_at > SESSION_TTL) {
      query('DELETE FROM sessions WHERE token=?', [token]).catch(() => {})
      return next()
    }
    session = { userId: row.user_id, userName: row.user_name, roles: JSON.parse(row.roles || '[]'), createdAt: row.created_at }
    sessions.set(token, session)
    req.user = session
    next()
  }).catch(() => next())
}

function saveSession(token, userId, userName, roles) {
  const now = Date.now()
  sessions.set(token, { userId, userName, roles, createdAt: now })
  query(
    `REPLACE INTO sessions (token, user_id, user_name, roles, created_at) VALUES (?, ?, ?, ?, ?)`,
    [token, userId, userName, JSON.stringify(roles || []), now]
  ).catch(() => {})
}

function generateToken() {
  return 'tk-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 10)
}

function systemRoutes(router, { query: dbQuery }) {
  // ========== 登录认证 ==========

  // POST /api/auth/login
  router.post('/api/auth/login', async (req, res) => {
    try {
      const { userName, username, password } = req.body
      const name = userName || username
      if (!name || !password) return res.json({ code: 400, msg: '用户名或密码不能为空' })

      const users = await dbQuery('SELECT id, username, password, password_hash, roles, status, ban_until FROM users WHERE username=? AND status!=?', [name, '4'])
      if (!users || users.length === 0) return res.json({ code: 400, msg: '用户名或密码错误' })

      const user = users[0]

      if (user.ban_until) {
        const now = new Date()
        const banUntil = new Date(user.ban_until.replace(' ', 'T') + (user.ban_until.includes('Z') ? '' : 'Z'))
        if (banUntil > now) {
          return res.json({ code: 403, msg: '该账号已被封禁，截止时间: ' + user.ban_until.replace('T', ' ').slice(0, 16) })
        }
      }

      if (user.status === '4') return res.json({ code: 403, msg: '该账号已被注销' })
      const passwordMatch = user.password_hash
        ? bcrypt.compareSync(password, user.password_hash)
        : (user.password === password)
      if (!passwordMatch) return res.json({ code: 400, msg: '用户名或密码错误' })

      let roles = []
      try { roles = typeof user.roles === 'string' ? JSON.parse(user.roles) : (user.roles || []) } catch { roles = [] }

      const token = generateToken()
      saveSession(token, user.id, user.username, roles)

      logFromReq(req, 'login', 'user', user.id, `用户 ${user.username} 登录`)

      emitSafe(USER_EVENTS.LOGIN, { userId: user.id, username: user.username, roles })

      res.json({
        code: 200, msg: '登录成功',
        data: { token, refreshToken: token }
      })
    } catch (e) {
      console.error('登录失败:', e.message)
      res.json({ code: 500, msg: '登录失败: ' + e.message })
    }
  })

  // GET /api/user/info
  router.get('/api/user/info', authRequired, async (req, res) => {
    try {
      const user = req.user
      const rows = await dbQuery(
        `SELECT id, username, email, avatar, phone, gender, nickname, bio, points, balance, experience, level_id, level_name, expire_time, fans_count, follow_count, signature FROM users WHERE id=?`,
        [user.userId]
      )
      const u = rows && rows.length > 0 ? rows[0] : null
      let discountRate = 1, pointsDiscountRate = 1, levelName = u?.level_name || '', levelTextColor = '#FFFFFF', levelBgColor = '#508DFF'
      let purchaseCount = 0
      if (u) {
        const pcRows = await dbQuery("SELECT COUNT(*) as cnt FROM mall_orders WHERE user_id=? AND status='paid'", [u.id])
        const legacyRows = await dbQuery("SELECT COUNT(*) as cnt FROM orders WHERE buyer_id=? AND status!='cancelled'", [u.id])
        purchaseCount = (pcRows && pcRows.length > 0 ? pcRows[0].cnt : 0) + (legacyRows && legacyRows.length > 0 ? legacyRows[0].cnt : 0)
      }
      if (u && u.level_id > 0) {
        const mlRows = await dbQuery('SELECT discount_rate, points_discount_rate, name, text_color, bg_color FROM membership_levels WHERE id=?', [u.level_id])
        if (mlRows && mlRows.length > 0) {
          discountRate = Number(mlRows[0].discount_rate || 1)
          pointsDiscountRate = Number(mlRows[0].points_discount_rate || 1)
          levelName = mlRows[0].name || levelName
          levelTextColor = mlRows[0].text_color || '#FFFFFF'
          levelBgColor = mlRows[0].bg_color || '#508DFF'
        }
      }
      res.json({
        code: 200, msg: 'success',
        data: {
          buttons: ['add', 'edit', 'delete'],
          roles: user.roles,
          userId: user.userId,
          userName: user.userName,
          email: u ? u.email : '',
          avatar: u ? u.avatar : '',
          phone: u ? u.phone : '',
          gender: u ? u.gender : '',
          nickname: u ? u.nickname : '',
          bio: u ? u.bio : '',
          points: u ? u.points : 0,
          balance: u ? u.balance : 0,
          experience: u ? u.experience : 0,
          levelId: u ? u.level_id : 0,
          levelName,
          levelTextColor,
          levelBgColor,
          expireTime: u ? u.expire_time : null,
          discountRate,
          pointsDiscountRate,
          fansCount: u ? u.fans_count : 0,
          followCount: u ? u.follow_count : 0,
          purchaseCount,
          signature: u ? u.signature : ''
        }
      })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ========== 角色管理 ==========

  router.get('/api/role/list', async (req, res) => {
    try {
      const { current = 1, size = 20 } = req.query
      const rows = await dbQuery('SELECT id as roleId, role_name as roleName, role_code as roleCode, description, enabled, create_time as createTime FROM roles ORDER BY id')
      res.json({ code: 200, msg: 'success', data: { records: rows, current: parseInt(current) || 1, size: parseInt(size) || 20, total: rows.length } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  router.post('/api/role/save', async (req, res) => {
    try {
      const { roleId, roleName, roleCode, description, enabled } = req.body
      if (roleId) {
        await dbQuery('UPDATE roles SET role_name=?, role_code=?, description=?, enabled=? WHERE id=?',
          [roleName, roleCode, description, enabled ? 1 : 0, roleId])
        logFromReq(req, 'update', 'role', roleId, `更新角色"${roleName}"`)
        res.json({ code: 200, msg: '更新成功', data: { roleId } })
      } else {
        const result = await dbQuery('INSERT INTO roles (role_name, role_code, description, enabled) VALUES (?, ?, ?, ?)',
          [roleName, roleCode, description, enabled ? 1 : 0])
        logFromReq(req, 'create', 'role', result.insertId, `新建角色"${roleName}"`)
        res.json({ code: 200, msg: '新增成功', data: { roleId: result.insertId } })
      }
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  router.delete('/api/role/:id', async (req, res) => {
    try {
      const role = await dbQuery('SELECT role_name FROM roles WHERE id=?', [req.params.id])
      const roleName = role && role.length > 0 ? role[0].role_name : '未知'
      await dbQuery('DELETE FROM roles WHERE id=?', [req.params.id])
      await dbQuery('DELETE FROM role_permissions WHERE role_id=?', [req.params.id])
      logFromReq(req, 'delete', 'role', req.params.id, `删除角色"${roleName}"`)
      res.json({ code: 200, msg: '删除成功', data: { success: true } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ========== 角色权限 ==========

  router.get('/api/role/:id/permissions', async (req, res) => {
    try {
      const roleId = req.params.id
      const roleRows = await dbQuery('SELECT role_code FROM roles WHERE id=?', [roleId])
      const roleCode = roleRows?.[0]?.role_code || ''

      if (roleCode === 'R_SUPER') {
        const allMenus = await dbQuery('SELECT id, auth_list FROM menus WHERE enabled=1')
        const data = []
        for (const m of allMenus) {
          data.push({ menuId: m.id, authMark: null })
          try {
            const authList = JSON.parse(m.auth_list || '[]')
            for (const auth of (Array.isArray(authList) ? authList : [])) {
              if (auth.authMark) data.push({ menuId: m.id, authMark: auth.authMark })
            }
          } catch {}
        }
        return res.json({ code: 200, msg: 'success', data })
      }

      const rows = await dbQuery(
        'SELECT menu_id as menuId, auth_mark as authMark FROM role_permissions WHERE role_id=?',
        [roleId]
      )
      res.json({ code: 200, msg: 'success', data: rows })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  router.post('/api/role/:id/permissions', async (req, res) => {
    try {
      const roleId = req.params.id
      const { permissions } = req.body
      await dbQuery('DELETE FROM role_permissions WHERE role_id=?', [roleId])
      if (Array.isArray(permissions) && permissions.length > 0) {
        for (const p of permissions) {
          await dbQuery(
            'INSERT INTO role_permissions (role_id, menu_id, auth_mark) VALUES (?, ?, ?)',
            [roleId, p.menuId, p.authMark || null]
          )
        }
      }
      logFromReq(req, 'update', 'role_permission', roleId, `更新角色权限`)
      res.json({ code: 200, msg: '保存成功', data: { success: true } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ========== 仪表盘统计 ==========

  router.get('/api/dashboard/stats', async (req, res) => {
    try {
      const [userCount] = await dbQuery("SELECT COUNT(*) as cnt FROM users WHERE status!='4'")
      const [onlineCount] = await dbQuery("SELECT COUNT(*) as cnt FROM users WHERE status='1'")
      const [totalPoints] = await dbQuery("SELECT COALESCE(SUM(points), 0) as cnt FROM users WHERE status!='4'")
      const [cardCount] = await dbQuery("SELECT COUNT(*) as cnt FROM card_keys WHERE status='0'")
      const todayDateFn = 'CURDATE()'
      const [todayNew] = await dbQuery(
        `SELECT COUNT(*) as cnt FROM users WHERE status!='4' AND DATE(create_time)=${todayDateFn}`)

      res.json({
        code: 200, msg: 'success',
        data: {
          userCount: userCount.cnt,
          onlineCount: onlineCount.cnt,
          totalPoints: totalPoints.cnt,
          cardCount: cardCount.cnt,
          todayNewCount: todayNew.cnt,
          weeklyNewCount: Math.floor(todayNew.cnt * 7 * (1 + Math.random() * 0.5)),
          weeklyActiveCount: Math.floor(onlineCount.cnt * 1.5)
        }
      })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ========== 移动端控制台综合统计 ==========

  router.get('/api/admin/console-stats', async (req, res) => {
    try {
      const today = 'CURDATE()'
      const all = await Promise.all([
        // 用户
        dbQuery("SELECT COUNT(*) as cnt FROM users WHERE status!='4'"),
        dbQuery(`SELECT COUNT(*) as cnt FROM users WHERE status!='4' AND DATE(create_time)=${today}`),
        dbQuery("SELECT COUNT(*) as cnt FROM users WHERE status='4'"),
        dbQuery("SELECT COUNT(*) as cnt FROM users WHERE status='1'"),
        // 会员
        dbQuery("SELECT COUNT(*) as cnt FROM membership_levels"),
        dbQuery("SELECT COUNT(*) as cnt FROM membership_purchases"),
        // 卡密
        dbQuery("SELECT COUNT(*) as cnt FROM card_keys"),
        dbQuery("SELECT COUNT(*) as cnt FROM card_keys WHERE status='0'"),
        dbQuery("SELECT COUNT(*) as cnt FROM card_keys WHERE status='1'"),
        // 优惠券
        dbQuery("SELECT COUNT(*) as cnt FROM coupons"),
        dbQuery("SELECT COUNT(*) as cnt FROM user_coupons WHERE status='1'"),
        dbQuery("SELECT COUNT(*) as cnt FROM user_coupons"),
        // 积分
        dbQuery("SELECT COALESCE(SUM(points), 0) as cnt FROM users WHERE status!='4'"),
        dbQuery("SELECT COALESCE(SUM(points), 0) as cnt FROM points_records WHERE points>0"),
        // 经验等级
        dbQuery("SELECT COUNT(*) as cnt FROM experience_levels"),
        dbQuery("SELECT COUNT(*) as cnt FROM experience_records"),
        // 插件
        dbQuery("SELECT COUNT(*) as cnt FROM plugins"),
        dbQuery("SELECT COUNT(*) as cnt FROM plugins WHERE enabled=1"),
        // 称号
        dbQuery("SELECT COUNT(*) as cnt FROM custom_titles"),
        dbQuery("SELECT COUNT(*) as cnt FROM user_titles"),
        // 推广返佣
        dbQuery("SELECT COUNT(*) as cnt FROM commission_records"),
        dbQuery("SELECT COALESCE(SUM(amount), 0) as cnt FROM commission_records"),
        dbQuery("SELECT COUNT(*) as cnt FROM commission_rules"),
        dbQuery("SELECT COUNT(*) as cnt FROM referral_links"),
        // 文件上传策略
        dbQuery("SELECT COUNT(*) as cnt FROM file_policies"),
        // 结算规则
        dbQuery("SELECT COUNT(*) as cnt FROM settlement_config"),
        // 会员商品
        dbQuery("SELECT COUNT(*) as cnt FROM membership_products"),
        // 购买记录
        dbQuery("SELECT COUNT(*) as cnt FROM orders"),
        dbQuery(`SELECT COALESCE(SUM(total_amount),0) as cnt FROM orders WHERE DATE(create_time)=${today}`),
        dbQuery("SELECT COUNT(*) as cnt FROM content_purchases"),
        // 角色
        dbQuery("SELECT COUNT(*) as cnt FROM roles"),
        // 菜单
        dbQuery("SELECT COUNT(*) as cnt FROM menus"),
        dbQuery("SELECT COUNT(*) as cnt FROM menus WHERE enabled=1"),
        // 注销审核
        dbQuery("SELECT COUNT(*) as cnt FROM user_delete_requests WHERE status='pending'"),
        // 蓝V认证
        dbQuery("SELECT COUNT(*) as cnt FROM verification_requests WHERE status='pending'"),
        dbQuery("SELECT COUNT(*) as cnt FROM verification_requests"),
        dbQuery("SELECT COUNT(*) as cnt FROM verification_config"),
        // 邀请码
        dbQuery("SELECT COUNT(*) as cnt FROM invite_codes"),
        dbQuery("SELECT COUNT(*) as cnt FROM invite_codes WHERE status='0'"),
        // 邮件
        dbQuery("SELECT COUNT(*) as cnt FROM email_config"),
        dbQuery("SELECT COUNT(*) as cnt FROM email_templates"),
        dbQuery("SELECT COUNT(*) as cnt FROM email_push_config"),
        // 文件仓库
        dbQuery("SELECT COUNT(*) as cnt FROM file_repository"),
        dbQuery("SELECT COALESCE(SUM(file_size), 0) as cnt FROM file_repository"),
        // 回收站
        dbQuery("SELECT COUNT(*) as cnt FROM recycle_bin"),
        // 系统日志
        dbQuery("SELECT COUNT(*) as cnt FROM system_logs"),
        dbQuery(`SELECT COUNT(*) as cnt FROM system_logs WHERE DATE(create_time)=${today}`),
        // 系统配置
        dbQuery("SELECT COUNT(*) as cnt FROM sys_config"),
        // 任务
        dbQuery("SELECT COUNT(*) as cnt FROM custom_tasks"),
        dbQuery("SELECT COUNT(*) as cnt FROM task_records"),
        // 存储
        dbQuery("SELECT COUNT(*) as cnt FROM storage_configs"),
        // 应用商店
        dbQuery("SELECT COUNT(*) as cnt FROM app_store"),
        dbQuery("SELECT COUNT(*) as cnt FROM app_store WHERE status='approved'"),
        dbQuery("SELECT COUNT(*) as cnt FROM app_store WHERE status='pending'"),
        dbQuery("SELECT COUNT(*) as cnt FROM app_categories"),
        dbQuery("SELECT COUNT(*) as cnt FROM app_official_tags"),
        dbQuery("SELECT COUNT(*) as cnt FROM app_versions"),
        dbQuery("SELECT COUNT(*) as cnt FROM app_comments"),
        dbQuery("SELECT COUNT(*) as cnt FROM app_purchases"),
        dbQuery("SELECT COUNT(*) as cnt FROM app_favorites"),
        // 社区
        dbQuery("SELECT COUNT(*) as cnt FROM community_posts"),
        dbQuery("SELECT COUNT(*) as cnt FROM community_comments"),
        dbQuery("SELECT COUNT(*) as cnt FROM community_topics"),
        dbQuery("SELECT COUNT(*) as cnt FROM community_sections"),
        dbQuery("SELECT COUNT(*) as cnt FROM community_reports"),
        dbQuery("SELECT COUNT(*) as cnt FROM community_likes"),
        // 商城
        dbQuery("SELECT COUNT(*) as cnt FROM mall_products"),
        dbQuery("SELECT COUNT(*) as cnt FROM mall_orders"),
        dbQuery(`SELECT COALESCE(SUM(total_amount),0) as cnt FROM mall_orders WHERE DATE(create_time)=${today}`),
        dbQuery("SELECT COUNT(*) as cnt FROM mall_categories"),
        dbQuery("SELECT COUNT(*) as cnt FROM mall_reviews"),
        dbQuery("SELECT COUNT(*) as cnt FROM mall_promotions"),
        // 聊天
        dbQuery("SELECT COUNT(*) as cnt FROM chat_rooms"),
        dbQuery("SELECT COUNT(*) as cnt FROM chat_room_messages"),
        dbQuery("SELECT COUNT(*) as cnt FROM chat_room_members"),
        dbQuery("SELECT COUNT(*) as cnt FROM chat_gifts"),
        // 充值
        dbQuery("SELECT COUNT(*) as cnt FROM recharge_orders"),
        dbQuery(`SELECT COALESCE(SUM(amount),0) as cnt FROM recharge_orders WHERE status='paid' AND DATE(paid_time)=${today}`),
        dbQuery(`SELECT COALESCE(SUM(amount),0) as cnt FROM recharge_orders WHERE status='paid'`),
        // 关注/社交
        dbQuery("SELECT COUNT(*) as cnt FROM user_follows"),
        dbQuery("SELECT COUNT(*) as cnt FROM user_blocks"),
        dbQuery("SELECT COUNT(*) as cnt FROM private_messages"),
        // 签到
        dbQuery("SELECT COUNT(*) as cnt FROM checkin_records"),
        dbQuery(`SELECT COUNT(*) as cnt FROM checkin_records WHERE DATE(checkin_date)=${today}`),
        dbQuery("SELECT COUNT(*) as cnt FROM checkin_groups"),
        // 提现
        dbQuery("SELECT COUNT(*) as cnt FROM withdraw_records"),
        dbQuery("SELECT COALESCE(SUM(amount),0) as cnt FROM withdraw_records WHERE status='completed'"),
        dbQuery("SELECT COUNT(*) as cnt FROM withdraw_records WHERE status='pending'"),
        // 头像框
        dbQuery("SELECT COUNT(*) as cnt FROM avatar_frames"),
        dbQuery("SELECT COUNT(*) as cnt FROM user_avatar_frames"),
        // 通知
        dbQuery("SELECT COUNT(*) as cnt FROM sys_notifications"),
        // 敏感词
        dbQuery("SELECT COUNT(*) as cnt FROM sensitive_words"),
        // session
        dbQuery("SELECT COUNT(*) as cnt FROM sessions")
      ])

      const [
        rUser, rTodayUser, rDeleted, rOnline,
        rMemLevels, rMemPurchases,
        rCardKeys, rCardAvail, rCardUsed,
        rCoupons, rCouponUsed, rCouponIssued,
        rPoints, rPointsRecords,
        rExpLevels, rExpRecords,
        rPlugins, rPluginsActive,
        rTitles, rUserTitles,
        rCommission, rCommissionAmt, rCommRules, rRefLinks,
        rFilePolicies,
        rSettlements,
        rMemProducts,
        rOrders, rTodayOrderAmt, rContentPurchases,
        rRoles,
        rMenus, rMenusEnabled,
        rDelPending,
        rVerifyPending, rVerifyTotal, rVerifyConfig,
        rInvites, rInvitesUsed,
        rEmailConfig, rEmailTemplates, rEmailPush,
        rFiles, rFileSize,
        rRecycle,
        rLogs, rTodayLogs,
        rSysConfig,
        rTasks, rTaskRecords,
        rStorage,
        rApps, rAppsApproved, rAppsPending, rAppCats, rAppTags, rAppVers, rAppComments, rAppPurchases, rAppFav,
        rPosts, rComments, rTopics, rSections, rReports, rLikes,
        rMallProducts, rMallOrders, rMallOrderTodayAmt, rMallCats, rMallReviews, rMallPromotions,
        rChatRooms, rChatMsgs, rChatMembers, rChatGifts,
        rRecharges, rRechargeTodayAmt, rRechargeTotalAmt,
        rFollows, rBlocks, rPMs,
        rCheckins, rTodayCheckins, rCheckinGroups,
        rWithdraws, rWithdrawDoneAmt, rWithdrawPending,
        rAvatars, rUserAvatars,
        rNotifications,
        rSensitive,
        rSessions
      ] = all

      const fmt = (v) => Number((Array.isArray(v) ? v[0]?.cnt : v?.cnt) || 0)

      res.json({
        code: 200, msg: 'success',
        data: {
          user:                { total: fmt(rUser), todayNew: fmt(rTodayUser), deleted: fmt(rDeleted), online: fmt(rOnline) },
          membership:          { levels: fmt(rMemLevels), purchases: fmt(rMemPurchases), products: fmt(rMemProducts) },
          cardKey:             { total: fmt(rCardKeys), available: fmt(rCardAvail), used: fmt(rCardUsed) },
          coupon:              { total: fmt(rCoupons), issued: fmt(rCouponIssued), used: fmt(rCouponUsed) },
          points:              { total: fmt(rPoints), records: fmt(rPointsRecords) },
          experience:          { levels: fmt(rExpLevels), records: fmt(rExpRecords) },
          plugin:              { total: fmt(rPlugins), active: fmt(rPluginsActive) },
          title:               { custom: fmt(rTitles), assigned: fmt(rUserTitles) },
          commission:          { records: fmt(rCommission), amount: fmt(rCommissionAmt), rules: fmt(rCommRules), links: fmt(rRefLinks) },
          filePolicy:          { total: fmt(rFilePolicies) },
          settlement:          { total: fmt(rSettlements) },
          order:               { total: fmt(rOrders), todayAmount: fmt(rTodayOrderAmt) },
          contentPurchase:     { total: fmt(rContentPurchases) },
          role:                { total: fmt(rRoles) },
          menu:                { total: fmt(rMenus), enabled: fmt(rMenusEnabled) },
          deleteRequest:       { pending: fmt(rDelPending) },
          verification:        { pending: fmt(rVerifyPending), total: fmt(rVerifyTotal), config: fmt(rVerifyConfig) },
          inviteCode:          { total: fmt(rInvites), used: fmt(rInvitesUsed) },
          email:               { config: fmt(rEmailConfig), templates: fmt(rEmailTemplates), push: fmt(rEmailPush) },
          fileRepo:            { total: fmt(rFiles), size: fmt(rFileSize) },
          recycle:             { total: fmt(rRecycle) },
          systemLog:           { total: fmt(rLogs), today: fmt(rTodayLogs) },
          sysConfig:           { total: fmt(rSysConfig) },
          task:                { custom: fmt(rTasks), records: fmt(rTaskRecords) },
          storage:             { configs: fmt(rStorage) },
          appStore:            { total: fmt(rApps), approved: fmt(rAppsApproved), pending: fmt(rAppsPending), categories: fmt(rAppCats), tags: fmt(rAppTags), versions: fmt(rAppVers), comments: fmt(rAppComments), purchases: fmt(rAppPurchases), favorites: fmt(rAppFav) },
          community:           { posts: fmt(rPosts), comments: fmt(rComments), topics: fmt(rTopics), sections: fmt(rSections), reports: fmt(rReports), likes: fmt(rLikes) },
          mall:                { products: fmt(rMallProducts), orders: fmt(rMallOrders), todayAmount: fmt(rMallOrderTodayAmt), categories: fmt(rMallCats), reviews: fmt(rMallReviews), promotions: fmt(rMallPromotions) },
          chat:                { rooms: fmt(rChatRooms), messages: fmt(rChatMsgs), members: fmt(rChatMembers), gifts: fmt(rChatGifts) },
          recharge:            { orders: fmt(rRecharges), todayAmount: fmt(rRechargeTodayAmt), totalAmount: fmt(rRechargeTotalAmt) },
          social:              { follows: fmt(rFollows), blocks: fmt(rBlocks), messages: fmt(rPMs) },
          checkin:             { records: fmt(rCheckins), today: fmt(rTodayCheckins), groups: fmt(rCheckinGroups) },
          withdraw:            { total: fmt(rWithdraws), completedAmount: fmt(rWithdrawDoneAmt), pending: fmt(rWithdrawPending) },
          avatarFrame:         { total: fmt(rAvatars), assigned: fmt(rUserAvatars) },
          notification:        { total: fmt(rNotifications) },
          sensitiveWord:       { total: fmt(rSensitive) },
          session:             { active: fmt(rSessions) }
        }
      })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ========== 菜单树 (权限过滤) ==========

  router.get('/api/v3/system/menus/simple', async (req, res) => {
    try {
      const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '')
      const session = sessions.get(token)

      let visibleMenuIds = null
      if (session && !session.roles.includes('R_SUPER')) {
        const perms = await dbQuery(
          'SELECT DISTINCT menu_id FROM role_permissions WHERE role_id IN (SELECT id FROM roles WHERE role_code IN (?))',
          [session.roles]
        )
        visibleMenuIds = new Set(perms.map(p => p.menu_id))
      }

      const rows = await dbQuery(
        `SELECT id, parent_id as parentId, name, path, component, redirect, title, icon,
                sort_order as sortOrder, is_hidden as isHidden, is_full_page as isFullPage,
                is_keep_alive as isKeepAlive, is_fixed_tab as isFixedTab, auth_list as authList,
                roles as menuRoles, enabled, create_time as createTime, update_time as updateTime
         FROM menus WHERE enabled=1 ORDER BY sort_order, id`
      )

      // Filter by role permissions (R_SUPER sees all)
      const filtered = visibleMenuIds
        ? rows.filter(r => visibleMenuIds.has(r.id))
        : rows

      const list = filtered.map(r => {
        try { r.authList = r.authList ? JSON.parse(r.authList) : null } catch { r.authList = null }
        try { r.menuRoles = r.menuRoles ? JSON.parse(r.menuRoles) : null } catch { r.menuRoles = null }
        return r
      })

      // Build tree (with cycle protection)
      const nodeMap = {}
      const tree = []
      for (const m of list) {
        nodeMap[m.id] = { ...m, children: [] }
      }
      for (const m of list) {
        const pid = Number(m.parentId)
        if (pid && pid !== m.id && nodeMap[pid]) {
          nodeMap[pid].children.push(nodeMap[m.id])
        } else {
          tree.push(nodeMap[m.id])
        }
      }

      // Convert to frontend format (max depth 50 to prevent stack overflow from cycles)
      function toRoute(node, basePath, depth = 0) {
        if (depth > 50) return null
        const meta = {
          title: node.title,
          icon: node.icon || undefined,
          isHide: !!node.isHidden,
          isFullPage: !!node.isFullPage,
          keepAlive: !!node.isKeepAlive,
          fixedTab: !!node.isFixedTab,
          roles: node.menuRoles || undefined,
          authList: node.authList || undefined
        }
        Object.keys(meta).forEach(k => meta[k] === undefined && delete meta[k])

        const route = {
          id: node.id,
          parentId: node.parentId || 0,
          name: node.name,
          path: node.path,
          component: node.component || undefined,
          redirect: node.redirect || undefined,
          sortOrder: node.sortOrder || 0,
          enabled: !!node.enabled,
          createTime: node.createTime || undefined,
          updateTime: node.updateTime || undefined,
          meta
        }

        route.children = node.children
          ? node.children.map(c => toRoute(c, node.path, depth + 1)).filter(Boolean)
          : []

        Object.keys(route).forEach(k => route[k] === undefined && delete route[k])
        return route
      }

      const menuTree = tree.map(t => toRoute(t, '/'))

      res.json({ code: 200, msg: 'success', data: menuTree })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

}

systemRoutes.sessions = sessions
systemRoutes.SESSION_TTL = SESSION_TTL
systemRoutes.authRequired = authRequired
systemRoutes.optionalAuth = optionalAuth

module.exports = systemRoutes
