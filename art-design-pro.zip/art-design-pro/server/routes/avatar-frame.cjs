const { query } = require('../database.cjs')
const { authRequired, sessions, SESSION_TTL } = require('./system.cjs')
const { logFromReq } = require('../middleware/security.cjs')

const multer = require('multer')
const path = require('path')
const fs = require('fs')

const uploadDir = path.join(__dirname, '..', 'uploads')
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true })

const frameUpload = multer({
  storage: multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, uploadDir),
    filename: (_req, file, cb) => {
      const ext = path.extname(file.originalname) || '.png'
      cb(null, 'frame-' + Date.now() + '-' + Math.round(Math.random() * 1e9) + ext)
    }
  }),
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    if (/\.(png|webp|svg|gif)$/i.test(path.extname(file.originalname))) {
      cb(null, true)
    } else {
      cb(new Error('仅支持 png/webp/svg/gif 格式'))
    }
  }
})

function initTables() {
  try {
    const autoInc = 'AUTO_INCREMENT'
    const nowDefault = 'DEFAULT NOW()'

    query(`CREATE TABLE IF NOT EXISTS avatar_frames (
      id INTEGER PRIMARY KEY ${autoInc},
      name VARCHAR(100) NOT NULL,
      image_url VARCHAR(500) DEFAULT '',
      thumbnail_url VARCHAR(500) DEFAULT '',
      description VARCHAR(500) DEFAULT '',
      obtain_type VARCHAR(20) DEFAULT 'manual',
      exp_level_required INTEGER DEFAULT 0,
      member_level_required INTEGER DEFAULT 0,
      sort_order INTEGER DEFAULT 0,
      status VARCHAR(2) DEFAULT '1',
      create_time DATETIME ${nowDefault},
      update_time DATETIME ${nowDefault}
    )`)
    query(`CREATE TABLE IF NOT EXISTS user_avatar_frames (
      id INTEGER PRIMARY KEY ${autoInc},
      user_id INTEGER NOT NULL,
      frame_id INTEGER NOT NULL,
      is_active TINYINT(1) DEFAULT 0,
      obtain_type VARCHAR(20) DEFAULT 'manual',
      obtain_time DATETIME ${nowDefault},
      UNIQUE(user_id, frame_id)
    )`)
    query("ALTER TABLE users ADD COLUMN IF NOT EXISTS active_frame_id INTEGER DEFAULT 0").catch(() => {})
    query("ALTER TABLE users ADD COLUMN IF NOT EXISTS active_frame_url VARCHAR(500) DEFAULT ''").catch(() => {})
  } catch (e) {
    console.error('avatar_frame initTables error:', e.message)
  }
}

initTables()

async function getUserId(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return 0
  const session = sessions.get(token)
  if (session) {
    if (Date.now() - session.createdAt > SESSION_TTL) { sessions.delete(token); return 0 }
    return Number(session.userId) || 0
  }
  try {
    const rows = await query('SELECT user_id, created_at FROM sessions WHERE token=?', [token])
    if (rows.length > 0) {
      const createdAt = typeof rows[0].created_at === 'number' ? rows[0].created_at : new Date(rows[0].created_at).getTime()
      if (Date.now() - createdAt > SESSION_TTL) { return 0 }
      return Number(rows[0].user_id) || 0
    }
  } catch {}
  return 0
}

async function isAdmin(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return false
  const session = sessions.get(token)
  if (session) { const roles = session.roles || []; return roles.includes('R_SUPER') || roles.includes('R_ADMIN') }
  try {
    const rows = await query('SELECT roles FROM sessions WHERE token=?', [token])
    if (rows.length > 0) { const roles = JSON.parse(rows[0].roles || '[]'); return roles.includes('R_SUPER') || roles.includes('R_ADMIN') }
  } catch {}
  return false
}

module.exports = function avatarFrameRoutes(app) {
  app.get('/api/avatar-frame/list', async (req, res) => {
    try {
      const list = await query("SELECT * FROM avatar_frames WHERE status='1' ORDER BY sort_order ASC")
      res.json({ code: 200, data: list })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.get('/api/avatar-frame/all', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const list = await query('SELECT * FROM avatar_frames ORDER BY sort_order ASC')
      res.json({ code: 200, data: list })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.post('/api/avatar-frame/save', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const { id, name, imageUrl, thumbnailUrl, description, obtainType, expLevelRequired, memberLevelRequired, sortOrder, status } = req.body
      if (id) {
        await query(
          `UPDATE avatar_frames SET name=?, image_url=?, thumbnail_url=?, description=?, obtain_type=?, exp_level_required=?, member_level_required=?, sort_order=?, status=?, update_time=NOW() WHERE id=?`,
          [name, imageUrl || '', thumbnailUrl || '', description || '', obtainType || 'manual', expLevelRequired || 0, memberLevelRequired || 0, sortOrder || 0, status || '1', id]
        )
        logFromReq(req, 'update', 'avatar_frame', id, `更新头像框"${name}"`)
      } else {
        const result = await query(
          `INSERT INTO avatar_frames (name, image_url, thumbnail_url, description, obtain_type, exp_level_required, member_level_required, sort_order, status) VALUES (?,?,?,?,?,?,?,?,?)`,
          [name, imageUrl || '', thumbnailUrl || '', description || '', obtainType || 'manual', expLevelRequired || 0, memberLevelRequired || 0, sortOrder || 0, status || '1']
        )
        logFromReq(req, 'create', 'avatar_frame', result.insertId || 0, `新增头像框"${name}"`)
      }
      res.json({ code: 200, message: '保存成功' })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.delete('/api/avatar-frame/:id', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const frameId = parseInt(req.params.id)
      await query('DELETE FROM user_avatar_frames WHERE frame_id=?', [frameId])
      await query("UPDATE users SET active_frame_id=0, active_frame_url='' WHERE active_frame_id=?", [frameId])
      await query('DELETE FROM avatar_frames WHERE id=?', [frameId])
      logFromReq(req, 'delete', 'avatar_frame', frameId, `删除头像框ID:${frameId}`)
      res.json({ code: 200, message: '删除成功' })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.post('/api/avatar-frame/upload', authRequired, frameUpload.single('file'), async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      if (!req.file) return res.json({ code: 400, message: '请选择文件' })
      const { resolveUploadPath } = require('./upload.cjs')
      const url = await resolveUploadPath(req.file, req, true)
      res.json({ code: 200, data: { url } })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.get('/api/user/avatar-frames', authRequired, async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, message: '请先登录' })

      const allFrames = await query("SELECT * FROM avatar_frames WHERE status='1' ORDER BY sort_order ASC")
      const userFrameRows = await query('SELECT frame_id, obtain_type, obtain_time FROM user_avatar_frames WHERE user_id=?', [userId])
      const userFrameMap = {}
      for (const r of userFrameRows) {
        userFrameMap[r.frame_id] = { obtainType: r.obtain_type, obtainTime: r.obtain_time }
      }

      const userData = await query('SELECT active_frame_id FROM users WHERE id=?', [userId])
      const activeFrameId = userData.length > 0 ? (userData[0].active_frame_id || 0) : 0

      const frames = allFrames.map(f => ({
        ...f,
        owned: !!userFrameMap[f.id],
        obtainType: userFrameMap[f.id]?.obtainType || null,
        obtainTime: userFrameMap[f.id]?.obtainTime || null,
        isActive: f.id === activeFrameId
      }))

      res.json({ code: 200, data: { frames, activeFrameId } })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.post('/api/user/active-frame', authRequired, async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, message: '请先登录' })
      const { frameId } = req.body

      if (frameId > 0) {
        const owned = await query('SELECT id FROM user_avatar_frames WHERE user_id=? AND frame_id=?', [userId, frameId])
        if (owned.length === 0) return res.json({ code: 400, message: '您尚未获得该头像框' })
        const frame = await query('SELECT image_url FROM avatar_frames WHERE id=?', [frameId])
        const frameUrl = frame.length > 0 ? frame[0].image_url : ''
        await query('UPDATE user_avatar_frames SET is_active=0 WHERE user_id=?', [userId])
        await query('UPDATE user_avatar_frames SET is_active=1 WHERE user_id=? AND frame_id=?', [userId, frameId])
        await query('UPDATE users SET active_frame_id=?, active_frame_url=? WHERE id=?', [frameId, frameUrl, userId])
      } else {
        await query('UPDATE user_avatar_frames SET is_active=0 WHERE user_id=?', [userId])
        await query("UPDATE users SET active_frame_id=0, active_frame_url='' WHERE id=?", [userId])
      }
      res.json({ code: 200, message: '设置成功' })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.post('/api/user/grant-frame', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const { userId, frameId } = req.body
      const existing = await query('SELECT id FROM user_avatar_frames WHERE user_id=? AND frame_id=?', [userId, frameId])
      if (existing.length === 0) {
        await query('INSERT INTO user_avatar_frames (user_id, frame_id, obtain_type) VALUES (?,?,?)', [userId, frameId, 'manual'])
      }
      logFromReq(req, 'update', 'avatar_frame', frameId, `授予用户${userId}头像框ID:${frameId}`)
      res.json({ code: 200, message: '授予成功' })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.delete('/api/user/revoke-frame/:frameId', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const userId = parseInt(req.query.userId) || 0
      const frameId = parseInt(req.params.frameId)
      await query('DELETE FROM user_avatar_frames WHERE user_id=? AND frame_id=?', [userId, frameId])
      await query("UPDATE users SET active_frame_id=0, active_frame_url='' WHERE id=? AND active_frame_id=?", [userId, frameId])
      logFromReq(req, 'delete', 'avatar_frame', frameId, `撤销用户${userId}头像框ID:${frameId}`)
      res.json({ code: 200, message: '撤销成功' })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.post('/api/avatar-frame/auto-grant', authRequired, async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, message: '请先登录' })

      const user = await query('SELECT experience, level_id FROM users WHERE id=?', [userId])
      if (user.length === 0) return res.json({ code: 400, message: '用户不存在' })
      const userExp = user[0].experience || 0
      const userLevelId = user[0].level_id || 0

      const frames = await query("SELECT * FROM avatar_frames WHERE status='1'")
      const userFrames = await query('SELECT frame_id FROM user_avatar_frames WHERE user_id=?', [userId])
      const ownedIds = new Set(userFrames.map(r => r.frame_id))

      const expLevels = await query('SELECT id, level, exp_required FROM experience_levels ORDER BY exp_required ASC')
      const currentExpLevel = expLevels.filter(l => (l.exp_required || 0) <= userExp).sort((a, b) => b.exp_required - a.exp_required)[0]
      const expLevelId = currentExpLevel ? currentExpLevel.id : 0

      let granted = []
      for (const f of frames) {
        if (ownedIds.has(f.id)) continue
        let shouldGrant = false
        if (f.obtain_type === 'experience') {
          const expRows = await query('SELECT id FROM experience_levels WHERE id=?', [f.exp_level_required || 0])
          if (expRows.length > 0) {
            const expReq = expRows[0].exp_required || 0
            if (userExp >= expReq) shouldGrant = true
          }
        } else if (f.obtain_type === 'membership') {
          if (f.member_level_required > 0 && userLevelId >= f.member_level_required) shouldGrant = true
        }
        if (shouldGrant) {
          await query('INSERT INTO user_avatar_frames (user_id, frame_id, obtain_type) VALUES (?,?,?)', [userId, f.id, f.obtain_type])
          granted.push(f)
        }
      }

      res.json({ code: 200, message: granted.length > 0 ? `自动获得 ${granted.length} 个头像框` : '无可获取的头像框', data: { granted } })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.get('/api/avatar-frame/:id/users', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const frameId = parseInt(req.params.id)
      const list = await query(
        `SELECT u.id, u.username, u.nickname, u.avatar, u.level_name as levelName,
                uf.obtain_time as obtainTime, uf.obtain_type as obtainType
         FROM user_avatar_frames uf JOIN users u ON uf.user_id = u.id
         WHERE uf.frame_id = ? ORDER BY uf.obtain_time DESC`, [frameId]
      )
      res.json({ code: 200, data: list })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })
}
