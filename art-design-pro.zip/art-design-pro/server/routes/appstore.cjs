const { query, dbType } = require('../database.cjs')
const nowExpr = dbType === 'mysql' ? 'NOW()' : "datetime('now','localtime')"
const randFn = dbType === 'mysql' ? 'RAND()' : 'RANDOM()'

function appStoreRoutes(router) {

  // GET /api/app/list — 应用列表
  router.get('/api/app/list', async (req, res) => {
    try {
      const { keyword, category, status, page = 1, pageSize = 20 } = req.query
      let sql = `SELECT id, name, package_name as packageName, version, version_code as versionCode,
                icon, icon_bg_color as iconBgColor, size_mb as sizeMb, downloads, rating,
                categories,
                description, update_content as updateContent, screenshots, tags, official_tags as officialTags,
                has_ads as hasAds, requires_network as requiresNetwork, has_paid_content as hasPaidContent, is_free as isFree,
                download_url as downloadUrl,
                coin_count as coinCount, coin_people as coinPeople, developer, category,
                price_type as priceType, price_amount as priceAmount,
                category_id as categoryId, is_pinned as isPinned, user_id as userId,
                status, create_time as createTime, update_time as updateTime
               FROM app_store WHERE 1=1`
      const params = []

      if (keyword) {
        sql += ' AND (name LIKE ? OR package_name LIKE ?)'
        params.push(`%${keyword}%`, `%${keyword}%`)
      }
      if (category) { sql += ' AND category=?'; params.push(category) }
      if (status !== undefined && status !== '') { sql += ' AND status=?'; params.push(status) }

      const offset = (parseInt(page) - 1) * parseInt(pageSize)
      const countResult = await query(`SELECT COUNT(*) as total FROM (${sql}) t`, params)
      const total = countResult[0]?.total || 0

      const list = await query(sql + ` ORDER BY is_pinned DESC, id DESC LIMIT ${parseInt(pageSize)} OFFSET ${offset}`, params)
      for (const item of list) {
        try { item.screenshots = item.screenshots ? JSON.parse(item.screenshots) : [] } catch { item.screenshots = [] }
        try { item.tags = item.tags ? JSON.parse(item.tags) : [] } catch { item.tags = [] }
        try { item.officialTags = item.officialTags ? JSON.parse(item.officialTags) : [] } catch { item.officialTags = [] }
      }
      res.json({ code: 200, msg: 'success', data: { list, total, page: parseInt(page), pageSize: parseInt(pageSize) } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // POST /api/app/save — 添加/更新应用
  router.post('/api/app/save', async (req, res) => {
    try {
      const { id, name, packageName, version, versionCode, icon, iconBgColor, sizeMb,
              downloadUrl, downloads, rating, description, updateContent, screenshots, tags,
              officialTags, hasAds, requiresNetwork, hasPaidContent, isFree,
              price_type, price_amount,
              coinCount, coinPeople, developer, category, categoryId, categories, isPinned, status, userId } = req.body

      const ss = screenshots ? JSON.stringify(screenshots) : '[]'
      const tg = tags ? JSON.stringify(tags) : '[]'
      const ot = officialTags ? JSON.stringify(officialTags) : '[]'

      if (id) {
        const original = await query('SELECT user_id, status FROM app_store WHERE id=?', [id])
        const isOwnerEdit = original.length > 0 && Number(userId) > 0 && Number(userId) === original[0].user_id
        const finalStatus = isOwnerEdit ? '0' : (status || '1')
         await query(
            `UPDATE app_store SET name=?, package_name=?, version=?, version_code=?, icon=?,
             icon_bg_color=?, size_mb=?, downloads=?, rating=?, description=?, update_content=?,
             screenshots=?, tags=?, official_tags=?, has_ads=?, requires_network=?, has_paid_content=?, is_free=?,
             price_type=?, price_amount=?,
             download_url=?, coin_count=?, coin_people=?, developer=?, category=?,
             categories=?, category_id=?, is_pinned=?, status=?, user_id=?, update_time=${nowExpr} WHERE id=?`,
            [name || '', packageName || '', version || '1.0.0', versionCode || '100', icon || '', iconBgColor || '#00BFA5',
             sizeMb || 0, downloads || 0, rating || 0, description || '', updateContent || '',
             ss, tg, ot, hasAds ? 1 : 0, requiresNetwork ? 1 : 0, hasPaidContent ? 1 : 0, isFree ? 1 : 0,
             price_type || 'free', Number(price_amount) || 0,
             downloadUrl || '', coinCount || 0, coinPeople || 0, developer || '', category || '工具',
             categories || '', Number(categoryId) || 0, isPinned ? 1 : 0, finalStatus, Number(userId) || 0, id]
        )
        const msg = isOwnerEdit ? '更新成功，需等待重新审核' : '更新成功'
        res.json({ code: 200, msg, data: { id } })
      } else {
        const result = await query(
           `INSERT INTO app_store (name, package_name, version, version_code, icon, icon_bg_color,
            size_mb, downloads, rating, description, update_content, screenshots, tags, official_tags,
            has_ads, requires_network, has_paid_content, is_free,
            price_type, price_amount,
            download_url, coin_count, coin_people, developer, category, categories, category_id, is_pinned, status, user_id)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
           [name, packageName || '', version || '1.0.0', versionCode || '100', icon || '', iconBgColor || '#00BFA5',
            sizeMb || 0, downloads || 0, rating || 0, description || '', updateContent || '',
            ss, tg, ot, hasAds ? 1 : 0, requiresNetwork ? 1 : 0, hasPaidContent ? 1 : 0, isFree ? 1 : 0,
            price_type || 'free', Number(price_amount) || 0,
            downloadUrl || '', coinCount || 0, coinPeople || 0, developer || '', category || '工具',
            categories || '', Number(categoryId) || 0, isPinned ? 1 : 0, status || '1', Number(userId) || 0]
        )
        res.json({ code: 200, msg: '新增成功', data: { id: result.lastInsertRowid || result.insertId } })
      }
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // DELETE /api/app/:id — 删除应用
  router.delete('/api/app/:id', async (req, res) => {
    try {
      await query('DELETE FROM app_versions WHERE app_id=?', [req.params.id])
      await query('DELETE FROM app_comments WHERE app_id=?', [req.params.id])
      await query('DELETE FROM app_tips WHERE app_id=?', [req.params.id])
      await query('DELETE FROM app_store WHERE id=?', [req.params.id])
      res.json({ code: 200, msg: '删除成功', data: { success: true } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // GET /api/app/:id/detail — 应用详情页数据
  router.get('/api/app/:id/detail', async (req, res) => {
    try {
      const app = await query(
        `SELECT id, name, package_name as packageName, category, version, version_code as versionCode,
                size_mb as sizeMb, icon, icon_bg_color as iconBgColor, screenshots, tags, official_tags as officialTags,
                developer, description, downloads, rating, coin_count as coinCount, coin_people as coinPeople,
                has_ads as hasAds, requires_network as requiresNetwork, has_paid_content as hasPaidContent, is_free as isFree,
                price_type as priceType, price_amount as priceAmount, download_url as downloadUrl,
                user_id as userId, status, update_time as updateTime
         FROM app_store WHERE id=?`, [req.params.id]
      )
      if (!app || app.length === 0) {
        return res.json({ code: 404, msg: '应用不存在' })
      }
      const item = app[0]
      try { item.screenshots = item.screenshots ? JSON.parse(item.screenshots) : [] } catch { item.screenshots = [] }
      try { item.tags = item.tags ? JSON.parse(item.tags) : [] } catch { item.tags = [] }
      try { item.officialTags = item.officialTags ? JSON.parse(item.officialTags) : [] } catch { item.officialTags = [] }

      const comments = await query(
        `SELECT id, app_id as appId, parent_id as parentId, user_id as userId, user_name as userName, user_avatar as userAvatar,
                device, version, content, likes, replies, reported, is_pinned as isPinned, rating, create_time as createTime
         FROM app_comments WHERE app_id=? AND parent_id=0 ORDER BY is_pinned DESC, create_time DESC`, [req.params.id]
      )
      // 查所有回复
      const allReplies = await query(
        `SELECT id, app_id as appId, parent_id as parentId, user_id as userId, user_name as userName, user_avatar as userAvatar,
                content, likes, replies, reported, is_pinned as isPinned, rating, create_time as createTime
         FROM app_comments WHERE app_id=? AND parent_id>0 ORDER BY create_time ASC`, [req.params.id]
      )
      const replyMap = {}
      for (const r of allReplies) {
        if (!replyMap[r.parentId]) replyMap[r.parentId] = []
        replyMap[r.parentId].push(r)
      }

      const versions = await query(
        `SELECT id, app_id as appId, version, version_code as versionCode, size_mb as sizeMb,
                downloads, rating, update_content as updateContent, tags, official_tags as officialTags,
                has_ads as hasAds, requires_network as requiresNetwork, has_paid_content as hasPaidContent, is_free as isFree,
                download_url as downloadUrl,
                is_current as isCurrent,
                user_id as userId, user_name as userName, create_time as createTime,
                description, screenshots
          FROM app_versions WHERE app_id=? ORDER BY create_time DESC`, [req.params.id]
      )
      for (const v of versions) {
        try { v.tags = v.tags ? JSON.parse(v.tags) : [] } catch { v.tags = [] }
        try { v.screenshots = v.screenshots ? JSON.parse(v.screenshots) : [] } catch { v.screenshots = [] }
        try { v.officialTags = v.officialTags ? JSON.parse(v.officialTags) : [] } catch { v.officialTags = [] }
      }

      const rated = comments.filter(c => Number(c.rating) > 0)
      const ratingStats = {
        total: rated.length,
        average: rated.length > 0 ? Math.round(rated.reduce((s, c) => s + Number(c.rating), 0) / rated.length * 10) / 10 : 0,
        distribution: { 5: 0, 4: 0, 3: 0, 2: 0, 1: 0 }
      }
      comments.forEach(c => {
        const star = Math.round(c.rating || 0)
        if (star >= 1 && star <= 5) ratingStats.distribution[star]++
      })

      // 有登录态时查点赞状态
      let likedIds = new Set()
      if (req.query.userId && comments.length > 0) {
        try {
          const likes = await query(
            `SELECT comment_id FROM comment_likes WHERE user_id=? AND comment_id IN (${comments.map(() => '?').join(',')})`,
            [Number(req.query.userId), ...comments.map(c => c.id)]
          )
          likedIds = new Set(likes.map(l => l.comment_id))
        } catch {}
      }
      for (const c of comments) {
        c.isLiked = likedIds.has(c.id)
        c.likeCount = Number(c.likes) || 0
        c.replies = replyMap[c.id] || []
        for (const r of c.replies) {
          r.isLiked = likedIds.has(r.id)
          r.likeCount = Number(r.likes) || 0
        }
      }

      // 查询评论者的购买信息
      const allCommentUserIds = [...new Set([
        ...comments.map(c => c.userId),
        ...allReplies.map(r => r.userId)
      ].filter(Boolean))]
      const purchaseMap = {}
      if (allCommentUserIds.length > 0) {
        try {
          const purchases = await query(
            `SELECT user_id, price_type FROM app_purchases WHERE app_id=? AND user_id IN (${allCommentUserIds.map(() => '?').join(',')})`,
            [Number(req.params.id), ...allCommentUserIds]
          )
          for (const p of purchases) {
            purchaseMap[p.user_id] = p.price_type || 'free'
          }
        } catch {}
      }
      for (const c of comments) {
        if (purchaseMap[c.userId]) {
          c.purchased = true
          c.purchaseType = purchaseMap[c.userId]
        }
        for (const r of (c.replies || [])) {
          if (purchaseMap[r.userId]) {
            r.purchased = true
            r.purchaseType = purchaseMap[r.userId]
          }
        }
      }

      const tips = await query(
        `SELECT id, user_id as userId, user_name as userName, amount, tip_type as tipType, message, create_time as createTime
         FROM app_tips WHERE app_id=? ORDER BY id DESC LIMIT 20`, [req.params.id]
      )

      const coinStats = await query(
        `SELECT COUNT(DISTINCT user_id) as people, SUM(amount) as total
         FROM app_tips WHERE app_id=?`, [req.params.id]
      )
      item.coinCount = Number(coinStats[0]?.total || 0)
      item.coinPeople = Number(coinStats[0]?.people || 0)

      res.json({ code: 200, msg: 'success', data: { app: item, comments, versions, tips, ratingStats } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // POST /api/app/:id/comment — 添加评论 (任何用户)
  // 限制: 每用户每应用只能评分一次, 两次评论间隔 >= 30 秒
  router.post('/api/app/:id/comment', async (req, res) => {
    try {
      const { userId, userName, device, version, content, rating } = req.body
      const uid = Number(userId) || 0

      // 30秒限流
      if (uid > 0) {
        const last = await query(
          'SELECT create_time FROM app_comments WHERE user_id=? ORDER BY id DESC LIMIT 1', [uid]
        )
        if (last.length > 0) {
          const elapsed = (Date.now() - new Date(last[0].create_time).getTime()) / 1000
          if (elapsed < 30) {
            return res.json({ code: 429, msg: `请${Math.ceil(30 - elapsed)}秒后再发表评论` })
          }
        }
      }

      // 同一用户同一应用只能评分一次, 已评过分则忽略新评分
      let finalRating = Number(rating) || 0
      if (uid > 0 && finalRating > 0) {
        const exists = await query(
          'SELECT id FROM app_comments WHERE app_id=? AND user_id=? AND rating > 0 LIMIT 1',
          [req.params.id, uid]
        )
        if (exists.length > 0) finalRating = 0
      }

      const colors = ['#FF5777', '#448AFF', '#FFB74D', '#66BB6A', '#AB47BC', '#26C6DA']
      const avatar = colors[Math.floor(Math.random() * colors.length)]
      await query(
        `INSERT INTO app_comments (app_id, user_id, user_name, user_avatar, device, version, content, rating)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        [req.params.id, uid, userName || '匿名用户', avatar, device || '', version || '', content || '', finalRating]
      )

      // 通知应用作者收到评论
      if (uid > 0 && content) {
        const app = await query('SELECT name, user_id FROM app_store WHERE id=?', [req.params.id])
        if (app && app.length > 0 && app[0].user_id && Number(app[0].user_id) !== uid) {
          const preview = content.length > 30 ? content.substring(0, 30) + '...' : content
          await query(
            `INSERT INTO sys_notifications (title, content, type, target_user_id)
             VALUES (?, ?, 'comment', ?)`,
            ['新评论', `${userName || '匿名用户'} 评论了您的应用《${app[0].name}》: ${preview}`, app[0].user_id]
          )
        }
      }

      // 更新 app_store 评分统计
      const stat = await query(
        'SELECT COUNT(*) as cnt, AVG(rating) as avg FROM app_comments WHERE app_id=? AND rating > 0',
        [req.params.id]
      )
      if (stat.length > 0) {
        await query('UPDATE app_store SET rating=? WHERE id=?', [
          Math.round((Number(stat[0].avg) || 0) * 10) / 10, req.params.id
        ])
      }

      res.json({ code: 200, msg: '评论成功' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // POST /api/app/:id/comment/:cid/like — 点赞/取消
  router.post('/api/app/:id/comment/:cid/like', async (req, res) => {
    try {
      const { userId } = req.body
      const cid = Number(req.params.cid)
      const uid = Number(userId)
      const existing = await query('SELECT id FROM comment_likes WHERE comment_id=? AND user_id=?', [cid, uid])
      if (existing.length > 0) {
        await query('DELETE FROM comment_likes WHERE id=?', [existing[0].id])
        await query('UPDATE app_comments SET likes=GREATEST(likes-1,0) WHERE id=?', [cid])
        res.json({ code: 200, msg: '已取消', data: { liked: false } })
      } else {
        await query('INSERT INTO comment_likes (comment_id, user_id) VALUES (?,?)', [cid, uid])
        await query('UPDATE app_comments SET likes=likes+1 WHERE id=?', [cid])
        res.json({ code: 200, msg: '已点赞', data: { liked: true } })
      }
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // DELETE /api/app/:id/comment/:cid — 删除评论
  router.delete('/api/app/:id/comment/:cid', async (req, res) => {
    try {
      const cid = Number(req.params.cid)
      const { userId } = req.query
      const comment = await query('SELECT user_id FROM app_comments WHERE id=?', [cid])
      if (comment.length === 0) return res.json({ code: 404, msg: '评论不存在' })
      // 仅自己的评论可删 (后续可扩展管理员)
      if (Number(comment[0].user_id) !== Number(userId)) {
        return res.json({ code: 403, msg: '只能删除自己的评论' })
      }
      await query('DELETE FROM comment_likes WHERE comment_id=?', [cid])
      await query('DELETE FROM app_comments WHERE id=?', [cid])
      res.json({ code: 200, msg: '删除成功', data: {} })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // POST /api/app/:id/comment/:cid/reply — 回复评论
  router.post('/api/app/:id/comment/:cid/reply', async (req, res) => {
    try {
      const { userId, userName, content } = req.body
      const cid = Number(req.params.cid)
      const colors = ['#FF5777', '#448AFF', '#FFB74D', '#66BB6A', '#AB47BC', '#26C6DA']
      const avatar = colors[Math.floor(Math.random() * colors.length)]
      await query(
        `INSERT INTO app_comments (app_id, parent_id, user_id, user_name, user_avatar, content, rating)
         VALUES (?, ?, ?, ?, ?, ?, 0)`,
        [Number(req.params.id), cid, Number(userId) || 0, userName || '匿名', avatar, content || '']
      )
      await query('UPDATE app_comments SET replies=replies+1 WHERE id=?', [cid])
      res.json({ code: 200, msg: '回复成功', data: {} })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // POST /api/app/:id/comment/:cid/pin — 置顶(最多3条)
  router.post('/api/app/:id/comment/:cid/pin', async (req, res) => {
    try {
      const cid = Number(req.params.cid)
      const { userId } = req.body
      // 权限检查: 仅超级管理员/管理员或应用上传者
      const appInfo = await query('SELECT id, user_id as userId, developer FROM app_store WHERE id=?', [Number(req.params.id)])
      const appOwnerId = Number(appInfo[0]?.userId || 0)
      const appDev = appInfo[0]?.developer || ''

      // 先通过session查角色, 简单版: 允许所有登录用户(后续可在前端限制)
      const pinned = await query('SELECT COUNT(*) as cnt FROM app_comments WHERE app_id=? AND is_pinned=1', [Number(req.params.id)])
      const comment = await query('SELECT is_pinned FROM app_comments WHERE id=?', [cid])
      if (comment.length === 0) return res.json({ code: 404, msg: '评论不存在' })
      const wasPinned = Number(comment[0].is_pinned)
      if (wasPinned) {
        await query('UPDATE app_comments SET is_pinned=0 WHERE id=?', [cid])
        res.json({ code: 200, msg: '已取消置顶', data: { pinned: false } })
      } else {
        if (Number(pinned[0].cnt) >= 3) return res.json({ code: 400, msg: '最多置顶3条评论' })
        await query('UPDATE app_comments SET is_pinned=1 WHERE id=?', [cid])
        res.json({ code: 200, msg: '已置顶', data: { pinned: true } })
      }
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ========== 版本管理 ==========

  // GET /api/app/:id/versions — 版本列表
  router.get('/api/app/:id/versions', async (req, res) => {
    try {
      const list = await query(
        `SELECT id, app_id as appId, version, version_code as versionCode, size_mb as sizeMb,
                downloads, rating, update_content as updateContent, tags, official_tags as officialTags,
                has_ads as hasAds, requires_network as requiresNetwork, has_paid_content as hasPaidContent, is_free as isFree,
                download_url as downloadUrl,
                is_current as isCurrent,
                user_id as userId, user_name as userName, create_time as createTime,
                description, screenshots
         FROM app_versions WHERE app_id=? ORDER BY create_time DESC`, [req.params.id]
      )
      for (const v of list) {
        try { v.tags = v.tags ? JSON.parse(v.tags) : [] } catch { v.tags = [] }
        try { v.screenshots = v.screenshots ? JSON.parse(v.screenshots) : [] } catch { v.screenshots = [] }
        try { v.officialTags = v.officialTags ? JSON.parse(v.officialTags) : [] } catch { v.officialTags = [] }
      }
      res.json({ code: 200, msg: 'success', data: list })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // POST /api/app/version/save — 添加/更新版本 (任何用户)
  router.post('/api/app/version/save', async (req, res) => {
    try {
      const { id, appId, version, versionCode, sizeMb, downloads, rating,
              downloadUrl, updateContent, tags, officialTags, hasAds, requiresNetwork, hasPaidContent, isFree, isCurrent, userId, userName } = req.body
      const tg = tags ? JSON.stringify(tags) : '[]'
      const ot = officialTags ? JSON.stringify(officialTags) : '[]'

      if (id) {
        if (isCurrent) {
          await query('UPDATE app_versions SET is_current=0 WHERE app_id=(SELECT app_id FROM app_versions WHERE id=?)', [id])
        }
        await query(
          `UPDATE app_versions SET version=?, version_code=?, size_mb=?, downloads=?, rating=?,
           download_url=?, update_content=?, tags=?, official_tags=?, has_ads=?, requires_network=?, has_paid_content=?, is_free=?, is_current=?, user_name=? WHERE id=?`,
          [version, versionCode || '', sizeMb || 0, downloads || 0, rating || 0,
           downloadUrl || '', updateContent || '', tg, ot,
           hasAds ? 1 : 0, requiresNetwork ? 1 : 0, hasPaidContent ? 1 : 0, isFree ? 1 : 0,
           isCurrent ? 1 : 0, userName || '', id]
        )
        res.json({ code: 200, msg: '版本更新成功', data: { id } })
      } else {
        // 如果设为当前版本，取消同应用的其它当前版本
        if (isCurrent) {
          await query('UPDATE app_versions SET is_current=0 WHERE app_id=?', [appId])
        }
        const result = await query(
          `INSERT INTO app_versions (app_id, version, version_code, size_mb, downloads, rating,
           download_url, update_content, tags, official_tags, has_ads, requires_network, has_paid_content, is_free, is_current, user_id, user_name)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
          [appId, version, versionCode || '', sizeMb || 0, downloads || 0, rating || 0,
           downloadUrl || '', updateContent || '', tg, ot,
           hasAds ? 1 : 0, requiresNetwork ? 1 : 0, hasPaidContent ? 1 : 0, isFree ? 1 : 0,
           isCurrent ? 1 : 0, userId || 0, userName || '']
        )
        // 同步更新 app_store 版本号
        if (isCurrent) {
          await query('UPDATE app_store SET version=?, version_code=?, size_mb=? WHERE id=?',
            [version, versionCode || '', sizeMb || 0, appId])
        }
        res.json({ code: 200, msg: '版本新增成功', data: { id: result.lastInsertRowid || result.insertId } })
      }
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // DELETE /api/app/version/:id — 删除版本
  router.delete('/api/app/version/:id', async (req, res) => {
    try {
      await query('DELETE FROM app_versions WHERE id=?', [req.params.id])
      res.json({ code: 200, msg: '版本删除成功', data: { success: true } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ========== 用户上传 ==========

  // POST /api/app/upload — 用户上传应用
  router.post('/api/app/upload', async (req, res) => {
    try {
      const { userId, userName, name, packageName, category, description, icon, price_type, price_amount } = req.body
      const result = await query(
        `INSERT INTO app_uploads (user_id, user_name, name, package_name, category, description, icon, status, price_type, price_amount)
         VALUES (?, ?, ?, ?, ?, ?, ?, '0', ?, ?)`,
        [userId || 0, userName || '', name, packageName || '', category || '工具', description || '', icon || '', price_type || 'free', Number(price_amount || 0)]
      )
      // 同时创建 app_store 待审核记录
      await query(
        `INSERT INTO app_store (name, package_name, version, version_code, icon, icon_bg_color, size_mb, description, category, status, price_type, price_amount)
         VALUES (?, ?, '1.0.0', '100', ?, '#00BFA5', 0, ?, ?, '0', ?, ?)`,
        [name, packageName || '', icon || '', description || '', category || '工具', price_type || 'free', Number(price_amount || 0)]
      )
      res.json({ code: 200, msg: '上传成功，等待审核', data: { id: result.lastInsertRowid || result.insertId } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // GET /api/app/uploads — 用户上传列表
  router.get('/api/app/uploads', async (req, res) => {
    try {
      const { userId } = req.query
      let sql = `SELECT id, app_id as appId, user_id as userId, user_name as userName,
                  name, package_name as packageName, category, description, icon,
                  status, create_time as createTime, update_time as updateTime
                 FROM app_uploads WHERE 1=1`
      const params = []
      if (userId) { sql += ' AND user_id=?'; params.push(userId) }
      const list = await query(sql + ' ORDER BY id DESC', params)
      res.json({ code: 200, msg: 'success', data: list })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // GET /api/app/recommend — 随便看看推荐
  router.get('/api/app/recommend', async (req, res) => {
    try {
      const list = await query(
        `SELECT id, name, icon_bg_color as iconBgColor, downloads, icon
         FROM app_store WHERE status='1' ORDER BY ${randFn} LIMIT 6`
      )
      res.json({ code: 200, msg: 'success', data: list })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ========== 应用分类管理 ==========

  // GET /api/category/list
  router.get('/api/category/list', async (req, res) => {
    try {
      const list = await query(
        `SELECT id, name, icon, sort_order as sortOrder, status, create_time as createTime
         FROM app_categories ORDER BY sort_order ASC, id ASC`
      )
      res.json({ code: 200, msg: 'success', data: list })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // POST /api/category/save
  router.post('/api/category/save', async (req, res) => {
    try {
      const { id, name, icon, sortOrder, status } = req.body
      if (id) {
        await query(
          `UPDATE app_categories SET name=?, icon=?, sort_order=?, status=? WHERE id=?`,
          [name, icon || '', Number(sortOrder) || 0, status || '1', Number(id)]
        )
        res.json({ code: 200, msg: '更新成功', data: { id: Number(id) } })
      } else {
        const result = await query(
          `INSERT INTO app_categories (name, icon, sort_order, status) VALUES (?, ?, ?, ?)`,
          [name, icon || '', Number(sortOrder) || 0, status || '1']
        )
        res.json({ code: 200, msg: '新增成功', data: { id: result.lastInsertRowid || result.insertId } })
      }
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // DELETE /api/category/:id
  router.delete('/api/category/:id', async (req, res) => {
    try {
      await query('DELETE FROM app_categories WHERE id=?', [Number(req.params.id)])
      res.json({ code: 200, msg: '删除成功', data: { success: true } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ========== 投币打赏 ==========

  // POST /api/app/:id/tip — 用户打赏（需登录，支持余额/积分）
  router.post('/api/app/:id/tip', async (req, res) => {
    try {
      const { userId, userName, amount, message, tipType = 'balance' } = req.body
      const appId = Number(req.params.id)
      const tipAmount = Number(amount) || 0

      if (tipAmount <= 0) return res.json({ code: 400, msg: '打赏金额必须大于0' })

      // 检查是否给自己打赏：用 user_id (如果应用关联了用户) 或 developer 字段匹配
      const appInfo = await query('SELECT id, name, user_id as userId, developer FROM app_store WHERE id=?', [appId])
      if (!appInfo || appInfo.length === 0) return res.json({ code: 404, msg: '应用不存在' })
      const appOwnerId = Number(appInfo[0].userId || 0)
      const appDev = (appInfo[0].developer || '').trim()
      const tipUserName = (userName || user?.username || '').trim()

      const isSelf = appOwnerId > 0
        ? appOwnerId === Number(userId)
        : appDev && tipUserName && appDev === tipUserName

      if (isSelf) return res.json({ code: 400, msg: '不能给自己打赏' })

      const users = await query('SELECT id, username, balance, points FROM users WHERE id=?', [Number(userId)])
      if (!users || users.length === 0) return res.json({ code: 404, msg: '用户不存在' })

      const user = users[0]

      // 扣除打赏者余额/积分
      let newBalance = Number(user.balance)
      let newPoints = Number(user.points || 0)
      if (tipType === 'balance') {
        if (Number(user.balance) < tipAmount) return res.json({ code: 400, msg: '余额不足' })
        newBalance = Number(user.balance) - tipAmount
        await query(`UPDATE users SET balance=?, update_time=${nowExpr} WHERE id=?`, [newBalance, Number(userId)])
      } else {
        if (Number(user.points || 0) < tipAmount) return res.json({ code: 400, msg: '积分不足' })
        newPoints = Number(user.points || 0) - tipAmount
        await query(`UPDATE users SET points=?, update_time=${nowExpr} WHERE id=?`, [newPoints, Number(userId)])
      }

      // 给应用拥有者增加余额/积分
      let ownerId = Number(appInfo[0].userId || 0)
      if (ownerId === 0 && appInfo[0].developer) {
        const ownerRow = await query('SELECT id FROM users WHERE username=? LIMIT 1', [appInfo[0].developer])
        if (ownerRow && ownerRow.length > 0) ownerId = Number(ownerRow[0].id)
      }
      if (ownerId > 0 && ownerId !== Number(userId)) {
        if (tipType === 'balance') {
          await query(`UPDATE users SET balance=balance+?, update_time=${nowExpr} WHERE id=?`, [tipAmount, ownerId])
        } else {
          await query(`UPDATE users SET points=points+?, update_time=${nowExpr} WHERE id=?`, [tipAmount, ownerId])
        }
      }

      await query(
        `INSERT INTO app_tips (app_id, user_id, user_name, amount, tip_type, message) VALUES (?, ?, ?, ?, ?, ?)`,
        [appId, Number(userId), userName || user.username, tipAmount, tipType, message || '']
      )
      await query('UPDATE app_store SET coin_count=coin_count+?, coin_people=coin_people+1 WHERE id=?', [tipAmount, appId])

      const trimmedMsg = (message || '').trim()
      const commentContent = trimmedMsg
        ? `[打赏${tipAmount}${tipType === 'balance' ? '元' : '积分'}] ${trimmedMsg}`
        : `[打赏${tipAmount}${tipType === 'balance' ? '元' : '积分'}]`
      await query(
        `INSERT INTO app_comments (app_id, user_id, user_name, user_avatar, content, rating)
         VALUES (?, ?, ?, '#00BFA5', ?, 0)`,
        [appId, Number(userId), userName || user.username, commentContent]
      )

      // 通知应用作者收到打赏
      if (ownerId > 0) {
        const unit = tipType === 'balance' ? '元' : '积分'
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id)
           VALUES (?, ?, 'system', ?)`,
          ['收到打赏', `${userName || user.username} 给您的应用《${appInfo[0].name || ''}》打赏了 ${tipAmount}${unit}`, ownerId]
        )
      }

      res.json({ code: 200, msg: '打赏成功', data: { tipType, amount: tipAmount, newBalance, newPoints } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // POST /api/app/:id/purchase — 购买应用
  router.post('/api/app/:id/purchase', async (req, res) => {
    const appId = Number(req.params.id)
    const { userId: rawUserId, priceType } = req.body
    const userId = Number(rawUserId || 0)
    if (!userId || userId <= 0) return res.json({ code: 401, msg: '请先登录' })
    try {
      const app = await query('SELECT * FROM app_store WHERE id=?', [appId])
      if (!app.length) return res.json({ code: 404, msg: '应用不存在' })
      const info = app[0]

      // 上传者自己免费下载
      if (info.user_id > 0 && Number(info.user_id) === userId) {
        return res.json({ code: 200, msg: '您是该应用的上传者，可免费下载', data: { isOwner: true, alreadyPurchased: false, paidPrice: 0 } })
      }

      const price_type = priceType || info.price_type || 'free'
      const price_amount = Number(info.price_amount || 0)

      // 检查是否已购买
      const bought = await query('SELECT id FROM app_purchases WHERE app_id=? AND user_id=?', [appId, userId])
      if (bought.length) return res.json({ code: 200, msg: '您已购买过该应用，可直接下载', data: { alreadyPurchased: true } })

      if (price_type === 'free' || price_amount <= 0) {
        await query(`INSERT INTO app_purchases (app_id, user_id, user_name, price_type, original_price, paid_price, discount_rate)
          VALUES (?, ?, ?, 'free', 0, 0, 1.0)`, [appId, userId, ''])
        await query('UPDATE app_store SET downloads=downloads+1 WHERE id=?', [appId])
        return res.json({ code: 200, msg: '免费应用，已获得下载权限', data: { alreadyPurchased: false, paidPrice: 0 } })
      }

      // 获取用户信息
      const users = await query('SELECT * FROM users WHERE id=?', [userId])
      if (!users.length) return res.json({ code: 404, msg: '用户不存在' })
      const user = users[0]

      // 应用折扣率
      const membershipRows = await query('SELECT * FROM membership_levels WHERE id=?', [user.level_id || 0])
      let discountRate = 1.0
      let membershipName = ''
      if (membershipRows.length) {
        const ml = membershipRows[0]
        if (price_type === 'points') {
          discountRate = Number(ml.points_discount_rate || 1.0)
        } else {
          discountRate = Number(ml.discount_rate || 1.0)
        }
        membershipName = ml.name || ''
      }
      const finalPrice = Math.round(price_amount * discountRate * 100) / 100

      if (price_type === 'balance') {
        const currentBalance = Number(user.balance || 0)
        if (currentBalance < finalPrice) return res.json({ code: 400, msg: `余额不足，需要 ${finalPrice} 元，当前余额 ${currentBalance} 元`, data: { needBalance: finalPrice, currentBalance } })
        await query('UPDATE users SET balance=ROUND(balance-?,2) WHERE id=?', [finalPrice, userId])
      } else if (price_type === 'points') {
        const currentPoints = Number(user.points || 0)
        if (currentPoints < finalPrice) return res.json({ code: 400, msg: `积分不足，需要 ${finalPrice} 积分，当前积分 ${currentPoints}` })
        await query('UPDATE users SET points=points-? WHERE id=?', [finalPrice, userId])
      }

      // 写入购买记录
      await query(`INSERT INTO app_purchases (app_id, user_id, user_name, price_type, original_price, paid_price, discount_rate)
        VALUES (?, ?, ?, ?, ?, ?, ?)`, [appId, userId, user.username || '', price_type, price_amount, finalPrice, discountRate])

      // 通知购买者
      const unit = price_type === 'balance' ? '元' : '积分'
      const discountInfo = discountRate < 1 ? `（${membershipName}折扣${Math.round(discountRate*100)}%）` : ''
      await query(`INSERT INTO sys_notifications (title, content, type, target_user_id)
        VALUES (?, ?, 'system', ?)`,
        ['购买成功', `您已成功购买《${info.name}》，支付 ${finalPrice}${unit}${discountInfo}，可永久下载`, userId])

      // 通知上传者
      if (info.user_id > 0 && Number(info.user_id) !== userId) {
        await query(`INSERT INTO sys_notifications (title, content, type, target_user_id)
          VALUES (?, ?, 'system', ?)`,
          ['应用售出', `用户 ${user.username} 购买了您的应用《${info.name}》，收入 ${finalPrice}${unit}`, info.user_id])
      }

      // 增加下载计数
      await query('UPDATE app_store SET downloads=downloads+1 WHERE id=?', [appId])

      const newBalance = price_type === 'balance' ? Math.round((Number(user.balance) - finalPrice) * 100) / 100 : Number(user.balance)
      const newPoints = price_type === 'points' ? Number(user.points) - finalPrice : Number(user.points)

      res.json({ code: 200, msg: '购买成功', data: { alreadyPurchased: false, paidPrice: finalPrice, discountRate, membershipName, newBalance, newPoints } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // GET /api/app/:id/purchase-status — 检查购买状态
  router.get('/api/app/:id/purchase-status', async (req, res) => {
    const appId = Number(req.params.id)
    const userId = Number(req.query.userId || 0)
    if (!userId || userId <= 0) return res.json({ code: 200, data: { purchased: false } })
    try {
      const bought = await query('SELECT id FROM app_purchases WHERE app_id=? AND user_id=?', [appId, userId])
      res.json({ code: 200, data: { purchased: bought.length > 0 } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // GET /api/app/:id/purchasers — 购买者列表
  router.get('/api/app/:id/purchasers', async (req, res) => {
    const appId = Number(req.params.id)
    try {
      const list = await query(
        `SELECT p.id, p.app_id as appId, p.user_id as userId, p.user_name as userName,
                p.price_type as priceType, p.original_price as originalPrice, p.paid_price as paidPrice,
                p.discount_rate as discountRate, p.create_time as createTime,
                u.avatar, u.level_name as levelName
         FROM app_purchases p
         LEFT JOIN users u ON u.id = p.user_id
         WHERE p.app_id=?
         ORDER BY p.create_time DESC`, [appId]
      )
      res.json({ code: 200, data: { list } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // GET /api/app/:id/tips — 打赏列表
  router.get('/api/app/:id/tips', async (req, res) => {
    try {
      const list = await query(
        `SELECT id, app_id as appId, user_id as userId, user_name as userName,
                amount, tip_type as tipType, message, create_time as createTime
         FROM app_tips WHERE app_id=? ORDER BY id DESC`,
        [Number(req.params.id)]
      )
      const stats = await query(
        `SELECT
           SUM(CASE WHEN tip_type='balance' THEN amount ELSE 0 END) as totalBalance,
           SUM(CASE WHEN tip_type='points' THEN amount ELSE 0 END) as totalPoints
         FROM app_tips WHERE app_id=?`,
        [Number(req.params.id)]
      )
      res.json({ code: 200, msg: 'success', data: { list, stats: stats[0] || { totalBalance: 0, totalPoints: 0 } } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ========== 评论管理 ==========

  // DELETE /api/app/comment/:id — 管理员删除评论
  router.delete('/api/app/comment/:id', async (req, res) => {
    try {
      await query('DELETE FROM comment_likes WHERE comment_id=?', [Number(req.params.id)])
      await query('DELETE FROM app_comments WHERE id=?', [Number(req.params.id)])
      res.json({ code: 200, msg: '删除成功', data: { success: true } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // GET /api/app/reports — 举报列表
  router.get('/api/app/reports', async (req, res) => {
    try {
      const page = Number(req.query.page) || 1
      const pageSize = Number(req.query.pageSize) || 20
      const offset = (page - 1) * pageSize
      const list = await query(
        `SELECT c.id, c.app_id as appId, a.name as appName, c.user_name as userName,
                c.content, c.reported, c.create_time as createTime
         FROM app_comments c LEFT JOIN app_store a ON c.app_id = a.id
         WHERE c.reported > 0 ORDER BY c.reported DESC, c.id DESC
         LIMIT ? OFFSET ?`, [pageSize, offset]
      )
      const cnt = await query('SELECT COUNT(*) as total FROM app_comments WHERE reported > 0')
      res.json({ code: 200, msg: 'success', data: { list, total: cnt[0]?.total || 0 } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // POST /api/app/comment/:id/ignore — 忽略举报
  router.post('/api/app/comment/:id/ignore', async (req, res) => {
    try {
      await query('UPDATE app_comments SET reported=0 WHERE id=?', [Number(req.params.id)])
      res.json({ code: 200, msg: '已忽略', data: {} })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ========== 置顶管理 ==========

  // POST /api/app/:id/pin — 切换置顶状态
  router.post('/api/app/:id/pin', async (req, res) => {
    try {
      const { pinned } = req.body
      await query('UPDATE app_store SET is_pinned=? WHERE id=?', [pinned ? 1 : 0, Number(req.params.id)])
      res.json({ code: 200, msg: pinned ? '已置顶' : '已取消置顶', data: { success: true } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })
}

module.exports = appStoreRoutes
