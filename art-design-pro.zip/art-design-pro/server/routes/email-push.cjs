const { query } = require('../database.cjs')
const { authRequired, sessions, SESSION_TTL } = require('./system.cjs')

async function isAdmin(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return false
  const session = sessions.get(token)
  if (session) { const roles = session.roles || []; return roles.includes('R_SUPER') || roles.includes('R_ADMIN') }
  try {
    const rows = await query('SELECT roles FROM sessions WHERE token=?', [token])
    if (rows.length > 0) { const roles = JSON.parse(rows[0].roles || '[]'); return roles.includes('R_SUPER') || roles.includes('R_ADMIN') }
  } catch {}
  return false
}

const DEFAULT_PUSH_CONFIGS = [
  { code: 'new_submission', name: '链接提交邮件', description: '前台有新的链接提交向管理员发送邮件', target: 'admin', enabled: 0 },
  { code: 'new_order', name: '新订单邮件', description: '用户支付订单后向管理员发送邮件', target: 'admin', enabled: 0 },
  { code: 'withdraw_request', name: '提现邮件', description: '用户申请提现向管理员发送邮件', target: 'admin', enabled: 0 },
  { code: 'submission_review', name: '投稿待审核通知邮件', description: '有用户投稿待审核时向管理员发送邮件', target: 'admin', enabled: 0 },
  { code: 'post_review', name: '帖子待审核通知邮件(管理员)', description: '[论坛]有用户发帖待审核时向管理员发送邮件', target: 'admin', enabled: 0 },
  { code: 'post_review_moderator', name: '帖子待审核通知邮件(版主)', description: '[论坛]有用户发帖待审核时向版主发送邮件', target: 'moderator', enabled: 0 },
  { code: 'identity_verify', name: '身份认证通知邮件', description: '有用户申请身份认证向管理员发送邮件', target: 'admin', enabled: 0 },
  { code: 'account_appeal', name: '帐号申诉通知邮件', description: '有用户帐号禁封申诉向管理员发送邮件', target: 'admin', enabled: 0 },
  { code: 'report_notify', name: '举报通知邮件', description: '收到举报信息向管理员发送邮件', target: 'admin', enabled: 0 },
  { code: 'moderator_apply', name: '版主申请通知邮件', description: '[论坛]有用户申请版主向管理员和超级版主发送邮件', target: 'admin', enabled: 0 },
  { code: 'order_paid_user', name: '新订单邮件(用户)', description: '用户支付订单后向用户发送邮件', target: 'user', enabled: 0 },
  { code: 'withdraw_result', name: '提现通知邮件', description: '处理用户提现申请后向用户发送邮件', target: 'user', enabled: 0 },
  { code: 'order_paid_referrer', name: '佣金通知邮件', description: '用户支付订单后向推荐人发送邮件', target: 'user', enabled: 0 },
  { code: 'revenue_split', name: '分成通知邮件', description: '用户支付订单后有创作分成时向分成作者发送邮件', target: 'user', enabled: 0 },
  { code: 'comment_approved', name: '评论审核邮件', description: '评论通过审核后向用户发送邮件', target: 'user', enabled: 0 },
  { code: 'comment_reply', name: '评论回复通知邮件', description: '评论有新的回复向用户发送邮件', target: 'user', enabled: 0 },
  { code: 'content_approved', name: '内容审核邮件', description: '投稿、发帖通过审核后向用户发送邮件', target: 'user', enabled: 0 },
  { code: 'phone_changed', name: '手机号修改通知邮件', description: '用户修改绑定手机号向用户发送邮件', target: 'user', enabled: 0 },
  { code: 'identity_result', name: '身份认证通知邮件(用户)', description: '处理用户身份认证申请后向用户发送邮件', target: 'user', enabled: 0 },
  { code: 'account_ban_user', name: '帐号禁封通知邮件', description: '用户帐号禁封、解封向用户发送邮件', target: 'user', enabled: 0 },
  { code: 'report_result', name: '举报反馈邮件', description: '处理用户举报后向用户发送邮件', target: 'user', enabled: 0 },
  { code: 'moderator_apply_result', name: '版主申请通知邮件(用户)', description: '[论坛]处理用户版主申请后向用户发送邮件', target: 'user', enabled: 0 },
  { code: 'moderator_removed', name: '版主移出通知邮件', description: '[论坛]将用户版主身份移出后向用户发送邮件', target: 'user', enabled: 0 },
  { code: 'answer_accepted', name: '回答被采纳', description: '[论坛]回答被采纳后向用户发送邮件', target: 'user', enabled: 0 },
  { code: 'private_message', name: '私信通知邮件', description: '收到私信后向收信用户发送邮件', target: 'user', enabled: 0 }
]

module.exports = function emailPushRoutes(app) {
  app.get('/api/email-push/configs', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const rows = await query('SELECT * FROM email_push_config ORDER BY id')
      res.json({ code: 200, data: rows })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.post('/api/email-push/configs', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const { code, enabled } = req.body
      if (!code) return res.json({ code: 400, message: '配置代码不能为空' })
      await query(
        `UPDATE email_push_config SET enabled=?, update_time=NOW() WHERE code=?`,
        [enabled ? 1 : 0, code]
      )
      res.json({ code: 200, message: '更新成功' })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.post('/api/email-push/configs/batch', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const { configs } = req.body
      if (!Array.isArray(configs)) return res.json({ code: 400, message: '参数格式错误' })
      for (const c of configs) {
        await query(
          `UPDATE email_push_config SET enabled=?, update_time=NOW() WHERE code=?`,
          [c.enabled ? 1 : 0, c.code]
        )
      }
      res.json({ code: 200, message: '批量更新成功' })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.put('/api/email-push/configs/:code', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const { enabled, user_group, level_ids } = req.body
      await query(
        `UPDATE email_push_config SET enabled=?, user_group=?, level_ids=?, update_time=NOW() WHERE code=?`,
        [enabled ? 1 : 0, user_group || '', level_ids || '', req.params.code]
      )
      res.json({ code: 200, message: '更新成功' })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.get('/api/email-push/init', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const existing = await query('SELECT code FROM email_push_config')
      const existingCodes = new Set(existing.map(r => r.code))
      let added = 0
      for (const cfg of DEFAULT_PUSH_CONFIGS) {
        if (!existingCodes.has(cfg.code)) {
          await query(
            `INSERT INTO email_push_config (code, name, description, target, enabled) VALUES (?,?,?,?,?)`,
            [cfg.code, cfg.name, cfg.description, cfg.target, cfg.enabled]
          )
          added++
        }
      }
      res.json({ code: 200, message: `初始化完成，新增 ${added} 条配置`, data: { added } })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })
}
