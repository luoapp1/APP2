const { query } = require('../database.cjs')
const { logFromReq } = require('../middleware/security.cjs')

function isMobileUA(ua) {
  if (!ua) return false
  const lower = ua.toLowerCase()
  return /mobile|android|iphone|ipad|ipod|blackberry|iemobile|opera mini|webos/.test(lower)
}

function getUserRoles(req) {
  try {
    const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '')
    if (!token) return []
    const systemRoutes = require('./system.cjs')
    const session = systemRoutes.sessions.get(token)
    if (session && Array.isArray(session.roles)) return session.roles
  } catch {}
  return []
}

function isAdmin(req) {
  const roles = getUserRoles(req)
  return roles.includes('R_SUPER') || roles.includes('R_ADMIN')
}

function themesRoutes(app) {
  app.get('/api/themes/active', async (req, res) => {
    try {
      const rows = await query("SELECT * FROM themes WHERE is_active=1 LIMIT 1")
      if (!rows.length) {
        const defaults = await query("SELECT * FROM themes WHERE is_preset=1 LIMIT 1")
        if (defaults.length) {
          await query("UPDATE themes SET is_active=0 WHERE is_active=1")
          await query("UPDATE themes SET is_active=1 WHERE id=?", [defaults[0].id])
          return res.json(withDevice(parseTheme(defaults[0]), req))
        }
        return res.json({
          code: 200,
          data: { device: 'pc', vars: {}, varsDark: {}, varsMobile: {}, varsMobileDark: {} }
        })
      }
      res.json({ code: 200, data: withDevice(parseTheme(rows[0]), req) })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.get('/api/themes', async (req, res) => {
    if (!isAdmin(req)) return res.json({ code: 403, msg: '权限不足' })
    try {
      const rows = await query("SELECT * FROM themes ORDER BY is_active DESC, is_preset DESC, id")
      res.json({ code: 200, data: rows.map(parseTheme) })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.get('/api/themes/:id', async (req, res) => {
    if (!isAdmin(req)) return res.json({ code: 403, msg: '权限不足' })
    try {
      const rows = await query("SELECT * FROM themes WHERE id=?", [req.params.id])
      if (!rows.length) return res.json({ code: 404, msg: '主题不存在' })
      res.json({ code: 200, data: parseTheme(rows[0]) })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/themes', async (req, res) => {
    if (!isAdmin(req)) return res.json({ code: 403, msg: '权限不足' })
    try {
      const { name, description, thumbnail, vars, varsDark, varsMobile, varsMobileDark } = req.body
      if (!name) return res.json({ code: 400, msg: '主题名称不能为空' })
      const safeVars = safeJSON(vars)
      const safeVarsDark = safeJSON(varsDark)
      const safeVarsMobile = safeJSON(varsMobile)
      const safeVarsMobileDark = safeJSON(varsMobileDark)
      const result = await query(
        `INSERT INTO themes (name, description, thumbnail, vars, vars_dark, vars_mobile, vars_mobile_dark, is_preset)
         VALUES (?, ?, ?, ?, ?, ?, ?, 0)`,
        [name, description || '', thumbnail || '', safeVars, safeVarsDark, safeVarsMobile, safeVarsMobileDark]
      )
      logFromReq(req, 'theme', 'themes', result.insertId || 0, `创建主题: ${name}`)
      res.json({ code: 200, msg: '创建成功', data: { id: result.insertId || 0 } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.put('/api/themes/:id', async (req, res) => {
    if (!isAdmin(req)) return res.json({ code: 403, msg: '权限不足' })
    try {
      const { name, description, thumbnail, vars, varsDark, varsMobile, varsMobileDark } = req.body
      const existing = await query("SELECT * FROM themes WHERE id=?", [req.params.id])
      if (!existing.length) return res.json({ code: 404, msg: '主题不存在' })

      const fields = []
      const values = []
      if (name !== undefined) { fields.push('name=?'); values.push(name) }
      if (description !== undefined) { fields.push('description=?'); values.push(description) }
      if (thumbnail !== undefined) { fields.push('thumbnail=?'); values.push(thumbnail) }
      if (vars !== undefined) { fields.push('vars=?'); values.push(safeJSON(vars)) }
      if (varsDark !== undefined) { fields.push('vars_dark=?'); values.push(safeJSON(varsDark)) }
      if (varsMobile !== undefined) { fields.push('vars_mobile=?'); values.push(safeJSON(varsMobile)) }
      if (varsMobileDark !== undefined) { fields.push('vars_mobile_dark=?'); values.push(safeJSON(varsMobileDark)) }

      fields.push('update_time=NOW()')
      values.push(req.params.id)
      await query(`UPDATE themes SET ${fields.join(',')} WHERE id=?`, values)
      logFromReq(req, 'theme', 'themes', req.params.id, `更新主题: ${name || existing[0].name}`)
      res.json({ code: 200, msg: '更新成功' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.delete('/api/themes/:id', async (req, res) => {
    if (!isAdmin(req)) return res.json({ code: 403, msg: '权限不足' })
    try {
      const existing = await query("SELECT * FROM themes WHERE id=?", [req.params.id])
      if (!existing.length) return res.json({ code: 404, msg: '主题不存在' })
      if (existing[0].is_preset) return res.json({ code: 400, msg: '预设主题不可删除' })
      if (existing[0].is_active) return res.json({ code: 400, msg: '激活中的主题不可删除，请先激活其他主题' })
      await query("DELETE FROM themes WHERE id=?", [req.params.id])
      logFromReq(req, 'theme', 'themes', req.params.id, `删除主题: ${existing[0].name}`)
      res.json({ code: 200, msg: '删除成功' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.put('/api/themes/:id/activate', async (req, res) => {
    if (!isAdmin(req)) return res.json({ code: 403, msg: '权限不足' })
    try {
      const existing = await query("SELECT * FROM themes WHERE id=?", [req.params.id])
      if (!existing.length) return res.json({ code: 404, msg: '主题不存在' })

      await query("UPDATE themes SET is_active=0 WHERE is_active=1")
      await query("UPDATE themes SET is_active=1, update_time=NOW() WHERE id=?", [req.params.id])
      logFromReq(req, 'theme', 'themes', req.params.id, `激活主题: ${existing[0].name}`)
      res.json({ code: 200, msg: `已激活主题「${existing[0].name}」`, data: parseTheme(existing[0]) })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })
}

function parseTheme(row) {
  return {
    id: row.id,
    name: row.name,
    description: row.description,
    isPreset: !!row.is_preset,
    isActive: !!row.is_active,
    thumbnail: row.thumbnail,
    vars: parseJSON(row.vars),
    varsDark: parseJSON(row.vars_dark),
    varsMobile: parseJSON(row.vars_mobile),
    varsMobileDark: parseJSON(row.vars_mobile_dark),
    createTime: row.create_time,
    updateTime: row.update_time
  }
}

function withDevice(theme, req) {
  const ua = req.headers['user-agent'] || ''
  const device = isMobileUA(ua) ? 'mobile' : 'pc'
  return { ...theme, device }
}

function parseJSON(str) {
  if (!str) return {}
  try { return JSON.parse(str) } catch { return {} }
}

function safeJSON(obj) {
  if (typeof obj === 'string') {
    try { JSON.parse(obj); return obj }
    catch { return '{}' }
  }
  if (obj && typeof obj === 'object') return JSON.stringify(obj)
  return '{}'
}

module.exports = themesRoutes
