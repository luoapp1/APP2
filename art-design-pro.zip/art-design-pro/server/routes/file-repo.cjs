const { query } = require('../database.cjs')
const { authRequired, sessions, SESSION_TTL } = require('./system.cjs')
const { decryptStorageConfig } = require('../utils/storage-decrypt.cjs')
const { deleteFileFromStorage, updateUserUsedBytes, deleteFileRecordById } = require('../utils/file-helper.cjs')
const fs = require('fs')
const path = require('path')

async function isAdmin(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return false
  const session = sessions.get(token)
  if (session) { const roles = session.roles || []; return roles.includes('R_SUPER') || roles.includes('R_ADMIN') }
  return false
}

function validateOwnership(userId, fileKeyOrPrefix) {
  if (!userId || !fileKeyOrPrefix) return false
  const allowedPrefix = `user/${userId}/`
  const normalized = fileKeyOrPrefix.replace(/^\/+/, '')
  return normalized.startsWith(allowedPrefix) || normalized === `user/${userId}`
}

module.exports = function fileRepoRoutes(app) {
  app.get('/api/file-repo/list', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const { page = 1, pageSize = 20, category, keyword } = req.query
      const offset = (page - 1) * pageSize
      let where = '1=1'
      const params = []
      if (category) { where += ' AND category=?'; params.push(category) }
      if (keyword) { where += ' AND (file_name LIKE ? OR file_path LIKE ?)'; params.push(`%${keyword}%`, `%${keyword}%`) }
      const list = await query(`SELECT * FROM file_repository WHERE ${where} ORDER BY create_time DESC LIMIT ? OFFSET ?`, [...params, parseInt(pageSize), offset])
      const cnt = await query(`SELECT COUNT(*) as total FROM file_repository WHERE ${where}`, params)
      res.json({ code: 200, data: { list, total: cnt[0].total } })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.get('/api/file-repo/categories', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const rows = await query('SELECT category, COUNT(*) as count, SUM(file_size) as total_size FROM file_repository GROUP BY category')
      res.json({ code: 200, data: rows })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.delete('/api/file-repo/:id', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const row = await query('SELECT * FROM file_repository WHERE id=?', [req.params.id])
      if (row.length === 0) return res.json({ code: 404, message: '文件不存在' })
      await deleteFileFromStorage(row[0].file_path)
      const userId = row[0].user_id || 0
      await query('DELETE FROM file_repository WHERE id=?', [req.params.id])
      if (userId) await updateUserUsedBytes(userId)
      res.json({ code: 200, message: '删除成功' })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app._recordFile = async function(userId, userName, fileName, filePath, fileSize, fileType, mimeType, category, refId, refType, description) {
    try {
      const { recordFileUpload, updateUserUsedBytes, buildFileDesc } = require('./upload.cjs')
      await recordFileUpload({
        userId: userId || 0,
        userName: userName || '',
        fileName,
        fileUrl: filePath,
        fileSize: fileSize || 0,
        fileType,
        mimeType: mimeType || '',
        category: category || 'other',
        refId: refId || 0,
        refType: refType || '',
        description: description || buildFileDesc({ category: category || 'other', refType: refType || '', refId: refId || 0 })
      })
      if (userId) await updateUserUsedBytes(userId)
    } catch { console.error('文件记录失败') }
  }

  const UPLOADS_ROOT = path.resolve(__dirname, '..', 'uploads')

  function isImage(ext) {
    return ['.jpg','.jpeg','.png','.gif','.webp','.bmp','.svg','.ico'].includes(ext.toLowerCase())
  }
  function isVideo(ext) {
    return ['.mp4','.avi','.mov','.wmv','.flv','.mkv','.webm'].includes(ext.toLowerCase())
  }
  function isAudio(ext) {
    return ['.mp3','.wav','.ogg','.aac','.flac','.m4a'].includes(ext.toLowerCase())
  }

  app.get('/api/file-repo/local-browse', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const subDir = (req.query.dir || '').replace(/\.\./g, '').replace(/^\/+|\/+$/g, '')
      const scanPath = subDir ? path.resolve(UPLOADS_ROOT, subDir) : UPLOADS_ROOT
      if (!scanPath.startsWith(UPLOADS_ROOT)) return res.json({ code: 400, message: '非法路径' })
      if (!fs.existsSync(scanPath)) return res.json({ code: 404, message: '目录不存在' })

      const entries = fs.readdirSync(scanPath, { withFileTypes: true })

      const dirs = []
      const files = []

      for (const entry of entries) {
        if (entry.isDirectory()) {
          dirs.push({ name: entry.name, isDir: true })
        } else {
          const stat = fs.statSync(path.join(scanPath, entry.name))
          const ext = path.extname(entry.name).toLowerCase()
          const relPath = subDir ? `${subDir}/${entry.name}` : entry.name
          const url = `/uploads/${relPath}`
          files.push({
            name: entry.name,
            path: relPath,
            url,
            size: stat.size,
            mtime: stat.mtime.toISOString(),
            ext,
            isImage: isImage(ext),
            isVideo: isVideo(ext),
            isAudio: isAudio(ext)
          })
        }
      }

      files.sort((a, b) => b.mtime.localeCompare(a.mtime))
      dirs.sort((a, b) => a.name.localeCompare(b.name))

      const page = Math.max(1, parseInt(req.query.page) || 1)
      const pageSize = Math.min(100, Math.max(5, parseInt(req.query.pageSize) || 30))
      const totalFiles = files.length
      const totalPages = Math.ceil(totalFiles / pageSize) || 1
      const start = (page - 1) * pageSize
      const pagedFiles = files.slice(start, start + pageSize)

      res.json({
        code: 200,
        data: {
          currentDir: subDir || '/',
          dirs,
          files: pagedFiles,
          page,
          pageSize,
          totalFiles,
          totalPages
        }
      })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.get('/api/file-repo/local-detail', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const filePath = (req.query.path || '').replace(/\.\./g, '')
      const absPath = path.resolve(UPLOADS_ROOT, filePath.replace(/^\/+/, ''))
      if (!absPath.startsWith(UPLOADS_ROOT)) return res.json({ code: 400, message: '非法路径' })
      if (!fs.existsSync(absPath)) return res.json({ code: 404, message: '文件不存在' })

      const stat = fs.statSync(absPath)
      const ext = path.extname(filePath).toLowerCase()
      const fileName = path.basename(filePath)
      const url = '/uploads/' + filePath.replace(/^\/+/, '')

      const dbRow = await query('SELECT * FROM file_repository WHERE file_path=? LIMIT 1', [url])

      res.json({
        code: 200,
        data: {
          name: fileName,
          path: filePath,
          url,
          size: stat.size,
          mtime: stat.mtime.toISOString(),
          ctime: stat.birthtime?.toISOString() || stat.ctime.toISOString(),
          ext,
          isImage: isImage(ext),
          isVideo: isVideo(ext),
          isAudio: isAudio(ext),
          dbRecord: dbRow.length > 0 ? dbRow[0] : null
        }
      })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.delete('/api/file-repo/local-delete', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const filePath = (req.query.path || '').replace(/\.\./g, '')
      const absPath = path.resolve(UPLOADS_ROOT, filePath.replace(/^\/+/, ''))
      if (!absPath.startsWith(UPLOADS_ROOT)) return res.json({ code: 400, message: '非法路径' })
      if (!fs.existsSync(absPath)) return res.json({ code: 404, message: '文件不存在' })

      fs.unlinkSync(absPath)

      const url = '/uploads/' + filePath.replace(/^\/+/, '')
      await query('DELETE FROM file_repository WHERE file_path=?', [url])

      res.json({ code: 200, message: '删除成功' })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  async function getUserId(req) {
    const raw = req.headers.authorization || req.headers.token || req.query.token || ''
    const token = raw.replace(/^Bearer\s+/i, '')
    if (!token) return 0
    const session = sessions.get(token)
    return session && session.userId ? session.userId : 0
  }

  app.get('/api/file-repo/my-files', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, message: '请先登录' })

      const { prefix } = req.query
      if (prefix && !validateOwnership(userId, prefix)) {
        return res.json({ code: 403, message: '无权访问其他用户的文件' })
      }
      const basePrefix = prefix ? `${prefix}` : `user/${userId}/`

      const configs = await query('SELECT * FROM storage_configs WHERE status=? ORDER BY is_default DESC, id ASC LIMIT 1', ['1'])
      if (!configs.length) return res.json({ code: 200, data: { list: [], total: 0, usedBytes: 0, totalDataLimitMb: 0 } })

      const cfg = decryptStorageConfig(configs[0])
      if (cfg.type === 'local') {
        const list = await query('SELECT id, file_name, file_path, file_size, file_type, mime_type, category, ref_type, ref_id, description, create_time FROM file_repository WHERE user_id=? ORDER BY create_time DESC', [userId])
        const used = await query('SELECT COALESCE(SUM(file_size),0) as total FROM file_repository WHERE user_id=?', [userId])
        return res.json({
          code: 200,
          data: { list, total: list.length, usedBytes: Number(used[0]?.total || 0), totalDataLimitMb: 200 }
        })
      }

      const entries = await listCloudObjects(cfg, basePrefix, true, userId)

      const user = await query('SELECT level_id, expire_time, used_bytes, bonus_data_limit_mb, bonus_file_limit_mb FROM users WHERE id=?', [userId])
      let totalDataLimitMb = 200
      if (user.length) {
        let effectiveLevelId = 0
        if (user[0].level_id && user[0].expire_time && new Date(user[0].expire_time) > new Date()) {
          effectiveLevelId = user[0].level_id
        } else {
          const active = await query(
            'SELECT um.level_id FROM user_memberships um JOIN membership_levels ml ON um.level_id=ml.id WHERE um.user_id=? AND um.expire_time>NOW() ORDER BY ml.tier DESC LIMIT 1',
            [userId]
          )
          effectiveLevelId = active.length ? active[0].level_id : 0
        }
        const lv = effectiveLevelId ? await query('SELECT data_limit_mb, file_limit_mb FROM membership_levels WHERE id=? AND status=?', [effectiveLevelId, '1']) : []
        const baseDataMb = lv.length ? (lv[0].data_limit_mb || 0) : 0
        const bonusDataMb = user[0].bonus_data_limit_mb || 0
        totalDataLimitMb = baseDataMb + bonusDataMb
      }

      const used = await query('SELECT COALESCE(SUM(file_size),0) as total FROM file_repository WHERE user_id=?', [userId])

      res.json({
        code: 200,
        data: {
          list: entries,
          total: entries.length,
          usedBytes: Number(used[0]?.total || 0),
          totalDataLimitMb
        }
      })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  async function listCloudObjects(cfg, prefix, withDelimiter, userId) {
    return new Promise((resolve, reject) => {
      const result = []

      if (cfg.type === 'oss') {
        const OSS = require('ali-oss')
        const client = new OSS({
          region: cfg.region,
          accessKeyId: cfg.access_key,
          accessKeySecret: cfg.secret_key,
          bucket: cfg.bucket,
          endpoint: cfg.endpoint
        })
        ;(async () => {
          try {
            let marker = null
            while (true) {
              const resp = await client.list({
                prefix,
                delimiter: withDelimiter ? '/' : '',
                'max-keys': 100,
                marker
              })
              if (withDelimiter && resp.prefixes) {
                for (const p of resp.prefixes) {
                  result.push({ name: p.replace(/\/$/, '').split('/').pop(), prefix: p, isFolder: true, size: 0 })
                }
              }
              if (resp.objects) {
                for (const obj of resp.objects) {
                  if (obj.name === prefix) continue
                  const baseUrl = cfg.base_url || `https://${cfg.bucket}.${cfg.endpoint?.replace(/^https?:\/\//, '') || cfg.region + '.aliyuncs.com'}`
                  result.push({
                    name: obj.name.split('/').pop(),
                    key: obj.name,
                    size: obj.size || 0,
                    url: `${baseUrl.replace(/\/$/, '')}/${obj.name}`,
                    time: obj.lastModified,
                    type: (obj.name.split('/').pop() || '').split('.').pop()?.toLowerCase() || '',
                    isFolder: false
                  })
                }
              }
              if (!resp.isTruncated || !resp.nextMarker) break
              marker = resp.nextMarker
            }
            const dbFiles = await query('SELECT file_path FROM file_repository WHERE user_id=? AND file_path IS NOT NULL', [userId])
            const pathSet = new Set()
            for (const r of dbFiles) {
              const p = (r.file_path || '')
              pathSet.add(p)
              pathSet.add(p.replace(/^https:/, 'http:'))
              pathSet.add(p.replace(/^http:/, 'https:'))
            }
            for (const f of result) {
              if (!f.isFolder) {
                f.dbId = (pathSet.has(f.key) || pathSet.has('/' + f.key) || pathSet.has(f.url)) ? f.key : null
              }
            }
            resolve(result)
          } catch (e) { reject(e) }
        })()
      } else if (cfg.type === 'cos') {
        const COS = require('cos-nodejs-sdk-v5')
        const cos = new COS({ SecretId: cfg.access_key, SecretKey: cfg.secret_key })
        cos.getBucket({
          Bucket: cfg.bucket,
          Region: cfg.region,
          Prefix: prefix,
          Delimiter: withDelimiter ? '/' : '',
          MaxKeys: 200
        }, async (err, data) => {
          if (err) return reject(err)
          if (withDelimiter && data.CommonPrefixes) {
            for (const p of data.CommonPrefixes) {
              result.push({ name: p.Prefix.replace(/\/$/, '').split('/').pop(), prefix: p.Prefix, isFolder: true, size: 0 })
            }
          }
          const baseUrl = cfg.base_url || `https://${cfg.bucket}.cos.${cfg.region}.myqcloud.com`
          if (data.Contents) {
            for (const f of data.Contents) {
              if (f.Key === prefix) continue
              result.push({
                name: f.Key.split('/').pop(),
                key: f.Key,
                size: f.Size || 0,
                url: `${baseUrl.replace(/\/$/, '')}/${f.Key.split('/').map(encodeURIComponent).join('/')}`,
                time: f.LastModified,
                type: (f.Key.split('/').pop() || '').split('.').pop()?.toLowerCase() || '',
                isFolder: false
              })
            }
          }
          try {
            const dbFiles = await query('SELECT file_path FROM file_repository WHERE user_id=?', [userId])
            const pathSet = new Set()
            for (const r of dbFiles) {
              const p = (r.file_path || '')
              pathSet.add(p)
              pathSet.add(p.replace(/^https:/, 'http:'))
              pathSet.add(p.replace(/^http:/, 'https:'))
            }
            for (const f of result) {
              if (!f.isFolder) f.dbId = (pathSet.has(f.key) || pathSet.has('/' + f.key) || pathSet.has(f.url)) ? f.key : null
            }
          } catch {}
          resolve(result)
        })
      } else {
        resolve([])
      }
    })
  }

  app.post('/api/file-repo/my-file', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, message: '请先登录' })

      const fileKey = decodeURIComponent(req.body?.key || req.query?.key || '')
      if (!fileKey) return res.json({ code: 400, message: '缺少文件标识' })

      if (!validateOwnership(userId, fileKey)) {
        return res.json({ code: 403, message: '无权删除其他用户的文件' })
      }

      const configs = await query('SELECT * FROM storage_configs WHERE status=? ORDER BY is_default DESC, id ASC LIMIT 1', ['1'])
      const cfg = decryptStorageConfig(configs[0] || {})

      const baseUrl = cfg.base_url || `https://${cfg.bucket}.${cfg.endpoint?.replace(/^https?:\/\//, '') || (cfg.region || 'oss-cn-hongkong') + '.aliyuncs.com'}`
      const fullUrl = baseUrl.replace(/\/$/, '') + '/' + fileKey
      const altUrl = fullUrl.replace(/^https:/, 'http:')

      const rows = await query(
        'SELECT * FROM file_repository WHERE user_id=? AND (file_path=? OR file_path=?)',
        [userId, fullUrl, altUrl]
      )
      if (rows.length > 0) return res.json({ code: 400, message: '该文件被应用/帖子引用，不能直接删除' })

      try {
        const { deleteFromCloud } = require('./upload.cjs')
        const configs2 = await query('SELECT * FROM storage_configs WHERE status=? ORDER BY is_default DESC, id ASC LIMIT 1', ['1'])
        await deleteFromCloud(decryptStorageConfig(configs2[0] || {}), fileKey)
      } catch (e) {
        console.error('云存储删除失败:', e.message)
        return res.json({ code: 500, message: '云存储删除失败: ' + e.message })
      }

      res.json({ code: 200, message: '删除成功' })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.get('/api/file-repo/file-detail', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, message: '请先登录' })
      const key = decodeURIComponent(req.query.key || '')
      if (!key) return res.json({ code: 400, message: '缺少文件标识' })

      if (!validateOwnership(userId, key)) {
        return res.json({ code: 403, message: '无权查看其他用户的文件' })
      }

      const configs = await query('SELECT * FROM storage_configs WHERE status=? ORDER BY is_default DESC, id ASC LIMIT 1', ['1'])
      const cfg = decryptStorageConfig(configs[0] || {})
      const baseUrl = cfg.base_url || `https://${cfg.bucket}.${(cfg.endpoint || '').replace(/^https?:\/\//, '') || cfg.region + '.aliyuncs.com'}`
      const fullUrl = baseUrl.replace(/\/$/, '') + '/' + key
      const altUrl = fullUrl.replace(/^https:/, 'http:')

      const rows = await query(
        `SELECT fr.*, s.name as submission_name, s.package_name as submission_pkg
         FROM file_repository fr
         LEFT JOIN app_store s ON fr.ref_id = s.id AND fr.ref_type = 'app'
         WHERE fr.user_id=? AND (fr.file_path=? OR fr.file_path=?)`,
        [userId, fullUrl, altUrl]
      )

      if (rows.length === 0) {
        return res.json({ code: 200, data: { key, name: key.split('/').pop(), inDb: false, size: 0 } })
      }

      const r = rows[0]
      const refTypeLabel = {
        avatar: '用户头像', background: '用户背景', app_icon: '应用图标', app_screenshot: '应用截图',
        app: '应用文件', app_comment: '应用评论', submission: '投稿文件',
        post: '社区帖子', post_comment: '社区评论', content: '付费内容', content_comment: '内容评论',
        product: '商城商品'
      }[r.ref_type || ''] || (r.ref_type || '无')
      res.json({
        code: 200,
        data: {
          id: r.id,
          key,
          name: r.file_name,
          size: r.file_size || 0,
          type: r.file_type || '',
          mime: r.mime_type || '',
          category: r.category || '',
          time: r.create_time,
          inDb: true,
          refType: r.ref_type || '',
          refTypeLabel,
          refId: r.ref_id || 0,
          description: r.description || '',
          appName: r.submission_name || '',
          appPackage: r.submission_pkg || ''
        }
      })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })
}
