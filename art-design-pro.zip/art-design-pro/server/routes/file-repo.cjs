const { query } = require('../database.cjs')
const { authRequired, sessions, SESSION_TTL } = require('./system.cjs')
const fs = require('fs')
const path = require('path')

async function isAdmin(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return false
  const session = sessions.get(token)
  if (session) { const roles = session.roles || []; return roles.includes('R_SUPER') || roles.includes('R_ADMIN') }
  return false
}

module.exports = function fileRepoRoutes(app) {
  app.get('/api/file-repo/list', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const { page = 1, pageSize = 20, category, keyword } = req.query
      const offset = (page - 1) * pageSize
      let where = '1=1'
      const params = []
      if (category) { where += ' AND category=?'; params.push(category) }
      if (keyword) { where += ' AND (file_name LIKE ? OR file_path LIKE ?)'; params.push(`%${keyword}%`, `%${keyword}%`) }
      const list = await query(`SELECT * FROM file_repository WHERE ${where} ORDER BY create_time DESC LIMIT ? OFFSET ?`, [...params, parseInt(pageSize), offset])
      const cnt = await query(`SELECT COUNT(*) as total FROM file_repository WHERE ${where}`, params)
      res.json({ code: 200, data: { list, total: cnt[0].total } })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.get('/api/file-repo/categories', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const rows = await query('SELECT category, COUNT(*) as count, SUM(file_size) as total_size FROM file_repository GROUP BY category')
      res.json({ code: 200, data: rows })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.delete('/api/file-repo/:id', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const row = await query('SELECT * FROM file_repository WHERE id=?', [req.params.id])
      if (row.length === 0) return res.json({ code: 404, message: '文件不存在' })
      const filePath = path.resolve(__dirname, '..', row[0].file_path || '')
      if (filePath && fs.existsSync(filePath)) { fs.unlinkSync(filePath) }
      await query('DELETE FROM file_repository WHERE id=?', [req.params.id])
      res.json({ code: 200, message: '删除成功' })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app._recordFile = async function(userId, userName, fileName, filePath, fileSize, fileType, mimeType, category, refId, refType) {
    try {
      await query('INSERT INTO file_repository (user_id, user_name, file_name, file_path, file_size, file_type, mime_type, category, ref_id, ref_type) VALUES (?,?,?,?,?,?,?,?,?,?)',
        [userId || 0, userName || '', fileName, filePath, fileSize || 0, fileType || '', mimeType || '', category || 'other', refId || 0, refType || ''])
    } catch (e) { console.error('文件记录失败:', e.message) }
  }

  const UPLOADS_ROOT = path.resolve(__dirname, '..', 'uploads')

  function isImage(ext) {
    return ['.jpg','.jpeg','.png','.gif','.webp','.bmp','.svg','.ico'].includes(ext.toLowerCase())
  }
  function isVideo(ext) {
    return ['.mp4','.avi','.mov','.wmv','.flv','.mkv','.webm'].includes(ext.toLowerCase())
  }
  function isAudio(ext) {
    return ['.mp3','.wav','.ogg','.aac','.flac','.m4a'].includes(ext.toLowerCase())
  }

  app.get('/api/file-repo/local-browse', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const subDir = (req.query.dir || '').replace(/\.\./g, '').replace(/^\/+|\/+$/g, '')
      const scanPath = subDir ? path.resolve(UPLOADS_ROOT, subDir) : UPLOADS_ROOT
      if (!scanPath.startsWith(UPLOADS_ROOT)) return res.json({ code: 400, message: '非法路径' })
      if (!fs.existsSync(scanPath)) return res.json({ code: 404, message: '目录不存在' })

      const entries = fs.readdirSync(scanPath, { withFileTypes: true })

      const dirs = []
      const files = []

      for (const entry of entries) {
        if (entry.isDirectory()) {
          dirs.push({ name: entry.name, isDir: true })
        } else {
          const stat = fs.statSync(path.join(scanPath, entry.name))
          const ext = path.extname(entry.name).toLowerCase()
          const relPath = subDir ? `${subDir}/${entry.name}` : entry.name
          const url = `/uploads/${relPath}`
          files.push({
            name: entry.name,
            path: relPath,
            url,
            size: stat.size,
            mtime: stat.mtime.toISOString(),
            ext,
            isImage: isImage(ext),
            isVideo: isVideo(ext),
            isAudio: isAudio(ext)
          })
        }
      }

      files.sort((a, b) => b.mtime.localeCompare(a.mtime))
      dirs.sort((a, b) => a.name.localeCompare(b.name))

      const page = Math.max(1, parseInt(req.query.page) || 1)
      const pageSize = Math.min(100, Math.max(5, parseInt(req.query.pageSize) || 30))
      const totalFiles = files.length
      const totalPages = Math.ceil(totalFiles / pageSize) || 1
      const start = (page - 1) * pageSize
      const pagedFiles = files.slice(start, start + pageSize)

      res.json({
        code: 200,
        data: {
          currentDir: subDir || '/',
          dirs,
          files: pagedFiles,
          page,
          pageSize,
          totalFiles,
          totalPages
        }
      })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.get('/api/file-repo/local-detail', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const filePath = (req.query.path || '').replace(/\.\./g, '')
      const absPath = path.resolve(UPLOADS_ROOT, filePath.replace(/^\/+/, ''))
      if (!absPath.startsWith(UPLOADS_ROOT)) return res.json({ code: 400, message: '非法路径' })
      if (!fs.existsSync(absPath)) return res.json({ code: 404, message: '文件不存在' })

      const stat = fs.statSync(absPath)
      const ext = path.extname(filePath).toLowerCase()
      const fileName = path.basename(filePath)
      const url = '/uploads/' + filePath.replace(/^\/+/, '')

      const dbRow = await query('SELECT * FROM file_repository WHERE file_path=? LIMIT 1', [url])

      res.json({
        code: 200,
        data: {
          name: fileName,
          path: filePath,
          url,
          size: stat.size,
          mtime: stat.mtime.toISOString(),
          ctime: stat.birthtime?.toISOString() || stat.ctime.toISOString(),
          ext,
          isImage: isImage(ext),
          isVideo: isVideo(ext),
          isAudio: isAudio(ext),
          dbRecord: dbRow.length > 0 ? dbRow[0] : null
        }
      })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.delete('/api/file-repo/local-delete', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const filePath = (req.query.path || '').replace(/\.\./g, '')
      const absPath = path.resolve(UPLOADS_ROOT, filePath.replace(/^\/+/, ''))
      if (!absPath.startsWith(UPLOADS_ROOT)) return res.json({ code: 400, message: '非法路径' })
      if (!fs.existsSync(absPath)) return res.json({ code: 404, message: '文件不存在' })

      fs.unlinkSync(absPath)

      const url = '/uploads/' + filePath.replace(/^\/+/, '')
      await query('DELETE FROM file_repository WHERE file_path=?', [url])

      res.json({ code: 200, message: '删除成功' })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })
}
