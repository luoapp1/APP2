const { query } = require('../database.cjs')
const { authRequired, sessions, SESSION_TTL } = require('./system.cjs')
const fs = require('fs')
const path = require('path')

async function isAdmin(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return false
  const session = sessions.get(token)
  if (session) { const roles = session.roles || []; return roles.includes('R_SUPER') || roles.includes('R_ADMIN') }
  return false
}

module.exports = function fileRepoRoutes(app) {
  app.get('/api/file-repo/list', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const { page = 1, pageSize = 20, category, keyword } = req.query
      const offset = (page - 1) * pageSize
      let where = '1=1'
      const params = []
      if (category) { where += ' AND category=?'; params.push(category) }
      if (keyword) { where += ' AND (file_name LIKE ? OR file_path LIKE ?)'; params.push(`%${keyword}%`, `%${keyword}%`) }
      const list = await query(`SELECT * FROM file_repository WHERE ${where} ORDER BY create_time DESC LIMIT ? OFFSET ?`, [...params, parseInt(pageSize), offset])
      const cnt = await query(`SELECT COUNT(*) as total FROM file_repository WHERE ${where}`, params)
      res.json({ code: 200, data: { list, total: cnt[0].total } })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.get('/api/file-repo/categories', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const rows = await query('SELECT category, COUNT(*) as count, SUM(file_size) as total_size FROM file_repository GROUP BY category')
      res.json({ code: 200, data: rows })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.delete('/api/file-repo/:id', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const row = await query('SELECT * FROM file_repository WHERE id=?', [req.params.id])
      if (row.length === 0) return res.json({ code: 404, message: '文件不存在' })
      const filePath = path.resolve(__dirname, '..', row[0].file_path || '')
      if (filePath && fs.existsSync(filePath)) { fs.unlinkSync(filePath) }
      await query('DELETE FROM file_repository WHERE id=?', [req.params.id])
      res.json({ code: 200, message: '删除成功' })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app._recordFile = async function(userId, userName, fileName, filePath, fileSize, fileType, mimeType, category, refId, refType) {
    try {
      await query('INSERT INTO file_repository (user_id, user_name, file_name, file_path, file_size, file_type, mime_type, category, ref_id, ref_type) VALUES (?,?,?,?,?,?,?,?,?,?)',
        [userId || 0, userName || '', fileName, filePath, fileSize || 0, fileType || '', mimeType || '', category || 'other', refId || 0, refType || ''])
    } catch (e) { console.error('文件记录失败:', e.message) }
  }
}
