const { query, getSystemOperator } = require('../database.cjs')
const { authRequired, optionalAuth } = require('./system.cjs')
const nowExpr = 'NOW()'

function mallRoutes(router) {

  // 检查商品是否在销售期内，过期自动标记为下架
  async function checkProductSaleEnd(pid) {
    await query(`UPDATE mall_products SET status='off' WHERE id=? AND sale_end_time IS NOT NULL AND sale_end_time < NOW() AND status='1'`, [pid])
  }

  function formatProduct(r) {
    return {
      ...r,
      categoryId: r.category_id, categoryName: r.category_name,
      coverImage: r.cover_image, coverVideo: r.cover_video,
      priceType: r.price_type, originalPrice: r.original_price,
      productType: r.product_type, virtualContent: r.virtual_content,
      salesCount: r.sales_count, isRecommended: r.is_recommended,
      sortOrder: r.sort_order, purchaseLimitConfig: safeJSON(r.purchase_limit_config),
      commissionConfig: safeJSON(r.commission_config), customFields: safeJSON(r.custom_fields),
      afterSalesConfig: safeJSON(r.after_sales_config), services: safeJSON(r.services),
      tags: safeJSON(r.tags), productParams: safeJSON(r.product_params),
      paymentMethods: safeJSON(r.payment_methods),
      saleEndTime: r.sale_end_time || null,
      createdBy: r.created_by || 0, createdByName: r.created_by_name || '',
      createTime: r.create_time, updateTime: r.update_time
    }
  }

  // ==================== 分类 ====================
  router.get('/api/mall/categories/all', async (req, res) => {
    try {
      const rows = await query('SELECT id, parent_id as parentId, name, icon, sort_order as sortOrder, status FROM mall_categories WHERE status=? ORDER BY sort_order ASC, id ASC', ['1'])
      res.json({ code: 200, data: rows })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  router.get('/api/mall/categories', async (req, res) => {
    try {
      const rows = await query('SELECT id, parent_id as parentId, name, icon, sort_order as sortOrder, status FROM mall_categories WHERE status=? AND parent_id=0 ORDER BY sort_order ASC, id ASC', ['1'])
      res.json({ code: 200, data: rows })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // ==================== 商品 ====================
  router.get('/api/mall/products', async (req, res) => {
    try {
      const { categoryId, status, productType, priceType, isRecommended, admin, userId, page = 1, pageSize = 20 } = req.query
      const params = []
      let where = '1=1'
      if (categoryId) { where += ' AND p.category_id=?'; params.push(categoryId) }
      if (productType) { where += ' AND p.product_type=?'; params.push(productType) }
      if (priceType) { where += ' AND p.price_type=?'; params.push(priceType) }
      if (isRecommended) { where += ' AND p.is_recommended=1' }
      if (userId) { where += ' AND p.created_by=?'; params.push(userId) }

      const [countRows, listRows] = await Promise.all([
        query(`SELECT COUNT(*) as total FROM mall_products p WHERE ${where}`, params),
        query(
          `SELECT p.*, c.name as category_name
           FROM mall_products p LEFT JOIN mall_categories c ON p.category_id=c.id
           WHERE ${where} ORDER BY p.sort_order, p.id DESC LIMIT ? OFFSET ?`,
          [...params, Number(pageSize), (Number(page) - 1) * Number(pageSize)]
        )
      ])
      res.json({
        code: 200,
        data: {
          list: listRows.map(r => formatProduct(r)),
          total: countRows[0]?.total || 0,
          page: Number(page),
          pageSize: Number(pageSize)
        }
      })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  router.get('/api/mall/products/:id', async (req, res) => {
    try {
      const [rows, options, images] = await Promise.all([
        query('SELECT * FROM mall_products WHERE id=?', [req.params.id]),
        query('SELECT * FROM mall_product_options WHERE product_id=? ORDER BY sort_order', [req.params.id]),
        query('SELECT * FROM mall_product_images WHERE product_id=? ORDER BY sort_order', [req.params.id])
      ])
      if (!rows.length) return res.json({ code: 404, msg: '商品不存在' })
      const product = formatProduct(rows[0])
      product.options = options.map(o => ({ id: o.id, productId: o.product_id, name: o.name, specName: o.spec_name || '', price: o.price, originalPrice: o.original_price, pointsPrice: o.points_price, stock: o.stock, image: o.image, sortOrder: o.sort_order, cardConfig: safeJSON(o.card_config) }))
      product.images = images.map(i => ({ id: i.id, url: i.url, sortOrder: i.sort_order }))
      res.json({ code: 200, data: product })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  router.post('/api/mall/products', authRequired, async (req, res) => {
    try {
      const b = req.body
      const userId = req.user?.userId || 0
      const userName = req.user?.userName || ''
      const result = await query(
        `INSERT INTO mall_products (category_id,name,subtitle,description,cover_image,cover_video,price_type,price,original_price,stock,product_type,virtual_content,status,is_recommended,sort_order,freight,services,purchase_limit_config,commission_config,custom_fields,after_sales_config,tags,product_params,payment_methods,sale_end_time,created_by,created_by_name,create_time,update_time)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,${nowExpr},${nowExpr})`,
        [b.categoryId || 0, b.name, b.subtitle || '', b.description || '', b.coverImage || '', b.coverVideo || '',
         b.priceType || 'balance', b.price || 0, b.originalPrice || 0, b.stock || 0,
         b.productType || 'virtual_auto', b.virtualContent || '', b.status || 'draft',
         b.isRecommended ? 1 : 0, b.sortOrder || 0, b.freight || 0,
         JSON.stringify(b.services || []), JSON.stringify(b.purchaseLimitConfig || []),
         JSON.stringify(b.commissionConfig || []), JSON.stringify(b.customFields || []),
         JSON.stringify(b.afterSalesConfig || {}), JSON.stringify(b.tags || []), JSON.stringify(b.productParams || []),
         JSON.stringify(b.paymentMethods || ['balance']), b.saleEndTime || null, userId, userName]
      )
      const pid = result.insertId
      await saveProductRelations(pid, b)
      res.json({ code: 200, msg: '创建成功', data: { id: pid } })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  router.put('/api/mall/products/:id', async (req, res) => {
    try {
      const b = req.body; const id = req.params.id
      await query(
        `UPDATE mall_products SET category_id=?,name=?,subtitle=?,description=?,cover_image=?,cover_video=?,price_type=?,price=?,original_price=?,stock=?,product_type=?,virtual_content=?,status=?,is_recommended=?,sort_order=?,freight=?,services=?,purchase_limit_config=?,commission_config=?,custom_fields=?,after_sales_config=?,tags=?,product_params=?,payment_methods=?,sale_end_time=?,update_time=${nowExpr} WHERE id=?`,
        [b.categoryId || 0, b.name, b.subtitle || '', b.description || '', b.coverImage || '', b.coverVideo || '',
         b.priceType || 'balance', b.price || 0, b.originalPrice || 0, b.stock || 0,
         b.productType || 'virtual_auto', b.virtualContent || '', b.status || 'draft',
         b.isRecommended ? 1 : 0, b.sortOrder || 0, b.freight || 0,
         JSON.stringify(b.services || []), JSON.stringify(b.purchaseLimitConfig || []),
         JSON.stringify(b.commissionConfig || []), JSON.stringify(b.customFields || []),
         JSON.stringify(b.afterSalesConfig || {}), JSON.stringify(b.tags || []), JSON.stringify(b.productParams || []),
         JSON.stringify(b.paymentMethods || ['balance']), b.saleEndTime || null, id]
      )
      await saveProductRelations(id, b)
      res.json({ code: 200, msg: '更新成功' })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  router.delete('/api/mall/products/:id', async (req, res) => {
    try {
      const id = req.params.id
      await Promise.all([
        query('DELETE FROM mall_products WHERE id=?', [id]),
        query('DELETE FROM mall_product_options WHERE product_id=?', [id]),
        query('DELETE FROM mall_product_images WHERE product_id=?', [id])
      ])
      res.json({ code: 200, msg: '删除成功' })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  async function saveProductRelations(productId, body) {
    await query('DELETE FROM mall_product_options WHERE product_id=?', [productId])
    if (body.options && body.options.length) {
      for (const o of body.options) {
        await query(
          `INSERT INTO mall_product_options (product_id,name,spec_name,price,original_price,points_price,stock,image,sort_order,card_config) VALUES (?,?,?,?,?,?,?,?,?,?)`,
          [productId, o.name, o.specName || '', o.price || 0, o.originalPrice || 0, o.pointsPrice || 0, o.stock || 0, o.image || '', o.sortOrder || 0, JSON.stringify(o.cardConfig || {})]
        )
      }
    }
    await query('DELETE FROM mall_product_images WHERE product_id=?', [productId])
    if (body.images && body.images.length) {
      for (const img of body.images) {
        await query(
          `INSERT INTO mall_product_images (product_id,url,sort_order) VALUES (?,?,?)`,
          [productId, img.url || img, img.sortOrder || 0]
        )
      }
    }
  }

  function formatProduct(r) {
    return {
      ...r,
      categoryId: r.category_id, categoryName: r.category_name,
      coverImage: r.cover_image, coverVideo: r.cover_video,
      priceType: r.price_type, originalPrice: r.original_price,
      productType: r.product_type, virtualContent: r.virtual_content,
      salesCount: r.sales_count, isRecommended: r.is_recommended,
      sortOrder: r.sort_order, purchaseLimitConfig: safeJSON(r.purchase_limit_config),
      commissionConfig: safeJSON(r.commission_config), customFields: safeJSON(r.custom_fields),
      afterSalesConfig: safeJSON(r.after_sales_config), services: safeJSON(r.services),
      tags: safeJSON(r.tags), productParams: safeJSON(r.product_params),
      paymentMethods: safeJSON(r.payment_methods),
      saleEndTime: r.sale_end_time || null,
      createdBy: r.created_by || 0, createdByName: r.created_by_name || '',
      createTime: r.create_time, updateTime: r.update_time
    }
  }

  function safeJSON(v) { try { return typeof v === 'string' ? JSON.parse(v) : (v || []) } catch { return [] } }

  // 虚拟商品自动发货
  async function autoDeliver(item, product, user) {
    let deliveryInfo = ''
    let cardConfig = {}

    // 如果选择了规格，从规格读取卡密配置
    if (item.option_id) {
      const optRows = await query('SELECT * FROM mall_product_options WHERE id=?', [item.option_id])
      if (optRows.length && optRows[0].card_config) {
        cardConfig = safeJSON(optRows[0].card_config)
      }
    }

    // 从商品级虚拟内容读取（兼容旧数据）
    const vContent = product.virtual_content || ''
    if (!cardConfig.enabled && vContent) {
      deliveryInfo = vContent
      return deliveryInfo
    }

    // 没有卡密配置，返回空
    if (!cardConfig.enabled) {
      return ''
    }

    const cfgType = cardConfig.type || 'card_key'
    const cardType = cardConfig.cardType || 'membership'
    const targetId = cardConfig.targetId || 0
    const value = cardConfig.value || 0
    const durationUnit = cardConfig.durationUnit || 'day'
    const extraPoints = cardConfig.extraPoints || 0
    const extraBalance = cardConfig.extraBalance || 0
    const extraExperience = cardConfig.extraExperience || 0

    if (cfgType === 'auto_recharge') {
      // 自动充值：直接给账户加积分/余额/经验/开通会员，不生成卡密
      if (cardType === 'points') {
        await query('UPDATE users SET points = points + ? WHERE id=?', [value, user.id])
        await query(
          `INSERT INTO points_records (user_id, user_name, type, points, balance, source, description) VALUES (?,?,'earn',?, (SELECT points FROM users WHERE id=?), '商城购买赠送', ?)`,
          [user.id, user.username || '', value, user.id, `购买《${product.name || ''}》赠送${value}积分`]
        )
        deliveryInfo = `赠送 ${value} 积分`
      } else if (cardType === 'balance') {
        await query('UPDATE users SET balance = ROUND(balance + ?, 2) WHERE id=?', [value, user.id])
        await query(
          `INSERT INTO balance_records (user_id, user_name, type, amount, balance, source, description) VALUES (?,?,'earn',?, (SELECT balance FROM users WHERE id=?), '商城购买赠送', ?)`,
          [user.id, user.username || '', value, user.id, `购买《${product.name || ''}》赠送¥${value}`]
        )
        deliveryInfo = `赠送 ¥${value} 余额`
      } else if (cardType === 'experience') {
        await query('UPDATE users SET experience = experience + ? WHERE id=?', [value, user.id])
        await query(
          `INSERT INTO experience_records (user_id, user_name, amount, source, description) VALUES (?,?,?,?,?)`,
          [user.id, user.username || '', value, '商城购买赠送', `购买《${product.name || ''}》赠送${value}经验`]
        )
        deliveryInfo = `赠送 ${value} 经验`
      } else {
        // membership or free - 直接开通会员
        const lv = await query('SELECT id, name FROM membership_levels WHERE id=?', [targetId])
        if (lv && lv.length > 0) {
          const expDate = new Date(Date.now() + value * 24 * 60 * 60 * 1000).toISOString().replace('T', ' ').slice(0, 19)
          await query('UPDATE users SET level_id=?, level_name=?, expire_time=? WHERE id=?',
            [targetId, lv[0].name, expDate, user.id])
          await query(
            `INSERT INTO membership_purchases (user_id, level_id, level_name, amount, pay_type, purchase_type, duration_days, expire_time)
             VALUES (?, ?, ?, ?, 'balance', 'mall', ?, ?)`,
            [user.id, targetId, lv[0].name, 0, value, expDate]
          )
          deliveryInfo = `开通会员：${lv[0].name}，有效期 ${value} 天`
        } else {
          deliveryInfo = '开通会员失败：会员等级不存在'
        }
      }
    } else if (cfgType === 'card_key') {
      // 卡密：全部 cardType 都生成卡密返回给用户
      const qty = item.quantity || 1
      const cards = []
      for (let i = 0; i < qty; i++) {
        const cardNo = 'MC' + Date.now().toString(36).toUpperCase() + Math.random().toString(36).slice(2, 6).toUpperCase()
        const cardPwd = Math.random().toString(36).slice(2, 10).toUpperCase()
        const targetName = cardConfig.targetName || ''
        await query(
          `INSERT INTO card_keys (card_no, password, type, target_id, target_name, value, extra_points, extra_experience, extra_balance, duration, duration_unit, status, create_by, create_time)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,'0',?,${nowExpr})`,
          [cardNo, cardPwd, cardType, targetId, targetName, value, extraPoints, extraExperience, extraBalance, value, durationUnit, '系统自动发货']
        )
        cards.push(`卡密：${cardNo}，密码：${cardPwd}` + (targetName ? `，类型：${targetName}` : ''))
      }
      deliveryInfo = cards.join('\n')
    } else if (cfgType === 'invite_code') {
      const count = cardConfig.inviteCodeCount || 1
      const maxUses = cardConfig.maxUses || 1
      const rewardType = cardConfig.rewardType || 'membership'
      const rewardValue = cardConfig.rewardValue || 0
      const rewardDurationUnit = cardConfig.rewardDurationUnit || 'day'
      const rewardTargetId = cardConfig.targetId || 0
      const codes = []
      for (let i = 0; i < count; i++) {
        const code = 'INV' + Date.now().toString(36).toUpperCase() + Math.random().toString(36).slice(2, 4).toUpperCase() + String(i)
        await query(
          `INSERT INTO invite_codes (code, created_by, created_by_name, max_uses, use_count, reward_type, reward_value, reward_duration_unit, reward_target_id, status, create_time) VALUES (?,?,?,?,0,?,?,?,?,'1',${nowExpr})`,
          [code, user.id, user.username || '', maxUses, rewardType, rewardValue, rewardDurationUnit, rewardTargetId]
        )
        codes.push(code)
        // tiny delay to avoid same timestamp
        await new Promise(r => setTimeout(r, 1))
      }
      deliveryInfo = `邀请码：${codes.join(', ')}`
    } else if (cfgType === 'custom') {
      const customCards = cardConfig.customCards || []
      if (customCards.length === 0) {
        deliveryInfo = '卡池已空，请联系客服'
      } else {
        // 随机抽取一张
        const idx = Math.floor(Math.random() * customCards.length)
        const card = customCards[idx]
        customCards.splice(idx, 1)
        // 更新规格的卡池和库存
        if (item.option_id) {
          cardConfig.customCards = customCards
          await query(
            `UPDATE mall_product_options SET card_config=?, stock=? WHERE id=?`,
            [JSON.stringify(cardConfig), customCards.length, item.option_id]
          )
          // 同步减商品主库存
          await query('UPDATE mall_products SET stock = stock - 1 WHERE id=? AND stock > 0', [product.id])
        }
        const parts = card.split(':')
        const cardNo = parts[0] || ''
        const cardPwd = parts.slice(1).join(':') || ''
        deliveryInfo = `卡密：${cardNo}，密码：${cardPwd}`
      }
    }

    return deliveryInfo
  }

  // ==================== 订单 ====================
  function genOrderNo() {
    const now = new Date()
    const d = now.toISOString().slice(2,10).replace(/-/g,'')
    const t = String(now.getHours()).padStart(2,'0') + String(now.getMinutes()).padStart(2,'0') + String(now.getSeconds()).padStart(2,'0')
    const r = Math.random().toString(36).slice(2,8).toUpperCase()
    return d + t + r
  }

  router.post('/api/mall/orders', authRequired, async (req, res) => {
    try {
      const { productId, optionId, quantity = 1, paymentMethod = 'balance', remark = '', userCustomFields = null, userCouponId } = req.body
      const userId = req.user?.userId

      const [productRows] = await Promise.all([
        query('SELECT * FROM mall_products WHERE id=?', [productId])
      ])
      if (!productRows.length) return res.json({ code: 404, msg: '商品不存在' })
      const product = productRows[0]
      if (product.status !== 'published') return res.json({ code: 400, msg: '商品已下架' })
      if (product.sale_end_time) {
        await checkProductSaleEnd(productId)
        const [updated] = await query('SELECT status FROM mall_products WHERE id=?', [productId])
        if (updated && updated.status !== 'published') return res.json({ code: 400, msg: '商品销售已截止' })
      }

      let price = product.price
      let optionName = ''
      let optionIdVal = optionId || 0
      if (optionIdVal) {
        const optRows = await query('SELECT * FROM mall_product_options WHERE id=? AND product_id=?', [optionIdVal, productId])
        if (optRows.length) { price = optRows[0].price; optionName = optRows[0].name }
      }

      let totalAmount = price * quantity
      if (paymentMethod === 'points') {
        if (optionIdVal) {
          const optRows2 = await query('SELECT points_price FROM mall_product_options WHERE id=?', [optionIdVal])
          if (optRows2.length && optRows2[0].points_price) totalAmount = optRows2[0].points_price * quantity
        } else if (product.points_price) {
          totalAmount = product.points_price * quantity
        }
      }
      const freight = product.freight || 0
      const userRows = await query('SELECT * FROM users WHERE id=?', [userId])
      if (!userRows.length) return res.json({ code: 404, msg: '用户不存在' })
      const user = userRows[0]

      // ===== 优惠券处理 =====
      let couponDiscount = 0
      let couponUsedId = null
      if (userCouponId) {
        const uc = await query('SELECT * FROM user_coupons WHERE id=? AND user_id=?', [userCouponId, userId])
        if (!uc.length) return res.json({ code: 400, msg: '优惠券不存在或不属于您' })
        if (uc[0].status !== 'unused') return res.json({ code: 400, msg: '优惠券已使用或已过期' })

        const now = new Date().toISOString().replace('T', ' ').slice(0, 19)
        if (uc[0].expire_time && uc[0].expire_time < now) {
          await query("UPDATE user_coupons SET status='expired' WHERE id=?", [userCouponId])
          return res.json({ code: 400, msg: '优惠券已过期' })
        }

        const cd = uc[0].coupon_data ? JSON.parse(uc[0].coupon_data) : {}
        const c = await query('SELECT * FROM coupons WHERE id=?', [uc[0].coupon_id])
        if (!c.length) return res.json({ code: 404, msg: '优惠券模板不存在' })

        const scope = c[0].scope || cd.scope || ''
        if (scope && scope !== 'all' && scope !== 'mall') {
          return res.json({ code: 400, msg: '此优惠券不适用于商城场景' })
        }

        const minOrder = Number(c[0].min_order || cd.minOrder || 0)
        if (totalAmount < minOrder) {
          return res.json({ code: 400, msg: `未达到最低消费 ¥${minOrder}` })
        }

        const type = c[0].type || cd.type || ''
        const value = Number(c[0].value || cd.value || 0)
        const maxDisc = Number(c[0].max_discount || cd.maxDiscount || 0)
        const isMultiUse = !!(c[0].is_multi_use)

        const isPointsCoupon = type.includes('points')
        if (isPointsCoupon && paymentMethod !== 'points') {
          return res.json({ code: 400, msg: '此券仅限积分支付时使用' })
        }
        if (!isPointsCoupon && paymentMethod === 'points') {
          return res.json({ code: 400, msg: '此券仅限余额支付时使用' })
        }

        let availableValue = value
        if (isMultiUse) {
          availableValue = uc[0].remaining_value !== null ? Number(uc[0].remaining_value) : value
        }

        if (type === 'fixed' || type.includes('fixed')) {
          couponDiscount = Math.min(availableValue, totalAmount)
        } else if (type === 'percent' || type === 'discount' || type.includes('discount') || type.includes('percent')) {
          if (type.includes('discount') && type.includes('points')) {
            couponDiscount = Math.floor(totalAmount * value / 100 * 100) / 100
          } else {
            couponDiscount = Math.floor(totalAmount * value / 100 * 100) / 100
          }
          if (maxDisc > 0 && couponDiscount > maxDisc) couponDiscount = maxDisc
          couponDiscount = Math.min(couponDiscount, totalAmount)
        } else {
          couponDiscount = Math.min(value, totalAmount)
        }

        const afterRemaining = isMultiUse ? Math.max(0, availableValue - couponDiscount) : null
        if (isMultiUse) {
          if (afterRemaining <= 0) {
            await query(
              `UPDATE user_coupons SET status='used', use_time=?, use_scene='mall', use_order_id=?, use_amount=?, remaining_value=0 WHERE id=?`,
              [now, 0, couponDiscount, userCouponId]
            )
          } else {
            await query(
              `UPDATE user_coupons SET use_time=?, use_scene='mall', use_order_id=?, use_amount=use_amount+?, remaining_value=? WHERE id=?`,
              [now, 0, couponDiscount, afterRemaining, userCouponId]
            )
          }
        } else {
          await query(
            `UPDATE user_coupons SET status='used', use_time=?, use_scene='mall', use_order_id=?, use_amount=?, remaining_value=NULL WHERE id=?`,
            [now, 0, couponDiscount, userCouponId]
          )
        }
        couponUsedId = userCouponId
      }

      const finalAmount = Math.max(0, totalAmount - couponDiscount)

      // ===== 扣款 =====
      if (paymentMethod === 'balance') {
        const currentBalance = Number(user.balance || 0)
        if (currentBalance < finalAmount) {
          if (couponUsedId) {
            await query("UPDATE user_coupons SET status='unused', use_time=NULL, use_scene=NULL, use_order_id=NULL, use_amount=0 WHERE id=?", [couponUsedId])
          }
          return res.json({ code: 400, msg: `余额不足，需要 ¥${finalAmount}，当前余额 ¥${currentBalance}` })
        }
        await query('UPDATE users SET balance=ROUND(balance-?,2) WHERE id=?', [finalAmount, userId])
        await query(
          `INSERT INTO balance_records (user_id, user_name, type, amount, balance, source, description) VALUES (?,?,'expense',?, (SELECT balance FROM users WHERE id=?), '商城购物', ?)`,
          [userId, user.username || '', finalAmount, userId, `购买商品《${product.name || ''}》${couponDiscount > 0 ? ' (优惠券抵扣¥' + couponDiscount + ')' : ''}`]
        )
      } else if (paymentMethod === 'points') {
        const currentPoints = Number(user.points || 0)
        if (currentPoints < finalAmount) {
          if (couponUsedId) {
            await query("UPDATE user_coupons SET status='unused', use_time=NULL, use_scene=NULL, use_order_id=NULL, use_amount=0 WHERE id=?", [couponUsedId])
          }
          return res.json({ code: 400, msg: `积分不足，需要 ${finalAmount} 积分，当前积分 ${currentPoints}` })
        }
        await query('UPDATE users SET points=points-? WHERE id=?', [finalAmount, userId])
        await query(
          `INSERT INTO points_records (user_id, user_name, type, points, balance, source, description) VALUES (?,?,'expense',?, (SELECT points FROM users WHERE id=?), '商城购物', ?)`,
          [userId, user.username || '', finalAmount, userId, `购买商品《${product.name || ''}》${couponDiscount > 0 ? ' (优惠券抵扣' + couponDiscount + '积分)' : ''}`]
        )
      }

      // ===== 创建订单（已支付） =====
      const orderNo = genOrderNo()
      const orderResult = await query(
        `INSERT INTO mall_orders (order_no, user_id, status, total_amount, freight, payment_method, discount_amount, remark, user_custom_fields, payment_time, create_time, update_time)
         VALUES (?,?,?,?,?,?,?,?,?,${nowExpr},${nowExpr},${nowExpr})`,
        [orderNo, userId, 'paid', totalAmount, freight, paymentMethod, couponDiscount, remark, JSON.stringify(userCustomFields || {})]
      )
      const orderId = orderResult.insertId

      await query(
        `INSERT INTO mall_order_items (order_id, product_id, option_id, product_name, option_name, price, quantity, image, virtual_content)
         VALUES (?,?,?,?,?,?,?,?,?)`,
        [orderId, productId, optionIdVal, product.name, optionName, price, quantity, product.cover_image || '', product.virtual_content || '']
      )

      // ===== 销量 + 库存 =====
      await query('UPDATE mall_products SET sales_count = sales_count + ? WHERE id=?', [quantity, productId])
      if (optionIdVal) {
        await query('UPDATE mall_product_options SET stock = stock - ? WHERE id=? AND stock >= ?', [quantity, optionIdVal, quantity])
      } else {
        await query('UPDATE mall_products SET stock = stock - ? WHERE id=? AND stock >= ?', [quantity, productId, quantity])
      }

      // ===== 虚拟商品自动发货 =====
      let deliveryInfo = ''
      if (product.product_type && product.product_type.startsWith('virtual')) {
        const item = { id: orderId, product_id: productId, option_id: optionIdVal, quantity }
        deliveryInfo = await autoDeliver(item, product, user)
        if (deliveryInfo) {
          await query('UPDATE mall_order_items SET virtual_content=? WHERE order_id=?', [deliveryInfo, orderId])
        }
      }

      // ===== 系统通知 =====
      const sysOp = await getSystemOperator()
      const sysOpName = (sysOp && sysOp.username) ? sysOp.username : '管理员'
      const unit = paymentMethod === 'balance' ? '元' : '积分'
      let notifyContent = `您已成功购买《${product.name || ''}》，支付 ${finalAmount}${unit}`
      if (couponDiscount > 0) {
        notifyContent += `（优惠券抵扣 ${couponDiscount}${unit}）`
      }
      if (deliveryInfo) {
        notifyContent += `\n发货内容：${deliveryInfo}`
      }
      try {
        await query(
          `INSERT INTO sys_notifications (from_user_id, from_user_name, target_user_id, title, content, type, create_time)
           VALUES (?,?,?,?,?,'system',${nowExpr})`,
          [sysOp && sysOp.id ? sysOp.id : 1, sysOpName, userId, `购买商品《${product.name || ''}》`, notifyContent]
        )
      } catch {}

      res.json({ code: 200, msg: '支付成功', data: {
        id: orderId, orderNo,
        productType: product.product_type || '',
        deliveryInfo
      }})
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  router.post('/api/mall/orders/:id/pay', authRequired, async (req, res) => {
    try {
      const { paymentMethod = 'balance', userCouponId } = req.body
      const userId = req.user?.userId

      const orderRows = await query('SELECT * FROM mall_orders WHERE id=? AND user_id=?', [req.params.id, userId])
      if (!orderRows.length) return res.json({ code: 404, msg: '订单不存在' })
      const order = orderRows[0]
      if (order.status !== 'pending') return res.json({ code: 400, msg: '订单状态不允许支付' })

      const items = await query('SELECT * FROM mall_order_items WHERE order_id=?', [req.params.id])
      if (!items.length) return res.json({ code: 400, msg: '订单无商品' })
      const item = items[0]

      const productRows = await query('SELECT * FROM mall_products WHERE id=?', [item.product_id])
      if (!productRows.length) return res.json({ code: 404, msg: '商品不存在' })
      const product = productRows[0]
      const priceType = product.price_type || 'balance'
      let totalAmount = Number(order.total_amount)

      const userRows = await query('SELECT * FROM users WHERE id=?', [userId])
      if (!userRows.length) return res.json({ code: 404, msg: '用户不存在' })
      const user = userRows[0]

      // 优惠券验证与使用
      let couponDiscount = 0
      let couponUsedId = null
      if (userCouponId) {
        const uc = await query('SELECT * FROM user_coupons WHERE id=? AND user_id=?', [userCouponId, userId])
        if (!uc.length) return res.json({ code: 400, msg: '优惠券不存在或不属于您' })
        if (uc[0].status !== 'unused') return res.json({ code: 400, msg: '优惠券已使用或已过期' })

        const now = new Date().toISOString().replace('T', ' ').slice(0, 19)
        if (uc[0].expire_time && uc[0].expire_time < now) {
          await query("UPDATE user_coupons SET status='expired' WHERE id=?", [userCouponId])
          return res.json({ code: 400, msg: '优惠券已过期' })
        }

        const cd = uc[0].coupon_data ? JSON.parse(uc[0].coupon_data) : {}
        const c = await query('SELECT * FROM coupons WHERE id=?', [uc[0].coupon_id])
        if (!c.length) return res.json({ code: 404, msg: '优惠券模板不存在' })

        const scope = c[0].scope || cd.scope || ''
        if (scope && scope !== 'all' && scope !== 'mall') {
          return res.json({ code: 400, msg: '此优惠券不适用于商城场景' })
        }

        const minOrder = Number(c[0].min_order || cd.minOrder || 0)
        if (totalAmount < minOrder) {
          return res.json({ code: 400, msg: `未达到最低消费 ¥${minOrder}` })
        }

        const type = c[0].type || cd.type || ''
        const value = Number(c[0].value || cd.value || 0)
        const maxDisc = Number(c[0].max_discount || cd.maxDiscount || 0)
        const isMultiUse = !!(c[0].is_multi_use)

        const isPointsCoupon = type.includes('points')
        const actualPayType = paymentMethod || 'balance'
        if (isPointsCoupon && actualPayType !== 'points') {
          return res.json({ code: 400, msg: '此券仅限积分支付时使用' })
        }
        if (!isPointsCoupon && actualPayType === 'points') {
          return res.json({ code: 400, msg: '此券仅限余额支付时使用' })
        }

        let availableValue = value
        if (isMultiUse) {
          availableValue = uc[0].remaining_value !== null ? Number(uc[0].remaining_value) : value
        }

        if (type === 'fixed' || type.includes('fixed')) {
          couponDiscount = Math.min(availableValue, totalAmount)
        } else if (type === 'percent' || type === 'discount' || type.includes('discount') || type.includes('percent')) {
          if (type.includes('discount') && type.includes('points')) {
            couponDiscount = Math.floor(totalAmount * value / 100 * 100) / 100
          } else {
            couponDiscount = Math.floor(totalAmount * value / 100 * 100) / 100
          }
          if (maxDisc > 0 && couponDiscount > maxDisc) couponDiscount = maxDisc
          couponDiscount = Math.min(couponDiscount, totalAmount)
        } else {
          couponDiscount = Math.min(value, totalAmount)
        }

        const afterRemaining = isMultiUse ? Math.max(0, availableValue - couponDiscount) : null
        if (isMultiUse) {
          if (afterRemaining <= 0) {
            await query(
              `UPDATE user_coupons SET status='used', use_time=?, use_scene='mall', use_order_id=?, use_amount=?, remaining_value=0 WHERE id=?`,
              [now, req.params.id, couponDiscount, userCouponId]
            )
          } else {
            await query(
              `UPDATE user_coupons SET use_time=?, use_scene='mall', use_order_id=?, use_amount=use_amount+?, remaining_value=? WHERE id=?`,
              [now, req.params.id, couponDiscount, afterRemaining, userCouponId]
            )
          }
        } else {
          await query(
            `UPDATE user_coupons SET status='used', use_time=?, use_scene='mall', use_order_id=?, use_amount=?, remaining_value=NULL WHERE id=?`,
            [now, req.params.id, couponDiscount, userCouponId]
          )
        }
        couponUsedId = userCouponId
      }

      const finalAmount = Math.max(0, totalAmount - couponDiscount)

      if (paymentMethod === 'balance') {
        const currentBalance = Number(user.balance || 0)
        if (currentBalance < finalAmount) {
          if (couponUsedId) {
            await query("UPDATE user_coupons SET status='unused', use_time=NULL, use_scene=NULL, use_order_id=NULL, use_amount=0 WHERE id=?", [couponUsedId])
          }
          return res.json({ code: 400, msg: `余额不足，需要 ¥${finalAmount}，当前余额 ¥${currentBalance}` })
        }
        await query('UPDATE users SET balance=ROUND(balance-?,2) WHERE id=?', [finalAmount, userId])
        await query(
          `INSERT INTO balance_records (user_id, user_name, type, amount, balance, source, description) VALUES (?,?,'expense',?, (SELECT balance FROM users WHERE id=?), '商城购物', ?)`,
          [userId, user.username || '', finalAmount, userId, `购买商品《${product.name || ''}》${couponDiscount > 0 ? ' (优惠券抵扣¥' + couponDiscount + ')' : ''}`]
        )
      } else if (paymentMethod === 'points') {
        const currentPoints = Number(user.points || 0)
        if (currentPoints < finalAmount) {
          if (couponUsedId) {
            await query("UPDATE user_coupons SET status='unused', use_time=NULL, use_scene=NULL, use_order_id=NULL, use_amount=0 WHERE id=?", [couponUsedId])
          }
          return res.json({ code: 400, msg: `积分不足，需要 ${finalAmount} 积分，当前积分 ${currentPoints}` })
        }
        await query('UPDATE users SET points=points-? WHERE id=?', [finalAmount, userId])
        await query(
          `INSERT INTO points_records (user_id, user_name, type, points, balance, source, description) VALUES (?,?,'expense',?, (SELECT points FROM users WHERE id=?), '商城购物', ?)`,
          [userId, user.username || '', finalAmount, userId, `购买商品《${product.name || ''}》${couponDiscount > 0 ? ' (优惠券抵扣' + couponDiscount + '积分)' : ''}`]
        )
      }

      await query(
        `UPDATE mall_orders SET status='paid', payment_method=?, payment_time=${nowExpr}, update_time=${nowExpr}${couponDiscount > 0 ? `, discount_amount=${couponDiscount}` : ''} WHERE id=?`,
        [paymentMethod, req.params.id]
      )

      // Increase sales count
      await query('UPDATE mall_products SET sales_count = sales_count + ? WHERE id=?', [Number(item.quantity), item.product_id])

      // 减规格库存
      if (item.option_id) {
        await query('UPDATE mall_product_options SET stock = stock - ? WHERE id=? AND stock >= ?', [Number(item.quantity), item.option_id, Number(item.quantity)])
      } else {
        await query('UPDATE mall_products SET stock = stock - ? WHERE id=? AND stock >= ?', [Number(item.quantity), item.product_id, Number(item.quantity)])
      }

      // 处理虚拟商品自动发货
      let deliveryInfo = ''
      if (product.product_type && product.product_type.startsWith('virtual')) {
        deliveryInfo = await autoDeliver(item, product, user)
        if (deliveryInfo) {
          await query(
            `UPDATE mall_order_items SET virtual_content=? WHERE id=?`,
            [deliveryInfo, item.id]
          )
        }
      }

      // 发送系统通知
      const sysOp = await getSystemOperator()
      const sysOpName = (sysOp && sysOp.username) ? sysOp.username : '管理员'
      const unit = paymentMethod === 'balance' ? '元' : '积分'
      let notifyContent = `您已成功购买《${product.name || ''}》，支付 ${finalAmount}${unit}`
      if (couponDiscount > 0) {
        notifyContent += `（优惠券抵扣 ${couponDiscount}${unit}）`
      }
      if (deliveryInfo) {
        notifyContent += `\n发货内容：${deliveryInfo}`
      }
      await query(
        `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar)
         VALUES (?, ?, 'system', ?, 0, ?, '')`,
        ['商城购买成功', notifyContent, userId, sysOpName]
      )

      // 发送邮件通知
      if (user.email) {
        try {
          const emailCfg = await query("SELECT * FROM email_config WHERE enabled=1 LIMIT 1")
          if (emailCfg.length && emailCfg[0].host) {
            const nodemailer = require('nodemailer')
            const cfg = emailCfg[0]
            const transporter = nodemailer.createTransport({
              host: cfg.host, port: cfg.port, secure: !!cfg.secure,
              auth: { user: cfg.user, pass: cfg.password }
            })
            await transporter.sendMail({
              from: cfg.from_address || cfg.user,
              to: user.email,
              subject: '商城购买成功通知',
              text: `您已成功购买《${product.name || ''}》，支付 ${totalAmount}${unit}${deliveryInfo ? '\n发货内容：' + deliveryInfo : ''}`
            })
          }
        } catch {}
      }

      res.json({
        code: 200, msg: '购买成功',
        data: { id: order.id, orderNo: order.order_no, productType: product.product_type, deliveryInfo }
      })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  router.get('/api/mall/orders', async (req, res) => {
    try {
      const { keyword, status, page = 1, pageSize = 20 } = req.query
      let where = '1=1'; const params = []
      if (keyword) { where += ' AND (o.order_no LIKE ? OR o.receiver_name LIKE ? OR o.receiver_phone LIKE ?)'; params.push(`%${keyword}%`, `%${keyword}%`, `%${keyword}%`) }
      if (status) { where += ' AND o.status=?'; params.push(status) }

      const [countRows, listRows] = await Promise.all([
        query(`SELECT COUNT(*) as total FROM mall_orders o WHERE ${where}`, params),
        query(
          `SELECT o.*, u.username as user_name, u.avatar as user_avatar
           FROM mall_orders o LEFT JOIN users u ON o.user_id=u.id
           WHERE ${where} ORDER BY o.id DESC LIMIT ? OFFSET ?`,
          [...params, Number(pageSize), (Number(page) - 1) * Number(pageSize)]
        )
      ])

      const orders = []
      for (const o of listRows) {
        const items = await query('SELECT * FROM mall_order_items WHERE order_id=?', [o.id])
        orders.push({
          ...o, orderNo: o.order_no, userId: o.user_id, userName: o.user_name, userAvatar: o.user_avatar,
          totalAmount: o.total_amount, paymentMethod: o.payment_method, paymentTime: o.payment_time,
          receiverName: o.receiver_name, receiverPhone: o.receiver_phone, receiverAddress: o.receiver_address,
          logisticsCompany: o.logistics_company, logisticsNo: o.logistics_no,
          userCustomFields: safeJSON(o.user_custom_fields), createTime: o.create_time, updateTime: o.update_time,
          items: items.map(it => ({
            ...it, orderId: it.order_id, productId: it.product_id, optionId: it.option_id,
            productName: it.product_name, optionName: it.option_name, virtualContent: it.virtual_content
          }))
        })
      }
      res.json({ code: 200, data: { list: orders, total: countRows[0]?.total || 0, page: Number(page), pageSize: Number(pageSize) } })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // 用户自己的商城订单列表
  router.get('/api/mall/orders/my', async (req, res) => {
    try {
      const userId = req.query.userId || req.user?.userId || 0
      const { page = 1, pageSize = 20 } = req.query
      const [countRows, listRows] = await Promise.all([
        query('SELECT COUNT(*) as total FROM mall_orders WHERE user_id=?', [userId]),
        query(
          'SELECT * FROM mall_orders WHERE user_id=? ORDER BY id DESC LIMIT ? OFFSET ?',
          [userId, Number(pageSize), (Number(page) - 1) * Number(pageSize)]
        )
      ])

      const orders = []
      for (const o of listRows) {
        const items = await query('SELECT * FROM mall_order_items WHERE order_id=?', [o.id])
        orders.push({
          ...o, orderNo: o.order_no, userId: o.user_id, totalAmount: o.total_amount,
          paymentMethod: o.payment_method, paymentTime: o.payment_time,
          receiverName: o.receiver_name, receiverPhone: o.receiver_phone, receiverAddress: o.receiver_address,
          logisticsCompany: o.logistics_company, logisticsNo: o.logistics_no,
          userCustomFields: safeJSON(o.user_custom_fields), createTime: o.create_time, updateTime: o.update_time,
          items: items.map(it => ({
            ...it, orderId: it.order_id, productId: it.product_id, optionId: it.option_id,
            productName: it.product_name, optionName: it.option_name, virtualContent: it.virtual_content
          }))
        })
      }
      res.json({ code: 200, data: { list: orders, total: countRows[0]?.total || 0, page: Number(page), pageSize: Number(pageSize) } })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  router.get('/api/mall/orders/:id', async (req, res) => {
    try {
      const [rows] = await Promise.all([
        query('SELECT * FROM mall_orders WHERE id=?', [req.params.id])
      ])
      if (!rows.length) return res.json({ code: 404, msg: '订单不存在' })
      const o = rows[0]
      const items = await query('SELECT * FROM mall_order_items WHERE order_id=?', [o.id])
      const logistics = await query('SELECT * FROM mall_order_logistics WHERE order_id=? ORDER BY id DESC', [o.id])
      res.json({ code: 200, data: {
        ...o, orderNo: o.order_no, userId: o.user_id, totalAmount: o.total_amount,
        paymentMethod: o.payment_method, paymentTime: o.payment_time,
        receiverName: o.receiver_name, receiverPhone: o.receiver_phone, receiverAddress: o.receiver_address,
        logisticsCompany: o.logistics_company, logisticsNo: o.logistics_no,
        userCustomFields: safeJSON(o.user_custom_fields), createTime: o.create_time, updateTime: o.update_time,
        items: items.map(it => ({
          ...it, orderId: it.order_id, productId: it.product_id, optionId: it.option_id,
          productName: it.product_name, optionName: it.option_name, virtualContent: it.virtual_content
        })),
        logistics
      }})
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  router.put('/api/mall/orders/:id/status', async (req, res) => {
    try {
      const { status, logisticsCompany, logisticsNo } = req.body
      if (logisticsCompany || logisticsNo) {
        await query(
          `UPDATE mall_orders SET status=?, logistics_company=?, logistics_no=?, update_time=${nowExpr} WHERE id=?`,
          [status, logisticsCompany || '', logisticsNo || '', req.params.id]
        )
        await query(
          `INSERT INTO mall_order_logistics (order_id, company, tracking_no, status) VALUES (?,?,?,?)`,
          [req.params.id, logisticsCompany || '', logisticsNo || '', 'shipped']
        )
      } else {
        await query(`UPDATE mall_orders SET status=?, update_time=${nowExpr} WHERE id=?`, [status, req.params.id])
      }
      res.json({ code: 200, msg: '更新成功' })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // ==================== 售后 ====================
  router.get('/api/mall/after-sales', async (req, res) => {
    try {
      const { status, page = 1, pageSize = 20 } = req.query
      let where = '1=1'; const params = []
      if (status) { where += ' AND a.status=?'; params.push(status) }

      const [countRows, listRows] = await Promise.all([
        query(`SELECT COUNT(*) as total FROM mall_after_sales a WHERE ${where}`, params),
        query(
          `SELECT a.*, o.order_no, u.username as user_name
           FROM mall_after_sales a
           LEFT JOIN mall_orders o ON a.order_id=o.id
           LEFT JOIN users u ON a.user_id=u.id
           WHERE ${where} ORDER BY a.id DESC LIMIT ? OFFSET ?`,
          [...params, Number(pageSize), (Number(page) - 1) * Number(pageSize)]
        )
      ])
      res.json({
        code: 200, data: {
          list: listRows.map(a => ({
            ...a, id: a.id, orderId: a.order_id, orderItemId: a.order_item_id, userId: a.user_id,
            userName: a.user_name, orderNo: a.order_no, type: a.type, reason: a.reason,
            description: a.description, images: safeJSON(a.images), amount: a.amount, status: a.status,
            sellerReply: a.seller_reply, sellerReplyTime: a.seller_reply_time,
            createTime: a.create_time, updateTime: a.update_time
          })),
          total: countRows[0]?.total || 0
        }
      })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  router.put('/api/mall/after-sales/:id', async (req, res) => {
    try {
      const { status, sellerReply } = req.body
      await query(
        `UPDATE mall_after_sales SET status=?, seller_reply=?, seller_reply_time=${nowExpr}, update_time=${nowExpr} WHERE id=?`,
        [status, sellerReply || '', req.params.id]
      )
      res.json({ code: 200, msg: '处理成功' })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // ==================== 优惠活动 ====================
  router.get('/api/mall/promotions', async (req, res) => {
    try {
      const rows = await query(
        `SELECT * FROM mall_promotions ORDER BY id DESC`
      )
      res.json({ code: 200, data: rows.map(p => ({
        ...p, type: p.type, discountValue: p.discount_value, minAmount: p.min_amount,
        userTypes: safeJSON(p.user_types), startTime: p.start_time, endTime: p.end_time,
        createTime: p.create_time
      })) })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  router.post('/api/mall/promotions', async (req, res) => {
    try {
      const b = req.body
      const r = await query(
        `INSERT INTO mall_promotions (name,type,discount_value,min_amount,user_types,start_time,end_time,status) VALUES (?,?,?,?,?,?,?,?)`,
        [b.name, b.type || 'discount', b.discountValue || 0, b.minAmount || 0,
         JSON.stringify(b.userTypes || []), b.startTime || null, b.endTime || null, b.status || '1']
      )
      const pid = r.insertId
      await savePromotionRelations(pid, b)
      res.json({ code: 200, msg: '创建成功', data: { id: pid } })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  router.put('/api/mall/promotions/:id', async (req, res) => {
    try {
      const b = req.body; const id = req.params.id
      await query(
        `UPDATE mall_promotions SET name=?,type=?,discount_value=?,min_amount=?,user_types=?,start_time=?,end_time=?,status=? WHERE id=?`,
        [b.name, b.type || 'discount', b.discountValue || 0, b.minAmount || 0,
         JSON.stringify(b.userTypes || []), b.startTime || null, b.endTime || null, b.status || '1', id]
      )
      await savePromotionRelations(id, b)
      res.json({ code: 200, msg: '更新成功' })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  router.delete('/api/mall/promotions/:id', async (req, res) => {
    try {
      await Promise.all([
        query('DELETE FROM mall_promotions WHERE id=?', [req.params.id]),
        query('DELETE FROM mall_promotion_gifts WHERE promotion_id=?', [req.params.id]),
        query('DELETE FROM mall_promotion_products WHERE promotion_id=?', [req.params.id])
      ])
      res.json({ code: 200, msg: '删除成功' })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  async function savePromotionRelations(promotionId, body) {
    await query('DELETE FROM mall_promotion_gifts WHERE promotion_id=?', [promotionId])
    if (body.gifts && body.gifts.length) {
      for (const g of body.gifts) {
        await query(
          `INSERT INTO mall_promotion_gifts (promotion_id,gift_type,gift_value,gift_detail) VALUES (?,?,?,?)`,
          [promotionId, g.giftType || 'points', g.giftValue || 0, JSON.stringify(g.giftDetail || {})]
        )
      }
    }
    await query('DELETE FROM mall_promotion_products WHERE promotion_id=?', [promotionId])
    if (body.productIds && body.productIds.length) {
      for (const pid of body.productIds) {
        await query(`INSERT IGNORE INTO mall_promotion_products (promotion_id,product_id) VALUES (?,?)`, [promotionId, pid])
      }
    }
  }

  // ==================== 评论 ====================
  router.get('/api/mall/reviews', optionalAuth, async (req, res) => {
    try {
      const { productId, page = 1, pageSize = 20 } = req.query
      let where = '1=1'; const params = []
      if (productId) { where += ' AND r.product_id=?'; params.push(productId) }

      const [countRows, listRows, levels] = await Promise.all([
        query(`SELECT COUNT(*) as total FROM mall_reviews r WHERE ${where}`, params),
        query(
          `SELECT r.*,
            u.username as user_name, u.avatar as user_avatar,
            u.nickname as user_nickname, u.is_verified as user_verified,
            u.verified_org as user_verified_org, u.level_name as user_member_level,
            u.active_title_name as user_title_name, u.experience as user_experience,
            oi.option_name as order_option_name,
            o.receiver_address as order_address
          FROM mall_reviews r
          LEFT JOIN users u ON r.user_id=u.id
          LEFT JOIN mall_order_items oi ON r.order_id = oi.order_id AND r.product_id = oi.product_id
          LEFT JOIN mall_orders o ON r.order_id = o.id
          WHERE ${where} ORDER BY r.create_time DESC LIMIT ? OFFSET ?`,
          [...params, Number(pageSize), (Number(page) - 1) * Number(pageSize)]
        ),
        query('SELECT * FROM experience_levels WHERE status=? ORDER BY exp_required ASC', ['1'])
      ])

      const userId = req.user?.userId || req.user?.id || 0
      let likedIds = new Set()
      if (userId) {
        const likeRows = await query('SELECT review_id FROM mall_review_likes WHERE user_id=?', [userId])
        likedIds = new Set(likeRows.map(l => l.review_id))
      }

      const expLevels = levels || []
      const getUserExpLevel = (exp) => {
        let lv = 1
        for (const el of expLevels) {
          if (exp >= el.exp_required) lv = el.level
        }
        return lv
      }

      const extractCity = (address) => {
        if (!address) return ''
        const m = address.match(/([\u4e00-\u9fa5]{2,3})(?:省|市|区|县)/)
        return m ? m[1] + (address.includes('省') ? '省' : '市') : address.slice(0, 6)
      }

      res.json({ code: 200, data: {
        list: listRows.map(r => ({
          ...r, id: r.id, productId: r.product_id, userId: r.user_id, orderId: r.order_id,
          userName: (r.user_nickname || r.user_name || '') || '',
          userAvatar: r.user_avatar || '',
          userNickname: r.user_nickname || '',
          userVerified: !!r.user_verified,
          userVerifiedOrg: r.user_verified_org || '',
          userMemberLevel: r.user_member_level || '',
          userTitleName: r.user_title_name || '',
          userExpLevel: getUserExpLevel(r.user_experience || 0),
          userExperience: r.user_experience || 0,
          optionName: r.order_option_name || '',
          location: extractCity(r.order_address),
          dimProductRating: r.dim_product_rating || 5,
          dimServiceRating: r.dim_service_rating || 5,
          dimLogisticsRating: r.dim_logistics_rating || 5,
          rating: r.rating, content: r.content, images: safeJSON(r.images),
          reply: r.reply, replyTime: r.reply_time, createTime: r.create_time,
          likeCount: r.like_count || 0,
          liked: likedIds.has(r.id)
        })),
        total: countRows[0]?.total || 0
      }})
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  router.get('/api/mall/reviews/check', authRequired, async (req, res) => {
    try {
      const { productId } = req.query
      const userId = req.user?.id || req.user?.userId || 0
      if (!productId) return res.json({ code: 400, msg: '缺少productId' })
      const orders = await query(
        `SELECT o.id, o.status FROM mall_orders o
         INNER JOIN mall_order_items oi ON oi.order_id = o.id
         WHERE o.user_id = ? AND oi.product_id = ? AND o.status IN ('paid','shipped','completed','received')
         LIMIT 1`,
        [userId, productId]
      )
      const hasPurchased = orders.length > 0
      const orderId = hasPurchased ? orders[0].id : 0
      const existing = await query(
        'SELECT id FROM mall_reviews WHERE product_id = ? AND user_id = ? LIMIT 1',
        [productId, userId]
      )
      res.json({ code: 200, data: {
        canReview: hasPurchased && existing.length === 0,
        hasPurchased,
        hasReviewed: existing.length > 0,
        orderId
      }})
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  router.put('/api/mall/reviews/:id', authRequired, async (req, res) => {
    try {
      const userId = req.user?.id || req.user?.userId || 0
      const { rating, content, images, dimProductRating, dimServiceRating, dimLogisticsRating } = req.body
      const review = await query('SELECT * FROM mall_reviews WHERE id=? AND user_id=?', [req.params.id, userId])
      if (!review.length) return res.json({ code: 404, msg: '评价不存在或无权修改' })
      const imgs = Array.isArray(images) ? images.slice(0, 3) : []
      const fields = []; const vals = []
      if (rating !== undefined) { fields.push('rating=?'); vals.push(Math.min(5, Math.max(1, rating))) }
      if (content !== undefined) { fields.push('content=?'); vals.push(content) }
      if (images !== undefined) { fields.push('images=?'); vals.push(JSON.stringify(imgs)) }
      if (dimProductRating !== undefined) { fields.push('dim_product_rating=?'); vals.push(Math.min(5, Math.max(1, dimProductRating))) }
      if (dimServiceRating !== undefined) { fields.push('dim_service_rating=?'); vals.push(Math.min(5, Math.max(1, dimServiceRating))) }
      if (dimLogisticsRating !== undefined) { fields.push('dim_logistics_rating=?'); vals.push(Math.min(5, Math.max(1, dimLogisticsRating))) }
      if (!fields.length) return res.json({ code: 400, msg: '没有要更新的字段' })
      await query(`UPDATE mall_reviews SET ${fields.join(',')} WHERE id=?`, [...vals, req.params.id])
      res.json({ code: 200, msg: '评价已更新' })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  router.put('/api/mall/reviews/:id/like', authRequired, async (req, res) => {
    try {
      const reviewId = Number(req.params.id)
      const userId = req.user?.userId || req.user?.id || 0
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const { action } = req.body
      const existing = await query('SELECT id FROM mall_review_likes WHERE review_id=? AND user_id=?', [reviewId, userId])
      const hasLiked = existing.length > 0

      if (action === 'like' && hasLiked) return res.json({ code: 400, msg: '已点过赞' })
      if (action === 'unlike' && !hasLiked) return res.json({ code: 400, msg: '未点过赞' })

      if (action === 'like') {
        await query('INSERT INTO mall_review_likes (review_id, user_id) VALUES (?,?)', [reviewId, userId])
      } else {
        await query('DELETE FROM mall_review_likes WHERE review_id=? AND user_id=?', [reviewId, userId])
      }

      const delta = action === 'unlike' ? -1 : 1
      await query(`UPDATE mall_reviews SET like_count = GREATEST(0, like_count + ?) WHERE id=?`, [delta, reviewId])
      const row = await query(`SELECT like_count FROM mall_reviews WHERE id=?`, [reviewId])
      res.json({ code: 200, data: { likeCount: row[0]?.like_count || 0, liked: action === 'like' } })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  router.post('/api/mall/reviews', authRequired, async (req, res) => {
    try {
      const { productId, rating, content, images, orderId, dimProductRating, dimServiceRating, dimLogisticsRating } = req.body
      const userId = req.user?.id || req.user?.userId || 0
      if (!productId || !rating) return res.json({ code: 400, msg: '缺少必要参数' })
      if (rating < 1 || rating > 5) return res.json({ code: 400, msg: '评分范围1-5' })
      const imgs = Array.isArray(images) ? images.slice(0, 3) : []
      const dp = Math.min(5, Math.max(1, dimProductRating || 5))
      const ds = Math.min(5, Math.max(1, dimServiceRating || 5))
      const dl = Math.min(5, Math.max(1, dimLogisticsRating || 5))
      const result = await query(
        `INSERT INTO mall_reviews (product_id, user_id, order_id, rating, content, images, dim_product_rating, dim_service_rating, dim_logistics_rating) VALUES (?,?,?,?,?,?,?,?,?)`,
        [productId, userId, orderId || 0, rating, content || '', JSON.stringify(imgs), dp, ds, dl]
      )
      res.json({ code: 200, msg: '评价成功', data: { id: result.insertId } })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  router.put('/api/mall/reviews/:id/reply', async (req, res) => {
    try {
      const { reply } = req.body
      await query(`UPDATE mall_reviews SET reply=?, reply_time=${nowExpr} WHERE id=?`, [reply, req.params.id])
      res.json({ code: 200, msg: '回复成功' })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })
}

module.exports = mallRoutes
