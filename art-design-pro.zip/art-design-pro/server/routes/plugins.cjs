const multer = require('multer')
const path = require('path')
const fs = require('fs')
const os = require('os')
const { execSync } = require('child_process')
const { query, getDBProxy } = require('../database.cjs')
const { sessions, SESSION_TTL } = require('./system.cjs')
const { logFromReq } = require('../middleware/security.cjs')
const { eventBus, PluginError } = require('../plugins/event-bus.cjs')
const { scheduler } = require('../plugins/scheduler.cjs')
const { buildPluginContext } = require('../plugins/plugin-context.cjs')
const { slotRegistry, menuRegistry, permRegistry, i18nRegistry, mailRegistry, notifyRegistry } = require('../plugins/registry.cjs')

const PLUGINS_DIR = path.join(__dirname, '..', 'plugins')

if (!fs.existsSync(PLUGINS_DIR)) {
  fs.mkdirSync(PLUGINS_DIR, { recursive: true })
}

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 50 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    if (!file.originalname.endsWith('.zip')) {
      cb(new Error('只支持 .zip 格式的插件安装包'), false)
      return
    }
    cb(null, true)
  }
})

function authRequired(req, res, next) {
  const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '')
  if (!token) return res.status(401).json({ code: 401, msg: '未登录或登录已过期' })
  const session = sessions.get(token)
  if (!session) return res.status(401).json({ code: 401, msg: '未登录或登录已过期' })
  if (Date.now() - session.createdAt > SESSION_TTL) {
    sessions.delete(token)
    return res.status(401).json({ code: 401, msg: '登录已过期，请重新登录' })
  }
  req.user = session
  next()
}

function readManifest(pluginDir) {
  const manifestPath = path.join(pluginDir, 'plugin.json')
  if (!fs.existsSync(manifestPath)) return null
  try {
    return JSON.parse(fs.readFileSync(manifestPath, 'utf-8'))
  } catch {
    return null
  }
}

function validateManifest(manifest) {
  if (!manifest || !manifest.name) return 'plugin.json 缺少 name 字段'
  if (!manifest.version) return 'plugin.json 缺少 version 字段'
  return null
}

function sanitizeDirName(name) {
  return name.replace(/[^a-zA-Z0-9_-]/g, '_').replace(/^_+|_+$/g, '')
}

function removeDirSafe(dirPath) {
  if (!fs.existsSync(dirPath)) return
  const entries = fs.readdirSync(dirPath)
  for (const entry of entries) {
    const fullPath = path.join(dirPath, entry)
    if (fs.lstatSync(fullPath).isDirectory()) {
      removeDirSafe(fullPath)
    } else {
      fs.unlinkSync(fullPath)
    }
  }
  fs.rmdirSync(dirPath)
}

function extractZip(buffer, targetDir) {
  const tmpFile = path.join(os.tmpdir(), `plugin_${Date.now()}_${Math.random().toString(36).slice(2)}.zip`)
  try {
    fs.writeFileSync(tmpFile, buffer)
    execSync(`unzip -o -q "${tmpFile}" -d "${targetDir}"`, { timeout: 30000 })
  } finally {
    try { fs.unlinkSync(tmpFile) } catch {}
  }
}

function getFirstPluginJson(targetDir) {
  function find(dir) {
    const entries = fs.readdirSync(dir)
    for (const entry of entries) {
      if (entry.startsWith('__MACOSX')) continue
      const fullPath = path.join(dir, entry)
      if (fs.lstatSync(fullPath).isDirectory()) {
        const result = find(fullPath)
        if (result) return result
      } else if (entry === 'plugin.json') {
        return fullPath
      }
    }
    return null
  }
  return find(targetDir)
}

function getPluginRootDir(targetDir) {
  const manifestPath = getFirstPluginJson(targetDir)
  if (!manifestPath) return { rootDir: targetDir, manifestPath: null }
  return { rootDir: path.dirname(manifestPath), manifestPath }
}

// 已加载的服务端插件
const loadedServerPlugins = {}

// 已加载插件的 module 引用（用于调用生命周期钩子）
const loadedPluginModules = {}

/**
 * 执行数据库迁移
 */
function runMigrations(db, pluginDir, manifest) {
  if (manifest.extends?.migrations && Array.isArray(manifest.extends.migrations)) {
    for (const mFile of manifest.extends.migrations) {
      const sqlPath = path.join(pluginDir, mFile)
      if (fs.existsSync(sqlPath)) {
        const sql = fs.readFileSync(sqlPath, 'utf-8')
        const statements = sql.split(';').map(s => s.trim()).filter(s => s.length > 0)
        for (const stmt of statements) {
          try { db.exec(stmt) } catch (e) {
            console.warn(`[plugin:${manifest.name}] 迁移语句执行警告:`, e.message)
          }
        }
      }
    }
  }
}

/**
 * 执行已有表的 ALTER 迁移
 */
function runAlterTables(db, pluginDir, manifest) {
  if (manifest.extends?.alterTables) {
    for (const [tableName, statements] of Object.entries(manifest.extends.alterTables)) {
      for (const item of statements) {
        const sql = typeof item === 'string' ? item : item.install
        if (!sql) continue
        try {
          db.exec(sql)
        } catch (e) {
          if (!e.message.includes('duplicate column')) {
            console.warn(`[plugin:${manifest.name}] ALTER TABLE 执行警告:`, e.message)
          }
        }
      }
    }

    // 记录回滚 SQL（用于卸载时恢复）
    const alterRollback = {}
    for (const [tableName, statements] of Object.entries(manifest.extends.alterTables)) {
      alterRollback[tableName] = statements
        .filter(item => typeof item === 'object' && item.uninstall)
        .map(item => item.uninstall)
    }
    manifest._alterRollback = alterRollback
  }
}

/**
 * 执行 ALTER 回滚（卸载时恢复表结构）
 */
function rollbackAlterTables(db, pluginDir, manifest) {
  const rollback = manifest._alterRollback
  if (!rollback) return
  for (const [tableName, statements] of Object.entries(rollback)) {
    for (const sql of statements) {
      try { db.exec(sql) } catch (e) {
        console.warn(`[plugin:${manifest.name}] ALTER 回滚警告:`, e.message)
      }
    }
  }
}

/**
 * 检查插件依赖
 */
function checkDependencies(manifest) {
  if (!manifest.extends?.dependsOn) return null
  for (const [depName, versionRange] of Object.entries(manifest.extends.dependsOn)) {
    const entry = loadedServerPlugins[depName]
    if (!entry) return `缺少依赖插件: "${depName}" (${versionRange})`
    const depVersion = entry.manifest?.version
    if (!depVersion) return `依赖插件 "${depName}" 版本未知`
    if (!versionSatisfies(depVersion, versionRange)) {
      return `依赖插件 "${depName}" 版本不匹配: 需要 ${versionRange}, 当前 ${depVersion}`
    }
  }
  return null
}

function versionSatisfies(current, range) {
  const c = current.split('.').map(Number)
  const op = range.charAt(0)
  let r
  if (op === '^' || op === '~' || op === '>' || op === '<') {
    r = range.slice(op === '^' || op === '~' ? 1 : 0).split('.').map(Number)
  } else {
    r = range.split('.').map(Number)
  }
  if (range.startsWith('>=')) {
    for (let i = 0; i < r.length; i++) {
      if (c[i] > r[i]) return true
      if (c[i] < r[i]) return false
    }
    return true
  }
  if (range.startsWith('^')) {
    return c[0] === r[0] && (c[1] > r[1] || (c[1] === r[1] && c[2] >= r[2]))
  }
  if (range.startsWith('~')) {
    return c[0] === r[0] && c[1] === r[1] && c[2] >= r[2]
  }
  if (range.startsWith('>')) {
    for (let i = 0; i < r.length; i++) {
      if (c[i] > r[i]) return true
      if (c[i] < r[i]) return false
    }
    return false
  }
  // 精确匹配
  return current === range
}

/**
 * 加载服务端插件
 */
function loadServerPlugin(pluginName, app) {
  const manifest = readManifest(path.join(PLUGINS_DIR, sanitizeDirName(pluginName)))
  if (!manifest) return

  const depsError = checkDependencies(manifest)
  if (depsError) {
    console.warn(`[plugin:${pluginName}] ${depsError}`)
    return
  }

  if (!manifest.extends?.serverScript) return

  const pluginDir = path.join(PLUGINS_DIR, sanitizeDirName(pluginName))
  const scriptPath = path.join(pluginDir, manifest.extends.serverScript)

  if (!fs.existsSync(scriptPath)) {
    console.warn(`[plugin:${pluginName}] 服务端脚本不存在: ${scriptPath}`)
    return
  }

  delete require.cache[require.resolve(scriptPath)]
  const mod = require(scriptPath)

  if (typeof mod !== 'function') {
    console.warn(`[plugin:${pluginName}] server.js 必须导出一个函数`)
    return
  }

  const db = getDBProxy()
  const rows = require('../database.cjs').query
    ? null // 用同步方式获取 plugin id
    : null

  // 查询 plugin id
  let pluginId = null
  try {
    const db2 = getDBProxy()
    const rec = db2.prepare('SELECT id FROM plugins WHERE name=?').get(pluginName)
    if (rec) pluginId = rec.id
  } catch (e) { /* 忽略 */ }

  const ctx = buildPluginContext(db, app, manifest, pluginDir, pluginId || 0)

  try {
    const cleanup = mod(ctx)
    loadedServerPlugins[pluginName] = { cleanup, ctx, manifest }
    loadedPluginModules[pluginName] = mod

    // 注册插件的 API 路由
    if (ctx.router && ctx.router.stack && ctx.router.stack.length > 0) {
      const apiPath = manifest.extends?.apiBasePath || `/api/plugin/${pluginName}`
      app.use(apiPath, ctx.router)
    }

    // 注册静态资源
    if (manifest.extends?.serveStatic) {
      const staticPath = path.join(pluginDir, manifest.extends.serveStatic.path)
      const urlPrefix = manifest.extends.serveStatic.urlPrefix || `/plugin-assets/${pluginName}`
      if (fs.existsSync(staticPath)) {
        app.use(urlPrefix, require('express').static(staticPath))
      }
    }

    // 注册 Cron 任务
    if (manifest.extends?.cronJobs) {
      for (const job of manifest.extends.cronJobs) {
        const jobPath = path.join(pluginDir, job.handler)
        if (fs.existsSync(jobPath)) {
          const handler = require(jobPath)
          ctx.scheduler.registerCron({ ...job, handler })
        }
      }
    }

    // 暴露插件 API 给其他插件
    if (typeof mod.exposeAPI === 'object') {
      const { serviceRegistry } = require('../plugins/service-registry.cjs')
      serviceRegistry.register(`_plugin:${pluginName}`, mod.exposeAPI)
    }

    console.log(`[plugin:${pluginName}] 服务端插件已加载`)
  } catch (e) {
    console.error(`[plugin:${pluginName}] 加载失败:`, e.message)
  }
}

/**
 * 卸载服务端插件
 */
function unloadServerPlugin(pluginName) {
  const entry = loadedServerPlugins[pluginName]
  if (entry?.cleanup) {
    try { entry.cleanup() } catch (e) {
      console.error(`[plugin:${pluginName}] 卸载清理出错:`, e.message)
    }
  }

  // 清理暴露的 API
  const { serviceRegistry } = require('../plugins/service-registry.cjs')
  serviceRegistry.register(`_plugin:${pluginName}`, {})

  delete loadedServerPlugins[pluginName]
  delete loadedPluginModules[pluginName]
  console.log(`[plugin:${pluginName}] 服务端插件已卸载`)
}

function pluginsRoutes(router, app) {

  router.get('/api/plugins/list', async (req, res) => {
    try {
      const rows = await query(
        `SELECT id, name, description, version, author, icon, entry_url AS entryUrl,
                component_name AS componentName, plugin_dir AS pluginDir, manifest, status,
                create_time AS createTime
         FROM plugins ORDER BY id DESC`
      )
      const result = rows.map(r => ({
        ...r,
        installed: r.pluginDir ? fs.existsSync(path.join(PLUGINS_DIR, r.pluginDir)) : false
      }))
      res.json({ code: 200, msg: 'success', data: { records: result, current: 1, size: 100, total: result.length } })
    } catch (e) {
      console.error('插件列表查询失败:', e.message)
      res.json({ code: 500, msg: '查询失败: ' + e.message })
    }
  })

  router.post('/api/plugins/upload', authRequired, upload.single('file'), async (req, res) => {
    try {
      if (!req.file) return res.json({ code: 400, msg: '请上传插件安装包' })

      const id = req.body.id ? Number(req.body.id) : null
      const isUpgrade = id && req.body.upgrade === 'true'

      const tmpExtractDir = path.join(os.tmpdir(), `plugin_extract_${Date.now()}`)
      fs.mkdirSync(tmpExtractDir, { recursive: true })

      try {
        extractZip(req.file.buffer, tmpExtractDir)

        const { rootDir, manifestPath } = getPluginRootDir(tmpExtractDir)
        if (!manifestPath) return res.json({ code: 400, msg: '安装包缺少 plugin.json 清单文件' })

        let manifest
        try {
          manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf-8'))
        } catch {
          return res.json({ code: 400, msg: 'plugin.json 格式无效' })
        }

        const validationError = validateManifest(manifest)
        if (validationError) return res.json({ code: 400, msg: validationError })

        const pluginDirName = sanitizeDirName(manifest.name)
        const pluginDir = path.join(PLUGINS_DIR, pluginDirName)

        if (!isUpgrade && fs.existsSync(pluginDir)) {
          return res.json({ code: 400, msg: `插件「${manifest.name}」已安装，如需更新请使用升级功能` })
        }

        if (isUpgrade && fs.existsSync(pluginDir)) {
          // 升级前先卸载旧的
          if (loadedServerPlugins[manifest.name]) {
            unloadServerPlugin(manifest.name)
          }
          removeDirSafe(pluginDir)
        }

        function copyDir(src, dest) {
          fs.mkdirSync(dest, { recursive: true })
          const entries = fs.readdirSync(src)
          for (const entry of entries) {
            const srcPath = path.join(src, entry)
            const destPath = path.join(dest, entry)
            if (fs.lstatSync(srcPath).isDirectory()) {
              copyDir(srcPath, destPath)
            } else {
              fs.copyFileSync(srcPath, destPath)
            }
          }
        }

        copyDir(rootDir, pluginDir)

        // 执行数据库迁移（新建表）
        const db = getDBProxy()
        runMigrations(db, pluginDir, manifest)

        // 执行已有表 ALTER 迁移
        runAlterTables(db, pluginDir, manifest)

        // 重新读取 manifest（可能已被 runAlterTables 修改）
        const updatedManifest = readManifest(pluginDir) || manifest
        const manifestJson = JSON.stringify(updatedManifest)
        const entryUrl = updatedManifest.entryUrl || ''

        let newId = id
        if (isUpgrade && id) {
          await query(
            `UPDATE plugins SET name=?, description=?, version=?, author=?, icon=?, entry_url=?,
             plugin_dir=?, manifest=?, update_time=NOW()
             WHERE id=?`,
            [
              updatedManifest.name, updatedManifest.description || '', updatedManifest.version, updatedManifest.author || '',
              updatedManifest.icon || '', entryUrl, pluginDirName, manifestJson, id
            ]
          )
          logFromReq(req, 'update', 'plugin', id, `升级插件「${updatedManifest.name}」至 v${updatedManifest.version}`)
        } else {
          const result = await query(
            `INSERT INTO plugins (name, description, version, author, icon, entry_url, component_name,
             plugin_dir, manifest, status)
             VALUES (?,?,?,?,?,?,?,?,?,'1')`,
            [
              updatedManifest.name, updatedManifest.description || '', updatedManifest.version, updatedManifest.author || '',
              updatedManifest.icon || '', entryUrl, updatedManifest.name, pluginDirName, manifestJson
            ]
          )
          newId = result.insertId
          logFromReq(req, 'create', 'plugin', newId, `安装插件「${updatedManifest.name}」v${updatedManifest.version}`)
        }

        // 调用 onInstall 钩子
        try {
          const serverScript = updatedManifest.extends?.serverScript
          if (serverScript) {
            const scriptPath = path.join(pluginDir, serverScript)
            if (fs.existsSync(scriptPath)) {
              const mod = require(scriptPath)
              if (typeof mod.onInstall === 'function') {
                mod.onInstall(db, pluginDir)
              }
            }
          }
        } catch (e) {
          console.warn(`[plugin:${updatedManifest.name}] onInstall 钩子出错:`, e.message)
        }

        // 插件安装后自动加载（如果是新安装且 status=1）
        if (!isUpgrade) {
          try {
            loadServerPlugin(updatedManifest.name, app)
          } catch (e) {
            console.warn(`[plugin:${updatedManifest.name}] 自动加载失败:`, e.message)
          }
        }

        eventBus.emit('system:pluginEnabled', { pluginName: updatedManifest.name })

        res.json({
          code: 200,
          msg: isUpgrade ? '插件升级成功' : '插件安装成功',
          data: { id: newId, name: updatedManifest.name, version: updatedManifest.version }
        })
      } finally {
        removeDirSafe(tmpExtractDir)
      }
    } catch (e) {
      console.error('插件上传失败:', e.message)
      res.json({ code: 500, msg: '安装失败: ' + e.message })
    }
  })

  router.put('/api/plugins/:id/toggle', authRequired, async (req, res) => {
    try {
      const id = Number(req.params.id)
      const rows = await query('SELECT id, name, status, plugin_dir AS pluginDir FROM plugins WHERE id=?', [id])
      if (!rows || rows.length === 0) return res.json({ code: 404, msg: '插件不存在' })

      const plugin = rows[0]
      const newStatus = plugin.status === '1' ? '0' : '1'

      if (newStatus === '1' && plugin.pluginDir) {
        const dirPath = path.join(PLUGINS_DIR, plugin.pluginDir)
        if (!fs.existsSync(dirPath)) {
          return res.json({ code: 400, msg: '插件目录不存在，请重新安装此插件' })
        }
        loadServerPlugin(plugin.name, app)
        eventBus.emit('system:pluginEnabled', { pluginName: plugin.name })
      } else if (newStatus === '0') {
        unloadServerPlugin(plugin.name)
        eventBus.emit('system:pluginDisabled', { pluginName: plugin.name })
      }

      await query('UPDATE plugins SET status=? WHERE id=?', [newStatus, id])
      const action = newStatus === '1' ? '启用' : '禁用'
      logFromReq(req, 'update', 'plugin', id, `${action}插件「${plugin.name}」`)
      res.json({ code: 200, msg: `${action}成功`, data: { id, status: newStatus } })
    } catch (e) {
      console.error('切换插件状态失败:', e.message)
      res.json({ code: 500, msg: '操作失败: ' + e.message })
    }
  })

  router.delete('/api/plugins/:id', authRequired, async (req, res) => {
    try {
      const id = Number(req.params.id)
      const rows = await query('SELECT id, name, plugin_dir AS pluginDir FROM plugins WHERE id=?', [id])
      if (!rows || rows.length === 0) return res.json({ code: 404, msg: '插件不存在' })

      const plugin = rows[0]

      // 调用 onUninstall 钩子
      if (loadedPluginModules[plugin.name]) {
        const mod = loadedPluginModules[plugin.name]
        const db = getDBProxy()
        try {
          if (typeof mod.onUninstall === 'function') {
            mod.onUninstall(db)
          }
        } catch (e) {
          console.warn(`[plugin:${plugin.name}] onUninstall 钩子出错:`, e.message)
        }
      }

      // 回滚 ALTER TABLE
      if (plugin.pluginDir) {
        const dirPath = path.join(PLUGINS_DIR, plugin.pluginDir)
        const manifest = readManifest(dirPath)
        if (manifest) {
          const db = getDBProxy()
          rollbackAlterTables(db, dirPath, manifest)
        }
      }

      // 卸载服务端插件
      unloadServerPlugin(plugin.name)

      // 删除插件目录
      if (plugin.pluginDir) {
        const dirPath = path.join(PLUGINS_DIR, plugin.pluginDir)
        removeDirSafe(dirPath)
      }

      await query('DELETE FROM plugins WHERE id=?', [id])
      eventBus.emit('system:pluginDisabled', { pluginName: plugin.name })
      logFromReq(req, 'delete', 'plugin', id, `删除插件「${plugin.name}」`)
      res.json({ code: 200, msg: '删除成功', data: { success: true } })
    } catch (e) {
      console.error('删除插件失败:', e.message)
      res.json({ code: 500, msg: '删除失败: ' + e.message })
    }
  })

  router.post('/api/plugins/:id/upgrade', authRequired, upload.single('file'), async (req, res) => {
    if (!req.file) return res.json({ code: 400, msg: '请上传新版本插件安装包' })

    const id = Number(req.params.id)
    const existing = await query('SELECT id, name FROM plugins WHERE id=?', [id])
    if (!existing || existing.length === 0) return res.json({ code: 404, msg: '插件不存在' })

    req.body = { ...req.body, id, upgrade: 'true' }

    const tmpExtractDir = path.join(os.tmpdir(), `plugin_upgrade_${Date.now()}`)
    fs.mkdirSync(tmpExtractDir, { recursive: true })

    try {
      extractZip(req.file.buffer, tmpExtractDir)

      const { rootDir, manifestPath } = getPluginRootDir(tmpExtractDir)
      if (!manifestPath) return res.json({ code: 400, msg: '安装包缺少 plugin.json 清单文件' })

      let manifest
      try {
        manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf-8'))
      } catch {
        return res.json({ code: 400, msg: 'plugin.json 格式无效' })
      }

      const validationError = validateManifest(manifest)
      if (validationError) return res.json({ code: 400, msg: validationError })

      const pluginDirName = sanitizeDirName(manifest.name)
      const pluginDir = path.join(PLUGINS_DIR, pluginDirName)

      // 升级前卸载
      if (loadedServerPlugins[manifest.name]) {
        unloadServerPlugin(manifest.name)
      }
      if (fs.existsSync(pluginDir)) {
        removeDirSafe(pluginDir)
      }

      function copyDir(src, dest) {
        fs.mkdirSync(dest, { recursive: true })
        const entries = fs.readdirSync(src)
        for (const entry of entries) {
          const srcPath = path.join(src, entry)
          const destPath = path.join(dest, entry)
          if (fs.lstatSync(srcPath).isDirectory()) {
            copyDir(srcPath, destPath)
          } else {
            fs.copyFileSync(srcPath, destPath)
          }
        }
      }

      copyDir(rootDir, pluginDir)

      // 执行迁移
      const db = getDBProxy()
      runMigrations(db, pluginDir, manifest)
      runAlterTables(db, pluginDir, manifest)

      const updatedManifest = readManifest(pluginDir) || manifest
      const manifestJson = JSON.stringify(updatedManifest)
      const entryUrl = updatedManifest.entryUrl || ''

      await query(
        `UPDATE plugins SET name=?, description=?, version=?, author=?, icon=?, entry_url=?,
         plugin_dir=?, manifest=?, update_time=NOW()
         WHERE id=?`,
        [
          updatedManifest.name, updatedManifest.description || '', updatedManifest.version, updatedManifest.author || '',
          updatedManifest.icon || '', entryUrl, pluginDirName, manifestJson, id
        ]
      )

      // 重新加载
      try {
        loadServerPlugin(updatedManifest.name, app)
      } catch (e) {
        console.warn(`[plugin:${updatedManifest.name}] 升级后重新加载失败:`, e.message)
      }

      logFromReq(req, 'update', 'plugin', id, `升级插件「${updatedManifest.name}」至 v${updatedManifest.version}`)
      res.json({ code: 200, msg: '插件升级成功', data: { id, name: updatedManifest.name, version: updatedManifest.version } })
    } catch (e) {
      console.error('插件升级失败:', e.message)
      res.json({ code: 500, msg: '升级失败: ' + e.message })
    } finally {
      removeDirSafe(tmpExtractDir)
    }
  })

  router.put('/api/plugins/:name/config', authRequired, async (req, res) => {
    try {
      const pluginName = req.params.name
      const pluginDirName = sanitizeDirName(pluginName)
      const pluginDir = path.join(PLUGINS_DIR, pluginDirName)
      const manifestPath = path.join(pluginDir, 'plugin.json')

      if (!fs.existsSync(manifestPath)) {
        return res.json({ code: 404, msg: '插件配置文件不存在' })
      }

      const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf-8'))
      const oldConfig = JSON.parse(JSON.stringify(manifest.config || {}))

      manifest.config = req.body.config
      if (req.body.configMeta !== undefined) {
        manifest.configMeta = req.body.configMeta
      }

      fs.writeFileSync(manifestPath, JSON.stringify(manifest, null, 2), 'utf-8')

      await query(
        `UPDATE plugins SET manifest=?, update_time=NOW() WHERE name=?`,
        [JSON.stringify(manifest), pluginName]
      )

      // 触发 onConfigSave 钩子
      if (loadedPluginModules[pluginName]) {
        const mod = loadedPluginModules[pluginName]
        const db = getDBProxy()
        try {
          if (typeof mod.onConfigSave === 'function') {
            mod.onConfigSave(oldConfig, req.body.config, db)
          }
        } catch (e) {
          console.warn(`[plugin:${pluginName}] onConfigSave 钩子出错:`, e.message)
        }
      }

      // 触发系统事件
      eventBus.emit('system:configChange', {
        pluginName,
        oldConfig,
        newConfig: req.body.config
      })

      logFromReq(req, 'update', 'plugin', pluginName, `更新插件「${pluginName}」配置`)
      res.json({ code: 200, msg: '配置已保存', data: { success: true } })
    } catch (e) {
      console.error('保存插件配置失败:', e.message)
      res.json({ code: 500, msg: '保存失败: ' + e.message })
    }
  })

  router.get('/api/plugins/inject', async (req, res) => {
    try {
      const rows = await query(
        `SELECT id, name, version, plugin_dir AS pluginDir
         FROM plugins WHERE status='1' ORDER BY id`
      )

      const result = []
      for (const plugin of rows) {
        const dirPath = plugin.pluginDir ? path.join(PLUGINS_DIR, plugin.pluginDir) : null
        if (!dirPath || !fs.existsSync(dirPath)) continue

        const manifest = readManifest(dirPath)
        if (!manifest) continue

        result.push({
          id: plugin.id,
          name: plugin.name,
          version: plugin.version,
          config: manifest.config || null,
          styles: (manifest.styles || []).map(f => {
            const fp = path.join(dirPath, f)
            return fs.existsSync(fp) ? fs.readFileSync(fp, 'utf-8') : ''
          }).filter(Boolean),
          scripts: (manifest.scripts || []).map(f => {
            const fp = path.join(dirPath, f)
            return fs.existsSync(fp) ? fs.readFileSync(fp, 'utf-8') : ''
          }).filter(Boolean)
        })
      }

      // 附带前端扩展数据（slots、menus、i18n、dashboard widgets）
      const frontendExtras = {
        slots: slotRegistry.getAll(),
        menus: menuRegistry.getMenus(),
        dashboardWidgets: menuRegistry.getDashboardWidgets(),
        i18nBundles: i18nRegistry.getAllBundles(),
        globalStyles: slotRegistry.getStyles()
      }

      res.json({ code: 200, data: result, frontend: frontendExtras })
    } catch (e) {
      console.error('获取插件注入资源失败:', e.message)
      res.json({ code: 500, msg: e.message, data: [] })
    }
  })

  router.get('/api/plugins/:id/detail', authRequired, async (req, res) => {
    try {
      const id = Number(req.params.id)
      const rows = await query(
        `SELECT id, name, description, version, author, icon, entry_url AS entryUrl,
                component_name AS componentName, plugin_dir AS pluginDir, manifest,
                status, create_time AS createTime
         FROM plugins WHERE id=?`, [id]
      )
      if (!rows || rows.length === 0) return res.json({ code: 404, msg: '插件不存在' })
      res.json({ code: 200, data: rows[0] })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ===== 插件系统管理 API =====

  // 获取所有插件扩展数据（供前端管理页面使用）
  router.get('/api/plugins/extensions/state', authRequired, async (req, res) => {
    res.json({
      code: 200,
      data: {
        loadedPlugins: Object.keys(loadedServerPlugins),
        registeredEvents: eventBus.eventNames(),
        schedulerStatus: scheduler.getStatus(),
        menuCounts: {
          adminSidebar: menuRegistry.getMenus().adminSidebar.length,
          userDropdown: menuRegistry.getMenus().userDropdown.length,
          dashboardWidgets: menuRegistry.getDashboardWidgets().length
        },
        slotCount: slotRegistry.getAll().length,
        permissionNodes: permRegistry.getAllNodes().length,
        i18nBundles: i18nRegistry.getAllBundles().length
      }
    })
  })
}

module.exports = pluginsRoutes
