const { query, dbType } = require('../database.cjs')

function userRoutes(router) {
  // GET /api/user/list
  router.get('/api/user/list', async (req, res) => {
    try {
      const { current = 1, size = 20, userName, userPhone, status } = req.query
      const page = parseInt(current) || 1
      const pageSize = parseInt(size) || 20
      const offset = (page - 1) * pageSize

      let where = ['1=1']
      let params = []
      if (userName) { where.push('username LIKE ?'); params.push(`%${userName}%`) }
      if (userPhone) { where.push('phone LIKE ?'); params.push(`%${userPhone}%`) }
      if (status) { where.push('status = ?'); params.push(status) }

      const whereClause = where.join(' AND ')

      let totalRow
      if (dbType === 'sqlite') {
        const rows = await query(`SELECT COUNT(*) as total FROM users WHERE ${whereClause}`, params)
        totalRow = rows[0]
      } else {
        const rows = await query(`SELECT COUNT(*) as total FROM users WHERE ${whereClause}`, params)
        totalRow = rows[0]
      }
      const total = totalRow.total

      const records = await query(
        `SELECT id, username as userName, phone as userPhone, email as userEmail,
                gender as userGender, avatar, status, points, level_id as level, level_name as levelName,
                expire_time as expireTime, roles as userRoles, nickname, bio, balance, experience,
                create_time as createTime, update_time as updateTime
         FROM users WHERE ${whereClause} ORDER BY id DESC LIMIT ${pageSize} OFFSET ${offset}`,
        params
      )

      const list = records.map(r => {
        try { r.userRoles = typeof r.userRoles === 'string' ? JSON.parse(r.userRoles) : (r.userRoles || []) } catch { r.userRoles = [] }
        return r
      })

      res.json({ code: 200, msg: 'success', data: { records: list, current: page, size: pageSize, total } })
    } catch (e) {
      console.error('用户列表查询失败:', e.message)
      res.json({ code: 500, msg: '查询失败: ' + e.message })
    }
  })

  // POST /api/user/update
  router.post('/api/user/update', async (req, res) => {
    try {
      const { id, username, phone, gender, role, points, level_id, expireTime, password, nickname, bio, balance, email, experience } = req.body
      if (!id) return res.json({ code: 400, msg: '缺少用户ID' })

      const users = await query('SELECT * FROM users WHERE id = ?', [Number(id)])
      if (!users || users.length === 0) return res.json({ code: 404, msg: '用户不存在' })

      const sets = []
      const params = []

      if (username) { sets.push('username = ?'); params.push(username) }
      if (phone) { sets.push('phone = ?'); params.push(phone) }
      if (gender) { sets.push('gender = ?'); params.push(gender) }
      if (role) { sets.push('roles = ?'); params.push(JSON.stringify(Array.isArray(role) ? role : [role])) }
      if (points !== undefined) { sets.push('points = ?'); params.push(Number(points)) }
      if (level_id !== undefined) {
        const lvs = await query('SELECT id, name FROM membership_levels WHERE id = ?', [Number(level_id)])
        const lv = lvs && lvs.length > 0 ? lvs[0] : null
        sets.push('level_id = ?'); params.push(Number(level_id))
        sets.push('level_name = ?'); params.push(lv ? lv.name : '普通会员')
      }
      if (expireTime !== undefined) {
        let exp = expireTime || null
        if (exp && typeof exp === 'string' && exp.includes('T')) {
          exp = exp.replace('T', ' ').replace(/\.\d{3}Z$/, '').replace(/Z$/, '')
        }
        sets.push('expire_time = ?'); params.push(exp)
      }
      if (password && password.trim()) { sets.push('password = ?'); params.push(password) }
      if (nickname !== undefined) { sets.push('nickname = ?'); params.push(nickname) }
      if (bio !== undefined) { sets.push('bio = ?'); params.push(bio) }
      if (balance !== undefined) { sets.push('balance = ?'); params.push(Number(balance)) }
      if (email !== undefined) { sets.push('email = ?'); params.push(email) }
      if (experience !== undefined) {
        sets.push('experience = ?'); params.push(Number(experience))
        if (level_id === undefined) {
          const expLvs = await query(
            "SELECT id, name, level FROM experience_levels WHERE exp_required <= ? AND status='1' ORDER BY exp_required DESC LIMIT 1",
            [Number(experience)]
          )
          const expLv = expLvs && expLvs.length > 0 ? expLvs[0] : null
          if (expLv) {
            sets.push('level_id = ?'); params.push(Number(expLv.id))
            sets.push('level_name = ?'); params.push(expLv.name)
          }
        }
      }

      if (sets.length === 0) return res.json({ code: 200, msg: '无更新字段', data: { success: true } })

      const nowExpr = dbType === 'mysql' ? 'NOW()' : "datetime('now','localtime')"
      sets.push(`update_time = ${nowExpr}`)
      params.push(Number(id))
      await query(`UPDATE users SET ${sets.join(', ')} WHERE id = ?`, params)

      res.json({ code: 200, msg: '更新成功', data: { success: true } })
    } catch (e) {
      console.error('用户更新失败:', e.message)
      res.json({ code: 500, msg: '更新失败: ' + e.message })
    }
  })

  // POST /api/user/create
  router.post('/api/user/create', async (req, res) => {
    try {
      const { username, phone, gender, role, points, level_id, expireTime, nickname, bio, balance, email, experience } = req.body
      if (!username) return res.json({ code: 400, msg: '缺少用户名' })

      const existing = await query('SELECT id FROM users WHERE username = ?', [username])
      if (existing && existing.length > 0) return res.json({ code: 400, msg: '用户名已存在' })

      let levelName = '普通会员'
      if (level_id !== undefined && level_id > 0) {
        const lvs = await query('SELECT id, name FROM membership_levels WHERE id = ?', [Number(level_id)])
        if (lvs && lvs.length > 0) levelName = lvs[0].name
      }

      let exp = expireTime || null
      if (exp && typeof exp === 'string' && exp.includes('T')) {
        exp = exp.replace('T', ' ').replace(/\.\d{3}Z$/, '').replace(/Z$/, '')
      }

      const result = await query(
        `INSERT INTO users (username, phone, gender, roles, points, level_id, level_name, expire_time, nickname, bio, balance, email, experience)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [username, phone || '', gender || '男',
         JSON.stringify(Array.isArray(role) ? role : []),
         points !== undefined ? Number(points) : 0,
         level_id !== undefined ? Number(level_id) : 0,
         levelName,
         exp,
         nickname || '',
         bio || '',
         balance !== undefined ? Number(balance) : 0,
         email || '',
         experience !== undefined ? Number(experience) : 0]
      )

      res.json({ code: 200, msg: '添加成功', data: { id: result.lastInsertRowid || (result.insertId) } })
    } catch (e) {
      console.error('创建用户失败:', e.message)
      res.json({ code: 500, msg: '创建失败: ' + e.message })
    }
  })

  // DELETE /api/user/:id
  router.delete('/api/user/:id', async (req, res) => {
    try {
      const nowExpr = dbType === 'mysql' ? 'NOW()' : "datetime('now','localtime')"
      await query(`UPDATE users SET status = '4', update_time = ${nowExpr} WHERE id = ?`, [Number(req.params.id)])
      res.json({ code: 200, msg: '注销成功', data: { success: true } })
    } catch (e) {
      console.error('注销用户失败:', e.message)
      res.json({ code: 500, msg: '操作失败: ' + e.message })
    }
  })

  // GET /api/user/profile — 获取用户个人信息
  router.get('/api/user/profile', async (req, res) => {
    try {
      const uid = Number(req.query.userId) || 0
      if (!uid) return res.json({ code: 400, msg: '缺少userId' })

      const rows = await query(
        `SELECT id, username, nickname, avatar, bg_url as bgUrl, signature, bio, gender, phone, qq, email,
                balance, points, experience, level_id as levelId, level_name as levelName,
                show_coin as showCoin, follow_count as followCount, fans_count as fansCount,
                create_time as createTime, roles
         FROM users WHERE id=?`, [uid]
      )
      if (!rows || rows.length === 0) return res.json({ code: 404, msg: '用户不存在' })
      const u = rows[0]
      try { u.roles = typeof u.roles === 'string' ? JSON.parse(u.roles) : (u.roles || []) } catch { u.roles = [] }
      res.json({ code: 200, msg: 'success', data: u })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // PUT /api/user/profile — 更新个人信息
  router.put('/api/user/profile', async (req, res) => {
    try {
      const uid = Number(req.body.userId) || 0
      if (!uid) return res.json({ code: 400, msg: '缺少userId' })

      const { nickname, avatar, signature, bio, gender, phone, qq, email, bgUrl } = req.body
      const updates = []
      const params = []
      if (nickname !== undefined) { updates.push('nickname=?'); params.push(nickname) }
      if (avatar !== undefined) { updates.push('avatar=?'); params.push(avatar) }
      if (signature !== undefined) { updates.push('signature=?'); params.push(signature) }
      if (bio !== undefined) { updates.push('bio=?'); params.push(bio) }
      if (gender !== undefined) { updates.push('gender=?'); params.push(gender) }
      if (phone !== undefined) { updates.push('phone=?'); params.push(phone) }
      if (qq !== undefined) { updates.push('qq=?'); params.push(qq) }
      if (email !== undefined) { updates.push('email=?'); params.push(email) }
      if (bgUrl !== undefined) { updates.push('bg_url=?'); params.push(bgUrl) }

      if (updates.length === 0) return res.json({ code: 400, msg: '无更新内容' })

      const nowExpr = dbType === 'mysql' ? 'NOW()' : "datetime('now','localtime')"
      updates.push(`update_time=${nowExpr}`)
      params.push(uid)
      await query(`UPDATE users SET ${updates.join(',')} WHERE id=?`, params)
      res.json({ code: 200, msg: '更新成功', data: {} })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // GET /api/user/comments — 获取用户评论记录
  router.get('/api/user/comments', async (req, res) => {
    try {
      const { userId, page = 1, pageSize = 20 } = req.query
      const uid = Number(userId) || 0
      if (!uid) return res.json({ code: 400, msg: '缺少userId' })
      const offset = (Number(page) - 1) * Number(pageSize)
      const rows = await query(
        `SELECT c.id, c.app_id as appId, a.name as appName, c.content, c.likes, c.rating, c.create_time as createTime
         FROM app_comments c LEFT JOIN app_store a ON c.app_id=a.id
         WHERE c.user_id=? AND c.parent_id=0
         ORDER BY c.create_time DESC LIMIT ? OFFSET ?`,
        [uid, Number(pageSize), offset]
      )
      const [tc] = await query(
        `SELECT COUNT(*) as total FROM app_comments WHERE user_id=? AND parent_id=0`, [uid]
      )
      res.json({ code: 200, msg: 'success', data: { list: rows, total: tc?.total || 0 } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // POST /api/auth/change-pwd — 修改密码
  router.post('/api/auth/change-pwd', async (req, res) => {
    try {
      const { userId, oldPwd, newPwd } = req.body
      const users = await query('SELECT id, password FROM users WHERE id=?', [Number(userId)])
      if (!users || users.length === 0) return res.json({ code: 404, msg: '用户不存在' })
      if (users[0].password !== oldPwd) return res.json({ code: 400, msg: '原密码错误' })
      await query('UPDATE users SET password=? WHERE id=?', [newPwd, Number(userId)])
      res.json({ code: 200, msg: '密码修改成功', data: {} })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // GET /api/user/apps — 获取用户发布的应用
  router.get('/api/user/apps', async (req, res) => {
    try {
      const uid = Number(req.query.userId) || 0
      const rows = await query(
        `SELECT id, name, icon, icon_bg_color as iconBgColor, category, downloads, rating,
                coin_count as coinCount, coin_people as coinPeople, developer, create_time as createTime
         FROM app_store WHERE user_id=? OR developer=(SELECT username FROM users WHERE id=?)
         ORDER BY create_time DESC`,
        [uid, uid]
      )
      res.json({ code: 200, msg: 'success', data: { list: rows } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })
  // POST /api/user/delete-request — 用户申请注销账号
  router.post('/api/user/delete-request', async (req, res) => {
    try {
      const { userId } = req.body
      const uid = Number(userId) || 0
      if (!uid) return res.json({ code: 400, msg: '缺少userId' })
      const [existing] = await query('SELECT id FROM user_delete_requests WHERE user_id=? AND status="pending"', [uid])
      if (existing) return res.json({ code: 400, msg: '已有待审核的注销申请' })
      await query('INSERT INTO user_delete_requests (user_id, username) VALUES (?, (SELECT username FROM users WHERE id=?))', [uid, uid])
      res.json({ code: 200, msg: '注销申请已提交，等待管理员审核' })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // GET /api/user/delete-requests — 管理员查看注销审核列表
  router.get('/api/user/delete-requests', async (req, res) => {
    try {
      const { status } = req.query
      let sql = 'SELECT * FROM user_delete_requests WHERE 1=1'
      const params = []
      if (status) { sql += ' AND status=?'; params.push(status) }
      sql += ' ORDER BY create_time DESC'
      const rows = await query(sql, params)
      res.json({ code: 200, msg: 'success', data: rows })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // POST /api/user/delete-request/:id/review — 管理员审核注销申请
  router.post('/api/user/delete-request/:id/review', async (req, res) => {
    try {
      const { approved, adminNote, adminId } = req.body
      const id = Number(req.params.id)
      const [r] = await query('SELECT * FROM user_delete_requests WHERE id=?', [id])
      if (!r) return res.json({ code: 404, msg: '申请不存在' })
      const newStatus = approved ? 'approved' : 'rejected'
      await query('UPDATE user_delete_requests SET status=?, admin_id=?, admin_note=? WHERE id=?',
        [newStatus, Number(adminId) || 0, adminNote || '', id])
      if (approved) {
        await query('UPDATE users SET status="4" WHERE id=?', [r.user_id])
      }
      res.json({ code: 200, msg: approved ? '已通过注销' : '已拒绝注销' })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })
}

module.exports = userRoutes
