const { query, getSystemOperator } = require('../database.cjs')
const { sessions, SESSION_TTL } = require('./system.cjs')
const nowExpr = 'NOW()'
const { progressTasksByAction } = require('./custom-task.cjs')
const { systemLog } = require('../middleware/security.cjs')
const { emitSafe, POST_EVENTS, COMMENT_EVENTS, SECTION_EVENTS } = require('../plugins/events.cjs')
const { deleteFileRecordsByRef } = require('../utils/file-helper.cjs')
const { sendNotificationEmail, getAdminEmails } = require('./email.cjs')

async function getModeratorEmails(sectionId) {
  try {
    const mods = await query('SELECT u.email FROM community_moderators cm JOIN users u ON cm.user_id=u.id WHERE cm.section_id=? AND u.email IS NOT NULL AND u.email != \'\'', [sectionId])
    return mods.map(m => m.email)
  } catch { return [] }
}

async function getUserEmail(userId) {
  try {
    const rows = await query('SELECT email FROM users WHERE id=?', [userId])
    return rows.length > 0 ? rows[0].email : ''
  } catch { return '' }
}

async function getModeratorEmails(sectionId) {
  try {
    const mods = await query('SELECT u.email FROM community_moderators cm JOIN users u ON cm.user_id=u.id WHERE cm.section_id=? AND u.email IS NOT NULL AND u.email != \'\'', [sectionId])
    return mods.map(m => m.email)
  } catch { return [] }
}

async function getUserEmail(userId) {
  try {
    const rows = await query('SELECT email FROM users WHERE id=?', [userId])
    return rows.length > 0 ? rows[0].email : ''
  } catch { return '' }
}

async function getAdminUserName(req) {
  try {
    const raw = req.headers.authorization || req.headers.token || req.query.token || ''
    const token = raw.replace(/^Bearer\s+/i, '')
    const session = sessions.get(token)
    if (session && session.userName) return session.userName
    const rows = await query('SELECT username FROM users WHERE id=(SELECT user_id FROM sessions WHERE token=?)', [token])
    return rows.length > 0 ? rows[0].username : 'unknown'
  } catch {}
  return 'unknown'
}

async function getUserId(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return 0

  const session = sessions.get(token)
  if (session) {
    if (Date.now() - session.createdAt > SESSION_TTL) {
      sessions.delete(token)
      return 0
    }
    return Number(session.userId) || 0
  }

  // 后端重启后内存 session 丢失，从数据库恢复
  try {
    const rows = await query('SELECT user_id, user_name, roles, created_at FROM sessions WHERE token=?', [token])
    if (rows && rows.length > 0) {
      const row = rows[0]
      const createdAt = typeof row.created_at === 'number' ? row.created_at : new Date(row.created_at).getTime()
      if (Date.now() - createdAt > SESSION_TTL) {
        query('DELETE FROM sessions WHERE token=?', [token]).catch(() => {})
        return 0
      }
      sessions.set(token, { userId: row.user_id, userName: row.user_name, roles: JSON.parse(row.roles || '[]'), createdAt })
      return Number(row.user_id) || 0
    }
  } catch {}

  return 0
}

async function getUserRoles(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return []
  const session = sessions.get(token)
  if (session) return session.roles || []
  try {
    const rows = await query('SELECT roles FROM sessions WHERE token=?', [token])
    if (rows && rows.length > 0) {
      try { return JSON.parse(rows[0].roles || '[]') } catch { return [] }
    }
  } catch {}
  return []
}

async function isAdmin(req) {
  const roles = await getUserRoles(req)
  return roles.some(r => r === 'R_SUPER' || r === 'R_ADMIN')
}

async function isAdminById(userId) {
  if (!userId) return false
  try {
    const rows = await query('SELECT roles FROM users WHERE id=?', [userId])
    if (rows && rows.length > 0) {
      try {
        const roles = typeof rows[0].roles === 'string' ? JSON.parse(rows[0].roles) : (rows[0].roles || [])
        return roles.some(r => r === 'R_SUPER' || r === 'R_ADMIN')
      } catch { return false }
    }
  } catch {}
  return false
}

async function canAccessSection(userId, sectionId) {
  if (!userId) return false
  if (await isAdminById(userId)) return true
  try {
    const rows = await query('SELECT id FROM community_moderators WHERE section_id=? AND user_id=?', [sectionId, userId])
    return rows.length > 0
  } catch { return false }
}

function communityRoutes(app) {

  // ==================== Section APIs ====================

  app.get('/api/community/sections', async (req, res) => {
    try {
      const showAll = req.query.all === 'true' && (await isAdmin(req))
      const where = showAll ? '' : "WHERE status='active'"
      const sections = await query(
        `SELECT id, name, icon, icon_bg_color as iconBgColor, description,
                (SELECT COUNT(*) FROM community_posts WHERE section_id=cs.id) as postCount,
                view_count as viewCount,
                (SELECT COUNT(*) FROM community_posts WHERE section_id=cs.id AND DATE(create_time)=CURDATE()) as todayHeat,
                (SELECT COUNT(*) FROM community_posts WHERE section_id=cs.id) * 100 + view_count as totalHeat,
                sort_order as sortOrder, status, visibility,
                post_permission as postPermission, view_permission as viewPermission,
                view_level_required as viewLevelRequired, create_time as createTime
         FROM community_sections cs ${where} ORDER BY sort_order ASC`
      )
      const userId = await getUserId(req)
      const userRoles = await getUserRoles(req)
      const isUserAdminDB = userRoles.some(r => r === 'R_SUPER' || r === 'R_ADMIN')
      const user = userId ? (await query('SELECT level_name, level_id, is_verified FROM users WHERE id=?', [userId]))[0] : null
      const filtered = []
      for (const s of sections) {
        if (s.visibility === 'restricted' && !(await canAccessSection(userId, s.id))) continue
        if (!isUserAdminDB) {
          const vp = s.viewPermission || 'all'
          if (vp === 'moderator_only') {
            if (!userId || !(await canAccessSection(userId, s.id))) continue
          } else if (vp === 'admin_only') {
            continue
          } else if (vp === 'vip_only') {
            if (!user || !user.level_name || !user.level_name.includes('VIP')) continue
          } else if (vp === 'member_only') {
            if (!user || !user.level_id) continue
          } else if (vp === 'verified_only') {
            if (!user || !user.is_verified) continue
          }
          if (s.viewLevelRequired && s.viewLevelRequired > 0) {
            if (!user || !user.level_id || user.level_id < s.viewLevelRequired) continue
          }
        }
        filtered.push(s)
      }
      res.json({ code: 200, msg: 'success', data: filtered })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== 版主管理 API ====================

  app.get('/api/community/section/:id/moderators', async (req, res) => {
    try {
      const list = await query(
        `SELECT id, section_id as sectionId, user_id as userId, user_name as userName, CASE WHEN user_avatar LIKE 'avatar:%' THEN '' ELSE user_avatar END as userAvatar,
                role, sort_order as sortOrder, create_time as createTime
         FROM community_moderators WHERE section_id=? ORDER BY sort_order ASC, create_time ASC`,
        [req.params.id]
      )
      res.json({ code: 200, msg: 'success', data: list })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/section/:id/moderator', async (req, res) => {
    try {
      const { userId, userName, userAvatar, role } = req.body
      if (!userId) return res.json({ code: 400, msg: '缺少userId' })
      const existing = await query(
        'SELECT id FROM community_moderators WHERE section_id=? AND user_id=?',
        [req.params.id, userId]
      )
      if (existing.length) {
        await query(
          'UPDATE community_moderators SET user_name=?, user_avatar=?, role=? WHERE section_id=? AND user_id=?',
          [userName||'', userAvatar||'', role||'版主', req.params.id, userId]
        )
      } else {
        await query(
          'INSERT INTO community_moderators (section_id, user_id, user_name, user_avatar, role) VALUES (?,?,?,?,?)',
          [req.params.id, userId, userName||'', userAvatar||'', role||'版主']
        )
      }
      // 通知用户已成为版主
      try {
        const modUser = await query('SELECT username, email FROM users WHERE id=?', [userId])
        if (modUser.length > 0 && modUser[0].email) {
          sendNotificationEmail('moderator_apply_result', modUser[0].email, {
            username: modUser[0].username || '',
            subject: '版主申请通过',
            content: `恭喜，您已被任命为板块版主（${role || '版主'}）。`
          })
        }
      } catch {}
      res.json({ code: 200, msg: 'success' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.delete('/api/community/section/:id/moderator/:userId', async (req, res) => {
    try {
      await query('DELETE FROM community_moderators WHERE section_id=? AND user_id=?',
        [req.params.id, req.params.userId])
      // 通知用户版主身份已被移除
      try {
        const removedMod = await query('SELECT username, email FROM users WHERE id=?', [req.params.userId])
        if (removedMod.length > 0 && removedMod[0].email) {
          sendNotificationEmail('moderator_removed', removedMod[0].email, {
            username: removedMod[0].username || '',
            subject: '版主身份已移除',
            content: '您的版主身份已被管理员移除。'
          })
        }
      } catch {}
      res.json({ code: 200, msg: '删除成功' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // 查询用户担任版主的所有板块
  app.get('/api/community/user/:userId/moderator-sections', async (req, res) => {
    try {
      const list = await query(
        `SELECT m.section_id as sectionId, m.role, s.name as sectionName, s.icon_bg_color as iconBgColor
         FROM community_moderators m
         LEFT JOIN community_sections s ON m.section_id = s.id
         WHERE m.user_id=?`,
        [req.params.userId]
      )
      res.json({ code: 200, msg: 'success', data: list })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.get('/api/community/section/:id', async (req, res) => {
    try {
      const section = await query(
        `SELECT id, name, icon, icon_bg_color as iconBgColor, description,
                today_heat as todayHeat, total_heat as totalHeat,
                post_count as postCount, view_count as viewCount,
                sort_order as sortOrder, status, visibility, create_time as createTime
         FROM community_sections WHERE id=?`, [req.params.id]
      )
      if (!section || section.length === 0) {
        return res.json({ code: 404, msg: '板块不存在' })
      }
      const s = section[0]
      if (s.visibility === 'restricted') {
        const userId = await getUserId(req)
        if (!(await canAccessSection(userId, s.id))) {
          return res.json({ code: 403, msg: '无权限访问此板块' })
        }
      }
      res.json({ code: 200, msg: 'success', data: s })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/section', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const { id, name, icon, iconBgColor, description, todayHeat, totalHeat, postCount, viewCount, sortOrder, status, visibility, postPermission, viewPermission, viewLevelRequired } = req.body

      if (id) {
        await query(
          `UPDATE community_sections SET name=?, icon=?, icon_bg_color=?, description=?,
           today_heat=?, total_heat=?, post_count=?, view_count=?, sort_order=?, status=?, visibility=?,
           post_permission=?, view_permission=?, view_level_required=?
           WHERE id=?`,
          [name, icon || '', iconBgColor || '#00BFA5', description || '',
           todayHeat || 0, totalHeat || 0, postCount || 0, viewCount || 0,
           sortOrder || 0, status || 'active', visibility || 'public',
           postPermission || 'all', viewPermission || 'all', viewLevelRequired || 0, id]
        )
        emitSafe(SECTION_EVENTS.UPDATED, { sectionId: id, name })
        res.json({ code: 200, msg: '更新成功', data: { id } })
      } else {
        const result = await query(
          `INSERT INTO community_sections (name, icon, icon_bg_color, description, today_heat, total_heat, post_count, view_count, sort_order, status, visibility, post_permission, view_permission, view_level_required)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
          [name, icon || '', iconBgColor || '#00BFA5', description || '',
           todayHeat || 0, totalHeat || 0, postCount || 0, viewCount || 0,
           sortOrder || 0, status || 'active', visibility || 'public',
           postPermission || 'all', viewPermission || 'all', viewLevelRequired || 0]
        )
        const sectionId = result.insertId
        emitSafe(SECTION_EVENTS.CREATED, { sectionId, name })
        res.json({ code: 200, msg: '创建成功', data: { id: sectionId } })
      }
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.delete('/api/community/section/:id', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      await query('DELETE FROM community_sections WHERE id=?', [req.params.id])
      emitSafe(SECTION_EVENTS.DELETED, { sectionId: Number(req.params.id) })
      res.json({ code: 200, msg: '删除成功' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== Post APIs ====================

  app.get('/api/community/posts', async (req, res) => {
    try {
      const { sectionId, sort = 'latest', page = 1, pageSize = 20, keyword, tags, userId, viewerId, status: statusFilter, followed } = req.query
      const queryUserId = Number(userId) || 0
      const queryViewerId = Number(viewerId) || 0
      const authUserId = await getUserId(req)
      const effectiveViewerId = queryViewerId || queryUserId
      const blockViewerId = queryViewerId || authUserId
      const isAdminUser = authUserId ? await isAdminById(authUserId) : false

      let followedUserIds = null
      if (followed) {
        const authUserId = await getUserId(req)
        if (authUserId) {
          const follows = await query('SELECT following_id FROM user_follows WHERE follower_id=?', [authUserId])
          if (follows.length > 0) {
            followedUserIds = follows.map(f => f.following_id)
          }
        }
      }

      let sql = `SELECT p.id, p.section_id as sectionId, p.topic_id as topicId, p.user_id as userId, p.user_name as userName,
                  CASE WHEN u.avatar LIKE 'avatar:%' THEN '' ELSE COALESCE(NULLIF(u.avatar,''), p.user_avatar, '') END as userAvatar, p.title, p.content, p.device, p.tags, p.official_tags as officialTags,
                  p.images, p.has_resource as hasResource, p.resource_type as resourceType,
                  p.resource_url as resourceUrl, p.resource_price as resourcePrice,
                  p.resource_price_type as resourcePriceType, p.extract_code as extractCode,
                  p.content_permission as contentPermission, p.content_price as contentPrice,
                  p.content_price_type as contentPriceType,
                  p.permission, p.is_pinned as isPinned, p.is_essence as isEssence,
                p.is_hot as isHot, p.is_locked as isLocked, p.status, p.like_count as likeCount,
                  p.comment_count as commentCount, p.coin_count as coinCount,
                  p.view_count as viewCount, p.favorite_count as favoriteCount,
                  p.is_global_pinned as isGlobalPinned,
                  p.custom_badge as customBadge,
                  p.reject_reason as rejectReason,
                  p.create_time as createTime, p.update_time as updateTime,
                   u.level_name as userLevelName, u.is_verified as userIsVerified,
                   COALESCE((SELECT el.name FROM experience_levels el WHERE el.exp_required <= u.experience AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1), 'Lv.1') as userExpLevelName,
                   (SELECT el.icon FROM experience_levels el WHERE el.exp_required <= u.experience AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1) as userExpLevelIcon,
                   COALESCE((SELECT el.text_color FROM experience_levels el WHERE el.exp_required <= u.experience AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1), '#FFFFFF') as userExpLevelTextColor,
                   COALESCE((SELECT el.bg_color FROM experience_levels el WHERE el.exp_required <= u.experience AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1), '#508DFF') as userExpLevelBgColor,
                  COALESCE(ml.text_color, '#508DFF') as userLevelTextColor,
                  COALESCE(ml.bg_color, '#508DFF') as userLevelBgColor,
                  ml.name as userMemberLevelName, ml.icon as userMemberLevelIcon,
                 u.active_title_name as userTitleName,
                   ct.icon as userTitleIcon, ct.color as userTitleColor, ct.bg_color as userTitleBgColor,
                   (SELECT GROUP_CONCAT(ct2.icon SEPARATOR '|||') FROM user_titles ut2 JOIN custom_titles ct2 ON ut2.title_id = ct2.id WHERE ut2.user_id = u.id AND ct2.status='1' AND ct2.icon IS NOT NULL AND ct2.icon != '') as userAllTitleIcons,
                   tp.name as topicName,
                   (SELECT GROUP_CONCAT(pt.topic_id) FROM community_post_topics pt WHERE pt.post_id = p.id) as topicIds,
                   (SELECT GROUP_CONCAT(t.name SEPARATOR '|||') FROM community_post_topics pt JOIN community_topics t ON pt.topic_id = t.id WHERE pt.post_id = p.id) as topicNames
                 FROM community_posts p LEFT JOIN users u ON p.user_id = u.id LEFT JOIN membership_levels ml ON ml.id = u.level_id LEFT JOIN custom_titles ct ON ct.id = u.active_title_id LEFT JOIN community_topics tp ON p.topic_id = tp.id WHERE `
      const params = []

      if (statusFilter) {
        sql += 'p.status=?'
        params.push(statusFilter)
      } else if (queryUserId) {
        sql += "(p.status='published' OR (p.user_id=? AND p.status!='deleted'))"
        params.push(queryUserId)
      } else {
        sql += "p.status='published'"
      }

      if (sectionId) { sql += ' AND (p.section_id=? OR p.is_global_pinned=1)'; params.push(sectionId) }
      if (queryUserId) { sql += ' AND p.user_id=?'; params.push(queryUserId) }
      if (keyword) { sql += ' AND (p.title LIKE ? OR p.content LIKE ?)'; params.push(`%${keyword}%`, `%${keyword}%`) }
      if (tags) {
        const tagList = tags.split(',')
        for (const t of tagList) {
          sql += ' AND p.tags LIKE ?'
          params.push(`%${t.trim()}%`)
        }
      }

      // 过滤受限板块的帖子
      if (!isAdminUser) {
        const restrictedSections = await query('SELECT id FROM community_sections WHERE visibility=?', ['restricted'])
        if (restrictedSections.length > 0) {
          const restrictedIds = restrictedSections.map(s => s.id)
          let accessibleIds = []
          if (queryUserId) {
            const modRows = await query(
              `SELECT section_id FROM community_moderators WHERE user_id=? AND section_id IN (${restrictedIds.map(() => '?').join(',')})`,
              [queryUserId, ...restrictedIds]
            )
            accessibleIds = modRows.map(r => r.section_id)
          }
          const inaccessibleIds = restrictedIds.filter(id => !accessibleIds.includes(id))
          if (inaccessibleIds.length > 0) {
            sql += ` AND p.section_id NOT IN (${inaccessibleIds.map(() => '?').join(',')})`
            params.push(...inaccessibleIds)
          }
        }
      }

      // 关注筛选：仅显示关注用户的帖子
      if (followed) {
        if (followedUserIds && followedUserIds.length > 0) {
          sql += ` AND p.user_id IN (${followedUserIds.map(() => '?').join(',')})`
          params.push(...followedUserIds)
        } else {
          sql += ' AND 1=0'
        }
      }

      // 拉黑过滤：当前用户不看到拉黑自己的人的内容，也不看到被自己拉黑的人的内容
      if (blockViewerId && blockViewerId > 0) {
        const { getBlockedUserIds, getBlockerUserIds } = require('./user-block.cjs')
        const blockedIds = await getBlockedUserIds(blockViewerId)
        const blockerIds = await getBlockerUserIds(blockViewerId)
        const excludeIds = [...new Set([...blockedIds, ...blockerIds])]
        if (excludeIds.length > 0) {
          sql += ` AND p.user_id NOT IN (${excludeIds.map(() => '?').join(',')})`
          params.push(...excludeIds)
        }
      }

      let orderBy = ''
      switch (sort) {
        case 'recent_reply': orderBy = 'p.is_global_pinned DESC, p.update_time DESC'; break
        case 'most_likes': orderBy = 'p.is_global_pinned DESC, p.like_count DESC'; break
        case 'most_favorites': orderBy = 'p.is_global_pinned DESC, p.favorite_count DESC'; break
        case 'essence': orderBy = 'p.is_global_pinned DESC, p.is_essence DESC, p.id DESC'; break
        case 'hot': orderBy = 'p.is_global_pinned DESC, p.is_hot DESC, p.is_essence DESC, p.comment_count DESC, p.id DESC'; break
        case 'pinned': orderBy = 'p.is_global_pinned DESC, p.is_pinned DESC, p.id DESC'; break
        default: orderBy = 'p.is_global_pinned DESC, p.is_pinned DESC, p.id DESC'
      }

      const offset = (parseInt(page) - 1) * parseInt(pageSize)
      const countResult = await query(`SELECT COUNT(*) as total FROM (${sql}) t`, params)
      const total = countResult[0]?.total || 0

      const list = await query(sql + ` ORDER BY ${orderBy} LIMIT ${parseInt(pageSize)} OFFSET ${offset}`, params)
      for (const item of list) {
        try { item.tags = item.tags ? JSON.parse(item.tags) : [] } catch { item.tags = [] }
        try { item.officialTags = item.officialTags ? JSON.parse(item.officialTags) : [] } catch { item.officialTags = [] }
        try { item.images = item.images ? JSON.parse(item.images) : [] } catch { item.images = [] }
        item.isPinned = !!item.isPinned
        item.isEssence = !!item.isEssence
        item.isHot = !!item.isHot
        item.isGlobalPinned = !!item.isGlobalPinned
        // 解析多话题ID和名称
        item.topicIds = item.topicIds ? item.topicIds.split(',').map(Number) : []
        item.topicNames = item.topicNames ? item.topicNames.split('|||').filter(Boolean) : []
      }

      if (Number(userId) && list.length > 0) {
        try {
          const postIds = list.map(p => p.id)
          const likedRows = await query(
            `SELECT post_id FROM community_likes WHERE user_id=? AND post_id IN (${postIds.map(() => '?').join(',')})`,
            [Number(userId), ...postIds]
          )
          const favoritedRows = await query(
            `SELECT post_id FROM community_favorites WHERE user_id=? AND post_id IN (${postIds.map(() => '?').join(',')})`,
            [Number(userId), ...postIds]
          )
          const likedSet = new Set(likedRows.map(r => r.post_id))
          const favSet = new Set(favoritedRows.map(r => r.post_id))
          for (const item of list) {
            item.isLiked = likedSet.has(item.id)
            item.isFavorited = favSet.has(item.id)
          }
        } catch {}
      }

      // 过滤付费内容：非作者/非管理员/未购买的用户，隐藏付费帖子的内容
      if (list.length > 0) {
        try {
          const paidPosts = list.filter(p => p.contentPermission && p.contentPermission !== 'public')
          if (paidPosts.length > 0) {
            const paidIds = paidPosts.map(p => p.id)
            const paidSet = new Set()
            if (effectiveViewerId) {
              const purchases = await query(
                `SELECT content_id FROM content_purchases WHERE content_type='post' AND user_id=? AND content_id IN (${paidIds.map(() => '?').join(',')})`,
                [effectiveViewerId, ...paidIds]
              )
              purchases.forEach(p => paidSet.add(p.content_id))
            }
            const isViewerAdmin = effectiveViewerId ? await isAdminById(effectiveViewerId) : false
            for (const item of paidPosts) {
              if (effectiveViewerId && (item.userId === effectiveViewerId || isViewerAdmin)) continue
              if (paidSet.has(item.id)) continue
              const perm = item.contentPermission || 'paid'
              const hints = {
                paid: '部分内容付费 - 需购买后查看',
                comment: '评论后可见',
                level: '需达到一定等级后查看',
                password: '需密码查看',
                mixed: '部分内容付费 - 需购买后查看'
              }
              item.content = hints[perm] || hints.paid
              item.contentFiltered = true
              try { item.images = [] } catch {}
            }
          }
        } catch {}
      }

      res.json({ code: 200, msg: 'success', data: { list, total, page: parseInt(page), pageSize: parseInt(pageSize) } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.get('/api/community/post/:id', async (req, res) => {
    try {
      const { userId } = req.query
      const queryUserId = Number(userId) || 0
      const post = await query(
        `SELECT p.id, p.section_id as sectionId, p.topic_id as topicId, p.user_id as userId, p.user_name as userName,
                CASE WHEN u.avatar LIKE 'avatar:%' THEN '' ELSE COALESCE(NULLIF(u.avatar,''), p.user_avatar, '') END as userAvatar, p.title, p.content, p.device, p.tags, p.official_tags as officialTags,
                p.images, p.has_resource as hasResource, p.resource_type as resourceType,
                p.resource_url as resourceUrl, p.resource_price as resourcePrice,
                p.resource_price_type as resourcePriceType, p.extract_code as extractCode,
                p.content_permission as contentPermission, p.content_price as contentPrice,
                p.content_price_type as contentPriceType,
                p.access_password as accessPassword, p.access_password_tips as accessPasswordTips,
                p.custom_badge as customBadge,
                p.is_pinned as isPinned, p.is_essence as isEssence, p.is_hot as isHot,
                p.is_locked as isLocked, p.is_global_pinned as isGlobalPinned,
                p.like_count as likeCount, p.favorite_count as favoriteCount,
                p.view_count as viewCount, p.comment_count as commentCount,
                p.create_time as createTime, p.update_time as updateTime,
                p.status,
                ct.name as topicName,
                (SELECT COUNT(*) FROM content_purchases WHERE content_type='post' AND content_id=p.id) as soldCount,
                (SELECT GROUP_CONCAT(pt.topic_id) FROM community_post_topics pt WHERE pt.post_id = p.id) as topicIds
         FROM community_posts p LEFT JOIN users u ON p.user_id = u.id LEFT JOIN community_topics ct ON p.topic_id = ct.id WHERE p.id=?`, [req.params.id]
      )
      if (!post || post.length === 0 || post[0].status === 'deleted') {
        return res.json({ code: 404, msg: '帖子不存在' })
      }
      const item = post[0]

      // 检查板块可见性
      const secRows = await query('SELECT visibility FROM community_sections WHERE id=?', [item.sectionId])
      if (secRows.length > 0 && secRows[0].visibility === 'restricted') {
        if (!(await canAccessSection(queryUserId, item.sectionId))) {
          return res.json({ code: 403, msg: '无权限访问此帖子' })
        }
      }

      if (item.status === 'pending' || item.status === 'rejected') {
        const isOwner = item.userId === queryUserId
      const isAdminUser = queryUserId ? await isAdminById(queryUserId) : false
        if (!isOwner && !isAdminUser) {
          return res.json({ code: 404, msg: '帖子不存在' })
        }
      }
      try { item.tags = item.tags ? JSON.parse(item.tags) : [] } catch { item.tags = [] }
      try { item.officialTags = item.officialTags ? JSON.parse(item.officialTags) : [] } catch { item.officialTags = [] }
      try { item.images = item.images ? JSON.parse(item.images) : [] } catch { item.images = [] }
      item.isPinned = !!item.isPinned
      item.isEssence = !!item.isEssence
      item.isHot = !!item.isHot
      item.isGlobalPinned = !!item.isGlobalPinned
      item.topicIds = item.topicIds ? item.topicIds.split(',').map(Number) : []

      // 浏览数+1，同时检查是否达到15000自动设为热帖（未被管理员手动禁用的）
      await query(
        `UPDATE community_posts SET view_count = view_count + 1,
         is_hot = CASE WHEN view_count + 1 >= 15000 AND hot_manually_disabled = 0 THEN 1 ELSE is_hot END
         WHERE id=?`,
        [Number(req.params.id)]
      )

      {
        const updated = await query('SELECT is_hot, view_count FROM community_posts WHERE id=?', [Number(req.params.id)])
        if (updated.length > 0) {
          item.isHot = !!updated[0].is_hot
          item.viewCount = updated[0].view_count
        }
      }

      if (queryUserId > 0) await progressTasksByAction(queryUserId, '', 'view_post')

      const comments = await query(
        `SELECT c.id, c.post_id as postId, c.parent_id as parentId, c.user_id as userId,
                c.user_name as userName, CASE WHEN u.avatar LIKE 'avatar:%' THEN '' ELSE COALESCE(NULLIF(u.avatar,''), c.user_avatar, '') END as userAvatar, c.content,
                c.like_count as likeCount, c.reply_count as replyCount, c.create_time as createTime,
                u.is_verified as userIsVerified,
                COALESCE((SELECT el.name FROM experience_levels el WHERE el.exp_required <= u.experience AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1), 'Lv.1') as userExpLevelName,
                (SELECT el.icon FROM experience_levels el WHERE el.exp_required <= u.experience AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1) as userExpLevelIcon,
                COALESCE((SELECT el.text_color FROM experience_levels el WHERE el.exp_required <= u.experience AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1), '#FFFFFF') as userExpLevelTextColor,
                COALESCE((SELECT el.bg_color FROM experience_levels el WHERE el.exp_required <= u.experience AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1), '#508DFF') as userExpLevelBgColor,
                u.active_title_name as userTitleName,
                ct.icon as userTitleIcon, ct.color as userTitleColor, ct.bg_color as userTitleBgColor
         FROM community_comments c LEFT JOIN users u ON c.user_id = u.id LEFT JOIN custom_titles ct ON ct.id = u.active_title_id WHERE c.post_id=? AND c.parent_id=0 ORDER BY c.create_time DESC`,
        [req.params.id]
      )
      const allReplies = await query(
        `SELECT c.id, c.post_id as postId, c.parent_id as parentId, c.user_id as userId,
                c.user_name as userName, CASE WHEN u.avatar LIKE 'avatar:%' THEN '' ELSE COALESCE(NULLIF(u.avatar,''), c.user_avatar, '') END as userAvatar, c.content,
                c.like_count as likeCount, c.reply_count as replyCount, c.create_time as createTime,
                u.is_verified as userIsVerified,
                COALESCE((SELECT el.name FROM experience_levels el WHERE el.exp_required <= u.experience AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1), 'Lv.1') as userExpLevelName,
                (SELECT el.icon FROM experience_levels el WHERE el.exp_required <= u.experience AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1) as userExpLevelIcon,
                COALESCE((SELECT el.text_color FROM experience_levels el WHERE el.exp_required <= u.experience AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1), '#FFFFFF') as userExpLevelTextColor,
                COALESCE((SELECT el.bg_color FROM experience_levels el WHERE el.exp_required <= u.experience AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1), '#508DFF') as userExpLevelBgColor,
                u.active_title_name as userTitleName,
                ct.icon as userTitleIcon, ct.color as userTitleColor, ct.bg_color as userTitleBgColor
         FROM community_comments c LEFT JOIN users u ON c.user_id = u.id LEFT JOIN custom_titles ct ON ct.id = u.active_title_id WHERE c.post_id=? AND c.parent_id>0 ORDER BY c.create_time ASC`,
        [req.params.id]
      )
      const replyMap = {}
      for (const r of allReplies) {
        if (!replyMap[r.parentId]) replyMap[r.parentId] = []
        replyMap[r.parentId].push(r)
      }
      for (const c of comments) {
        c.replies = replyMap[c.id] || []
      }
      item.comments = comments

      if (Number(userId)) {
        try {
          const liked = await query(
            'SELECT id FROM community_likes WHERE post_id=? AND user_id=?',
            [req.params.id, Number(userId)]
          )
          item.isLiked = liked.length > 0
          const faved = await query(
            'SELECT id FROM community_favorites WHERE post_id=? AND user_id=?',
            [req.params.id, Number(userId)]
          )
          item.isFavorited = faved.length > 0
        } catch {}
      }

      // 内容块过滤：非作者/非管理员，根据 visibility 剥离受限内容
      const isAuthor = item.userId === queryUserId
      const isAdminUser = queryUserId ? await isAdminById(queryUserId) : false
      if (!isAuthor && !isAdminUser && item.content) {
        try {
          let blocks = typeof item.content === 'string' ? JSON.parse(item.content) : item.content
          if (Array.isArray(blocks) && blocks.length > 0) {
            // 查询已购买的 block 索引
            let purchasedBlocks = new Set()
            if (queryUserId > 0) {
              const purchases = await query(
                'SELECT block_index FROM content_purchases WHERE content_type=? AND content_id=? AND user_id=? AND block_index>=0',
                ['post', Number(req.params.id), queryUserId]
              )
              purchases.forEach(p => purchasedBlocks.add(p.block_index))
              // 全帖购买 (content_permission='paid' 且购买了)
              const fullPurchase = await query(
                'SELECT id FROM content_purchases WHERE content_type=? AND content_id=? AND user_id=? AND block_index<0',
                ['post', Number(req.params.id), queryUserId]
              )
              if (fullPurchase.length > 0) purchasedBlocks = new Set([-1]) // mark as full purchase
            }

            // 查询用户是否评论过
            let userCommented = false
            if (queryUserId > 0) {
              const cmtCheck = await query(
                'SELECT id FROM community_comments WHERE post_id=? AND user_id=?',
                [Number(req.params.id), queryUserId]
              )
              userCommented = cmtCheck.length > 0
            }

            // 查询用户等级 tier
            let userLevelTier = 0
            if (queryUserId > 0) {
              const ul = await query('SELECT COALESCE(ml.tier, 0) as tier FROM users u LEFT JOIN membership_levels ml ON ml.id = u.level_id WHERE u.id=?', [queryUserId])
              if (ul.length > 0) userLevelTier = ul[0].tier || 0
            }

            // 创建占位块替换被过滤的内容，保留所有 metadata（价格、等级等）
            const placeholder = (b, vis) => ({
              ...b,
              value: '',
              images: undefined,
              url: undefined,
              visibility: vis !== undefined ? vis : (b.visibility || 'public'),
              _filtered: true
            })

            const filtered = blocks.map(b => {
              const vis = (b.visibility || item.contentPermission || 'public').toString()
              if (!vis || vis === 'public') return b

              // 全帖已购买 → 所有块可见
              if (purchasedBlocks.has(-1)) return b

              if (vis === 'paid') {
                // 检查是否购买了该 block
                const blockIdx = blocks.indexOf(b)
                if (purchasedBlocks.has(blockIdx)) return b
                return placeholder(b, 'paid')
              }

              if (vis === 'comment') {
                if (userCommented) return b
                return placeholder(b, 'comment')
              }

              if (vis === 'level') {
                const required = b.visibilityLevel !== undefined ? Number(b.visibilityLevel) : 1
                if (userLevelTier >= required) return b
                return placeholder(b, 'level')
              }

              if (vis === 'level1') {
                if (userLevelTier >= 1) return b
                return placeholder(b, 'level1')
              }
              if (vis === 'level2') {
                if (userLevelTier >= 2) return b
                return placeholder(b, 'level2')
              }
              if (vis === 'level3') {
                if (userLevelTier >= 3) return b
                return placeholder(b, 'level3')
              }
              if (vis === 'level4') {
                if (userLevelTier >= 4) return b
                return placeholder(b, 'level4')
              }
              if (vis === 'level5') {
                if (userLevelTier >= 5) return b
                return placeholder(b, 'level5')
              }

              if (vis === 'level1') {
                if (userLevelId >= 1) return b
                return placeholder(b, 'level1')
              }
              if (vis === 'level2') {
                if (userLevelId >= 2) return b
                return placeholder(b, 'level2')
              }
              if (vis === 'password') {
                // 密码验证由前端处理，后端保留但加标记
                return b
              }

              // 未登录用户且 visibility 不是 public/login → 替换
              if (!queryUserId) return placeholder(b, vis)

              return b
            })

            item.content = JSON.stringify(filtered)
          }
        } catch {}
      }

      res.json({ code: 200, msg: 'success', data: item })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/post', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const {
        sectionId, title, content, device, tags, officialTags, images,
        hasResource, resourceType, resourceUrl, resourcePrice, resourcePriceType,
        extractCode, permission, scheduledTime, draftId,
        contentPermission, contentPrice, contentPriceType, accessPassword, accessPasswordTips,
        topicId, topicIds
      } = req.body

      // 检查板块发帖权限
      if (sectionId) {
        const section = await query('SELECT post_permission FROM community_sections WHERE id=?', [Number(sectionId)])
        if (section.length) {
          const perm = section[0].post_permission || 'all'
          if (perm !== 'all') {
            const isUserAdmin = await isAdmin(req)

            if (perm === 'admin_only' && !isUserAdmin) {
              return res.json({ code: 403, msg: '此板块仅管理员可发帖' })
            }
            if (perm === 'moderator_only') {
              if (!isUserAdmin) {
                const mods = await query('SELECT id FROM community_moderators WHERE section_id=? AND user_id=?', [Number(sectionId), userId])
                if (!mods.length) return res.json({ code: 403, msg: '此板块仅版主可发帖' })
              }
            }
            if (perm === 'member_only') {
              const user = await query('SELECT level_id FROM users WHERE id=?', [userId])
              if (!user.length || !user[0].level_id) {
                return res.json({ code: 403, msg: '此板块仅会员可发帖' })
              }
            }
            if (perm === 'vip_only') {
              const user = await query('SELECT level_id, level_name FROM users WHERE id=?', [userId])
              if (!user.length || !user[0].level_name || !user[0].level_name.includes('VIP')) {
                return res.json({ code: 403, msg: '此板块仅VIP会员可发帖' })
              }
            }
            if (perm === 'verified_only') {
              const user = await query('SELECT is_verified FROM users WHERE id=?', [userId])
              if (!user.length || !user[0].is_verified) {
                return res.json({ code: 403, msg: '此板块仅认证用户可发帖' })
              }
            }
          }
        }
      }

      const tg = tags ? (typeof tags === 'string' ? tags : JSON.stringify(tags)) : '[]'
      const ot = officialTags ? (typeof officialTags === 'string' ? officialTags : JSON.stringify(officialTags)) : '[]'
      const imgs = images ? (typeof images === 'string' ? images : JSON.stringify(images)) : '[]'

      let finalStatus = scheduledTime ? 'scheduled' : 'pending'

      const userInfo = await query('SELECT nickname, avatar FROM users WHERE id=?', [userId])
      const userName = userInfo[0]?.nickname || ('user_' + userId)
      const userAvatar = userInfo[0]?.avatar || ''

      const result = await query(
        `INSERT INTO community_posts (section_id, user_id, user_name, user_avatar, title, content, device, tags, official_tags, images,
          has_resource, resource_type, resource_url, resource_price, resource_price_type, extract_code, permission, status, scheduled_time,
           content_permission, content_price, content_price_type, access_password, access_password_tips, topic_id)
          VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
        [sectionId || 0, userId, userName, userAvatar, title || '', content || '', device || '', tg, ot, imgs,
         hasResource ? 1 : 0, resourceType || '', resourceUrl || '', resourcePrice || 0, resourcePriceType || 'free',
         extractCode || '', permission || 'public', finalStatus, scheduledTime || null,
         contentPermission || 'public', contentPrice || 0, contentPriceType || 'balance', accessPassword || '', accessPasswordTips || '',
         topicId || 0]
      )
      const postId = result.insertId

      // 处理多话题关联
      const finalTopicIds = (Array.isArray(topicIds) && topicIds.length > 0)
        ? topicIds
        : (topicId ? [Number(topicId)] : [])
      if (finalTopicIds.length > 0) {
        for (const tid of finalTopicIds) {
          try { await query('INSERT IGNORE INTO community_post_topics (post_id, topic_id) VALUES (?, ?)', [postId, Number(tid)]) } catch {}
        }
      }

      await query('UPDATE community_sections SET post_count = post_count + 1 WHERE id=?', [sectionId || 0])

      if (draftId) {
        await query('DELETE FROM community_drafts WHERE id=? AND user_id=?', [draftId, userId])
      }

      await progressTasksByAction(userId, userName, 'post')

      // 待审核帖子通知管理员和版主
      if (finalStatus === 'pending') {
        const sectionName = sectionId ? ((await query('SELECT name FROM community_sections WHERE id=?', [sectionId]))[0]?.name || '') : ''
        const adminEmails = await getAdminEmails()
        for (const adminEmail of adminEmails) {
          sendNotificationEmail('post_review', adminEmail, {
            username: '管理员',
            subject: '帖子待审核通知',
            content: `用户 ${userName} 在板块「${sectionName}」发布了帖子《${title}》，请尽快审核。`
          })
        }
        const modEmails = await getModeratorEmails(sectionId)
        for (const modEmail of modEmails) {
          if (!adminEmails.includes(modEmail)) {
            sendNotificationEmail('post_review_moderator', modEmail, {
              username: '版主',
              subject: '帖子待审核通知',
              content: `用户 ${userName} 在板块「${sectionName}」发布了帖子《${title}》，请尽快审核。`
            })
          }
        }
      }

      emitSafe(POST_EVENTS.CREATED, { postId, userId, userName, sectionId: sectionId || 0, title })

      res.json({ code: 200, msg: '发布成功', data: { id: postId } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.put('/api/community/post/:id', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const existing = await query('SELECT user_id, title FROM community_posts WHERE id=?', [req.params.id])
      if (!existing || existing.length === 0) return res.json({ code: 404, msg: '帖子不存在' })
      if (existing[0].user_id !== userId && !(await isAdminById(userId))) return res.json({ code: 403, msg: '无权编辑' })

      const {
        title, content, device, tags, officialTags, images,
        hasResource, resourceType, resourceUrl, resourcePrice, resourcePriceType,
        extractCode, permission, sectionId,
        contentPermission, contentPrice, contentPriceType, accessPassword, accessPasswordTips,
        topicId, topicIds
      } = req.body

      const tg = tags ? (typeof tags === 'string' ? tags : JSON.stringify(tags)) : undefined
      const ot = officialTags ? (typeof officialTags === 'string' ? officialTags : JSON.stringify(officialTags)) : undefined
      const imgs = images ? (typeof images === 'string' ? images : JSON.stringify(images)) : undefined

      const sets = []
      const params = []
      if (title !== undefined) { sets.push('title=?'); params.push(title) }
      if (content !== undefined) { sets.push('content=?'); params.push(content) }
      if (device !== undefined) { sets.push('device=?'); params.push(device) }
      if (tg !== undefined) { sets.push('tags=?'); params.push(tg) }
      if (ot !== undefined) { sets.push('official_tags=?'); params.push(ot) }
      if (imgs !== undefined) { sets.push('images=?'); params.push(imgs) }
      if (hasResource !== undefined) { sets.push('has_resource=?'); params.push(hasResource ? 1 : 0) }
      if (resourceType !== undefined) { sets.push('resource_type=?'); params.push(resourceType) }
      if (resourceUrl !== undefined) { sets.push('resource_url=?'); params.push(resourceUrl) }
      if (resourcePrice !== undefined) { sets.push('resource_price=?'); params.push(resourcePrice) }
      if (resourcePriceType !== undefined) { sets.push('resource_price_type=?'); params.push(resourcePriceType) }
      if (extractCode !== undefined) { sets.push('extract_code=?'); params.push(extractCode) }
      if (permission !== undefined) { sets.push('permission=?'); params.push(permission) }
      if (sectionId !== undefined) { sets.push('section_id=?'); params.push(sectionId) }
      if (contentPermission !== undefined) { sets.push('content_permission=?'); params.push(contentPermission) }
      if (contentPrice !== undefined) { sets.push('content_price=?'); params.push(contentPrice) }
      if (contentPriceType !== undefined) { sets.push('content_price_type=?'); params.push(contentPriceType) }
      if (accessPassword !== undefined) { sets.push('access_password=?'); params.push(accessPassword) }
      if (accessPasswordTips !== undefined) { sets.push('access_password_tips=?'); params.push(accessPasswordTips) }
      if (topicId !== undefined) { sets.push('topic_id=?'); params.push(topicId) }
      sets.push(`update_time=${nowExpr}`)
      params.push(req.params.id)

      await query(`UPDATE community_posts SET ${sets.join(',')} WHERE id=?`, params)

      // 处理多话题关联更新
      const finalTopicIds = (Array.isArray(topicIds) && topicIds.length > 0)
        ? topicIds
        : (topicId !== undefined ? [Number(topicId)] : undefined)
      if (finalTopicIds !== undefined) {
        await query('DELETE FROM community_post_topics WHERE post_id=?', [req.params.id])
        if (finalTopicIds.length > 0) {
          for (const tid of finalTopicIds) {
            try { await query('INSERT INTO community_post_topics (post_id, topic_id) VALUES (?, ?)', [req.params.id, Number(tid)]) } catch {}
          }
        }
      }

      emitSafe(POST_EVENTS.UPDATED, { postId: Number(req.params.id), userId, fields: Object.keys(req.body).filter(k => k !== 'id') })

      // Notify author when admin edits their post
      if (existing[0].user_id !== userId) {
        const adminNameEdit = await getAdminUserName(req)
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar) VALUES (?,?,?,?, ?, ?, '')`,
          ['帖子被编辑', `管理员编辑了您的帖子《${title || existing[0].title}》`, 'system', existing[0].user_id, userId, adminNameEdit || '管理员']
        )
      }

      res.json({ code: 200, msg: '更新成功' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.delete('/api/community/post/:id', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const existing = await query('SELECT user_id, section_id, title FROM community_posts WHERE id=?', [req.params.id])
      if (!existing || existing.length === 0) return res.json({ code: 404, msg: '帖子不存在' })

      const isPostOwner = existing[0].user_id === userId
      const isAdminUser = await isAdmin(req)
      if (!isPostOwner && !isAdminUser) return res.json({ code: 403, msg: '无权删除' })

      await query(`UPDATE community_posts SET status='deleted', update_time=${nowExpr} WHERE id=?`, [req.params.id])
      await query('UPDATE community_sections SET post_count = GREATEST(0, post_count - 1) WHERE id=?', [existing[0].section_id])

      deleteFileRecordsByRef(req.params.id, 'post').catch(() => {})

      systemLog('delete', userId, '', 'post', Number(req.params.id),
        `${isPostOwner ? '作者' : '管理员'}删除帖子《${existing[0].title}》`)

      // Notify author when admin deletes their post
      if (!isPostOwner) {
        const adminNameDel = await getAdminUserName(req)
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar) VALUES (?,?,?,?, ?, ?, '')`,
          ['帖子被删除', `您的帖子《${existing[0].title}》已被管理员删除`, 'system', existing[0].user_id, userId, adminNameDel || '管理员']
        )
      }

      emitSafe(POST_EVENTS.DELETED, { postId: Number(req.params.id), userId, title: existing[0].title, sectionId: existing[0].section_id })

      res.json({ code: 200, msg: '删除成功' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== Post Review APIs ====================

  app.get('/api/community/admin/posts/pending', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId || !(await isAdmin(req))) return res.json({ code: 403, msg: '无权限' })

      const { page = 1, pageSize = 20 } = req.query
      const offset = (parseInt(page) - 1) * parseInt(pageSize)

      const countResult = await query("SELECT COUNT(*) as total FROM community_posts WHERE status='pending'")
      const total = countResult[0]?.total || 0

      const list = await query(
        `SELECT p.id, p.section_id as sectionId, p.user_id as userId, p.user_name as userName,
                CASE WHEN p.user_avatar LIKE 'avatar:%' THEN '' ELSE p.user_avatar END as userAvatar, p.title, p.content, p.images,
                p.has_resource as hasResource, p.resource_type as resourceType,
                p.content_permission as contentPermission, p.content_price as contentPrice,
                p.content_price_type as contentPriceType, p.hidden_content as hiddenContent,
                p.access_password as accessPassword, p.access_password_tips as accessPasswordTips,
                p.resource_price as resourcePrice, p.resource_price_type as resourcePriceType,
                p.extract_code as extractCode, p.free_read as freeRead, p.free_count as freeCount,
                p.create_time as createTime
         FROM community_posts p WHERE p.status='pending'
         ORDER BY p.create_time ASC LIMIT ${parseInt(pageSize)} OFFSET ${offset}`
      )

      for (const item of list) {
        try { item.images = item.images ? JSON.parse(item.images) : [] } catch { item.images = [] }
      }

      res.json({ code: 200, msg: 'success', data: { list, total, page: parseInt(page), pageSize: parseInt(pageSize) } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/admin/post/:id/approve', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId || !(await isAdmin(req))) return res.json({ code: 403, msg: '无权限' })

      const post = await query('SELECT id, user_id, title FROM community_posts WHERE id=? AND status=?', [req.params.id, 'pending'])
      if (!post || post.length === 0) return res.json({ code: 404, msg: '帖子不存在或已处理' })

      await query(`UPDATE community_posts SET status='published', update_time=${nowExpr} WHERE id=?`, [req.params.id])
      await query('UPDATE community_sections SET post_count = post_count + 1 WHERE id=(SELECT section_id FROM community_posts WHERE id=?)', [req.params.id])

      const adminNameAp = await getAdminUserName(req)
      if (post[0].user_id !== userId) {
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar) VALUES (?,?,?,?, ?, ?, '')`,
          ['帖子审核通过', `您的帖子《${post[0].title}》已通过审核并发布`, 'system', post[0].user_id, userId, adminNameAp || '管理员']
        )
      }
      systemLog('approve', userId, adminNameAp, 'post', Number(req.params.id), `审核通过帖子《${post[0].title}》`)

      res.json({ code: 200, msg: '已通过审核' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/admin/post/:id/reject', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId || !(await isAdmin(req))) return res.json({ code: 403, msg: '无权限' })

      const { reason = '内容不符合规范' } = req.body
      const post = await query('SELECT id, user_id, title FROM community_posts WHERE id=? AND status=?', [req.params.id, 'pending'])
      if (!post || post.length === 0) return res.json({ code: 404, msg: '帖子不存在或已处理' })

      await query(`UPDATE community_posts SET status='rejected', reject_reason=?, update_time=${nowExpr} WHERE id=?`, [reason, req.params.id])

      const adminNameRj = await getAdminUserName(req)
      await query(
        `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar) VALUES (?,?,?,?, ?, ?, '')`,
        ['帖子审核未通过', `您的帖子《${post[0].title}》未通过审核，原因：${reason}`, 'system', post[0].user_id, userId, adminNameRj || '管理员']
      )
      systemLog('reject', userId, adminNameRj, 'post', Number(req.params.id), `驳回帖子《${post[0].title}》，原因：${reason}`)

      res.json({ code: 200, msg: '已驳回' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/post/:id/like', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const postId = Number(req.params.id)
      const existing = await query('SELECT id FROM community_likes WHERE post_id=? AND user_id=?', [postId, userId])

      if (existing.length > 0) {
        await query('DELETE FROM community_likes WHERE post_id=? AND user_id=?', [postId, userId])
        await query('UPDATE community_posts SET like_count = GREATEST(0, like_count - 1) WHERE id=?', [postId])
        const post = await query('SELECT like_count as likeCount FROM community_posts WHERE id=?', [postId])
        emitSafe(POST_EVENTS.LIKE_TOGGLED, { postId, userId, isLiked: false })
        res.json({ code: 200, msg: '已取消点赞', data: { isLiked: false, likeCount: post[0]?.likeCount || 0 } })
      } else {
        await query('INSERT INTO community_likes (post_id, user_id) VALUES (?,?)', [postId, userId])
        await query('UPDATE community_posts SET like_count = like_count + 1 WHERE id=?', [postId])
        const post = await query('SELECT like_count as likeCount FROM community_posts WHERE id=?', [postId])
        await progressTasksByAction(userId, '', 'like')
        emitSafe(POST_EVENTS.LIKE_TOGGLED, { postId, userId, isLiked: true })
        res.json({ code: 200, msg: '已点赞', data: { isLiked: true, likeCount: post[0]?.likeCount || 0 } })
      }
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/post/:id/favorite', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const postId = Number(req.params.id)
      const existing = await query('SELECT id FROM community_favorites WHERE post_id=? AND user_id=?', [postId, userId])

      if (existing.length > 0) {
        await query('DELETE FROM community_favorites WHERE post_id=? AND user_id=?', [postId, userId])
        await query('UPDATE community_posts SET favorite_count = GREATEST(0, favorite_count - 1) WHERE id=?', [postId])
        emitSafe(POST_EVENTS.FAVORITE_TOGGLED, { postId, userId, isFavorited: false })
        res.json({ code: 200, msg: '已取消收藏', data: { isFavorited: false } })
      } else {
        await query('INSERT INTO community_favorites (post_id, user_id) VALUES (?,?)', [postId, userId])
        await query('UPDATE community_posts SET favorite_count = favorite_count + 1 WHERE id=?', [postId])
        await progressTasksByAction(userId, '', 'favorite')
        emitSafe(POST_EVENTS.FAVORITE_TOGGLED, { postId, userId, isFavorited: true })
        res.json({ code: 200, msg: '已收藏', data: { isFavorited: true } })
      }
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.get('/api/community/user/favorites', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const page = Number(req.query.page) || 1
      const pageSize = Number(req.query.pageSize) || 20
      const offset = (page - 1) * pageSize

      const totalRow = await query(
        `SELECT COUNT(*) as total FROM community_favorites f
         INNER JOIN community_posts p ON f.post_id = p.id WHERE f.user_id=? AND p.status='published'`,
        [userId]
      )
      const total = totalRow[0]?.total || 0

      const list = await query(
        `SELECT p.id, p.section_id as sectionId, p.user_id as postUserId, p.user_name as userName,
                CASE WHEN u.avatar LIKE 'avatar:%' THEN '' ELSE COALESCE(NULLIF(u.avatar,''), p.user_avatar, '') END as userAvatar,
                p.title, p.content, p.device, p.tags, p.official_tags as officialTags,
                p.images, p.has_resource as hasResource, p.resource_type as resourceType,
                p.resource_price as resourcePrice, p.resource_price_type as resourcePriceType,
                p.permission, p.is_pinned as isPinned, p.is_essence as isEssence,
                p.is_hot as isHot, p.is_locked as isLocked, p.status,
                p.like_count as likeCount, p.comment_count as commentCount,
                p.view_count as viewCount, p.favorite_count as favoriteCount,
                p.is_global_pinned as isGlobalPinned,
                p.custom_badge as customBadge,
                p.content_permission as contentPermission, p.content_price as contentPrice, p.content_price_type as contentPriceType,
                p.create_time as createTime, p.update_time as updateTime,
                u.level_name as userLevelName, u.is_verified as userIsVerified,
                 COALESCE((SELECT el.name FROM experience_levels el WHERE el.exp_required <= u.experience AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1), 'Lv.1') as userExpLevelName,
                 (SELECT el.icon FROM experience_levels el WHERE el.exp_required <= u.experience AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1) as userExpLevelIcon,
                 COALESCE((SELECT el.text_color FROM experience_levels el WHERE el.exp_required <= u.experience AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1), '#FFFFFF') as userExpLevelTextColor,
                 COALESCE((SELECT el.bg_color FROM experience_levels el WHERE el.exp_required <= u.experience AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1), '#508DFF') as userExpLevelBgColor,
                 COALESCE(ml.text_color, '#508DFF') as userLevelTextColor,
                 COALESCE(ml.bg_color, '#508DFF') as userLevelBgColor,
                 ml.name as userMemberLevelName, ml.icon as userMemberLevelIcon,
                 u.active_title_name as userTitleName,
                 ct.icon as userTitleIcon, ct.color as userTitleColor, ct.bg_color as userTitleBgColor,
                 (SELECT GROUP_CONCAT(ct2.icon SEPARATOR '|||') FROM user_titles ut2 JOIN custom_titles ct2 ON ut2.title_id = ct2.id WHERE ut2.user_id = u.id AND ct2.status='1' AND ct2.icon IS NOT NULL AND ct2.icon != '') as userAllTitleIcons,
                 f.create_time as favTime
         FROM community_favorites f
         INNER JOIN community_posts p ON f.post_id = p.id
         LEFT JOIN users u ON p.user_id = u.id
         LEFT JOIN membership_levels ml ON ml.id = u.level_id
         LEFT JOIN custom_titles ct ON ct.id = u.active_title_id
         WHERE f.user_id=? AND p.status='published'
         ORDER BY f.create_time DESC
         LIMIT ${pageSize} OFFSET ${offset}`,
        [userId]
      )

      for (const item of list) {
        try { item.tags = item.tags ? JSON.parse(item.tags) : [] } catch { item.tags = [] }
        try { item.officialTags = item.officialTags ? JSON.parse(item.officialTags) : [] } catch { item.officialTags = [] }
        try { item.images = item.images ? JSON.parse(item.images) : [] } catch { item.images = [] }
        item.isPinned = !!item.isPinned
        item.isEssence = !!item.isEssence
        item.isHot = !!item.isHot
        item.isGlobalPinned = !!item.isGlobalPinned
      }

      res.json({ code: 200, msg: 'success', data: { list, total, page, pageSize } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/post/:id/pin', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      if (!(await isAdmin(req))) return res.json({ code: 403, msg: '仅管理员可操作' })

      const post = await query('SELECT user_id, title, is_pinned FROM community_posts WHERE id=?', [req.params.id])
      if (!post || post.length === 0) return res.json({ code: 404, msg: '帖子不存在' })

      const newVal = post[0].is_pinned ? 0 : 1
      await query('UPDATE community_posts SET is_pinned=? WHERE id=?', [newVal, req.params.id])

      emitSafe(POST_EVENTS.PINNED, { postId: Number(req.params.id), userId, isPinned: !!newVal, title: post[0].title })

      if (newVal && post[0].user_id !== userId) {
        const adminNamePin = await getAdminUserName(req)
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar) VALUES (?,?,?,?, ?, ?, '')`,
          ['帖子被置顶', `您的帖子《${post[0].title}》已被管理员置顶`, 'system', post[0].user_id, userId, adminNamePin || '管理员']
        )
      }

      const adminName = await getAdminUserName(req)
      systemLog(newVal ? 'pin' : 'unpin', userId, adminName, 'post', Number(req.params.id),
        `${newVal ? '版块置顶' : '取消版块置顶'}帖子《${post[0].title}》`)
      res.json({ code: 200, msg: newVal ? '已置顶' : '已取消置顶', data: { isPinned: !!newVal } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/post/:id/global-pin', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      if (!(await isAdmin(req))) return res.json({ code: 403, msg: '仅管理员可操作' })

      const post = await query('SELECT user_id, title, is_global_pinned FROM community_posts WHERE id=?', [req.params.id])
      if (!post || post.length === 0) return res.json({ code: 404, msg: '帖子不存在' })

      const newVal = post[0].is_global_pinned ? 0 : 1
      await query('UPDATE community_posts SET is_global_pinned=? WHERE id=?', [newVal, req.params.id])

      emitSafe(POST_EVENTS.GLOBAL_PINNED, { postId: Number(req.params.id), userId, isGlobalPinned: !!newVal, title: post[0].title })

      if (newVal && post[0].user_id !== userId) {
        const adminNameGp = await getAdminUserName(req)
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar) VALUES (?,?,?,?, ?, ?, '')`,
          ['帖子被全站置顶', `您的帖子《${post[0].title}》已被管理员全站置顶`, 'system', post[0].user_id, userId, adminNameGp || '管理员']
        )
      }

      const adminName2 = await getAdminUserName(req)
      systemLog(newVal ? 'pin' : 'unpin', userId, adminName2, 'post', Number(req.params.id),
        `${newVal ? '全站置顶' : '取消全站置顶'}帖子《${post[0].title}》`)
      res.json({ code: 200, msg: newVal ? '已全站置顶' : '已取消全站置顶', data: { isGlobalPinned: !!newVal } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // 自定义徽章
  app.post('/api/community/post/:id/custom-badge', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      if (!(await isAdmin(req))) return res.json({ code: 403, msg: '仅管理员可操作' })

      const { badge } = req.body || {}
      const post = await query('SELECT id, title, custom_badge FROM community_posts WHERE id=?', [req.params.id])
      if (!post || post.length === 0) return res.json({ code: 404, msg: '帖子不存在' })

      const val = badge ? String(badge).trim().slice(0, 10) : ''
      await query('UPDATE community_posts SET custom_badge=? WHERE id=?', [val, req.params.id])

      emitSafe(POST_EVENTS.BADGE_CHANGED, { postId: Number(req.params.id), userId, badge: val || null, title: post[0].title })

      const adminNameCB = await getAdminUserName(req)
      systemLog(val ? 'set_badge' : 'clear_badge', userId, adminNameCB, 'post', Number(req.params.id),
        `${val ? '设置自定义徽章' : '清除自定义徽章'}《${post[0].title}》${val ? '：' + val : ''}`)

      res.json({ code: 200, msg: val ? '自定义徽章已设置' : '自定义徽章已清除', data: { customBadge: val } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/post/:id/essence', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      if (!(await isAdmin(req))) return res.json({ code: 403, msg: '仅管理员可操作' })

      const post = await query('SELECT user_id, title, is_essence FROM community_posts WHERE id=?', [req.params.id])
      if (!post || post.length === 0) return res.json({ code: 404, msg: '帖子不存在' })

      const newVal = post[0].is_essence ? 0 : 1
      await query('UPDATE community_posts SET is_essence=? WHERE id=?', [newVal, req.params.id])
      emitSafe(POST_EVENTS.ESSENCED, { postId: Number(req.params.id), userId, isEssence: !!newVal, title: post[0].title })

      if (newVal && post[0].user_id !== userId) {
        const adminNameEss = await getAdminUserName(req)
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar) VALUES (?,?,?,?, ?, ?, '')`,
          ['帖子被加精', `您的帖子《${post[0].title}》已被管理员设为精华`, 'system', post[0].user_id, userId, adminNameEss || '管理员']
        )
      }

      const adminName = await getAdminUserName(req) // needed for systemLog below
      systemLog(newVal ? 'essence' : 'unessence', userId, adminName, 'post', Number(req.params.id),
        `${newVal ? '设为精华' : '取消精华'}帖子《${post[0].title}》`)
      res.json({ code: 200, msg: newVal ? '已加精' : '已取消加精', data: { isEssence: !!newVal } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/post/:id/hot', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      if (!(await isAdmin(req))) return res.json({ code: 403, msg: '仅管理员可操作' })

      const post = await query('SELECT user_id, title, is_hot FROM community_posts WHERE id=?', [req.params.id])
      if (!post || post.length === 0) return res.json({ code: 404, msg: '帖子不存在' })

      const newVal = post[0].is_hot ? 0 : 1
      // 手动取消热帖后禁止自动升级；手动设为热帖则重置
      const disabled = newVal ? 0 : 1
      await query('UPDATE community_posts SET is_hot=?, hot_manually_disabled=? WHERE id=?', [newVal, disabled, req.params.id])
      emitSafe(POST_EVENTS.HOT_TOGGLED, { postId: Number(req.params.id), userId, isHot: !!newVal, title: post[0].title })

      if (newVal && post[0].user_id !== userId) {
        const adminNameHot = await getAdminUserName(req)
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar) VALUES (?,?,?,?, ?, ?, '')`,
          ['帖子被设为热帖', `您的帖子《${post[0].title}》已被管理员设为热帖`, 'system', post[0].user_id, userId, adminNameHot || '管理员']
        )
        systemLog(newVal ? 'hot' : 'unhot', userId, adminNameHot, 'post', Number(req.params.id),
          `${newVal ? '设为热帖' : '取消热帖'}帖子《${post[0].title}》`)
      } else {
        const adminNameHot = await getAdminUserName(req)
        systemLog(newVal ? 'hot' : 'unhot', userId, adminNameHot, 'post', Number(req.params.id),
          `${newVal ? '设为热帖' : '取消热帖'}帖子《${post[0].title}》`)
      }
      res.json({ code: 200, msg: newVal ? '已设为热帖' : '已取消热帖', data: { isHot: !!newVal } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/post/:id/lock', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      if (!(await isAdmin(req))) return res.json({ code: 403, msg: '仅管理员可操作' })

      const post = await query('SELECT user_id, title, is_locked FROM community_posts WHERE id=?', [req.params.id])
      if (!post || post.length === 0) return res.json({ code: 404, msg: '帖子不存在' })

      const newVal = post[0].is_locked ? 0 : 1
      await query('UPDATE community_posts SET is_locked=? WHERE id=?', [newVal, req.params.id])
      emitSafe(POST_EVENTS.LOCKED, { postId: Number(req.params.id), userId, isLocked: !!newVal, title: post[0].title })

      const adminNameLock = await getAdminUserName(req)
      if (newVal && post[0].user_id !== userId) {
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar) VALUES (?,?,?,?, ?, ?, '')`,
          ['帖子被锁定', `您的帖子《${post[0].title}》已被管理员锁定`, 'system', post[0].user_id, userId, adminNameLock || '管理员']
        )
      }
      if (!newVal && post[0].user_id !== userId) {
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar) VALUES (?,?,?,?, ?, ?, '')`,
          ['帖子已解锁', `您的帖子《${post[0].title}》已被管理员解除锁定`, 'system', post[0].user_id, userId, adminNameLock || '管理员']
        )
      }

      systemLog(newVal ? 'lock' : 'unlock', userId, adminNameLock, 'post', Number(req.params.id),
        `${newVal ? '锁定' : '解锁'}帖子《${post[0].title}》`)
      res.json({ code: 200, msg: newVal ? '已锁定' : '已解锁', data: { isLocked: !!newVal } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/post/:id/coin', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 400, msg: '请先登录后再打赏' })

      const { amount = 1, coinType = 'coin' } = req.body
      const coinAmount = Number(amount)
      if (coinAmount <= 0) return res.json({ code: 400, msg: '投币数量必须大于0' })

      const post = await query('SELECT id, title, user_id, user_name, coin_count as coinCount FROM community_posts WHERE id=?', [req.params.id])
      if (!post || post.length === 0) return res.json({ code: 404, msg: '帖子不存在' })

      if (userId === post[0].user_id) return res.json({ code: 400, msg: '不能打赏自己的帖子' })

      const field = coinType === 'points' ? 'points' : 'balance'
      const user = await query(`SELECT ${field}, nickname, avatar FROM users WHERE id=?`, [userId])
      if (!user || user.length === 0) return res.json({ code: 404, msg: '用户不存在' })
      if (Number(user[0][field]) < coinAmount) return res.json({ code: 400, msg: (coinType === 'points' ? '积分' : '余额') + '不足' })

      await query(`UPDATE users SET ${field} = ${field} - ? WHERE id=?`, [coinAmount, userId])

      const unitLabel = coinType === 'points' ? '积分' : '余额'
      const fromName = user[0].nickname || ('user_' + userId)

      const postTitle = post[0].title || ''

      if (coinType === 'points') {
        await query(`INSERT INTO points_records (user_id, user_name, type, points, balance, source, description) VALUES (?,?,'expense',?, (SELECT points FROM users WHERE id=?), '帖子打赏', ?)`,
          [userId, fromName, coinAmount, userId, `打赏帖子「${postTitle}」`])
      } else {
        await query(`INSERT INTO balance_records (user_id, user_name, type, amount, balance, source, description) VALUES (?,?,'expense',?, (SELECT balance FROM users WHERE id=?), '帖子打赏', ?)`,
          [userId, fromName, coinAmount, userId, `打赏帖子「${postTitle}」`])
      }

      await query('UPDATE community_posts SET coin_count = coin_count + ? WHERE id=?', [coinAmount, req.params.id])
      const fromAvatar = user[0].avatar || ''
      await query(
        'INSERT INTO community_coin_logs (post_id, from_user_id, from_user_name, from_user_avatar, to_user_id, amount, coin_type) VALUES (?,?,?,?,?,?,?)',
        [req.params.id, userId, fromName, fromAvatar, post[0].user_id, coinAmount, coinType]
      )

      const postAuthorId = post[0].user_id

      // 通知帖子作者收到打赏
      await query(
        `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar)
         VALUES (?, ?, 'system', ?, ?, ?, '')`,
        ['打赏通知', `${fromName} 打赏了您的帖子「${postTitle}」${coinAmount}${unitLabel}`, postAuthorId, userId, fromName]
      )

      // 通知打赏者打赏成功
      const sysOpName = (await getSystemOperator())?.username || '管理员'
      await query(
        `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar)
         VALUES (?, ?, 'system', ?, 0, ?, '')`,
        ['打赏成功', `您成功打赏了 ${post[0].user_name || '用户'} 的帖子「${postTitle}」${coinAmount}${unitLabel}`, userId, sysOpName]
      )

      const updated = await query('SELECT coin_count as coinCount FROM community_posts WHERE id=?', [req.params.id])
      res.json({ code: 200, msg: '打赏成功', data: { coinCount: updated[0]?.coinCount || 0 } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // 打赏记录
  app.get('/api/community/post/:id/coin-logs', async (req, res) => {
    try {
      const { page = 1, pageSize = 20 } = req.query
      const offset = (parseInt(page) - 1) * parseInt(pageSize)
      const logs = await query(
        'SELECT id, from_user_id as fromUserId, from_user_name as fromUserName, from_user_avatar as fromUserAvatar, amount, coin_type as coinType, create_time as createTime FROM community_coin_logs WHERE post_id=? ORDER BY create_time DESC LIMIT ? OFFSET ?',
        [req.params.id, parseInt(pageSize), offset]
      )
      const count = await query('SELECT COUNT(*) as total FROM community_coin_logs WHERE post_id=?', [req.params.id])
      res.json({ code: 200, msg: 'success', data: { list: logs, total: count[0]?.total || 0 } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // 附件购买
  app.post('/api/community/attach/purchase', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 400, msg: '请先登录后再下载' })

      const { postId, attachUrl, coinType = 'coin', amount = 0 } = req.body
      const coinAmount = Number(amount)
      if (coinAmount <= 0) return res.json({ code: 400, msg: '金额有误' })

      // 查是否已购买
      const bought = await query(
        'SELECT id FROM community_attach_purchases WHERE post_id=? AND user_id=? AND attach_url=?',
        [postId || 0, userId, attachUrl || '']
      )
      if (bought && bought.length > 0) {
        return res.json({ code: 200, msg: '已购买过，无需重复购买' })
      }

      const field = coinType === 'points' ? 'points' : 'balance'
      const user = await query(`SELECT ${field}, username FROM users WHERE id=?`, [userId])
      if (!user || user.length === 0) return res.json({ code: 404, msg: '用户不存在' })
      if (Number(user[0][field]) < coinAmount) return res.json({ code: 400, msg: (coinType === 'points' ? '积分' : '余额') + '不足' })

      await query(`UPDATE users SET ${field} = ${field} - ? WHERE id=?`, [coinAmount, userId])
      if (coinType === 'points') {
        await query(`INSERT INTO points_records (user_id, user_name, type, points, balance, source, description) VALUES (?,?,'expense',?, (SELECT points FROM users WHERE id=?), '附件购买', ?)`,
          [userId, user[0].username || '', coinAmount, userId, `购买帖子附件 #${postId || 0}`])
      } else {
        await query(`INSERT INTO balance_records (user_id, user_name, type, amount, balance, source, description) VALUES (?,?,'expense',?, (SELECT balance FROM users WHERE id=?), '附件购买', ?)`,
          [userId, user[0].username || '', coinAmount, userId, `购买帖子附件 #${postId || 0}`])
      }
      await query(
        'INSERT INTO community_attach_purchases (post_id, user_id, attach_url, coin_type, coin_amount) VALUES (?,?,?,?,?)',
        [postId || 0, userId, attachUrl || '', coinType, coinAmount]
      )

      res.json({ code: 200, msg: '购买成功' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // 附件购买状态查询
  app.get('/api/community/attach/purchased', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 200, data: { urls: [] } })

      const rows = await query(
        'SELECT attach_url FROM community_attach_purchases WHERE post_id=? AND user_id=?',
        [req.query.postId || 0, userId]
      )
      res.json({ code: 200, data: { urls: (rows || []).map(r => r.attach_url) } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== Comment APIs ====================

  app.get('/api/community/post/:id/comments', async (req, res) => {
    try {
      const { page = 1, pageSize = 20, sortBy = 'default' } = req.query
      const postId = Number(req.params.id)

      const countResult = await query(
        'SELECT COUNT(*) as total FROM community_comments WHERE post_id=? AND parent_id=0', [postId]
      )
      const total = countResult[0]?.total || 0
      const offset = (parseInt(page) - 1) * parseInt(pageSize)

      const orderClause = sortBy === 'hot'
        ? 'ORDER BY c.is_pinned DESC, (c.like_count + c.reply_count) DESC, c.create_time DESC'
        : 'ORDER BY c.is_pinned DESC, c.create_time DESC'

      const comments = await query(
        `SELECT c.id, c.post_id as postId, c.parent_id as parentId, c.user_id as userId,
                c.user_name as userName, CASE WHEN u.avatar LIKE 'avatar:%' THEN '' ELSE COALESCE(NULLIF(u.avatar,''), c.user_avatar, '') END as userAvatar,
                c.content, c.images,
                c.like_count as likeCount, c.reply_count as replyCount, c.is_pinned as isPinned,
                c.create_time as createTime,
                u.is_verified as userIsVerified,
                  COALESCE((SELECT el.name FROM experience_levels el WHERE el.exp_required <= u.experience AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1), 'Lv.1') as userExpLevelName,
                  (SELECT el.icon FROM experience_levels el WHERE el.exp_required <= u.experience AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1) as userExpLevelIcon,
                  COALESCE((SELECT el.text_color FROM experience_levels el WHERE el.exp_required <= u.experience AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1), '#FFFFFF') as userExpLevelTextColor,
                COALESCE((SELECT el.bg_color FROM experience_levels el WHERE el.exp_required <= u.experience AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1), '#508DFF') as userExpLevelBgColor,
                u.active_title_name as userTitleName,
                ct.icon as userTitleIcon, ct.color as userTitleColor, ct.bg_color as userTitleBgColor
         FROM community_comments c
         LEFT JOIN users u ON c.user_id = u.id
         LEFT JOIN custom_titles ct ON ct.id = u.active_title_id
          WHERE c.post_id=? AND c.parent_id=0
          ${orderClause} LIMIT ${parseInt(pageSize)} OFFSET ${offset}`,
        [postId]
      )

      if (comments.length > 0) {
        const commentIds = comments.map(c => c.id)
        const allReplies = await query(
          `SELECT c.id, c.post_id as postId, c.parent_id as parentId, c.user_id as userId,
                c.user_name as userName, CASE WHEN u.avatar LIKE 'avatar:%' THEN '' ELSE COALESCE(NULLIF(u.avatar,''), c.user_avatar, '') END as userAvatar,
                  c.content, c.images,
                  c.like_count as likeCount, c.reply_count as replyCount, c.is_pinned as isPinned,
                  c.create_time as createTime,
                  u.is_verified as userIsVerified,
                  COALESCE((SELECT el.name FROM experience_levels el WHERE el.exp_required <= u.experience AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1), 'Lv.1') as userExpLevelName,
                  (SELECT el.icon FROM experience_levels el WHERE el.exp_required <= u.experience AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1) as userExpLevelIcon,
                  COALESCE((SELECT el.text_color FROM experience_levels el WHERE el.exp_required <= u.experience AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1), '#FFFFFF') as userExpLevelTextColor,
                  COALESCE((SELECT el.bg_color FROM experience_levels el WHERE el.exp_required <= u.experience AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1), '#508DFF') as userExpLevelBgColor,
                  u.active_title_name as userTitleName,
                  ct.icon as userTitleIcon, ct.color as userTitleColor, ct.bg_color as userTitleBgColor
           FROM community_comments c
           LEFT JOIN users u ON c.user_id = u.id
           LEFT JOIN custom_titles ct ON ct.id = u.active_title_id
           WHERE c.post_id=? AND c.parent_id IN (${commentIds.map(() => '?').join(',')})
           ORDER BY c.create_time ASC`,
          [postId, ...commentIds]
        )
        const replyMap = {}
        for (const r of allReplies) {
          if (!replyMap[r.parentId]) replyMap[r.parentId] = []
          replyMap[r.parentId].push(r)
        }
        for (const c of comments) {
          c.replies = replyMap[c.id] || []
          try { c.images = c.images ? JSON.parse(c.images) : [] } catch { c.images = [] }
          for (const r of (c.replies || [])) {
            try { r.images = r.images ? JSON.parse(r.images) : [] } catch { r.images = [] }
          }
        }
      }

      res.json({ code: 200, msg: 'success', data: { list: comments, total, page: parseInt(page), pageSize: parseInt(pageSize) } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/post/:id/comment', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const { content, parent_id: parentId = 0, images } = req.body
      if (!content || !content.trim()) return res.json({ code: 400, msg: '评论内容不能为空' })

      const userInfo = await query('SELECT nickname, avatar FROM users WHERE id=?', [userId])
      const userName = userInfo[0]?.nickname || ('user_' + userId)
      const userAvatar = userInfo[0]?.avatar || ''
      const imgStr = images ? (typeof images === 'string' ? images : JSON.stringify(images)) : '[]'

      const result = await query(
        `INSERT INTO community_comments (post_id, parent_id, user_id, user_name, user_avatar, content, images)
         VALUES (?,?,?,?,?,?,?)`,
        [Number(req.params.id), Number(parentId), userId, userName, userAvatar, content.trim(), imgStr]
      )
      const commentId = result.insertId

      if (Number(parentId) > 0) {
        await query('UPDATE community_comments SET reply_count = reply_count + 1 WHERE id=?', [Number(parentId)])
      }
      await query('UPDATE community_posts SET comment_count = comment_count + 1, update_time=' + nowExpr + ' WHERE id=?', [req.params.id])

      await progressTasksByAction(userId, userName, 'comment')

      // 评论回复通知
      const postInfo = await query('SELECT user_id, title FROM community_posts WHERE id=?', [Number(req.params.id)])
      if (postInfo.length > 0) {
        if (Number(parentId) > 0) {
          const parentInfo = await query('SELECT user_id, user_name FROM community_comments WHERE id=?', [Number(parentId)])
          if (parentInfo.length > 0 && parentInfo[0].user_id !== userId) {
            const targetEmail = await getUserEmail(parentInfo[0].user_id)
            if (targetEmail) {
              sendNotificationEmail('comment_reply', targetEmail, {
                username: parentInfo[0].user_name,
                subject: '评论收到新回复',
                content: `用户 ${userName} 回复了您在《${postInfo[0].title}》中的评论。`
              })
            }
          }
        } else {
          const targetEmail = await getUserEmail(postInfo[0].user_id)
          if (targetEmail && postInfo[0].user_id !== userId) {
            sendNotificationEmail('comment_reply', targetEmail, {
              username: '',
              subject: '帖子收到新评论',
              content: `用户 ${userName} 评论了您的帖子《${postInfo[0].title}》。`
            })
          }
        }
      }

      emitSafe(COMMENT_EVENTS.CREATED, { commentId, postId: Number(req.params.id), userId, userName, parentId: Number(parentId) })

      res.json({ code: 200, msg: '评论成功', data: { id: commentId } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.delete('/api/community/comment/:id', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const comment = await query('SELECT id, post_id, parent_id, user_id FROM community_comments WHERE id=?', [req.params.id])
      if (!comment || comment.length === 0) return res.json({ code: 404, msg: '评论不存在' })

      const c = comment[0]
      const post = await query('SELECT user_id FROM community_posts WHERE id=?', [c.post_id])
      if (!post || post.length === 0) return res.json({ code: 404, msg: '帖子不存在' })

      const isCommentOwner = c.user_id === userId
      const isPostOwner = post[0].user_id === userId
      const isAdminUser = await isAdmin(req)

      if (!isCommentOwner && !isPostOwner && !isAdminUser) {
        return res.json({ code: 403, msg: '无权删除此评论' })
      }

      const isReply = Number(c.parent_id) > 0
      if (isReply) {
        const isReplyR = await query('SELECT parent_id FROM community_comments WHERE id=?', [req.params.id])
        if (isReplyR.length && Number(isReplyR[0].parent_id) > 0) {
          await query('UPDATE community_comments SET reply_count = GREATEST(0, reply_count - 1) WHERE id=?', [isReplyR[0].parent_id])
        }
        await query('DELETE FROM community_comments WHERE id=?', [req.params.id])
        await query('UPDATE community_posts SET comment_count = GREATEST(0, comment_count - 1) WHERE id=?', [c.post_id])
      } else {
        const replyIds = await query('SELECT id FROM community_comments WHERE parent_id=?', [req.params.id])
        for (const r of replyIds) {
          deleteFileRecordsByRef(r.id, 'comment').catch(() => {})
        }
        await query('DELETE FROM community_comments WHERE id=? OR parent_id=?', [req.params.id, req.params.id])
        const replyCount = await query('SELECT COUNT(*) as cnt FROM community_comments WHERE parent_id=?', [req.params.id])
        const deletedReplies = replyCount[0]?.cnt || 0
        await query('UPDATE community_posts SET comment_count = GREATEST(0, comment_count - ' + (1 + deletedReplies) + ') WHERE id=?', [c.post_id])
      }

      deleteFileRecordsByRef(req.params.id, 'comment').catch(() => {})

      emitSafe(COMMENT_EVENTS.DELETED, { commentId: Number(req.params.id), postId: c.post_id, userId })

      res.json({ code: 200, msg: '删除成功' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/comment/:id/pin', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const comment = await query('SELECT id, post_id, parent_id, user_id FROM community_comments WHERE id=?', [req.params.id])
      if (!comment || comment.length === 0) return res.json({ code: 404, msg: '评论不存在' })

      const c = comment[0]
      if (Number(c.parent_id) > 0) return res.json({ code: 400, msg: '不能置顶回复' })

      const post = await query('SELECT user_id FROM community_posts WHERE id=?', [c.post_id])
      if (!post || post.length === 0) return res.json({ code: 404, msg: '帖子不存在' })

      const isPostOwner = post[0].user_id === userId
      const isAdminUser = await isAdmin(req)
      if (!isPostOwner && !isAdminUser) {
        return res.json({ code: 403, msg: '无权置顶此评论' })
      }

      const current = await query('SELECT is_pinned FROM community_comments WHERE id=?', [req.params.id])
      const newPinned = current[0]?.is_pinned ? 0 : 1
      await query('UPDATE community_comments SET is_pinned=? WHERE id=?', [newPinned, req.params.id])

      res.json({ code: 200, msg: newPinned ? '置顶成功' : '取消置顶成功', data: { isPinned: !!newPinned } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== Draft APIs ====================

  app.get('/api/community/drafts', async (req, res) => {
    try {
      const { userId } = req.query
      if (!userId) return res.json({ code: 400, msg: '缺少userId参数' })

      const drafts = await query(
        `SELECT id, user_id as userId, section_id as sectionId, title, content,
                images, tags, official_tags as officialTags, has_resource as hasResource,
                resource_type as resourceType, resource_url as resourceUrl,
                resource_price as resourcePrice, resource_price_type as resourcePriceType,
                extract_code as extractCode, permission,
                create_time as createTime, update_time as updateTime
         FROM community_drafts WHERE user_id=? ORDER BY update_time DESC`, [Number(userId)]
      )
      for (const d of drafts) {
        try { d.tags = d.tags ? JSON.parse(d.tags) : [] } catch { d.tags = [] }
        try { d.officialTags = d.officialTags ? JSON.parse(d.officialTags) : [] } catch { d.officialTags = [] }
        try { d.images = d.images ? JSON.parse(d.images) : [] } catch { d.images = [] }
        d.hasResource = !!d.hasResource
      }

      res.json({ code: 200, msg: 'success', data: drafts })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/draft', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const {
        id, sectionId, title, content, images, tags, officialTags,
        hasResource, resourceType, resourceUrl, resourcePrice, resourcePriceType,
        extractCode, permission
      } = req.body

      const imgs = images ? (typeof images === 'string' ? images : JSON.stringify(images)) : '[]'
      const tg = tags ? (typeof tags === 'string' ? tags : JSON.stringify(tags)) : '[]'
      const ot = officialTags ? (typeof officialTags === 'string' ? officialTags : JSON.stringify(officialTags)) : '[]'

      if (id) {
        await query(
          `UPDATE community_drafts SET section_id=?, title=?, content=?, images=?, tags=?, official_tags=?,
           has_resource=?, resource_type=?, resource_url=?, resource_price=?, resource_price_type=?,
           extract_code=?, permission=?, update_time=${nowExpr}
           WHERE id=? AND user_id=?`,
          [sectionId || 0, title || '', content || '', imgs, tg, ot,
           hasResource ? 1 : 0, resourceType || '', resourceUrl || '', resourcePrice || 0, resourcePriceType || 'free',
           extractCode || '', permission || 'public', id, userId]
        )
        res.json({ code: 200, msg: '草稿已更新', data: { id } })
      } else {
        const result = await query(
          `INSERT INTO community_drafts (user_id, section_id, title, content, images, tags, official_tags,
            has_resource, resource_type, resource_url, resource_price, resource_price_type, extract_code, permission)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
          [userId, sectionId || 0, title || '', content || '', imgs, tg, ot,
           hasResource ? 1 : 0, resourceType || '', resourceUrl || '', resourcePrice || 0, resourcePriceType || 'free',
           extractCode || '', permission || 'public']
        )
        res.json({ code: 200, msg: '草稿已保存', data: { id: result.insertId } })
      }
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.delete('/api/community/draft/:id', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      await query('DELETE FROM community_drafts WHERE id=? AND user_id=?', [req.params.id, userId])
      res.json({ code: 200, msg: '草稿已删除' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== Admin APIs ====================

  app.get('/api/community/admin/posts', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const { status, page = 1, pageSize = 20 } = req.query
      let sql = `SELECT p.id, p.section_id as sectionId, p.user_id as userId, p.user_name as userName,
                  p.title, p.status, p.is_pinned as isPinned, p.is_global_pinned as isGlobalPinned,
                  p.is_essence as isEssence, p.is_hot as isHot, p.custom_badge as customBadge,
                  p.like_count as likeCount, p.comment_count as commentCount,
                  p.view_count as viewCount, p.create_time as createTime
                FROM community_posts p WHERE 1=1`
      const params = []

      if (status) { sql += ' AND p.status=?'; params.push(status) }

      const offset = (parseInt(page) - 1) * parseInt(pageSize)
      const countResult = await query(`SELECT COUNT(*) as total FROM (${sql}) t`, params)
      const total = countResult[0]?.total || 0

      const list = await query(sql + ` ORDER BY p.id DESC LIMIT ${parseInt(pageSize)} OFFSET ${offset}`, params)
      res.json({ code: 200, msg: 'success', data: { list, total, page: parseInt(page), pageSize: parseInt(pageSize) } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.put('/api/community/admin/post/:id/status', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const { status } = req.body
      if (!status) return res.json({ code: 400, msg: '缺少status参数' })

      await query('UPDATE community_posts SET status=?, update_time=' + nowExpr + ' WHERE id=?', [status, req.params.id])
      res.json({ code: 200, msg: '状态已更新' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/admin/ban', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const { userId: targetUserId, reason, duration } = req.body
      if (!targetUserId) return res.json({ code: 400, msg: '缺少userId参数' })

      let bannedUntil = null
      if (duration) {
        const hours = Number(duration)
        bannedUntil = `DATE_ADD(NOW(), INTERVAL ${hours} HOUR)`
      }

      const userInfo = await query('SELECT nickname FROM users WHERE id=?', [targetUserId])
      const userName = userInfo[0]?.nickname || ''

      const existing = await query('SELECT id FROM community_banned_users WHERE user_id=?', [targetUserId])
      if (existing.length > 0) {
        if (bannedUntil) {
          await query(`UPDATE community_banned_users SET reason=?, banned_until=${bannedUntil} WHERE user_id=?`,
            [reason || '', targetUserId])
        } else {
          await query('UPDATE community_banned_users SET reason=?, banned_until=NULL WHERE user_id=?',
            [reason || '', targetUserId])
        }
      } else {
        const sql = bannedUntil
          ? `INSERT INTO community_banned_users (user_id, user_name, reason, banned_until) VALUES (?,?,?,${bannedUntil})`
          : 'INSERT INTO community_banned_users (user_id, user_name, reason) VALUES (?,?,?)'
        const params = bannedUntil
          ? [targetUserId, userName, reason || '']
          : [targetUserId, userName, reason || '']
        await query(sql, params)
      }

      res.json({ code: 200, msg: '用户已被禁言' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/admin/unban', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const { userId: targetUserId } = req.body
      if (!targetUserId) return res.json({ code: 400, msg: '缺少userId参数' })

      await query('DELETE FROM community_banned_users WHERE user_id=?', [targetUserId])
      res.json({ code: 200, msg: '已解除禁言' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.get('/api/community/admin/banned', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const list = await query(
        `SELECT id, user_id as userId, user_name as userName, reason, banned_until as bannedUntil, create_time as createTime
         FROM community_banned_users ORDER BY create_time DESC`
      )
      res.json({ code: 200, msg: 'success', data: list })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== User Search API ====================

  app.get('/api/community/user/search', async (req, res) => {
    try {
      const { keyword } = req.query
      if (!keyword || keyword.length < 1) return res.json({ code: 400, msg: '请输入搜索关键词' })
      const rows = await query(
        `SELECT id, username, nickname, avatar FROM users WHERE nickname LIKE ? OR username LIKE ? LIMIT 10`,
        [`%${keyword}%`, `%${keyword}%`]
      )
      res.json({ code: 200, msg: 'success', data: rows })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== Report APIs ====================

  app.post('/api/community/post/:id/report', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const { reportReason, reportDetail } = req.body || {}

      // Store detailed report record
      const user = await query('SELECT username FROM users WHERE id=?', [userId])
      await query(
        `INSERT INTO community_reports (reporter_id, reporter_name, target_type, target_id, report_reason, report_detail)
         VALUES (?,?,?,?,?,?)`,
        [userId, user[0]?.username || '', 'post', Number(req.params.id), reportReason || '其他', reportDetail || '']
      )

      // Also increment the old counter for backward compatibility
      await query('UPDATE community_posts SET reported = COALESCE(reported,0) + 1 WHERE id=?', [req.params.id])

      // 举报通知管理员
      const postTitle = await query('SELECT title FROM community_posts WHERE id=?', [Number(req.params.id)])
      const adminEmailsRp = await getAdminEmails()
      for (const adminEmail of adminEmailsRp) {
        sendNotificationEmail('report_notify', adminEmail, {
          username: '管理员',
          subject: '收到帖子举报',
          content: `用户 ${user[0]?.username || ''} 举报了帖子《${postTitle[0]?.title || ''}》，原因：${reportReason || '其他'}。`
        })
      }

      res.json({ code: 200, msg: '举报成功' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/comment/:id/report', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const { reportReason, reportDetail } = req.body || {}

      const user = await query('SELECT username FROM users WHERE id=?', [userId])
      await query(
        `INSERT INTO community_reports (reporter_id, reporter_name, target_type, target_id, report_reason, report_detail)
         VALUES (?,?,?,?,?,?)`,
        [userId, user[0]?.username || '', 'comment', Number(req.params.id), reportReason || '其他', reportDetail || '']
      )

      await query('UPDATE community_comments SET reported = COALESCE(reported,0) + 1 WHERE id=?', [req.params.id])

      // 举报通知管理员
      const adminEmailsCr = await getAdminEmails()
      for (const adminEmail of adminEmailsCr) {
        sendNotificationEmail('report_notify', adminEmail, {
          username: '管理员',
          subject: '收到评论举报',
          content: `用户 ${user[0]?.username || ''} 举报了一条评论，原因：${reportReason || '其他'}。`
        })
      }

      res.json({ code: 200, msg: '举报成功' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.get('/api/community/admin/reports', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId || !(await isAdmin(req))) return res.json({ code: 403, msg: '无权限' })

      const reports = await query(
        `SELECT r.id, r.reporter_id as reporterId, r.reporter_name as reporterName,
                r.target_type as targetType, r.target_id as targetId, r.report_reason as reportReason,
                r.report_detail as reportDetail, r.status, r.create_time as createTime
         FROM community_reports r WHERE r.status = 'pending' ORDER BY r.create_time DESC LIMIT 100`
      )

      // Enrich with target info
      const enriched = []
      for (const r of reports) {
        const item = { ...r }
        if (r.targetType === 'post') {
          const post = await query('SELECT id, title, user_id as userId, user_name as userName, status FROM community_posts WHERE id=?', [r.targetId])
          if (post.length > 0) {
            item.targetTitle = post[0].title
            item.targetUserId = post[0].userId
            item.targetUserName = post[0].userName
            item.targetStatus = post[0].status
          }
        } else {
          const comment = await query('SELECT id, content, user_id as userId, user_name as userName, post_id as postId FROM community_comments WHERE id=?', [r.targetId])
          if (comment.length > 0) {
            item.targetTitle = (comment[0].content || '').substring(0, 50)
            item.targetUserId = comment[0].userId
            item.targetUserName = comment[0].userName
            item.postId = comment[0].postId
          }
        }
        enriched.push(item)
      }

      res.json({ code: 200, msg: 'success', data: enriched })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/admin/report/ignore/:id', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId || !(await isAdmin(req))) return res.json({ code: 403, msg: '无权限' })
      await query('UPDATE community_reports SET status=? WHERE id=?', ['ignored', Number(req.params.id)])
      // 通知举报人
      try {
        const report = await query('SELECT reporter_id FROM community_reports WHERE id=?', [Number(req.params.id)])
        if (report.length > 0) {
          const reporter = await query('SELECT username, email FROM users WHERE id=?', [report[0].reporter_id])
          if (reporter.length > 0 && reporter[0].email) {
            sendNotificationEmail('report_result', reporter[0].email, {
              username: reporter[0].username || '',
              subject: '举报处理结果',
              content: '您提交的举报已被管理员审核，处理结果为：不予处理。'
            })
          }
        }
      } catch {}
      res.json({ code: 200, msg: '已忽略' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== Unlock Request APIs ====================

  app.post('/api/community/post/:id/request-unlock', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const { reason } = req.body || {}

      const post = await query('SELECT id, user_id, is_locked FROM community_posts WHERE id=?', [req.params.id])
      if (!post.length) return res.json({ code: 404, msg: '帖子不存在' })
      if (!post[0].is_locked) return res.json({ code: 400, msg: '该帖子未被锁定' })
      if (post[0].user_id !== userId) return res.json({ code: 403, msg: '只有帖子作者可以申请解锁' })

      // Check if already has a pending request
      const existing = await query(
        'SELECT id FROM community_unlock_requests WHERE post_id=? AND user_id=? AND status=?',
        [req.params.id, userId, 'pending']
      )
      if (existing.length > 0) return res.json({ code: 400, msg: '已有待处理的解锁申请' })

      const user = await query('SELECT username FROM users WHERE id=?', [userId])
      await query(
        `INSERT INTO community_unlock_requests (post_id, user_id, user_name, reason) VALUES (?,?,?,?)`,
        [Number(req.params.id), userId, user[0]?.username || '', reason || '']
      )
      res.json({ code: 200, msg: '解锁申请已提交' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.get('/api/community/admin/unlock-requests', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId || !(await isAdmin(req))) return res.json({ code: 403, msg: '无权限' })

      const requests = await query(
        `SELECT r.id, r.post_id as postId, r.user_id as userId, r.user_name as userName,
                r.reason, r.status, r.admin_reply as adminReply, r.create_time as createTime,
                p.title as postTitle
         FROM community_unlock_requests r
         LEFT JOIN community_posts p ON r.post_id = p.id
         ORDER BY r.status ASC, r.create_time DESC LIMIT 100`
      )
      res.json({ code: 200, msg: 'success', data: requests })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/admin/unlock-request/:id/handle', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId || !(await isAdmin(req))) return res.json({ code: 403, msg: '无权限' })
      const { action, reply } = req.body || {}

      const ur = await query('SELECT * FROM community_unlock_requests WHERE id=?', [req.params.id])
      if (!ur.length) return res.json({ code: 404, msg: '申请不存在' })
      if (ur[0].status !== 'pending') return res.json({ code: 400, msg: '该申请已处理' })

      if (action === 'approve') {
        await query('UPDATE community_posts SET is_locked=0 WHERE id=?', [ur[0].post_id])
        await query('UPDATE community_unlock_requests SET status=?, admin_reply=?, update_time=NOW() WHERE id=?',
          ['approved', reply || '', req.params.id])
        // Notify user
        const adminNameUr = await getAdminUserName(req)
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar) VALUES (?,?,?,?, ?, ?, '')`,
          ['解锁申请已通过', `您的解锁申请已通过`, 'system', ur[0].user_id, userId, adminNameUr || '管理员']
        )
        res.json({ code: 200, msg: '已通过解锁申请' })
      } else {
        await query('UPDATE community_unlock_requests SET status=?, admin_reply=?, update_time=NOW() WHERE id=?',
          ['rejected', reply || '', req.params.id])
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar) VALUES (?,?,?,?, ?, ?, '')`,
          ['解锁申请被拒绝', reply ? `拒绝原因: ${reply}` : '您的解锁申请被拒绝', 'system', ur[0].user_id, userId, adminNameUr || '管理员']
        )
        res.json({ code: 200, msg: '已拒绝解锁申请' })
      }
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.delete('/api/community/admin/report/post/:id', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId || !(await isAdmin(req))) return res.json({ code: 403, msg: '无权限' })

      const post = await query('SELECT section_id, user_id, title FROM community_posts WHERE id=?', [req.params.id])
        if (post.length) {
        await query("UPDATE community_posts SET status='deleted', update_time=" + nowExpr + " WHERE id=?", [req.params.id])
        await query('UPDATE community_sections SET post_count = GREATEST(0, post_count - 1) WHERE id=?', [post[0].section_id])
        deleteFileRecordsByRef(req.params.id, 'post').catch(() => {})
        const adminNameRp = await getAdminUserName(req)
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar) VALUES (?,?,?,?, ?, ?, '')`,
          ['帖子被下架', `您的帖子《${post[0].title}》因被举报已被管理员下架`, 'system', post[0].user_id, userId, adminNameRp || '管理员']
        )
        // 通知所有举报人
        try {
          const reporters = await query("SELECT DISTINCT reporter_id FROM community_reports WHERE target_type='post' AND target_id=? AND status='pending'", [req.params.id])
          for (const r of reporters) {
            const ru = await query('SELECT username, email FROM users WHERE id=?', [r.reporter_id])
            if (ru.length > 0 && ru[0].email) {
              sendNotificationEmail('report_result', ru[0].email, {
                username: ru[0].username || '',
                subject: '举报处理结果',
                content: `您举报的帖子《${post[0].title}》已被管理员下架处理。`
              })
            }
          }
          // 标记相关举报为已处理
          await query("UPDATE community_reports SET status='resolved' WHERE target_type='post' AND target_id=? AND status='pending'", [req.params.id])
        } catch {}
      }
      res.json({ code: 200, msg: '已下架' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.delete('/api/community/admin/report/comment/:id', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId || !(await isAdmin(req))) return res.json({ code: 403, msg: '无权限' })

      await query('DELETE FROM community_comments WHERE id=?', [req.params.id])
      // 通知所有举报人并标记已处理
      try {
        const reporters = await query("SELECT DISTINCT reporter_id FROM community_reports WHERE target_type='comment' AND target_id=? AND status='pending'", [req.params.id])
        for (const r of reporters) {
          const ru = await query('SELECT username, email FROM users WHERE id=?', [r.reporter_id])
          if (ru.length > 0 && ru[0].email) {
            sendNotificationEmail('report_result', ru[0].email, {
              username: ru[0].username || '',
              subject: '举报处理结果',
              content: '您举报的评论已被管理员删除处理。'
            })
          }
        }
        await query("UPDATE community_reports SET status='resolved' WHERE target_type='comment' AND target_id=? AND status='pending'", [req.params.id])
      } catch {}
      res.json({ code: 200, msg: '已删除' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })
}

module.exports = communityRoutes
