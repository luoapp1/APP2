const { query, dbType } = require('../database.cjs')
const { sessions, SESSION_TTL } = require('./system.cjs')
const nowExpr = dbType === 'mysql' ? 'NOW()' : "datetime('now','localtime')"
const { progressTasksByAction } = require('./custom-task.cjs')

async function getUserId(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return 0

  const session = sessions.get(token)
  if (session) {
    if (Date.now() - session.createdAt > SESSION_TTL) {
      sessions.delete(token)
      return 0
    }
    return Number(session.userId) || 0
  }

  // 后端重启后内存 session 丢失，从数据库恢复
  try {
    const rows = await query('SELECT user_id, user_name, roles, created_at FROM sessions WHERE token=?', [token])
    if (rows && rows.length > 0) {
      const row = rows[0]
      const createdAt = typeof row.created_at === 'number' ? row.created_at : new Date(row.created_at).getTime()
      if (Date.now() - createdAt > SESSION_TTL) {
        query('DELETE FROM sessions WHERE token=?', [token]).catch(() => {})
        return 0
      }
      sessions.set(token, { userId: row.user_id, userName: row.user_name, roles: JSON.parse(row.roles || '[]'), createdAt })
      return Number(row.user_id) || 0
    }
  } catch {}

  return 0
}

async function getUserRoles(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return []
  const session = sessions.get(token)
  if (session) return session.roles || []
  try {
    const rows = await query('SELECT roles FROM sessions WHERE token=?', [token])
    if (rows && rows.length > 0) {
      try { return JSON.parse(rows[0].roles || '[]') } catch { return [] }
    }
  } catch {}
  return []
}

async function isAdmin(req) {
  const roles = await getUserRoles(req)
  return roles.some(r => r === 'R_SUPER' || r === 'R_ADMIN')
}

async function isAdminById(userId) {
  if (!userId) return false
  try {
    const rows = await query('SELECT roles FROM users WHERE id=?', [userId])
    if (rows && rows.length > 0) {
      try {
        const roles = typeof rows[0].roles === 'string' ? JSON.parse(rows[0].roles) : (rows[0].roles || [])
        return roles.some(r => r === 'R_SUPER' || r === 'R_ADMIN')
      } catch { return false }
    }
  } catch {}
  return false
}

async function canAccessSection(userId, sectionId) {
  if (!userId) return false
  if (await isAdminById(userId)) return true
  try {
    const rows = await query('SELECT id FROM community_moderators WHERE section_id=? AND user_id=?', [sectionId, userId])
    return rows.length > 0
  } catch { return false }
}

function communityRoutes(app) {

  // ==================== Section APIs ====================

  app.get('/api/community/sections', async (req, res) => {
    try {
      const showAll = req.query.all === 'true' && (await isAdmin(req))
      const where = showAll ? '' : "WHERE status='active'"
      const sections = await query(
        `SELECT id, name, icon, icon_bg_color as iconBgColor, description,
                today_heat as todayHeat, total_heat as totalHeat,
                post_count as postCount, view_count as viewCount,
                sort_order as sortOrder, status, visibility,
                post_permission as postPermission, view_permission as viewPermission,
                view_level_required as viewLevelRequired, create_time as createTime
         FROM community_sections ${where} ORDER BY sort_order ASC`
      )
      const userId = await getUserId(req)
      const userRoles = await getUserRoles(req)
      const isUserAdminDB = userRoles.some(r => r === 'R_SUPER' || r === 'R_ADMIN')
      const user = userId ? (await query('SELECT level_name, level_id, is_verified FROM users WHERE id=?', [userId]))[0] : null
      const filtered = []
      for (const s of sections) {
        if (s.visibility === 'restricted' && !(await canAccessSection(userId, s.id))) continue
        if (!isUserAdminDB) {
          const vp = s.viewPermission || 'all'
          if (vp === 'moderator_only') {
            if (!userId || !(await canAccessSection(userId, s.id))) continue
          } else if (vp === 'admin_only') {
            continue
          } else if (vp === 'vip_only') {
            if (!user || !user.level_name || !user.level_name.includes('VIP')) continue
          } else if (vp === 'member_only') {
            if (!user || !user.level_id) continue
          } else if (vp === 'verified_only') {
            if (!user || !user.is_verified) continue
          }
          if (s.viewLevelRequired && s.viewLevelRequired > 0) {
            if (!user || !user.level_id || user.level_id < s.viewLevelRequired) continue
          }
        }
        filtered.push(s)
      }
      res.json({ code: 200, msg: 'success', data: filtered })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== 版主管理 API ====================

  app.get('/api/community/section/:id/moderators', async (req, res) => {
    try {
      const list = await query(
        `SELECT id, section_id as sectionId, user_id as userId, user_name as userName, user_avatar as userAvatar,
                role, sort_order as sortOrder, create_time as createTime
         FROM community_moderators WHERE section_id=? ORDER BY sort_order ASC, create_time ASC`,
        [req.params.id]
      )
      res.json({ code: 200, msg: 'success', data: list })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/section/:id/moderator', async (req, res) => {
    try {
      const { userId, userName, userAvatar, role } = req.body
      if (!userId) return res.json({ code: 400, msg: '缺少userId' })
      const existing = await query(
        'SELECT id FROM community_moderators WHERE section_id=? AND user_id=?',
        [req.params.id, userId]
      )
      if (existing.length) {
        await query(
          'UPDATE community_moderators SET user_name=?, user_avatar=?, role=? WHERE section_id=? AND user_id=?',
          [userName||'', userAvatar||'', role||'版主', req.params.id, userId]
        )
      } else {
        await query(
          'INSERT INTO community_moderators (section_id, user_id, user_name, user_avatar, role) VALUES (?,?,?,?,?)',
          [req.params.id, userId, userName||'', userAvatar||'', role||'版主']
        )
      }
      res.json({ code: 200, msg: 'success' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.delete('/api/community/section/:id/moderator/:userId', async (req, res) => {
    try {
      await query('DELETE FROM community_moderators WHERE section_id=? AND user_id=?',
        [req.params.id, req.params.userId])
      res.json({ code: 200, msg: '删除成功' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // 查询用户担任版主的所有板块
  app.get('/api/community/user/:userId/moderator-sections', async (req, res) => {
    try {
      const list = await query(
        `SELECT m.section_id as sectionId, m.role, s.name as sectionName, s.icon_bg_color as iconBgColor
         FROM community_moderators m
         LEFT JOIN community_sections s ON m.section_id = s.id
         WHERE m.user_id=?`,
        [req.params.userId]
      )
      res.json({ code: 200, msg: 'success', data: list })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.get('/api/community/section/:id', async (req, res) => {
    try {
      const section = await query(
        `SELECT id, name, icon, icon_bg_color as iconBgColor, description,
                today_heat as todayHeat, total_heat as totalHeat,
                post_count as postCount, view_count as viewCount,
                sort_order as sortOrder, status, visibility, create_time as createTime
         FROM community_sections WHERE id=?`, [req.params.id]
      )
      if (!section || section.length === 0) {
        return res.json({ code: 404, msg: '板块不存在' })
      }
      const s = section[0]
      if (s.visibility === 'restricted') {
        const userId = await getUserId(req)
        if (!(await canAccessSection(userId, s.id))) {
          return res.json({ code: 403, msg: '无权限访问此板块' })
        }
      }
      res.json({ code: 200, msg: 'success', data: s })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/section', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const { id, name, icon, iconBgColor, description, todayHeat, totalHeat, postCount, viewCount, sortOrder, status, visibility, postPermission, viewPermission, viewLevelRequired } = req.body

      if (id) {
        await query(
          `UPDATE community_sections SET name=?, icon=?, icon_bg_color=?, description=?,
           today_heat=?, total_heat=?, post_count=?, view_count=?, sort_order=?, status=?, visibility=?,
           post_permission=?, view_permission=?, view_level_required=?
           WHERE id=?`,
          [name, icon || '', iconBgColor || '#00BFA5', description || '',
           todayHeat || 0, totalHeat || 0, postCount || 0, viewCount || 0,
           sortOrder || 0, status || 'active', visibility || 'public',
           postPermission || 'all', viewPermission || 'all', viewLevelRequired || 0, id]
        )
        res.json({ code: 200, msg: '更新成功', data: { id } })
      } else {
        const result = await query(
          `INSERT INTO community_sections (name, icon, icon_bg_color, description, today_heat, total_heat, post_count, view_count, sort_order, status, visibility, post_permission, view_permission, view_level_required)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
          [name, icon || '', iconBgColor || '#00BFA5', description || '',
           todayHeat || 0, totalHeat || 0, postCount || 0, viewCount || 0,
           sortOrder || 0, status || 'active', visibility || 'public',
           postPermission || 'all', viewPermission || 'all', viewLevelRequired || 0]
        )
        res.json({ code: 200, msg: '创建成功', data: { id: result.lastInsertRowid || result.insertId } })
      }
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.delete('/api/community/section/:id', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      await query('DELETE FROM community_sections WHERE id=?', [req.params.id])
      res.json({ code: 200, msg: '删除成功' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== Post APIs ====================

  app.get('/api/community/posts', async (req, res) => {
    try {
      const { sectionId, sort = 'latest', page = 1, pageSize = 20, keyword, tags, userId, status: statusFilter } = req.query
      const queryUserId = Number(userId) || 0
      const isAdminUser = queryUserId ? await isAdminById(queryUserId) : false

      let sql = `SELECT p.id, p.section_id as sectionId, p.user_id as userId, p.user_name as userName,
                  p.user_avatar as userAvatar, p.title, p.content, p.device, p.tags, p.official_tags as officialTags,
                  p.images, p.has_resource as hasResource, p.resource_type as resourceType,
                  p.resource_url as resourceUrl, p.resource_price as resourcePrice,
                  p.resource_price_type as resourcePriceType, p.extract_code as extractCode,
                  p.permission, p.is_pinned as isPinned, p.is_essence as isEssence,
                p.is_hot as isHot, p.is_locked as isLocked, p.status, p.like_count as likeCount,
                  p.comment_count as commentCount, p.coin_count as coinCount,
                  p.view_count as viewCount, p.favorite_count as favoriteCount,
                  p.reject_reason as rejectReason,
                  p.create_time as createTime, p.update_time as updateTime
                FROM community_posts p WHERE `
      const params = []

      if (statusFilter) {
        sql += 'p.status=?'
        params.push(statusFilter)
      } else if (isAdminUser) {
        sql += "p.status != 'deleted'"
      } else if (queryUserId) {
        sql += "(p.status='published' OR (p.user_id=? AND p.status!='deleted'))"
        params.push(queryUserId)
      } else {
        sql += "p.status='published'"
      }

      if (sectionId) { sql += ' AND p.section_id=?'; params.push(sectionId) }
      if (keyword) { sql += ' AND (p.title LIKE ? OR p.content LIKE ?)'; params.push(`%${keyword}%`, `%${keyword}%`) }
      if (tags) {
        const tagList = tags.split(',')
        for (const t of tagList) {
          sql += ' AND p.tags LIKE ?'
          params.push(`%${t.trim()}%`)
        }
      }

      // 过滤受限板块的帖子
      if (!isAdminUser) {
        const restrictedSections = await query('SELECT id FROM community_sections WHERE visibility=?', ['restricted'])
        if (restrictedSections.length > 0) {
          const restrictedIds = restrictedSections.map(s => s.id)
          let accessibleIds = []
          if (queryUserId) {
            const modRows = await query(
              `SELECT section_id FROM community_moderators WHERE user_id=? AND section_id IN (${restrictedIds.map(() => '?').join(',')})`,
              [queryUserId, ...restrictedIds]
            )
            accessibleIds = modRows.map(r => r.section_id)
          }
          const inaccessibleIds = restrictedIds.filter(id => !accessibleIds.includes(id))
          if (inaccessibleIds.length > 0) {
            sql += ` AND p.section_id NOT IN (${inaccessibleIds.map(() => '?').join(',')})`
            params.push(...inaccessibleIds)
          }
        }
      }

      let orderBy = ''
      switch (sort) {
        case 'recent_reply': orderBy = 'p.update_time DESC'; break
        case 'most_likes': orderBy = 'p.like_count DESC'; break
        case 'most_favorites': orderBy = 'p.favorite_count DESC'; break
        case 'essence': orderBy = 'p.is_essence DESC, p.id DESC'; break
        case 'hot': orderBy = 'p.is_hot DESC, p.like_count DESC'; break
        case 'pinned': orderBy = 'p.is_pinned DESC, p.id DESC'; break
        default: orderBy = 'p.is_pinned DESC, p.id DESC'
      }

      const offset = (parseInt(page) - 1) * parseInt(pageSize)
      const countResult = await query(`SELECT COUNT(*) as total FROM (${sql}) t`, params)
      const total = countResult[0]?.total || 0

      const list = await query(sql + ` ORDER BY ${orderBy} LIMIT ${parseInt(pageSize)} OFFSET ${offset}`, params)
      for (const item of list) {
        try { item.tags = item.tags ? JSON.parse(item.tags) : [] } catch { item.tags = [] }
        try { item.officialTags = item.officialTags ? JSON.parse(item.officialTags) : [] } catch { item.officialTags = [] }
        try { item.images = item.images ? JSON.parse(item.images) : [] } catch { item.images = [] }
        item.isPinned = !!item.isPinned
        item.isEssence = !!item.isEssence
        item.isHot = !!item.isHot
      }

      if (Number(userId) && list.length > 0) {
        try {
          const postIds = list.map(p => p.id)
          const likedRows = await query(
            `SELECT post_id FROM community_likes WHERE user_id=? AND post_id IN (${postIds.map(() => '?').join(',')})`,
            [Number(userId), ...postIds]
          )
          const favoritedRows = await query(
            `SELECT post_id FROM community_favorites WHERE user_id=? AND post_id IN (${postIds.map(() => '?').join(',')})`,
            [Number(userId), ...postIds]
          )
          const likedSet = new Set(likedRows.map(r => r.post_id))
          const favSet = new Set(favoritedRows.map(r => r.post_id))
          for (const item of list) {
            item.isLiked = likedSet.has(item.id)
            item.isFavorited = favSet.has(item.id)
          }
        } catch {}
      }

      res.json({ code: 200, msg: 'success', data: { list, total, page: parseInt(page), pageSize: parseInt(pageSize) } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.get('/api/community/post/:id', async (req, res) => {
    try {
      const { userId } = req.query
      const queryUserId = Number(userId) || 0
      const post = await query(
        `SELECT p.id, p.section_id as sectionId, p.user_id as userId, p.user_name as userName,
                p.user_avatar as userAvatar, p.title, p.content, p.device, p.tags, p.official_tags as officialTags,
                p.images, p.has_resource as hasResource, p.resource_type as resourceType,
                p.resource_url as resourceUrl, p.resource_price as resourcePrice,
                p.resource_price_type as resourcePriceType, p.extract_code as extractCode,
                p.permission, p.is_pinned as isPinned, p.is_essence as isEssence,
                p.is_hot as isHot, p.is_locked as isLocked, p.status, p.like_count as likeCount,
                p.comment_count as commentCount, p.coin_count as coinCount,
                p.view_count as viewCount, p.favorite_count as favoriteCount,
                p.reject_reason as rejectReason, p.scheduled_time as scheduledTime,
                p.content_permission as contentPermission, p.content_price as contentPrice,
                p.content_price_type as contentPriceType,
                p.access_password as accessPassword, p.access_password_tips as accessPasswordTips,
                p.create_time as createTime, p.update_time as updateTime
         FROM community_posts p WHERE p.id=?`, [req.params.id]
      )
      if (!post || post.length === 0 || post[0].status === 'deleted') {
        return res.json({ code: 404, msg: '帖子不存在' })
      }
      const item = post[0]

      // 检查板块可见性
      const secRows = await query('SELECT visibility FROM community_sections WHERE id=?', [item.sectionId])
      if (secRows.length > 0 && secRows[0].visibility === 'restricted') {
        if (!(await canAccessSection(queryUserId, item.sectionId))) {
          return res.json({ code: 403, msg: '无权限访问此帖子' })
        }
      }

      if (item.status === 'pending' || item.status === 'rejected') {
        const isOwner = item.userId === queryUserId
        const isAdminUser = queryUserId ? await isAdminById(queryUserId) : false
        if (!isOwner && !isAdminUser) {
          return res.json({ code: 404, msg: '帖子不存在' })
        }
      }
      try { item.tags = item.tags ? JSON.parse(item.tags) : [] } catch { item.tags = [] }
      try { item.officialTags = item.officialTags ? JSON.parse(item.officialTags) : [] } catch { item.officialTags = [] }
      try { item.images = item.images ? JSON.parse(item.images) : [] } catch { item.images = [] }
      item.isPinned = !!item.isPinned
      item.isEssence = !!item.isEssence
      item.isHot = !!item.isHot

      // 浏览数+1，同时检查是否达到15000自动设为热帖（未被管理员手动禁用的）
      await query(
        `UPDATE community_posts SET view_count = view_count + 1,
         is_hot = CASE WHEN view_count + 1 >= 15000 AND hot_manually_disabled = 0 THEN 1 ELSE is_hot END
         WHERE id=?`,
        [Number(req.params.id)]
      )

      {
        const updated = await query('SELECT is_hot, view_count FROM community_posts WHERE id=?', [Number(req.params.id)])
        if (updated.length > 0) {
          item.isHot = !!updated[0].is_hot
          item.viewCount = updated[0].view_count
        }
      }

      if (queryUserId > 0) progressTasksByAction(queryUserId, '', 'view_post')

      const comments = await query(
        `SELECT id, post_id as postId, parent_id as parentId, user_id as userId,
                user_name as userName, user_avatar as userAvatar, content,
                like_count as likeCount, reply_count as replyCount, create_time as createTime
         FROM community_comments WHERE post_id=? AND parent_id=0 ORDER BY create_time DESC`,
        [req.params.id]
      )
      const allReplies = await query(
        `SELECT id, post_id as postId, parent_id as parentId, user_id as userId,
                user_name as userName, user_avatar as userAvatar, content,
                like_count as likeCount, reply_count as replyCount, create_time as createTime
         FROM community_comments WHERE post_id=? AND parent_id>0 ORDER BY create_time ASC`,
        [req.params.id]
      )
      const replyMap = {}
      for (const r of allReplies) {
        if (!replyMap[r.parentId]) replyMap[r.parentId] = []
        replyMap[r.parentId].push(r)
      }
      for (const c of comments) {
        c.replies = replyMap[c.id] || []
      }
      item.comments = comments

      if (Number(userId)) {
        try {
          const liked = await query(
            'SELECT id FROM community_likes WHERE post_id=? AND user_id=?',
            [req.params.id, Number(userId)]
          )
          item.isLiked = liked.length > 0
          const faved = await query(
            'SELECT id FROM community_favorites WHERE post_id=? AND user_id=?',
            [req.params.id, Number(userId)]
          )
          item.isFavorited = faved.length > 0
        } catch {}
      }

      res.json({ code: 200, msg: 'success', data: item })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/post', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const {
        sectionId, title, content, device, tags, officialTags, images,
        hasResource, resourceType, resourceUrl, resourcePrice, resourcePriceType,
        extractCode, permission, scheduledTime, draftId,
        contentPermission, contentPrice, contentPriceType, accessPassword, accessPasswordTips
      } = req.body

      // 检查板块发帖权限
      if (sectionId) {
        const section = await query('SELECT post_permission FROM community_sections WHERE id=?', [Number(sectionId)])
        if (section.length) {
          const perm = section[0].post_permission || 'all'
          if (perm !== 'all') {
            const isUserAdmin = await isAdmin(req)

            if (perm === 'admin_only' && !isUserAdmin) {
              return res.json({ code: 403, msg: '此板块仅管理员可发帖' })
            }
            if (perm === 'moderator_only') {
              if (!isUserAdmin) {
                const mods = await query('SELECT id FROM section_moderators WHERE section_id=? AND user_id=?', [Number(sectionId), userId])
                if (!mods.length) return res.json({ code: 403, msg: '此板块仅版主可发帖' })
              }
            }
            if (perm === 'member_only') {
              const user = await query('SELECT level_id FROM users WHERE id=?', [userId])
              if (!user.length || !user[0].level_id) {
                return res.json({ code: 403, msg: '此板块仅会员可发帖' })
              }
            }
            if (perm === 'vip_only') {
              const user = await query('SELECT level_id, level_name FROM users WHERE id=?', [userId])
              if (!user.length || !user[0].level_name || !user[0].level_name.includes('VIP')) {
                return res.json({ code: 403, msg: '此板块仅VIP会员可发帖' })
              }
            }
            if (perm === 'verified_only') {
              const user = await query('SELECT is_verified FROM users WHERE id=?', [userId])
              if (!user.length || !user[0].is_verified) {
                return res.json({ code: 403, msg: '此板块仅认证用户可发帖' })
              }
            }
          }
        }
      }

      const tg = tags ? (typeof tags === 'string' ? tags : JSON.stringify(tags)) : '[]'
      const ot = officialTags ? (typeof officialTags === 'string' ? officialTags : JSON.stringify(officialTags)) : '[]'
      const imgs = images ? (typeof images === 'string' ? images : JSON.stringify(images)) : '[]'

      let finalStatus = scheduledTime ? 'scheduled' : 'pending'

      const userInfo = await query('SELECT nickname, avatar FROM users WHERE id=?', [userId])
      const userName = userInfo[0]?.nickname || ('user_' + userId)
      const userAvatar = userInfo[0]?.avatar || ''

      const result = await query(
        `INSERT INTO community_posts (section_id, user_id, user_name, user_avatar, title, content, device, tags, official_tags, images,
          has_resource, resource_type, resource_url, resource_price, resource_price_type, extract_code, permission, status, scheduled_time,
          content_permission, content_price, content_price_type, access_password, access_password_tips)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
        [sectionId || 0, userId, userName, userAvatar, title || '', content || '', device || '', tg, ot, imgs,
         hasResource ? 1 : 0, resourceType || '', resourceUrl || '', resourcePrice || 0, resourcePriceType || 'free',
         extractCode || '', permission || 'public', finalStatus, scheduledTime || null,
         contentPermission || 'public', contentPrice || 0, contentPriceType || 'balance', accessPassword || '', accessPasswordTips || '']
      )
      const postId = result.lastInsertRowid || result.insertId

      await query('UPDATE community_sections SET post_count = post_count + 1 WHERE id=?', [sectionId || 0])

      if (draftId) {
        await query('DELETE FROM community_drafts WHERE id=? AND user_id=?', [draftId, userId])
      }

      progressTasksByAction(userId, userName, 'post')

      res.json({ code: 200, msg: '发布成功', data: { id: postId } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.put('/api/community/post/:id', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const existing = await query('SELECT user_id, title FROM community_posts WHERE id=?', [req.params.id])
      if (!existing || existing.length === 0) return res.json({ code: 404, msg: '帖子不存在' })
      if (existing[0].user_id !== userId && !(await isAdmin(userId))) return res.json({ code: 403, msg: '无权编辑' })

      const {
        title, content, device, tags, officialTags, images,
        hasResource, resourceType, resourceUrl, resourcePrice, resourcePriceType,
        extractCode, permission, sectionId,
        contentPermission, contentPrice, contentPriceType, accessPassword, accessPasswordTips
      } = req.body

      const tg = tags ? (typeof tags === 'string' ? tags : JSON.stringify(tags)) : undefined
      const ot = officialTags ? (typeof officialTags === 'string' ? officialTags : JSON.stringify(officialTags)) : undefined
      const imgs = images ? (typeof images === 'string' ? images : JSON.stringify(images)) : undefined

      const sets = []
      const params = []
      if (title !== undefined) { sets.push('title=?'); params.push(title) }
      if (content !== undefined) { sets.push('content=?'); params.push(content) }
      if (device !== undefined) { sets.push('device=?'); params.push(device) }
      if (tg !== undefined) { sets.push('tags=?'); params.push(tg) }
      if (ot !== undefined) { sets.push('official_tags=?'); params.push(ot) }
      if (imgs !== undefined) { sets.push('images=?'); params.push(imgs) }
      if (hasResource !== undefined) { sets.push('has_resource=?'); params.push(hasResource ? 1 : 0) }
      if (resourceType !== undefined) { sets.push('resource_type=?'); params.push(resourceType) }
      if (resourceUrl !== undefined) { sets.push('resource_url=?'); params.push(resourceUrl) }
      if (resourcePrice !== undefined) { sets.push('resource_price=?'); params.push(resourcePrice) }
      if (resourcePriceType !== undefined) { sets.push('resource_price_type=?'); params.push(resourcePriceType) }
      if (extractCode !== undefined) { sets.push('extract_code=?'); params.push(extractCode) }
      if (permission !== undefined) { sets.push('permission=?'); params.push(permission) }
      if (sectionId !== undefined) { sets.push('section_id=?'); params.push(sectionId) }
      if (contentPermission !== undefined) { sets.push('content_permission=?'); params.push(contentPermission) }
      if (contentPrice !== undefined) { sets.push('content_price=?'); params.push(contentPrice) }
      if (contentPriceType !== undefined) { sets.push('content_price_type=?'); params.push(contentPriceType) }
      if (accessPassword !== undefined) { sets.push('access_password=?'); params.push(accessPassword) }
      if (accessPasswordTips !== undefined) { sets.push('access_password_tips=?'); params.push(accessPasswordTips) }
      sets.push(`update_time=${nowExpr}`)
      params.push(req.params.id)

      await query(`UPDATE community_posts SET ${sets.join(',')} WHERE id=?`, params)

      // Notify author when admin edits their post
      if (existing[0].user_id !== userId) {
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id) VALUES (?,?,?,?)`,
          ['帖子被编辑', `管理员编辑了您的帖子《${title || existing[0].title}》`, 'system', existing[0].user_id]
        )
      }

      res.json({ code: 200, msg: '更新成功' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.delete('/api/community/post/:id', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const existing = await query('SELECT user_id, section_id, title FROM community_posts WHERE id=?', [req.params.id])
      if (!existing || existing.length === 0) return res.json({ code: 404, msg: '帖子不存在' })

      const isPostOwner = existing[0].user_id === userId
      const isAdminUser = await isAdmin(req)
      if (!isPostOwner && !isAdminUser) return res.json({ code: 403, msg: '无权删除' })

      await query(`UPDATE community_posts SET status='deleted', update_time=${nowExpr} WHERE id=?`, [req.params.id])
      await query('UPDATE community_sections SET post_count = MAX(0, post_count - 1) WHERE id=?', [existing[0].section_id])

      // Notify author when admin deletes their post
      if (!isPostOwner) {
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id) VALUES (?,?,?,?)`,
          ['帖子被删除', `您的帖子《${existing[0].title}》已被管理员删除`, 'system', existing[0].user_id]
        )
      }

      res.json({ code: 200, msg: '删除成功' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== Post Review APIs ====================

  app.get('/api/community/admin/posts/pending', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId || !(await isAdmin(req))) return res.json({ code: 403, msg: '无权限' })

      const { page = 1, pageSize = 20 } = req.query
      const offset = (parseInt(page) - 1) * parseInt(pageSize)

      const countResult = await query("SELECT COUNT(*) as total FROM community_posts WHERE status='pending'")
      const total = countResult[0]?.total || 0

      const list = await query(
        `SELECT p.id, p.section_id as sectionId, p.user_id as userId, p.user_name as userName,
                p.user_avatar as userAvatar, p.title, p.content, p.images,
                p.has_resource as hasResource, p.resource_type as resourceType,
                p.create_time as createTime
         FROM community_posts p WHERE p.status='pending'
         ORDER BY p.create_time ASC LIMIT ${parseInt(pageSize)} OFFSET ${offset}`
      )

      for (const item of list) {
        try { item.images = item.images ? JSON.parse(item.images) : [] } catch { item.images = [] }
      }

      res.json({ code: 200, msg: 'success', data: { list, total, page: parseInt(page), pageSize: parseInt(pageSize) } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/admin/post/:id/approve', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId || !(await isAdmin(req))) return res.json({ code: 403, msg: '无权限' })

      const post = await query('SELECT id, user_id, title FROM community_posts WHERE id=? AND status=?', [req.params.id, 'pending'])
      if (!post || post.length === 0) return res.json({ code: 404, msg: '帖子不存在或已处理' })

      await query(`UPDATE community_posts SET status='published', update_time=${nowExpr} WHERE id=?`, [req.params.id])
      await query('UPDATE community_sections SET post_count = post_count + 1 WHERE id=(SELECT section_id FROM community_posts WHERE id=?)', [req.params.id])

      await query(
        `INSERT INTO sys_notifications (title, content, type, target_user_id) VALUES (?,?,?,?)`,
        ['帖子审核通过', `您的帖子《${post[0].title}》已通过审核并发布`, 'system', post[0].user_id]
      )

      res.json({ code: 200, msg: '已通过审核' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/admin/post/:id/reject', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId || !(await isAdmin(req))) return res.json({ code: 403, msg: '无权限' })

      const { reason = '内容不符合规范' } = req.body
      const post = await query('SELECT id, user_id, title FROM community_posts WHERE id=? AND status=?', [req.params.id, 'pending'])
      if (!post || post.length === 0) return res.json({ code: 404, msg: '帖子不存在或已处理' })

      await query(`UPDATE community_posts SET status='rejected', reject_reason=?, update_time=${nowExpr} WHERE id=?`, [reason, req.params.id])

      await query(
        `INSERT INTO sys_notifications (title, content, type, target_user_id) VALUES (?,?,?,?)`,
        ['帖子审核未通过', `您的帖子《${post[0].title}》未通过审核，原因：${reason}`, 'system', post[0].user_id]
      )

      res.json({ code: 200, msg: '已驳回' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/post/:id/like', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const postId = Number(req.params.id)
      const existing = await query('SELECT id FROM community_likes WHERE post_id=? AND user_id=?', [postId, userId])

      if (existing.length > 0) {
        await query('DELETE FROM community_likes WHERE post_id=? AND user_id=?', [postId, userId])
        await query('UPDATE community_posts SET like_count = MAX(0, like_count - 1) WHERE id=?', [postId])
        const post = await query('SELECT like_count as likeCount FROM community_posts WHERE id=?', [postId])
        res.json({ code: 200, msg: '已取消点赞', data: { isLiked: false, likeCount: post[0]?.likeCount || 0 } })
      } else {
        await query('INSERT INTO community_likes (post_id, user_id) VALUES (?,?)', [postId, userId])
        await query('UPDATE community_posts SET like_count = like_count + 1 WHERE id=?', [postId])
        const post = await query('SELECT like_count as likeCount FROM community_posts WHERE id=?', [postId])
        progressTasksByAction(userId, '', 'like')
        res.json({ code: 200, msg: '已点赞', data: { isLiked: true, likeCount: post[0]?.likeCount || 0 } })
      }
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/post/:id/favorite', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const postId = Number(req.params.id)
      const existing = await query('SELECT id FROM community_favorites WHERE post_id=? AND user_id=?', [postId, userId])

      if (existing.length > 0) {
        await query('DELETE FROM community_favorites WHERE post_id=? AND user_id=?', [postId, userId])
        await query('UPDATE community_posts SET favorite_count = MAX(0, favorite_count - 1) WHERE id=?', [postId])
        res.json({ code: 200, msg: '已取消收藏', data: { isFavorited: false } })
      } else {
        await query('INSERT INTO community_favorites (post_id, user_id) VALUES (?,?)', [postId, userId])
        await query('UPDATE community_posts SET favorite_count = favorite_count + 1 WHERE id=?', [postId])
        progressTasksByAction(userId, '', 'favorite')
        res.json({ code: 200, msg: '已收藏', data: { isFavorited: true } })
      }
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/post/:id/pin', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      if (!(await isAdmin(req))) return res.json({ code: 403, msg: '仅管理员可操作' })

      const post = await query('SELECT user_id, title, is_pinned FROM community_posts WHERE id=?', [req.params.id])
      if (!post || post.length === 0) return res.json({ code: 404, msg: '帖子不存在' })

      const newVal = post[0].is_pinned ? 0 : 1
      await query('UPDATE community_posts SET is_pinned=? WHERE id=?', [newVal, req.params.id])

      if (newVal && post[0].user_id !== userId) {
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id) VALUES (?,?,?,?)`,
          ['帖子被置顶', `您的帖子《${post[0].title}》已被管理员置顶`, 'system', post[0].user_id]
        )
      }

      res.json({ code: 200, msg: newVal ? '已置顶' : '已取消置顶', data: { isPinned: !!newVal } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/post/:id/essence', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      if (!(await isAdmin(req))) return res.json({ code: 403, msg: '仅管理员可操作' })

      const post = await query('SELECT user_id, title, is_essence FROM community_posts WHERE id=?', [req.params.id])
      if (!post || post.length === 0) return res.json({ code: 404, msg: '帖子不存在' })

      const newVal = post[0].is_essence ? 0 : 1
      await query('UPDATE community_posts SET is_essence=? WHERE id=?', [newVal, req.params.id])

      if (newVal && post[0].user_id !== userId) {
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id) VALUES (?,?,?,?)`,
          ['帖子被加精', `您的帖子《${post[0].title}》已被管理员设为精华`, 'system', post[0].user_id]
        )
      }

      res.json({ code: 200, msg: newVal ? '已加精' : '已取消加精', data: { isEssence: !!newVal } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/post/:id/hot', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      if (!(await isAdmin(req))) return res.json({ code: 403, msg: '仅管理员可操作' })

      const post = await query('SELECT user_id, title, is_hot FROM community_posts WHERE id=?', [req.params.id])
      if (!post || post.length === 0) return res.json({ code: 404, msg: '帖子不存在' })

      const newVal = post[0].is_hot ? 0 : 1
      // 手动取消热帖后禁止自动升级；手动设为热帖则重置
      const disabled = newVal ? 0 : 1
      await query('UPDATE community_posts SET is_hot=?, hot_manually_disabled=? WHERE id=?', [newVal, disabled, req.params.id])

      if (newVal && post[0].user_id !== userId) {
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id) VALUES (?,?,?,?)`,
          ['帖子被设为热帖', `您的帖子《${post[0].title}》已被管理员设为热帖`, 'system', post[0].user_id]
        )
      }

      res.json({ code: 200, msg: newVal ? '已设为热帖' : '已取消热帖', data: { isHot: !!newVal } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/post/:id/lock', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      if (!(await isAdmin(req))) return res.json({ code: 403, msg: '仅管理员可操作' })

      const post = await query('SELECT user_id, title, is_locked FROM community_posts WHERE id=?', [req.params.id])
      if (!post || post.length === 0) return res.json({ code: 404, msg: '帖子不存在' })

      const newVal = post[0].is_locked ? 0 : 1
      await query('UPDATE community_posts SET is_locked=? WHERE id=?', [newVal, req.params.id])

      if (newVal && post[0].user_id !== userId) {
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id) VALUES (?,?,?,?)`,
          ['帖子被锁定', `您的帖子《${post[0].title}》已被管理员锁定`, 'system', post[0].user_id]
        )
      }
      if (!newVal && post[0].user_id !== userId) {
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id) VALUES (?,?,?,?)`,
          ['帖子已解锁', `您的帖子《${post[0].title}》已被管理员解除锁定`, 'system', post[0].user_id]
        )
      }

      res.json({ code: 200, msg: newVal ? '已锁定' : '已解锁', data: { isLocked: !!newVal } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/post/:id/coin', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 400, msg: '请先登录后再打赏' })

      const { amount = 1, coinType = 'coin' } = req.body
      const coinAmount = Number(amount)
      if (coinAmount <= 0) return res.json({ code: 400, msg: '投币数量必须大于0' })

      const post = await query('SELECT id, title, user_id, user_name, coin_count as coinCount FROM community_posts WHERE id=?', [req.params.id])
      if (!post || post.length === 0) return res.json({ code: 404, msg: '帖子不存在' })

      if (userId === post[0].user_id) return res.json({ code: 400, msg: '不能打赏自己的帖子' })

      const field = coinType === 'points' ? 'points' : 'balance'
      const user = await query(`SELECT ${field}, nickname, avatar FROM users WHERE id=?`, [userId])
      if (!user || user.length === 0) return res.json({ code: 404, msg: '用户不存在' })
      if (Number(user[0][field]) < coinAmount) return res.json({ code: 400, msg: (coinType === 'points' ? '积分' : '余额') + '不足' })

      await query(`UPDATE users SET ${field} = ${field} - ? WHERE id=?`, [coinAmount, userId])
      await query('UPDATE community_posts SET coin_count = coin_count + ? WHERE id=?', [coinAmount, req.params.id])

      const fromName = user[0].nickname || ('user_' + userId)
      const fromAvatar = user[0].avatar || ''
      await query(
        'INSERT INTO community_coin_logs (post_id, from_user_id, from_user_name, from_user_avatar, to_user_id, amount, coin_type) VALUES (?,?,?,?,?,?,?)',
        [req.params.id, userId, fromName, fromAvatar, post[0].user_id, coinAmount, coinType]
      )

      const unitLabel = coinType === 'points' ? '积分' : '余额'
      const postAuthorId = post[0].user_id

      const postTitle = post[0].title || ''

      // 通知帖子作者收到打赏
      await query(
        `INSERT INTO sys_notifications (title, content, type, target_user_id)
         VALUES (?, ?, 'system', ?)`,
        ['打赏通知', `${fromName} 打赏了您的帖子「${postTitle}」${coinAmount}${unitLabel}`, postAuthorId]
      )

      // 通知打赏者打赏成功
      await query(
        `INSERT INTO sys_notifications (title, content, type, target_user_id)
         VALUES (?, ?, 'system', ?)`,
        ['打赏成功', `您成功打赏了 ${post[0].user_name || '用户'} 的帖子「${postTitle}」${coinAmount}${unitLabel}`, userId]
      )

      const updated = await query('SELECT coin_count as coinCount FROM community_posts WHERE id=?', [req.params.id])
      res.json({ code: 200, msg: '打赏成功', data: { coinCount: updated[0]?.coinCount || 0 } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // 打赏记录
  app.get('/api/community/post/:id/coin-logs', async (req, res) => {
    try {
      const { page = 1, pageSize = 20 } = req.query
      const offset = (parseInt(page) - 1) * parseInt(pageSize)
      const logs = await query(
        'SELECT id, from_user_id as fromUserId, from_user_name as fromUserName, from_user_avatar as fromUserAvatar, amount, coin_type as coinType, create_time as createTime FROM community_coin_logs WHERE post_id=? ORDER BY create_time DESC LIMIT ? OFFSET ?',
        [req.params.id, parseInt(pageSize), offset]
      )
      const count = await query('SELECT COUNT(*) as total FROM community_coin_logs WHERE post_id=?', [req.params.id])
      res.json({ code: 200, msg: 'success', data: { list: logs, total: count[0]?.total || 0 } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // 附件购买
  app.post('/api/community/attach/purchase', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 400, msg: '请先登录后再下载' })

      const { postId, attachUrl, coinType = 'coin', amount = 0 } = req.body
      const coinAmount = Number(amount)
      if (coinAmount <= 0) return res.json({ code: 400, msg: '金额有误' })

      // 查是否已购买
      const bought = await query(
        'SELECT id FROM community_attach_purchases WHERE post_id=? AND user_id=? AND attach_url=?',
        [postId || 0, userId, attachUrl || '']
      )
      if (bought && bought.length > 0) {
        return res.json({ code: 200, msg: '已购买过，无需重复购买' })
      }

      const field = coinType === 'points' ? 'points' : 'balance'
      const user = await query(`SELECT ${field} FROM users WHERE id=?`, [userId])
      if (!user || user.length === 0) return res.json({ code: 404, msg: '用户不存在' })
      if (Number(user[0][field]) < coinAmount) return res.json({ code: 400, msg: (coinType === 'points' ? '积分' : '余额') + '不足' })

      await query(`UPDATE users SET ${field} = ${field} - ? WHERE id=?`, [coinAmount, userId])
      await query(
        'INSERT INTO community_attach_purchases (post_id, user_id, attach_url, coin_type, coin_amount) VALUES (?,?,?,?,?)',
        [postId || 0, userId, attachUrl || '', coinType, coinAmount]
      )

      res.json({ code: 200, msg: '购买成功' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // 附件购买状态查询
  app.get('/api/community/attach/purchased', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 200, data: { urls: [] } })

      const rows = await query(
        'SELECT attach_url FROM community_attach_purchases WHERE post_id=? AND user_id=?',
        [req.query.postId || 0, userId]
      )
      res.json({ code: 200, data: { urls: (rows || []).map(r => r.attach_url) } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== Comment APIs ====================

  app.get('/api/community/post/:id/comments', async (req, res) => {
    try {
      const { page = 1, pageSize = 20 } = req.query
      const postId = Number(req.params.id)

      const countResult = await query(
        'SELECT COUNT(*) as total FROM community_comments WHERE post_id=? AND parent_id=0', [postId]
      )
      const total = countResult[0]?.total || 0
      const offset = (parseInt(page) - 1) * parseInt(pageSize)

      const comments = await query(
        `SELECT id, post_id as postId, parent_id as parentId, user_id as userId,
                user_name as userName, user_avatar as userAvatar, content,
                like_count as likeCount, reply_count as replyCount, is_pinned as isPinned,
                create_time as createTime
         FROM community_comments WHERE post_id=? AND parent_id=0
         ORDER BY is_pinned DESC, create_time DESC LIMIT ${parseInt(pageSize)} OFFSET ${offset}`,
        [postId]
      )

      if (comments.length > 0) {
        const commentIds = comments.map(c => c.id)
        const allReplies = await query(
          `SELECT id, post_id as postId, parent_id as parentId, user_id as userId,
                  user_name as userName, user_avatar as userAvatar, content,
                  like_count as likeCount, reply_count as replyCount, is_pinned as isPinned,
                  create_time as createTime
           FROM community_comments WHERE post_id=? AND parent_id IN (${commentIds.map(() => '?').join(',')})
           ORDER BY create_time ASC`,
          [postId, ...commentIds]
        )
        const replyMap = {}
        for (const r of allReplies) {
          if (!replyMap[r.parentId]) replyMap[r.parentId] = []
          replyMap[r.parentId].push(r)
        }
        for (const c of comments) {
          c.replies = replyMap[c.id] || []
        }
      }

      res.json({ code: 200, msg: 'success', data: { list: comments, total, page: parseInt(page), pageSize: parseInt(pageSize) } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/post/:id/comment', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const { content, parent_id: parentId = 0 } = req.body
      if (!content || !content.trim()) return res.json({ code: 400, msg: '评论内容不能为空' })

      const userInfo = await query('SELECT nickname, avatar FROM users WHERE id=?', [userId])
      const userName = userInfo[0]?.nickname || ('user_' + userId)
      const userAvatar = userInfo[0]?.avatar || ''

      const result = await query(
        `INSERT INTO community_comments (post_id, parent_id, user_id, user_name, user_avatar, content)
         VALUES (?,?,?,?,?,?)`,
        [Number(req.params.id), Number(parentId), userId, userName, userAvatar, content.trim()]
      )
      const commentId = result.lastInsertRowid || result.insertId

      if (Number(parentId) > 0) {
        await query('UPDATE community_comments SET reply_count = reply_count + 1 WHERE id=?', [Number(parentId)])
      }
      await query('UPDATE community_posts SET comment_count = comment_count + 1, update_time=' + nowExpr + ' WHERE id=?', [req.params.id])

      progressTasksByAction(userId, userName, 'comment')

      res.json({ code: 200, msg: '评论成功', data: { id: commentId } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.delete('/api/community/comment/:id', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const comment = await query('SELECT id, post_id, parent_id, user_id FROM community_comments WHERE id=?', [req.params.id])
      if (!comment || comment.length === 0) return res.json({ code: 404, msg: '评论不存在' })

      const c = comment[0]
      const post = await query('SELECT user_id FROM community_posts WHERE id=?', [c.post_id])
      if (!post || post.length === 0) return res.json({ code: 404, msg: '帖子不存在' })

      const isCommentOwner = c.user_id === userId
      const isPostOwner = post[0].user_id === userId
      const isAdminUser = await isAdmin(req)

      if (!isCommentOwner && !isPostOwner && !isAdminUser) {
        return res.json({ code: 403, msg: '无权删除此评论' })
      }

      const isReply = Number(c.parent_id) > 0
      if (isReply) {
        await query('DELETE FROM community_comments WHERE id=?', [req.params.id])
        await query('UPDATE community_comments SET reply_count = MAX(0, reply_count - 1) WHERE id=?', [c.parent_id])
        await query('UPDATE community_posts SET comment_count = MAX(0, comment_count - 1) WHERE id=?', [c.post_id])
      } else {
        await query('DELETE FROM community_comments WHERE id=? OR parent_id=?', [req.params.id, req.params.id])
        const replyCount = await query('SELECT COUNT(*) as cnt FROM community_comments WHERE parent_id=?', [req.params.id])
        const deletedReplies = replyCount[0]?.cnt || 0
        await query('UPDATE community_posts SET comment_count = MAX(0, comment_count - ' + (1 + deletedReplies) + ') WHERE id=?', [c.post_id])
      }

      res.json({ code: 200, msg: '删除成功' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/comment/:id/pin', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const comment = await query('SELECT id, post_id, parent_id, user_id FROM community_comments WHERE id=?', [req.params.id])
      if (!comment || comment.length === 0) return res.json({ code: 404, msg: '评论不存在' })

      const c = comment[0]
      if (Number(c.parent_id) > 0) return res.json({ code: 400, msg: '不能置顶回复' })

      const post = await query('SELECT user_id FROM community_posts WHERE id=?', [c.post_id])
      if (!post || post.length === 0) return res.json({ code: 404, msg: '帖子不存在' })

      const isPostOwner = post[0].user_id === userId
      const isAdminUser = await isAdmin(req)
      if (!isPostOwner && !isAdminUser) {
        return res.json({ code: 403, msg: '无权置顶此评论' })
      }

      const current = await query('SELECT is_pinned FROM community_comments WHERE id=?', [req.params.id])
      const newPinned = current[0]?.is_pinned ? 0 : 1
      await query('UPDATE community_comments SET is_pinned=? WHERE id=?', [newPinned, req.params.id])

      res.json({ code: 200, msg: newPinned ? '置顶成功' : '取消置顶成功', data: { isPinned: !!newPinned } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== Draft APIs ====================

  app.get('/api/community/drafts', async (req, res) => {
    try {
      const { userId } = req.query
      if (!userId) return res.json({ code: 400, msg: '缺少userId参数' })

      const drafts = await query(
        `SELECT id, user_id as userId, section_id as sectionId, title, content,
                images, tags, official_tags as officialTags, has_resource as hasResource,
                resource_type as resourceType, resource_url as resourceUrl,
                resource_price as resourcePrice, resource_price_type as resourcePriceType,
                extract_code as extractCode, permission,
                create_time as createTime, update_time as updateTime
         FROM community_drafts WHERE user_id=? ORDER BY update_time DESC`, [Number(userId)]
      )
      for (const d of drafts) {
        try { d.tags = d.tags ? JSON.parse(d.tags) : [] } catch { d.tags = [] }
        try { d.officialTags = d.officialTags ? JSON.parse(d.officialTags) : [] } catch { d.officialTags = [] }
        try { d.images = d.images ? JSON.parse(d.images) : [] } catch { d.images = [] }
        d.hasResource = !!d.hasResource
      }

      res.json({ code: 200, msg: 'success', data: drafts })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/draft', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const {
        id, sectionId, title, content, images, tags, officialTags,
        hasResource, resourceType, resourceUrl, resourcePrice, resourcePriceType,
        extractCode, permission
      } = req.body

      const imgs = images ? (typeof images === 'string' ? images : JSON.stringify(images)) : '[]'
      const tg = tags ? (typeof tags === 'string' ? tags : JSON.stringify(tags)) : '[]'
      const ot = officialTags ? (typeof officialTags === 'string' ? officialTags : JSON.stringify(officialTags)) : '[]'

      if (id) {
        await query(
          `UPDATE community_drafts SET section_id=?, title=?, content=?, images=?, tags=?, official_tags=?,
           has_resource=?, resource_type=?, resource_url=?, resource_price=?, resource_price_type=?,
           extract_code=?, permission=?, update_time=${nowExpr}
           WHERE id=? AND user_id=?`,
          [sectionId || 0, title || '', content || '', imgs, tg, ot,
           hasResource ? 1 : 0, resourceType || '', resourceUrl || '', resourcePrice || 0, resourcePriceType || 'free',
           extractCode || '', permission || 'public', id, userId]
        )
        res.json({ code: 200, msg: '草稿已更新', data: { id } })
      } else {
        const result = await query(
          `INSERT INTO community_drafts (user_id, section_id, title, content, images, tags, official_tags,
            has_resource, resource_type, resource_url, resource_price, resource_price_type, extract_code, permission)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
          [userId, sectionId || 0, title || '', content || '', imgs, tg, ot,
           hasResource ? 1 : 0, resourceType || '', resourceUrl || '', resourcePrice || 0, resourcePriceType || 'free',
           extractCode || '', permission || 'public']
        )
        res.json({ code: 200, msg: '草稿已保存', data: { id: result.lastInsertRowid || result.insertId } })
      }
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.delete('/api/community/draft/:id', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      await query('DELETE FROM community_drafts WHERE id=? AND user_id=?', [req.params.id, userId])
      res.json({ code: 200, msg: '草稿已删除' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== Admin APIs ====================

  app.get('/api/community/admin/posts', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const { status, page = 1, pageSize = 20 } = req.query
      let sql = `SELECT p.id, p.section_id as sectionId, p.user_id as userId, p.user_name as userName,
                  p.title, p.status, p.is_pinned as isPinned, p.is_essence as isEssence,
                  p.like_count as likeCount, p.comment_count as commentCount,
                  p.view_count as viewCount, p.create_time as createTime
                FROM community_posts p WHERE 1=1`
      const params = []

      if (status) { sql += ' AND p.status=?'; params.push(status) }

      const offset = (parseInt(page) - 1) * parseInt(pageSize)
      const countResult = await query(`SELECT COUNT(*) as total FROM (${sql}) t`, params)
      const total = countResult[0]?.total || 0

      const list = await query(sql + ` ORDER BY p.id DESC LIMIT ${parseInt(pageSize)} OFFSET ${offset}`, params)
      res.json({ code: 200, msg: 'success', data: { list, total, page: parseInt(page), pageSize: parseInt(pageSize) } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.put('/api/community/admin/post/:id/status', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const { status } = req.body
      if (!status) return res.json({ code: 400, msg: '缺少status参数' })

      await query('UPDATE community_posts SET status=?, update_time=' + nowExpr + ' WHERE id=?', [status, req.params.id])
      res.json({ code: 200, msg: '状态已更新' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/admin/ban', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const { userId: targetUserId, reason, duration } = req.body
      if (!targetUserId) return res.json({ code: 400, msg: '缺少userId参数' })

      let bannedUntil = null
      if (duration) {
        const hours = Number(duration)
        if (dbType === 'mysql') {
          bannedUntil = `DATE_ADD(NOW(), INTERVAL ${hours} HOUR)`
        } else {
          bannedUntil = `datetime('now','localtime','+${hours} hours')`
        }
      }

      const userInfo = await query('SELECT nickname FROM users WHERE id=?', [targetUserId])
      const userName = userInfo[0]?.nickname || ''

      const existing = await query('SELECT id FROM community_banned_users WHERE user_id=?', [targetUserId])
      if (existing.length > 0) {
        if (bannedUntil) {
          await query(`UPDATE community_banned_users SET reason=?, banned_until=${bannedUntil} WHERE user_id=?`,
            [reason || '', targetUserId])
        } else {
          await query('UPDATE community_banned_users SET reason=?, banned_until=NULL WHERE user_id=?',
            [reason || '', targetUserId])
        }
      } else {
        const sql = bannedUntil
          ? `INSERT INTO community_banned_users (user_id, user_name, reason, banned_until) VALUES (?,?,?,${bannedUntil})`
          : 'INSERT INTO community_banned_users (user_id, user_name, reason) VALUES (?,?,?)'
        const params = bannedUntil
          ? [targetUserId, userName, reason || '']
          : [targetUserId, userName, reason || '']
        await query(sql, params)
      }

      res.json({ code: 200, msg: '用户已被禁言' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/admin/unban', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const { userId: targetUserId } = req.body
      if (!targetUserId) return res.json({ code: 400, msg: '缺少userId参数' })

      await query('DELETE FROM community_banned_users WHERE user_id=?', [targetUserId])
      res.json({ code: 200, msg: '已解除禁言' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.get('/api/community/admin/banned', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const list = await query(
        `SELECT id, user_id as userId, user_name as userName, reason, banned_until as bannedUntil, create_time as createTime
         FROM community_banned_users ORDER BY create_time DESC`
      )
      res.json({ code: 200, msg: 'success', data: list })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== User Search API ====================

  app.get('/api/community/user/search', async (req, res) => {
    try {
      const { keyword } = req.query
      if (!keyword || keyword.length < 1) return res.json({ code: 400, msg: '请输入搜索关键词' })
      const rows = await query(
        `SELECT id, nickname, avatar FROM users WHERE nickname LIKE ? OR username LIKE ? LIMIT 10`,
        [`%${keyword}%`, `%${keyword}%`]
      )
      res.json({ code: 200, msg: 'success', data: rows })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== Report APIs ====================

  app.post('/api/community/post/:id/report', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const { reportReason, reportDetail } = req.body || {}

      // Store detailed report record
      const user = await query('SELECT username FROM users WHERE id=?', [userId])
      await query(
        `INSERT INTO community_reports (reporter_id, reporter_name, target_type, target_id, report_reason, report_detail)
         VALUES (?,?,?,?,?,?)`,
        [userId, user[0]?.username || '', 'post', Number(req.params.id), reportReason || '其他', reportDetail || '']
      )

      // Also increment the old counter for backward compatibility
      await query('UPDATE community_posts SET reported = COALESCE(reported,0) + 1 WHERE id=?', [req.params.id])
      res.json({ code: 200, msg: '举报成功' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/comment/:id/report', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const { reportReason, reportDetail } = req.body || {}

      const user = await query('SELECT username FROM users WHERE id=?', [userId])
      await query(
        `INSERT INTO community_reports (reporter_id, reporter_name, target_type, target_id, report_reason, report_detail)
         VALUES (?,?,?,?,?,?)`,
        [userId, user[0]?.username || '', 'comment', Number(req.params.id), reportReason || '其他', reportDetail || '']
      )

      await query('UPDATE community_comments SET reported = COALESCE(reported,0) + 1 WHERE id=?', [req.params.id])
      res.json({ code: 200, msg: '举报成功' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.get('/api/community/admin/reports', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId || !(await isAdmin(req))) return res.json({ code: 403, msg: '无权限' })

      const reports = await query(
        `SELECT r.id, r.reporter_id as reporterId, r.reporter_name as reporterName,
                r.target_type as targetType, r.target_id as targetId, r.report_reason as reportReason,
                r.report_detail as reportDetail, r.status, r.create_time as createTime
         FROM community_reports r WHERE r.status = 'pending' ORDER BY r.create_time DESC LIMIT 100`
      )

      // Enrich with target info
      const enriched = []
      for (const r of reports) {
        const item = { ...r }
        if (r.targetType === 'post') {
          const post = await query('SELECT id, title, user_id as userId, user_name as userName, status FROM community_posts WHERE id=?', [r.targetId])
          if (post.length > 0) {
            item.targetTitle = post[0].title
            item.targetUserId = post[0].userId
            item.targetUserName = post[0].userName
            item.targetStatus = post[0].status
          }
        } else {
          const comment = await query('SELECT id, content, user_id as userId, user_name as userName, post_id as postId FROM community_comments WHERE id=?', [r.targetId])
          if (comment.length > 0) {
            item.targetTitle = (comment[0].content || '').substring(0, 50)
            item.targetUserId = comment[0].userId
            item.targetUserName = comment[0].userName
            item.postId = comment[0].postId
          }
        }
        enriched.push(item)
      }

      res.json({ code: 200, msg: 'success', data: enriched })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/admin/report/ignore/:id', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId || !(await isAdmin(req))) return res.json({ code: 403, msg: '无权限' })
      await query('UPDATE community_reports SET status=? WHERE id=?', ['ignored', Number(req.params.id)])
      res.json({ code: 200, msg: '已忽略' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== Unlock Request APIs ====================

  app.post('/api/community/post/:id/request-unlock', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const { reason } = req.body || {}

      const post = await query('SELECT id, user_id, is_locked FROM community_posts WHERE id=?', [req.params.id])
      if (!post.length) return res.json({ code: 404, msg: '帖子不存在' })
      if (!post[0].is_locked) return res.json({ code: 400, msg: '该帖子未被锁定' })
      if (post[0].user_id !== userId) return res.json({ code: 403, msg: '只有帖子作者可以申请解锁' })

      // Check if already has a pending request
      const existing = await query(
        'SELECT id FROM community_unlock_requests WHERE post_id=? AND user_id=? AND status=?',
        [req.params.id, userId, 'pending']
      )
      if (existing.length > 0) return res.json({ code: 400, msg: '已有待处理的解锁申请' })

      const user = await query('SELECT username FROM users WHERE id=?', [userId])
      await query(
        `INSERT INTO community_unlock_requests (post_id, user_id, user_name, reason) VALUES (?,?,?,?)`,
        [Number(req.params.id), userId, user[0]?.username || '', reason || '']
      )
      res.json({ code: 200, msg: '解锁申请已提交' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.get('/api/community/admin/unlock-requests', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId || !(await isAdmin(req))) return res.json({ code: 403, msg: '无权限' })

      const requests = await query(
        `SELECT r.id, r.post_id as postId, r.user_id as userId, r.user_name as userName,
                r.reason, r.status, r.admin_reply as adminReply, r.create_time as createTime,
                p.title as postTitle
         FROM community_unlock_requests r
         LEFT JOIN community_posts p ON r.post_id = p.id
         ORDER BY r.status ASC, r.create_time DESC LIMIT 100`
      )
      res.json({ code: 200, msg: 'success', data: requests })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/admin/unlock-request/:id/handle', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId || !(await isAdmin(req))) return res.json({ code: 403, msg: '无权限' })
      const { action, reply } = req.body || {}

      const ur = await query('SELECT * FROM community_unlock_requests WHERE id=?', [req.params.id])
      if (!ur.length) return res.json({ code: 404, msg: '申请不存在' })
      if (ur[0].status !== 'pending') return res.json({ code: 400, msg: '该申请已处理' })

      if (action === 'approve') {
        await query('UPDATE community_posts SET is_locked=0 WHERE id=?', [ur[0].post_id])
        await query('UPDATE community_unlock_requests SET status=?, admin_reply=?, update_time=datetime(\'now\',\'localtime\') WHERE id=?',
          ['approved', reply || '', req.params.id])
        // Notify user
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id) VALUES (?,?,?,?)`,
          ['解锁申请已通过', `您的解锁申请已通过`, 'system', ur[0].user_id]
        )
        res.json({ code: 200, msg: '已通过解锁申请' })
      } else {
        await query('UPDATE community_unlock_requests SET status=?, admin_reply=?, update_time=datetime(\'now\',\'localtime\') WHERE id=?',
          ['rejected', reply || '', req.params.id])
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id) VALUES (?,?,?,?)`,
          ['解锁申请被拒绝', reply ? `拒绝原因: ${reply}` : '您的解锁申请被拒绝', 'system', ur[0].user_id]
        )
        res.json({ code: 200, msg: '已拒绝解锁申请' })
      }
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.delete('/api/community/admin/report/post/:id', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId || !(await isAdmin(req))) return res.json({ code: 403, msg: '无权限' })

      const post = await query('SELECT section_id, user_id, title FROM community_posts WHERE id=?', [req.params.id])
      if (post.length) {
        await query("UPDATE community_posts SET status='deleted', update_time=" + nowExpr + " WHERE id=?", [req.params.id])
        await query('UPDATE community_sections SET post_count = MAX(0, post_count - 1) WHERE id=?', [post[0].section_id])
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id) VALUES (?,?,?,?)`,
          ['帖子被下架', `您的帖子《${post[0].title}》因被举报已被管理员下架`, 'system', post[0].user_id]
        )
      }
      res.json({ code: 200, msg: '已下架' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.delete('/api/community/admin/report/comment/:id', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId || !(await isAdmin(req))) return res.json({ code: 403, msg: '无权限' })

      await query('DELETE FROM community_comments WHERE id=?', [req.params.id])
      res.json({ code: 200, msg: '已删除' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })
}

module.exports = communityRoutes
