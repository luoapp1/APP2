const { query } = require('../database.cjs')
const { authRequired, sessions, SESSION_TTL } = require('./system.cjs')
const { logFromReq } = require('../middleware/security.cjs')

async function isAdmin(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return false
  const session = sessions.get(token)
  if (session) { const roles = session.roles || []; return roles.includes('R_SUPER') || roles.includes('R_ADMIN') }
  try {
    const rows = await query('SELECT roles FROM sessions WHERE token=?', [token])
    if (rows.length > 0) { const roles = JSON.parse(rows[0].roles || '[]'); return roles.includes('R_SUPER') || roles.includes('R_ADMIN') }
  } catch {}
  return false
}

async function getUserId(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return 0
  const session = sessions.get(token)
  if (session) {
    if (Date.now() - session.createdAt > SESSION_TTL) { sessions.delete(token); return 0 }
    return Number(session.userId) || 0
  }
  try {
    const rows = await query('SELECT user_id, created_at FROM sessions WHERE token=?', [token])
    if (rows.length > 0) {
      const createdAt = typeof rows[0].created_at === 'number' ? rows[0].created_at : new Date(rows[0].created_at).getTime()
      if (Date.now() - createdAt > SESSION_TTL) { return 0 }
      return Number(rows[0].user_id) || 0
    }
  } catch {}
  return 0
}

module.exports = function emailRoutes(app) {
  app.get('/api/email/config', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const rows = await query('SELECT id,host,port,secure,user,from_name,from_address,test_address,register_verify,enabled FROM email_config LIMIT 1')
      res.json({ code: 200, data: rows.length > 0 ? rows[0] : null })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.post('/api/email/config', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const { host, port, secure, user, password, fromName, fromAddress, testAddress, registerVerify, enabled } = req.body
      const existing = await query('SELECT id FROM email_config LIMIT 1')
      if (existing.length > 0) {
        const id = existing[0].id
        await query(`UPDATE email_config SET host=?,port=?,secure=?,user=?,from_name=?,from_address=?,test_address=?,register_verify=?,enabled=?,update_time=datetime('now','localtime') WHERE id=?`,
          [host, port, secure ? 1 : 0, user, fromName || '', fromAddress || user, testAddress || '', registerVerify ? 1 : 0, enabled ? 1 : 0, id])
        if (password) await query('UPDATE email_config SET password=? WHERE id=?', [password, id])
      } else {
        await query(`INSERT INTO email_config (host,port,secure,user,password,from_name,from_address,test_address,register_verify,enabled) VALUES (?,?,?,?,?,?,?,?,?,?)`,
          [host, port, secure ? 1 : 0, user, password, fromName || '', fromAddress || user, testAddress || '', registerVerify ? 1 : 0, enabled ? 1 : 0])
      }
      logFromReq(req, 'config', 'email', 0, `更新邮件服务配置`)
      res.json({ code: 200, message: '保存成功' })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.post('/api/email/test', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const { to } = req.body
      const cfg = await query('SELECT * FROM email_config LIMIT 1')
      if (!cfg.length || !cfg[0].enabled) return res.json({ code: 400, message: '邮件服务未配置或未启用' })
      const ok = await sendEmail(cfg[0], to || cfg[0].test_address, '测试邮件 - Art Design Pro', '这是一封测试邮件，如果您收到此邮件，说明SMTP配置正确。')
      res.json({ code: ok ? 200 : 500, message: ok ? '发送成功' : '发送失败，请检查配置' })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.post('/api/email/send-code', async (req, res) => {
    try {
      const { email, type = 'register' } = req.body
      if (!email) return res.json({ code: 400, message: '请输入邮箱地址' })
      const cfg = await query('SELECT * FROM email_config LIMIT 1')
      if (!cfg.length || !cfg[0].enabled) return res.json({ code: 400, message: '邮件服务暂不可用' })
      const recent = await query("SELECT id FROM email_verifications WHERE email=? AND create_time > datetime('now','-60 seconds')", [email])
      if (recent.length > 0) return res.json({ code: 400, message: '请60秒后再试' })
      const code = String(Math.floor(100000 + Math.random() * 900000))
      const expiresAt = new Date(Date.now() + 10 * 60000).toISOString().replace('T', ' ').substring(0, 19)
      await query('INSERT INTO email_verifications (email, code, type, expires_at) VALUES (?,?,?,?)', [email, code, type, expiresAt])
      const ok = await sendEmail(cfg[0], email, type === 'register' ? '注册验证码 - Art Design Pro' : '邮箱验证码 - Art Design Pro',
        `<div style="max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif"><h2>邮箱验证码</h2><p>您的验证码是：</p><div style="font-size:32px;font-weight:bold;color:#409EFF;padding:10px 20px;background:#f0f7ff;display:inline-block;border-radius:6px;letter-spacing:4px">${code}</div><p style="margin-top:20px;color:#999">验证码10分钟内有效，请勿泄露。</p></div>`)
      res.json({ code: ok ? 200 : 500, message: ok ? '验证码已发送' : '发送失败' })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.post('/api/email/verify-code', async (req, res) => {
    try {
      const { email, code, type = 'register' } = req.body
      const row = await query(`SELECT * FROM email_verifications WHERE email=? AND code=? AND type=? AND used=0 AND expires_at > datetime('now','localtime') ORDER BY create_time DESC LIMIT 1`, [email, code, type])
      if (row.length === 0) return res.json({ code: 400, message: '验证码无效或已过期' })
      await query('UPDATE email_verifications SET used=1 WHERE id=?', [row[0].id])
      res.json({ code: 200, message: '验证成功' })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })
}

async function sendEmail(config, to, subject, html) {
  try {
    const nodemailer = require('nodemailer')
    const transporter = nodemailer.createTransport({
      host: config.host, port: config.port,
      secure: config.secure === 1,
      auth: { user: config.user, pass: config.password }
    })
    await transporter.sendMail({ from: config.from_address ? `"${config.from_name || ''}" <${config.from_address}>` : config.user, to, subject, html })
    return true
  } catch (e) { console.error('邮件发送失败:', e.message); return false }
}
