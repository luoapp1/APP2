const { query } = require('../database.cjs')

function customTaskRoutes(router) {
  router.get('/api/custom-task/list', async (req, res) => {
    try {
      const { status } = req.query
      let where = ''
      const params = []
      if (status) { where = 'WHERE status=?'; params.push(status) }
      const list = await query(`SELECT * FROM custom_tasks ${where} ORDER BY sort_order, id`, params)
      res.json({ code: 200, data: list })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  router.post('/api/custom-task/save', async (req, res) => {
    try {
      const {
        id, name, description, icon, task_type, action_type, target_count,
        section_id, section_limit, points_reward, exp_reward, balance_reward,
        card_key_type, card_key_value, card_key_duration, title_id, status, sort_order,
        start_time, end_time
      } = req.body

      if (!name || !task_type || !action_type) {
        return res.json({ code: 400, msg: '任务名称、类型和动作类型不能为空' })
      }

      const fields = {
        name, description: description || '', icon: icon || '',
        task_type, action_type, target_count: target_count || 1,
        section_id: section_id || 0, section_limit: section_limit || 0,
        points_reward: points_reward || 0, exp_reward: exp_reward || 0,
        balance_reward: balance_reward || 0,
        card_key_type: card_key_type || '', card_key_value: card_key_value || 0,
        card_key_duration: card_key_duration || 0, title_id: title_id || 0,
        status: status || '1', sort_order: sort_order || 0,
        start_time: start_time || null, end_time: end_time || null
      }

      if (id) {
        const sets = Object.keys(fields).map(k => `${k}=?`).join(',')
        const vals = Object.values(fields)
        await query(`UPDATE custom_tasks SET ${sets} WHERE id=?`, [...vals, Number(id)])
      } else {
        const keys = Object.keys(fields).join(',')
        const placeholders = Object.keys(fields).map(() => '?').join(',')
        await query(`INSERT INTO custom_tasks (${keys}) VALUES (${placeholders})`, Object.values(fields))
      }
      res.json({ code: 200, msg: id ? '更新成功' : '创建成功' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  router.post('/api/custom-task/delete', async (req, res) => {
    try {
      await query('DELETE FROM custom_tasks WHERE id=?', [Number(req.body.id)])
      res.json({ code: 200, msg: '删除成功' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  router.get('/api/custom-task/my', async (req, res) => {
    try {
      const userId = req.query.userId || req.headers['x-user-id']
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const now = new Date()
      const dateKey = now.toISOString().slice(0, 10)
      const weekKey = getWeekKey(now)
      const monthKey = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`

      const tasks = await query("SELECT * FROM custom_tasks WHERE status='1' ORDER BY sort_order, id")
      const records = await query(
        'SELECT * FROM task_records WHERE user_id=?',
        [Number(userId)]
      )

      const result = tasks.filter(task => {
        if (task.start_time && new Date(task.start_time) > now) return false
        if (task.end_time && new Date(task.end_time) < now) return false
        return true
      }).map(task => {
        let periodKey = ''
        if (task.task_type === 'daily') periodKey = dateKey
        else if (task.task_type === 'weekly') periodKey = weekKey
        else if (task.task_type === 'monthly') periodKey = monthKey

        const record = records.find(r => r.task_id === task.id && r.period_key === periodKey)
        return {
          ...task,
          progress: record ? record.progress : 0,
          completed: record ? record.status === 'completed' : false,
          recordId: record ? record.id : null
        }
      })

      res.json({ code: 200, data: result })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  router.post('/api/custom-task/do', async (req, res) => {
    try {
      const { userId, taskId, actionCount = 1 } = req.body
      if (!userId || !taskId) return res.json({ code: 400, msg: '参数不完整' })

      const tasks = await query('SELECT * FROM custom_tasks WHERE id=? AND status=?', [Number(taskId), '1'])
      if (!tasks || !tasks.length) return res.json({ code: 404, msg: '任务不存在或已下线' })

      const task = tasks[0]
      const now = new Date()

      // 检查任务时间范围
      if (task.start_time && new Date(task.start_time) > now) {
        return res.json({ code: 400, msg: '任务尚未开始' })
      }
      if (task.end_time && new Date(task.end_time) < now) {
        return res.json({ code: 400, msg: '任务已结束' })
      }

      const dateKey = now.toISOString().slice(0, 10)
      const weekKey = getWeekKey(now)
      const monthKey = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`

      let periodKey = ''
      if (task.task_type === 'daily') periodKey = dateKey
      else if (task.task_type === 'weekly') periodKey = weekKey
      else if (task.task_type === 'monthly') periodKey = monthKey

      const existing = await query(
        'SELECT * FROM task_records WHERE user_id=? AND task_id=? AND period_key=?',
        [Number(userId), Number(taskId), periodKey]
      )

      let record = existing && existing.length > 0 ? existing[0] : null
      const newProgress = (record ? record.progress : 0) + Number(actionCount)
      const completed = newProgress >= task.target_count && task.target_count > 0

      if (record) {
        await query(
          'UPDATE task_records SET progress=?, status=?, completed_at=? WHERE id=?',
          [newProgress, completed ? 'completed' : 'pending', completed ? now.toISOString() : null, record.id]
        )
      } else {
        const userName = req.headers['x-user-name'] || ''
        await query(
          'INSERT INTO task_records (user_id, user_name, task_id, task_name, progress, target_count, status, completed_at, period_key) VALUES (?,?,?,?,?,?,?,?,?)',
          [Number(userId), userName, Number(taskId), task.name, newProgress, task.target_count, completed ? 'completed' : 'pending', completed ? now.toISOString() : null, periodKey]
        )
      }

      const rewards = []
      if (completed) {
        if (task.points_reward > 0) {
          await query('UPDATE users SET points=points+? WHERE id=?', [task.points_reward, Number(userId)])
          await query(
            `INSERT INTO points_records (user_id, user_name, type, amount, source, description) VALUES (?,?,?,?,?,?)`,
            [Number(userId), '', 'earn', task.points_reward, 'task', `完成任务: ${task.name}`]
          )
          rewards.push({ type: 'points', amount: task.points_reward })
        }
        if (task.exp_reward > 0) {
          await query('UPDATE users SET experience=experience+? WHERE id=?', [task.exp_reward, Number(userId)])
          rewards.push({ type: 'experience', amount: task.exp_reward })
        }
        if (task.balance_reward > 0) {
          await query('UPDATE users SET balance=balance+? WHERE id=?', [task.balance_reward, Number(userId)])
          rewards.push({ type: 'balance', amount: task.balance_reward })
        }
        if (task.title_id > 0) {
          const titles = await query('SELECT * FROM custom_titles WHERE id=?', [task.title_id])
          if (titles && titles.length > 0) {
            const title = titles[0]
            const hasTitle = await query(
              'SELECT * FROM user_titles WHERE user_id=? AND title_id=?',
              [Number(userId), task.title_id]
            )
            if (!hasTitle || !hasTitle.length) {
              await query(
                'INSERT INTO user_titles (user_id, title_id, title_name, title_type, obtained_from) VALUES (?,?,?,?,?)',
                [Number(userId), title.id, title.name, title.type || 'task', 'task']
              )
            }
            rewards.push({ type: 'title', name: title.name })
          }
        }
      }

      res.json({
        code: 200,
        msg: completed ? '任务完成!' : `进度 +${actionCount}`,
        data: { progress: newProgress, target: task.target_count, completed, rewards }
      })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })
}

function getWeekKey(date) {
  const d = new Date(date)
  const day = d.getDay()
  const diff = d.getDate() - day + (day === 0 ? -6 : 1)
  const monday = new Date(d.setDate(diff))
  return monday.toISOString().slice(0, 10)
}

module.exports = customTaskRoutes
