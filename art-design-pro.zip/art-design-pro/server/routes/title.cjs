const { query } = require('../database.cjs')
const { authRequired, requirePermission, sessions, SESSION_TTL } = require('./system.cjs')
const { logFromReq } = require('../middleware/security.cjs')

async function getUserId(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return 0
  const session = sessions.get(token)
  if (session) {
    if (Date.now() - session.createdAt > SESSION_TTL) { sessions.delete(token); return 0 }
    return Number(session.userId) || 0
  }
  try {
    const rows = await query('SELECT user_id, roles, created_at FROM sessions WHERE token=?', [token])
    if (rows.length > 0) {
      const createdAt = typeof rows[0].created_at === 'number' ? rows[0].created_at : new Date(rows[0].created_at).getTime()
      if (Date.now() - createdAt > SESSION_TTL) { return 0 }
      return Number(rows[0].user_id) || 0
    }
  } catch {}
  return 0
}

async function isAdmin(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return false
  const session = sessions.get(token)
  if (session) { const roles = session.roles || []; return roles.includes('R_SUPER') || roles.includes('R_ADMIN') }
  try {
    const rows = await query('SELECT roles FROM sessions WHERE token=?', [token])
    if (rows.length > 0) { const roles = JSON.parse(rows[0].roles || '[]'); return roles.includes('R_SUPER') || roles.includes('R_ADMIN') }
  } catch {}
  return false
}

module.exports = function titleRoutes(app) {
  app.get('/api/title/list', async (req, res) => {
    try {
      const list = await query("SELECT * FROM custom_titles WHERE status='1' ORDER BY sort_order ASC")
      res.json({ code: 200, data: list })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.get('/api/title/all', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const list = await query('SELECT * FROM custom_titles ORDER BY sort_order ASC')
      res.json({ code: 200, data: list })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.post('/api/title/save', authRequired, requirePermission('add'), async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const { id, name, icon, color, bgColor, description, conditionType, conditionValue, sortOrder, status } = req.body
      if (id) {
        await query(`UPDATE custom_titles SET name=?,icon=?,color=?,bg_color=?,description=?,condition_type=?,condition_value=?,sort_order=?,status=? WHERE id=?`,
          [name, icon || '', color || '#409EFF', bgColor || '#ecf5ff', description || '', conditionType || 'manual', conditionValue || '', sortOrder || 0, status || '1', id])
        logFromReq(req, 'update', 'title', id, `更新称号"${name}"`)
      } else {
        const result = await query(`INSERT INTO custom_titles (name,icon,color,bg_color,description,condition_type,condition_value,sort_order,status) VALUES (?,?,?,?,?,?,?,?,?)`,
          [name, icon || '', color || '#409EFF', bgColor || '#ecf5ff', description || '', conditionType || 'manual', conditionValue || '', sortOrder || 0, status || '1'])
        logFromReq(req, 'create', 'title', result.insertId || 0, `新增称号"${name}"`)
      }
      res.json({ code: 200, message: '保存成功' })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.delete('/api/title/:id', authRequired, requirePermission('delete'), async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      await query('DELETE FROM user_titles WHERE title_id=?', [req.params.id])
      await query('DELETE FROM custom_titles WHERE id=?', [req.params.id])
      logFromReq(req, 'delete', 'title', req.params.id, `删除称号ID:${req.params.id}`)
      res.json({ code: 200, message: '删除成功' })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.post('/api/user/:id/grant-title', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const userId = parseInt(req.params.id)
      const { titleId } = req.body
      const existing = await query('SELECT id FROM user_titles WHERE user_id=? AND title_id=?', [userId, titleId])
      if (existing.length === 0) {
        await query('INSERT INTO user_titles (user_id, title_id, grant_by) VALUES (?,?,?)', [userId, titleId, '管理员'])
      }
      const title = await query('SELECT name FROM custom_titles WHERE id=?', [titleId])
      const titleName = title.length > 0 ? title[0].name : ''
      await query('UPDATE users SET active_title_id=?, active_title_name=? WHERE id=?', [titleId, titleName, userId])
      logFromReq(req, 'update', 'title', titleId, `授予用户${userId}称号ID:${titleId}`)
      res.json({ code: 200, message: '授予成功' })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.delete('/api/user/:id/revoke-title/:titleId', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const userId = parseInt(req.params.id)
      const titleId = parseInt(req.params.titleId)
      await query('DELETE FROM user_titles WHERE user_id=? AND title_id=?', [userId, titleId])
      await query('UPDATE users SET active_title_id=0, active_title_name="" WHERE id=? AND active_title_id=?', [userId, titleId])
      logFromReq(req, 'delete', 'title', titleId, `撤销用户${userId}称号ID:${titleId}`)
      res.json({ code: 200, message: '撤销成功' })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.post('/api/user/active-title', authRequired, async (req, res) => {
    try {
      const userId = await getUserId(req)
      const { titleId } = req.body
      const row = titleId > 0
        ? await query('SELECT t.name FROM custom_titles t JOIN user_titles ut ON t.id=ut.title_id WHERE ut.user_id=? AND ut.title_id=?', [userId, titleId])
        : []
      const name = row.length > 0 ? row[0].name : ''
      await query('UPDATE users SET active_title_id=?, active_title_name=? WHERE id=?', [titleId || 0, name, userId])
      res.json({ code: 200, message: '设置成功' })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.get('/api/user/titles', authRequired, async (req, res) => {
    try {
      const userId = await getUserId(req)
      const list = await query(`SELECT t.*, ut.grant_time FROM custom_titles t JOIN user_titles ut ON t.id=ut.title_id WHERE ut.user_id=? ORDER BY ut.grant_time DESC`, [userId])
      res.json({ code: 200, data: list })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.get('/api/title/user/:id', async (req, res) => {
    try {
      const userId = parseInt(req.params.id)
      const list = await query(`SELECT t.*, ut.grant_time FROM custom_titles t JOIN user_titles ut ON t.id=ut.title_id WHERE ut.user_id=?`, [userId])
      res.json({ code: 200, data: list })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.get('/api/title/:id/users', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const titleId = parseInt(req.params.id)
      const list = await query(
        `SELECT u.id, u.username, u.nickname, u.avatar, u.level_name as levelName,
                ut.grant_time as grantTime, ut.is_active as isActive
         FROM user_titles ut JOIN users u ON ut.user_id = u.id
         WHERE ut.title_id = ? ORDER BY ut.grant_time DESC`, [titleId]
      )
      res.json({ code: 200, data: list })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })
}
