const { query } = require('../database.cjs')
const nowExpr = 'NOW()'
const multer = require('multer')
const path = require('path')
const fs = require('fs')

const groupFileUploadDir = path.join(__dirname, '..', 'uploads', 'group-files')
if (!fs.existsSync(groupFileUploadDir)) fs.mkdirSync(groupFileUploadDir, { recursive: true })

const groupFileStorage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, groupFileUploadDir),
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname) || '.bin'
    const safeName = Date.now() + '-' + Math.round(Math.random() * 1e9) + ext
    cb(null, safeName)
  }
})

const groupFileUpload = multer({
  storage: groupFileStorage,
  limits: { fileSize: 50 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const dangerous = /\.(exe|sh|bat|cmd|com|msi|php|py|rb|pl)$/i
    if (dangerous.test(path.extname(file.originalname))) {
      return cb(new Error('不允许上传可执行文件'))
    }
    cb(null, true)
  }
})

function getFileType(ext) {
  const imageExts = ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.svg', '.bmp', '.ico']
  const videoExts = ['.mp4', '.avi', '.mov', '.wmv', '.flv', '.mkv', '.webm']
  const audioExts = ['.mp3', '.wav', '.ogg', '.aac', '.flac', '.m4a']
  const docExts = ['.pdf', '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx', '.txt', '.csv']
  const archiveExts = ['.zip', '.rar', '.7z', '.tar', '.gz', '.bz2']
  if (imageExts.includes(ext)) return 'image'
  if (videoExts.includes(ext)) return 'video'
  if (audioExts.includes(ext)) return 'audio'
  if (docExts.includes(ext)) return 'document'
  if (archiveExts.includes(ext)) return 'archive'
  return 'other'
}

module.exports = function chatRoomRoutes(app) {

  // ========== 聊天室 CRUD ==========

  // 获取聊天室列表
  app.get('/api/chat-rooms', async (req, res) => {
    try {
      const { page = 1, pageSize = 20, keyword } = req.query
      let whereClause = "WHERE cr.status = 'active'"
      const params = []
      if (keyword) {
        whereClause += ' AND cr.name LIKE ?'
        params.push('%' + keyword + '%')
      }
    const list = await query(
      `SELECT cr.id, cr.name, cr.description, cr.avatar, cr.owner_id as ownerId,
              cr.max_members as maxMembers, cr.status, cr.chat_enabled as chatEnabled,
              cr.create_time as createTime, cr.join_mode,
              u.username as ownerName, u.avatar as ownerAvatar,
              (SELECT COUNT(*) FROM chat_room_members WHERE room_id = cr.id AND status = 'active') as memberCount,
              (SELECT m.content FROM chat_room_messages m WHERE m.room_id = cr.id AND m.is_recalled = 0 ORDER BY m.id DESC LIMIT 1) as lastMsg,
              (SELECT m.create_time FROM chat_room_messages m WHERE m.room_id = cr.id AND m.is_recalled = 0 ORDER BY m.id DESC LIMIT 1) as lastMsgTime
       FROM chat_rooms cr
         LEFT JOIN users u ON u.id = cr.owner_id
         ${whereClause}
         ORDER BY cr.id DESC LIMIT ? OFFSET ?`,
        [...params, Number(pageSize), (Number(page) - 1) * Number(pageSize)]
      )
      const cnt = await query(
        `SELECT COUNT(*) as total FROM chat_rooms cr ${whereClause}`,
        params
      )
      res.json({ code: 200, msg: 'success', data: { list, total: cnt[0]?.total || 0 } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // 获取我的聊天室
  app.get('/api/chat-rooms/my', async (req, res) => {
    try {
      const { userId } = req.query
      const uid = Number(userId)
      if (!uid) return res.json({ code: 400, msg: '请先登录' })
    const list = await query(
      `SELECT cr.id, cr.name, cr.description, cr.avatar, cr.owner_id as ownerId,
              cr.max_members as maxMembers, cr.status, cr.chat_enabled as chatEnabled,
              cr.create_time as createTime, cr.join_mode,
              u.username as ownerName, u.avatar as ownerAvatar,
              crm.role as myRole,
              (SELECT COUNT(*) FROM chat_room_members WHERE room_id = cr.id AND status = 'active') as memberCount,
              (SELECT m.content FROM chat_room_messages m WHERE m.room_id = cr.id AND m.is_recalled = 0 ORDER BY m.id DESC LIMIT 1) as lastMsg,
              (SELECT m.create_time FROM chat_room_messages m WHERE m.room_id = cr.id AND m.is_recalled = 0 ORDER BY m.id DESC LIMIT 1) as lastMsgTime
       FROM chat_room_members crm
       JOIN chat_rooms cr ON cr.id = crm.room_id
         LEFT JOIN users u ON u.id = cr.owner_id
         WHERE crm.user_id = ? AND crm.status = 'active' AND cr.status = 'active'
         ORDER BY crm.join_time DESC`,
        [uid]
      )
      res.json({ code: 200, msg: 'success', data: list })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // 获取升级申请列表（管理员查看）
  app.get('/api/chat-rooms/limit-upgrades', async (req, res) => {
    try {
      const status = req.query.status || 'pending'
      const rows = await query(
        `SELECT u.*, cr.name as room_name FROM chat_room_limit_upgrades u
         LEFT JOIN chat_rooms cr ON cr.id = u.room_id
         WHERE u.status = ? ORDER BY u.create_time DESC`,
        [status]
      )
      res.json({ code: 200, data: rows || [] })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // 审核升级申请
  app.put('/api/chat-rooms/limit-upgrades/:upgradeId', async (req, res) => {
    try {
      const { userId, status, reviewComment } = req.body
      const uid = Number(userId)
      const upgradeId = Number(req.params.upgradeId)
      if (!uid || !upgradeId) return res.json({ code: 400, msg: '参数错误' })

      const row = await query('SELECT * FROM chat_room_limit_upgrades WHERE id = ?', [upgradeId])
      if (!row || !row.length) return res.json({ code: 404, msg: '申请不存在' })
      if (row[0].status !== 'pending') return res.json({ code: 400, msg: '该申请已处理' })

      await query(
        `UPDATE chat_room_limit_upgrades SET status = ?, reviewed_by = ?, review_comment = ?, review_time = ${nowExpr}
         WHERE id = ?`,
        [status, uid, reviewComment || '', upgradeId]
      )

      if (status === 'approved') {
        await query('UPDATE chat_rooms SET member_limit = ? WHERE id = ?', [row[0].request_limit, row[0].room_id])
      }

      res.json({ code: 200, msg: status === 'approved' ? '已批准' : '已拒绝' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // 检查用户是否可以创建聊天室
  app.get('/api/chat-rooms/can-create', async (req, res) => {
    try {
      const { userId } = req.query
      const uid = Number(userId)
      if (!uid) return res.json({ code: 400, msg: '请先登录' })

      const configRows = await query("SELECT config_value FROM sys_config WHERE config_key='chat_room_create_condition'")
      const configValue = configRows && configRows[0] ? configRows[0].config_value : ''
      let config = { enabled: false, min_experience_level: 0, min_membership_level: 0, min_post_count: 0, min_points: 0 }

      if (configValue) {
        try { config = JSON.parse(configValue) } catch {}
      }

      if (!config.enabled) {
        return res.json({ code: 200, data: { canCreate: true } })
      }

      const users = await query(
        'SELECT u.experience, u.points, u.level_id FROM users u WHERE u.id = ?',
        [uid]
      )
      if (!users || !users.length) return res.json({ code: 400, msg: '用户不存在' })

      const user = users[0]

      let postCount = 0
      if (config.min_post_count > 0) {
        const pcRows = await query('SELECT COUNT(*) as cnt FROM community_posts WHERE user_id = ? AND status IN (\'published\',\'reviewed\')', [uid])
        postCount = pcRows && pcRows[0] ? pcRows[0].cnt : 0
      }

      let userExpLevel = 0
      if (config.min_experience_level > 0) {
        const expLevels = await query(
          'SELECT level FROM experience_levels WHERE exp_required <= ? AND status=\'1\' ORDER BY exp_required DESC LIMIT 1',
          [user.experience]
        )
        userExpLevel = expLevels && expLevels[0] ? expLevels[0].level : 0
      }

      let userMembershipLevel = 0
      if (config.min_membership_level > 0 && user.level_id > 0) {
        const mlRows = await query('SELECT level FROM membership_levels WHERE id = ?', [user.level_id])
        userMembershipLevel = mlRows && mlRows[0] ? mlRows[0].level : 0
      }

      const failReasons = []

      if (config.min_experience_level > 0 && userExpLevel < config.min_experience_level) {
        failReasons.push(`需要经验等级达到 ${config.min_experience_level} 级（当前 ${userExpLevel} 级）`)
      }
      if (config.min_membership_level > 0 && userMembershipLevel < config.min_membership_level) {
        failReasons.push(`需要会员等级达到 ${config.min_membership_level} 级（当前 ${userMembershipLevel} 级）`)
      }
      if (config.min_post_count > 0 && postCount < config.min_post_count) {
        failReasons.push(`需要发帖数达到 ${config.min_post_count}（当前 ${postCount}）`)
      }
      if (config.min_points > 0 && (user.points || 0) < config.min_points) {
        failReasons.push(`需要积分达到 ${config.min_points}（当前 ${user.points || 0}）`)
      }

      if (failReasons.length === 0) {
        res.json({ code: 200, data: { canCreate: true } })
      } else {
        res.json({ code: 200, data: { canCreate: false, reasons: failReasons } })
      }
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // 获取聊天室详情
  app.get('/api/chat-rooms/:roomId', async (req, res) => {
    try {
      const { userId } = req.query
      const rid = Number(req.params.roomId)
      const uid = Number(userId)
      if (!rid) return res.json({ code: 400, msg: '参数错误' })

      const room = await query(
        `SELECT cr.id, cr.name, cr.description, cr.avatar, cr.owner_id as ownerId,
                cr.password, cr.max_members as maxMembers, cr.status,
                cr.chat_enabled as chatEnabled, cr.create_time as createTime,
                cr.join_mode, cr.member_limit,
                u.username as ownerName, u.avatar as ownerAvatar
         FROM chat_rooms cr
         LEFT JOIN users u ON u.id = cr.owner_id
         WHERE cr.id = ?`,
        [rid]
      )
      if (!room || !room.length) return res.json({ code: 404, msg: '聊天室不存在' })

      let myMembership = null
      if (uid) {
        const mem = await query(
          `SELECT role, muted_until, status FROM chat_room_members WHERE room_id = ? AND user_id = ?`,
          [rid, uid]
        )
        if (mem && mem.length) myMembership = mem[0]
      }

      const memberCount = await query(
        `SELECT COUNT(*) as cnt FROM chat_room_members WHERE room_id = ? AND status = 'active'`,
        [rid]
      )

      res.json({
        code: 200, msg: 'success',
        data: {
          ...room[0],
          myMembership,
          memberCount: memberCount[0]?.cnt || 0,
          hasPassword: !!room[0].password
        }
      })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // 创建聊天室
  app.post('/api/chat-rooms', async (req, res) => {
    try {
      const { userId, name, description, avatar, password, maxMembers } = req.body
      const uid = Number(userId)
      if (!uid) return res.json({ code: 400, msg: '请先登录' })
      if (!name || !name.trim()) return res.json({ code: 400, msg: '请输入聊天室名称' })

      // 检查用户角色，决定成员上限
      let memberLimit = 50
      const userInfo = await query('SELECT roles FROM users WHERE id = ?', [uid])
      if (userInfo && userInfo.length) {
        const roles = userInfo[0].roles || ''
        if (roles.includes('super_admin') || roles.includes('admin')) {
          memberLimit = maxMembers || 999999
        }
      }

      const result = await query(
        `INSERT INTO chat_rooms (name, description, avatar, owner_id, password, max_members, member_limit, join_mode)
         VALUES (?, ?, ?, ?, ?, ?, ?, 'public')`,
        [name.trim(), description || '', avatar || '', uid, password || '', maxMembers || 500, memberLimit]
      )
      const roomId = result.insertId

      await query(
        `INSERT INTO chat_room_members (room_id, user_id, role) VALUES (?, ?, 'owner')`,
        [roomId, uid]
      )

      await query(
        `INSERT INTO chat_room_admin_logs (room_id, admin_id, admin_name, action, target_user_id, target_user_name, detail)
         VALUES (?, ?, ?, 'create', ?, ?, ?)`,
        [roomId, uid, req.body.userName || '', uid, req.body.userName || '', `创建了聊天室 "${name}"`]
      )

      res.json({ code: 200, msg: '创建成功', data: { id: roomId } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // 更新聊天室设置（仅管理员）
  app.put('/api/chat-rooms/:roomId', async (req, res) => {
    try {
      const { userId, name, description, avatar, password, chatEnabled, joinMode } = req.body
      const uid = Number(userId)
      const rid = Number(req.params.roomId)
      if (!uid || !rid) return res.json({ code: 400, msg: '参数错误' })

      const room = await query('SELECT owner_id FROM chat_rooms WHERE id = ?', [rid])
      if (!room || !room.length) return res.json({ code: 404, msg: '聊天室不存在' })
      if (room[0].owner_id !== uid) {
        const isAdmin = await query(
          `SELECT id FROM chat_room_members WHERE room_id = ? AND user_id = ? AND role IN ('owner','admin')`,
          [rid, uid]
        )
        if (!isAdmin || !isAdmin.length) return res.json({ code: 403, msg: '仅管理员可修改' })
      }

      const sets = []
      const params = []
      if (name !== undefined) { sets.push('name = ?'); params.push(name) }
      if (description !== undefined) { sets.push('description = ?'); params.push(description) }
      if (avatar !== undefined) { sets.push('avatar = ?'); params.push(avatar) }
      if (password !== undefined) { sets.push('password = ?'); params.push(password) }
      if (chatEnabled !== undefined) { sets.push('chat_enabled = ?'); params.push(chatEnabled ? 1 : 0) }
      if (joinMode !== undefined) { sets.push('join_mode = ?'); params.push(joinMode) }

      if (sets.length > 0) {
        await query(`UPDATE chat_rooms SET ${sets.join(', ')} WHERE id = ?`, [...params, rid])
      }

      await query(
        `INSERT INTO chat_room_admin_logs (room_id, admin_id, admin_name, action, detail)
         VALUES (?, ?, ?, 'update_settings', ?)`,
        [rid, uid, req.body.userName || '', `更新了聊天室设置: ${sets.map(s => s.split('=')[0].trim()).join(', ')}`]
      )

      res.json({ code: 200, msg: '更新成功' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // 删除聊天室
  app.delete('/api/chat-rooms/:roomId', async (req, res) => {
    try {
      const { userId } = req.query
      const uid = Number(userId)
      const rid = Number(req.params.roomId)
      if (!uid || !rid) return res.json({ code: 400, msg: '参数错误' })

      const room = await query('SELECT id, owner_id FROM chat_rooms WHERE id = ?', [rid])
      if (!room || !room.length) return res.json({ code: 404, msg: '聊天室不存在' })
      if (room[0].owner_id !== uid) return res.json({ code: 403, msg: '仅群主可删除' })

      await query(`UPDATE chat_rooms SET status = 'deleted' WHERE id = ?`, [rid])
      res.json({ code: 200, msg: '聊天室已删除' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ========== 成员管理 ==========

  // 加入聊天室
  app.post('/api/chat-rooms/:roomId/join', async (req, res) => {
    try {
      const { userId, password } = req.body
      const uid = Number(userId)
      const rid = Number(req.params.roomId)
      if (!uid || !rid) return res.json({ code: 400, msg: '参数错误' })

      const room = await query(
        'SELECT id, password, max_members, member_limit, join_mode, status FROM chat_rooms WHERE id = ?',
        [rid]
      )
      if (!room || !room.length) return res.json({ code: 404, msg: '聊天室不存在' })
      if (room[0].status !== 'active') return res.json({ code: 400, msg: '聊天室不可用' })

      if (room[0].password && room[0].password !== (password || '')) {
        return res.json({ code: 403, msg: '密码错误' })
      }

      const currentCount = await query(
        'SELECT COUNT(*) as cnt FROM chat_room_members WHERE room_id = ? AND status = ?',
        [rid, 'active']
      )
      const limit = room[0].member_limit || 50
      if (currentCount[0]?.cnt >= limit) {
        return res.json({ code: 400, msg: '聊天室人数已满' })
      }

      // 检查进群方式
      const joinMode = room[0].join_mode || 'public'
      if (joinMode === 'closed') return res.json({ code: 403, msg: '该群聊禁止任何人加入' })

      // 公开群直接加入
      if (joinMode === 'public') {
        // continue below
      } else if (joinMode === 'approval') {
        // 审核模式：提交申请
        const existingReq = await query(
          `SELECT id, status FROM chat_room_join_requests WHERE room_id = ? AND user_id = ? AND status = 'pending'`,
          [rid, uid]
        )
        if (existingReq && existingReq.length) return res.json({ code: 200, msg: '已提交申请，请等待管理员审核' })

        await query(
          `INSERT INTO chat_room_join_requests (room_id, user_id, user_name, user_avatar, reason, status)
           VALUES (?, ?, ?, ?, ?, 'pending')`,
          [rid, uid, req.body.userName || '', req.body.userAvatar || '', req.body.reason || '']
        )
        return res.json({ code: 200, msg: '入群申请已提交，请等待管理员审核' })
      } else if (joinMode === 'invite') {
        return res.json({ code: 403, msg: '该群聊仅支持邀请加入' })
      }

      // 检查黑名单
      const banned = await query(
        `SELECT id FROM chat_room_bans WHERE room_id = ? AND user_id = ? AND status = 'active'
         AND (ban_until IS NULL OR ban_until > ${nowExpr})`,
        [rid, uid]
      )
      if (banned && banned.length > 0) return res.json({ code: 403, msg: '你已被禁止进入此聊天室' })

      const existing = await query(
        'SELECT id, status FROM chat_room_members WHERE room_id = ? AND user_id = ?',
        [rid, uid]
      )
      if (existing && existing.length) {
        if (existing[0].status === 'active') return res.json({ code: 200, msg: '已在聊天室中' })
        await query(`UPDATE chat_room_members SET status = 'active', join_time = ${nowExpr} WHERE id = ?`, [existing[0].id])
      } else {
        await query(
          `INSERT INTO chat_room_members (room_id, user_id, role) VALUES (?, ?, 'member')`,
          [rid, uid]
        )
      }

      res.json({ code: 200, msg: '加入成功' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // 退出聊天室
  app.post('/api/chat-rooms/:roomId/leave', async (req, res) => {
    try {
      const { userId } = req.body
      const uid = Number(userId)
      const rid = Number(req.params.roomId)
      if (!uid || !rid) return res.json({ code: 400, msg: '参数错误' })

      const member = await query(
        'SELECT id, role FROM chat_room_members WHERE room_id = ? AND user_id = ? AND status = ?',
        [rid, uid, 'active']
      )
      if (!member || !member.length) return res.json({ code: 400, msg: '你不在聊天室中' })

      if (member[0].role === 'owner') return res.json({ code: 400, msg: '群主不能退出，请先转让群主或删除聊天室' })

      await query(`UPDATE chat_room_members SET status = 'left' WHERE id = ?`, [member[0].id])
      res.json({ code: 200, msg: '已退出' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // 获取成员列表
  app.get('/api/chat-rooms/:roomId/members', async (req, res) => {
    try {
      const { page = 1, pageSize = 50 } = req.query
      const rid = Number(req.params.roomId)

      const list = await query(
        `SELECT crm.id, crm.user_id as userId, crm.role, crm.muted_until as mutedUntil,
                crm.status, crm.join_time as joinTime,
                u.username, u.avatar
         FROM chat_room_members crm
         LEFT JOIN users u ON u.id = crm.user_id
         WHERE crm.room_id = ? AND crm.status = 'active'
         ORDER BY CASE crm.role WHEN 'owner' THEN 0 WHEN 'admin' THEN 1 ELSE 2 END, crm.join_time ASC
         LIMIT ? OFFSET ?`,
        [rid, Number(pageSize), (Number(page) - 1) * Number(pageSize)]
      )
      const cnt = await query(
        `SELECT COUNT(*) as total FROM chat_room_members WHERE room_id = ? AND status = 'active'`,
        [rid]
      )
      res.json({ code: 200, msg: 'success', data: { list, total: cnt[0]?.total || 0 } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // 禁言成员
  app.put('/api/chat-rooms/:roomId/mute/:userId', async (req, res) => {
    try {
      const { operatorId, duration, type } = req.body
      const oid = Number(operatorId)
      const rid = Number(req.params.roomId)
      const targetUid = Number(req.params.userId)
      if (!oid || !rid || !targetUid) return res.json({ code: 400, msg: '参数错误' })

      const opMember = await query(
        'SELECT role FROM chat_room_members WHERE room_id = ? AND user_id = ? AND status = ?',
        [rid, oid, 'active']
      )
      if (!opMember || !opMember.length) return res.json({ code: 403, msg: '你不是聊天室成员' })
      if (!['owner', 'admin'].includes(opMember[0].role)) return res.json({ code: 403, msg: '仅管理员可操作' })

      const targetMember = await query(
        'SELECT id, role FROM chat_room_members WHERE room_id = ? AND user_id = ? AND status = ?',
        [rid, targetUid, 'active']
      )
      if (!targetMember || !targetMember.length) return res.json({ code: 404, msg: '用户不在聊天室中' })
      if (targetMember[0].role === 'owner') return res.json({ code: 403, msg: '不能禁言群主' })
      if (targetMember[0].role === 'admin' && opMember[0].role !== 'owner') return res.json({ code: 403, msg: '仅群主可禁言管理员' })

      let mutedUntil = null
      if (type === 'permanent') {
        mutedUntil = '2099-12-31 23:59:59'
      } else if (duration) {
        mutedUntil = new Date(Date.now() + Number(duration) * 60000).toISOString().slice(0, 19).replace('T', ' ')
      } else {
        return res.json({ code: 400, msg: '请设置禁言时长' })
      }

      await query(
        `UPDATE chat_room_members SET muted_until = ? WHERE id = ?`,
        [mutedUntil, targetMember[0].id]
      )

      await query(
        `INSERT INTO chat_room_admin_logs (room_id, admin_id, admin_name, action, target_user_id, target_user_name, detail)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [rid, oid, req.body.operatorName || '', 'mute', targetUid, req.body.targetUserName || '',
         type === 'permanent' ? '永久禁言' : `禁言 ${duration} 分钟`]
      )

      res.json({ code: 200, msg: '设置成功' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // 解除禁言
  app.put('/api/chat-rooms/:roomId/unmute/:userId', async (req, res) => {
    try {
      const { operatorId } = req.body
      const oid = Number(operatorId)
      const rid = Number(req.params.roomId)
      const targetUid = Number(req.params.userId)
      if (!oid || !rid || !targetUid) return res.json({ code: 400, msg: '参数错误' })

      const opMember = await query(
        'SELECT role FROM chat_room_members WHERE room_id = ? AND user_id = ? AND status = ?',
        [rid, oid, 'active']
      )
      if (!opMember || !opMember.length) return res.json({ code: 403, msg: '你不是聊天室成员' })
      if (!['owner', 'admin'].includes(opMember[0].role)) return res.json({ code: 403, msg: '仅管理员可操作' })

      await query(
        `UPDATE chat_room_members SET muted_until = NULL WHERE room_id = ? AND user_id = ? AND status = ?`,
        [rid, targetUid, 'active']
      )
      res.json({ code: 200, msg: '已解除禁言' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // 踢出成员
  app.post('/api/chat-rooms/:roomId/kick/:userId', async (req, res) => {
    try {
      const { operatorId, reason } = req.body
      const oid = Number(operatorId)
      const rid = Number(req.params.roomId)
      const targetUid = Number(req.params.userId)
      if (!oid || !rid || !targetUid) return res.json({ code: 400, msg: '参数错误' })

      const opMember = await query(
        'SELECT role FROM chat_room_members WHERE room_id = ? AND user_id = ? AND status = ?',
        [rid, oid, 'active']
      )
      if (!opMember || !opMember.length) return res.json({ code: 403, msg: '你不是聊天室成员' })
      if (!['owner', 'admin'].includes(opMember[0].role)) return res.json({ code: 403, msg: '仅管理员可操作' })

      const targetMember = await query(
        'SELECT role FROM chat_room_members WHERE room_id = ? AND user_id = ? AND status = ?',
        [rid, targetUid, 'active']
      )
      if (!targetMember || !targetMember.length) return res.json({ code: 404, msg: '用户不在聊天室中' })
      if (targetMember[0].role === 'owner') return res.json({ code: 403, msg: '不能踢群主' })

      await query(`UPDATE chat_room_members SET status = 'kicked' WHERE room_id = ? AND user_id = ? AND status = ?`, [rid, targetUid, 'active'])

      await query(
        `INSERT INTO chat_room_admin_logs (room_id, admin_id, admin_name, action, target_user_id, target_user_name, detail)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [rid, oid, req.body.operatorName || '', 'kick', targetUid, req.body.targetUserName || '', reason || '被踢出聊天室']
      )

      res.json({ code: 200, msg: '已踢出' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ========== 聊天室消息 ==========

  // 获取聊天室消息
  app.get('/api/chat-rooms/:roomId/messages', async (req, res) => {
    try {
      const { userId, page = 1, pageSize = 50 } = req.query
      const rid = Number(req.params.roomId)
      const uid = Number(userId)
      if (!uid || !rid) return res.json({ code: 400, msg: '参数错误' })

      const member = await query(
        'SELECT id FROM chat_room_members WHERE room_id = ? AND user_id = ? AND status = ?',
        [rid, uid, 'active']
      )
      if (!member || !member.length) return res.json({ code: 403, msg: '请先加入聊天室' })

      const messages = await query(
        `SELECT m.id, m.room_id as roomId, m.from_user_id as fromUserId,
                m.from_user_name as fromUserName, m.from_user_avatar as fromUserAvatar,
                m.content, m.image_url as imageUrl, m.message_type as messageType,
                m.mention_ids as mentionIds, m.is_recalled as isRecalled,
                m.report_status as reportStatus, m.order_card as orderCard,
                m.create_time as createTime
         FROM chat_room_messages m
         WHERE m.room_id = ?
         ORDER BY m.id ASC LIMIT ? OFFSET ?`,
        [rid, Number(pageSize), (Number(page) - 1) * Number(pageSize)]
      )

      res.json({ code: 200, msg: 'success', data: messages })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // 发送聊天室消息
  app.post('/api/chat-rooms/:roomId/messages', async (req, res) => {
    try {
      const { userId, userName, userAvatar, content, imageUrl, messageType, mentionIds, orderCard } = req.body
      const uid = Number(userId)
      const rid = Number(req.params.roomId)
      if (!uid || !rid) return res.json({ code: 400, msg: '参数错误' })
      if (!content && !imageUrl) return res.json({ code: 400, msg: '消息内容不能为空' })

      const member = await query(
        'SELECT id, muted_until, role FROM chat_room_members WHERE room_id = ? AND user_id = ? AND status = ?',
        [rid, uid, 'active']
      )
      if (!member || !member.length) return res.json({ code: 403, msg: '请先加入聊天室' })

      const room = await query('SELECT chat_enabled FROM chat_rooms WHERE id = ?', [rid])
      if (room && room.length && !room[0].chat_enabled && member[0].role !== 'owner' && member[0].role !== 'admin') {
        return res.json({ code: 403, msg: '聊天室已关闭发言' })
      }

      if (member[0].muted_until) {
        const mutedTime = new Date(member[0].muted_until).getTime()
        if (mutedTime > Date.now()) return res.json({ code: 403, msg: '你已被禁言' })
      }

      // 敏感词过滤
      let filteredContent = content || ''
      try {
        const sensitiveWords = await query(`SELECT word FROM sensitive_words WHERE enabled = 1`)
        if (sensitiveWords && sensitiveWords.length > 0) {
          for (const sw of sensitiveWords) {
            if (sw.word && filteredContent.includes(sw.word)) {
              filteredContent = filteredContent.replaceAll(sw.word, '*'.repeat(sw.word.length))
            }
          }
        }
      } catch (e) {}

      const avatar = userAvatar || '#448AFF'
      const result = await query(
        `INSERT INTO chat_room_messages (room_id, from_user_id, from_user_name, from_user_avatar, content, image_url, message_type, mention_ids, order_card)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [rid, uid, userName || '用户', avatar, filteredContent, imageUrl || '', messageType || 'text', mentionIds || '[]', orderCard || '']
      )

      // 图片消息自动保存为群文件
      if (imageUrl) {
        try {
          const fileName = imageUrl.split('/').pop() || 'image'
          const ext = (fileName.split('.').pop() || 'jpg').toLowerCase()
          const fileType = ['jpg','jpeg','png','gif','webp','bmp','svg'].includes(ext) ? 'image' : 'other'
          await query(
            `INSERT INTO chat_room_files (room_id, user_id, user_name, file_name, file_url, file_type, file_size, mime_type, create_time)
             VALUES (?, ?, ?, ?, ?, ?, 0, ?, ${nowExpr})`,
            [rid, uid, userName || '用户', fileName, imageUrl, fileType, 'image/' + ext]
          )
        } catch (e) {}
      }

      // 处理 @提及通知
      if (mentionIds) {
        try {
          const mentionList = JSON.parse(mentionIds)
          if (Array.isArray(mentionList) && mentionList.length > 0) {
            const roomInfo = await query('SELECT name FROM chat_rooms WHERE id = ?', [rid])
            for (const mid of mentionList) {
              if (mid !== uid) {
                await query(
                  `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar)
                   VALUES (?, ?, 'mention', ?, ?, ?, ?)`,
                  ['有人 @了你', `${userName || '用户'} 在聊天室「${roomInfo[0]?.name || ''}」中 @了你`, mid, uid, userName || '', avatar]
                )
              }
            }
          }
        } catch (e) {}
      }

      res.json({
        code: 200, msg: '发送成功',
        data: {
          id: result.insertId,
          roomId: rid,
          fromUserId: uid,
          fromUserName: userName,
          fromUserAvatar: avatar,
          content: filteredContent,
          imageUrl: imageUrl || '',
          messageType: messageType || 'text',
          orderCard: orderCard || '',
          mentionIds: mentionIds || '[]',
          isRecalled: 0,
          reportStatus: 'none',
          createTime: new Date().toISOString()
        }
      })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // 撤回聊天室消息
  app.put('/api/chat-rooms/:roomId/messages/:msgId/recall', async (req, res) => {
    try {
      const { userId } = req.body
      const uid = Number(userId)
      const rid = Number(req.params.roomId)
      const msgId = Number(req.params.msgId)
      if (!uid || !rid || !msgId) return res.json({ code: 400, msg: '参数错误' })

      const msg = await query(
        'SELECT from_user_id, create_time FROM chat_room_messages WHERE id = ? AND room_id = ?',
        [msgId, rid]
      )
      if (!msg || !msg.length) return res.json({ code: 404, msg: '消息不存在' })
      if (msg[0].from_user_id !== uid) {
        const isAdmin = await query(
          'SELECT id FROM chat_room_members WHERE room_id = ? AND user_id = ? AND role IN (\'owner\',\'admin\')',
          [rid, uid]
        )
        if (!isAdmin || !isAdmin.length) return res.json({ code: 403, msg: '只能撤回自己的消息' })
      }

      const msgTime = new Date(msg[0].create_time).getTime()
      if (Date.now() - msgTime > 2 * 60 * 1000) {
        return res.json({ code: 400, msg: '超过2分钟无法撤回' })
      }

      await query(
        `UPDATE chat_room_messages SET is_recalled = 1, content = '', image_url = '' WHERE id = ?`,
        [msgId]
      )
      res.json({ code: 200, msg: '消息已撤回' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // 举报聊天室消息
  app.post('/api/chat-rooms/:roomId/messages/:msgId/report', async (req, res) => {
    try {
      const { userId, reason, detail } = req.body
      const msgId = Number(req.params.msgId)
      if (!msgId || !userId || !reason) return res.json({ code: 400, msg: '参数不完整' })

      await query(
        `UPDATE chat_room_messages SET report_status = 'reported' WHERE id = ? AND report_status = 'none'`,
        [msgId]
      )

      await query(
        `INSERT INTO chat_reports (message_id, reporter_id, reason, detail, room_id, create_time)
         VALUES (?, ?, ?, ?, ?, NOW())`,
        [msgId, Number(userId), reason, detail || '', Number(req.params.roomId)]
      )

      res.json({ code: 200, msg: '举报已提交' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ========== 管理日志 ==========

  app.get('/api/chat-rooms/:roomId/admin-logs', async (req, res) => {
    try {
      const { page = 1, pageSize = 20 } = req.query
      const rid = Number(req.params.roomId)
      const list = await query(
        `SELECT id, admin_id as adminId, admin_name as adminName, action,
                target_user_id as targetUserId, target_user_name as targetUserName,
                detail, create_time as createTime
         FROM chat_room_admin_logs
         WHERE room_id = ?
         ORDER BY id DESC LIMIT ? OFFSET ?`,
        [rid, Number(pageSize), (Number(page) - 1) * Number(pageSize)]
      )
      const cnt = await query(
        'SELECT COUNT(*) as total FROM chat_room_admin_logs WHERE room_id = ?',
        [rid]
      )
      res.json({ code: 200, msg: 'success', data: { list, total: cnt[0]?.total || 0 } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ========== 管理员管理 ==========

  // 设置/取消管理员
  app.put('/api/chat-rooms/:roomId/set-admin/:userId', async (req, res) => {
    try {
      const { operatorId, isAdmin } = req.body
      const oid = Number(operatorId)
      const rid = Number(req.params.roomId)
      const targetUid = Number(req.params.userId)
      if (!oid || !rid || !targetUid) return res.json({ code: 400, msg: '参数错误' })

      const opMember = await query(
        'SELECT role FROM chat_room_members WHERE room_id = ? AND user_id = ? AND status = ?',
        [rid, oid, 'active']
      )
      if (!opMember || !opMember.length) return res.json({ code: 403, msg: '你不是聊天室成员' })
      if (opMember[0].role !== 'owner') return res.json({ code: 403, msg: '仅群主可设置管理员' })

      const targetMember = await query(
        'SELECT id, role FROM chat_room_members WHERE room_id = ? AND user_id = ? AND status = ?',
        [rid, targetUid, 'active']
      )
      if (!targetMember || !targetMember.length) return res.json({ code: 404, msg: '用户不在聊天室中' })
      if (targetMember[0].role === 'owner') return res.json({ code: 403, msg: '群主不能降级' })

      const newRole = isAdmin ? 'admin' : 'member'
      await query('UPDATE chat_room_members SET role = ? WHERE id = ?', [newRole, targetMember[0].id])

      await query(
        `INSERT INTO chat_room_admin_logs (room_id, admin_id, admin_name, action, target_user_id, target_user_name, detail)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [rid, oid, req.body.operatorName || '', 'set_admin', targetUid, req.body.targetUserName || '',
         isAdmin ? '设为管理员' : '取消管理员']
      )

      res.json({ code: 200, msg: isAdmin ? '已设为管理员' : '已取消管理员' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // 转让群主
  app.post('/api/chat-rooms/:roomId/transfer/:userId', async (req, res) => {
    try {
      const { operatorId } = req.body
      const oid = Number(operatorId)
      const rid = Number(req.params.roomId)
      const targetUid = Number(req.params.userId)
      if (!oid || !rid || !targetUid) return res.json({ code: 400, msg: '参数错误' })

      const room = await query('SELECT owner_id FROM chat_rooms WHERE id = ?', [rid])
      if (!room || !room.length) return res.json({ code: 404, msg: '聊天室不存在' })
      if (room[0].owner_id !== oid) return res.json({ code: 403, msg: '仅群主可转让' })

      const targetMember = await query(
        'SELECT id FROM chat_room_members WHERE room_id = ? AND user_id = ? AND status = ?',
        [rid, targetUid, 'active']
      )
      if (!targetMember || !targetMember.length) return res.json({ code: 404, msg: '用户不在聊天室中' })

      await query('UPDATE chat_rooms SET owner_id = ? WHERE id = ?', [targetUid, rid])
      await query('UPDATE chat_room_members SET role = ? WHERE room_id = ? AND user_id = ?', ['member', rid, oid])
      await query('UPDATE chat_room_members SET role = ? WHERE room_id = ? AND user_id = ?', ['owner', rid, targetUid])

      await query(
        `INSERT INTO chat_room_admin_logs (room_id, admin_id, admin_name, action, target_user_id, target_user_name, detail)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [rid, oid, req.body.operatorName || '', 'transfer', targetUid, req.body.targetUserName || '', '转让群主身份']
      )

      res.json({ code: 200, msg: '群主转让成功' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // 解散群聊（仅群主）
  app.delete('/api/chat-rooms/:roomId/dissolve', async (req, res) => {
    try {
      const { userId } = req.body
      const uid = Number(userId)
      const rid = Number(req.params.roomId)
      if (!uid || !rid) return res.json({ code: 400, msg: '参数错误' })

      const room = await query('SELECT id, owner_id, name FROM chat_rooms WHERE id = ?', [rid])
      if (!room || !room.length) return res.json({ code: 404, msg: '聊天室不存在' })
      if (room[0].owner_id !== uid) return res.json({ code: 403, msg: '仅群主可解散群聊' })

      await query(`UPDATE chat_rooms SET status = 'deleted' WHERE id = ?`, [rid])

      await query(
        `INSERT INTO chat_room_admin_logs (room_id, admin_id, admin_name, action, detail)
         VALUES (?, ?, ?, 'dissolve', ?)`,
        [rid, uid, req.body.userName || '', `解散了聊天室「${room[0].name}」`]
      )

      res.json({ code: 200, msg: '群聊已解散' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ========== 黑名单管理 ==========

  // 永久拉黑（禁止再加入）
  app.post('/api/chat-rooms/:roomId/ban/:userId', async (req, res) => {
    try {
      const { operatorId } = req.body
      const oid = Number(operatorId)
      const rid = Number(req.params.roomId)
      const targetUid = Number(req.params.userId)
      if (!oid || !rid || !targetUid) return res.json({ code: 400, msg: '参数错误' })

      const opMember = await query(
        'SELECT role FROM chat_room_members WHERE room_id = ? AND user_id = ? AND status = ?',
        [rid, oid, 'active']
      )
      if (!opMember || !opMember.length) return res.json({ code: 403, msg: '你不是聊天室成员' })
      if (!['owner', 'admin'].includes(opMember[0].role)) return res.json({ code: 403, msg: '仅管理员可操作' })

      const targetMember = await query(
        'SELECT role FROM chat_room_members WHERE room_id = ? AND user_id = ? AND status = ?',
        [rid, targetUid, 'active']
      )
      if (!targetMember || !targetMember.length) return res.json({ code: 404, msg: '用户不在聊天室中' })
      if (targetMember[0].role === 'owner') return res.json({ code: 403, msg: '不能拉黑群主' })

      // 踢出聊天室
      await query(`UPDATE chat_room_members SET status = 'kicked' WHERE room_id = ? AND user_id = ? AND status = ?`, [rid, targetUid, 'active'])

      // 加入黑名单（永久）
      const existingBan = await query(
        'SELECT id FROM chat_room_bans WHERE room_id = ? AND user_id = ?',
        [rid, targetUid]
      )
      if (existingBan && existingBan.length) {
        await query(`UPDATE chat_room_bans SET status = 'active', ban_until = NULL, banned_by = ? WHERE id = ?`, [oid, existingBan[0].id])
      } else {
        await query(
          `INSERT INTO chat_room_bans (room_id, user_id, type, reason, ban_until, banned_by, status)
           VALUES (?, ?, 'permanent', ?, NULL, ?, 'active')`,
          [rid, targetUid, req.body.reason || '被拉黑', oid]
        )
      }

      await query(
        `INSERT INTO chat_room_admin_logs (room_id, admin_id, admin_name, action, target_user_id, target_user_name, detail)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [rid, oid, req.body.operatorName || '', 'ban', targetUid, req.body.targetUserName || '', '永久拉黑并踢出']
      )

      res.json({ code: 200, msg: '已永久拉黑并踢出' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // 解除拉黑
  app.delete('/api/chat-rooms/:roomId/ban/:userId', async (req, res) => {
    try {
      const { operatorId } = req.body
      const oid = Number(operatorId)
      const rid = Number(req.params.roomId)
      const targetUid = Number(req.params.userId)
      if (!oid || !rid || !targetUid) return res.json({ code: 400, msg: '参数错误' })

      await query(`UPDATE chat_room_bans SET status = 'revoked' WHERE room_id = ? AND user_id = ? AND status = 'active'`, [rid, targetUid])
      res.json({ code: 200, msg: '已解除拉黑' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ========== 群数据统计 ==========

  app.get('/api/chat-rooms/:roomId/stats', async (req, res) => {
    try {
      const rid = Number(req.params.roomId)

      const totalMembers = await query(
        'SELECT COUNT(*) as cnt FROM chat_room_members WHERE room_id = ? AND status = ?',
        [rid, 'active']
      )

      const maleCount = await query(
        `SELECT COUNT(*) as cnt FROM chat_room_members crm
         JOIN users u ON u.id = crm.user_id
         WHERE crm.room_id = ? AND crm.status = ? AND u.gender = '男'`,
        [rid, 'active']
      )

      const femaleCount = await query(
        `SELECT COUNT(*) as cnt FROM chat_room_members crm
         JOIN users u ON u.id = crm.user_id
         WHERE crm.room_id = ? AND crm.status = ? AND u.gender = '女'`,
        [rid, 'active']
      )

      const todayMessages = await query(
        `SELECT COUNT(*) as cnt FROM chat_room_messages
         WHERE room_id = ? AND create_time >= date(${nowExpr})`,
        [rid]
      )

      const weekMessages = await query(
        `SELECT COUNT(*) as cnt FROM chat_room_messages
         WHERE room_id = ? AND create_time >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)`,
        [rid]
      )

      const newMembersToday = await query(
        `SELECT COUNT(*) as cnt FROM chat_room_members
         WHERE room_id = ? AND join_time >= date(${nowExpr})`,
        [rid]
      )

      const totalMessages = await query(
        'SELECT COUNT(*) as cnt FROM chat_room_messages WHERE room_id = ?',
        [rid]
      )

      const fileCount = await query(
        'SELECT COUNT(*) as cnt FROM chat_room_files WHERE room_id = ?',
        [rid]
      )

      res.json({
        code: 200, msg: 'success',
        data: {
          totalMembers: totalMembers[0]?.cnt || 0,
          maleCount: maleCount[0]?.cnt || 0,
          femaleCount: femaleCount[0]?.cnt || 0,
          todayMessages: todayMessages[0]?.cnt || 0,
          weekMessages: weekMessages[0]?.cnt || 0,
          newMembersToday: newMembersToday[0]?.cnt || 0,
          totalMessages: totalMessages[0]?.cnt || 0,
          fileCount: fileCount[0]?.cnt || 0
        }
      })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ========== 群头像上传 ==========

  app.post('/api/chat-rooms/:roomId/avatar', groupFileUpload.single('file'), async (req, res) => {
    try {
      const rid = Number(req.params.roomId)
      const { userId } = req.body
      const uid = Number(userId)
      if (!uid) return res.json({ code: 400, msg: '请先登录' })
      if (!req.file) return res.json({ code: 400, msg: '请选择图片' })

      const mem = await query(
        'SELECT role FROM chat_room_members WHERE room_id = ? AND user_id = ? AND status = ? AND role IN (?, ?)',
        [rid, uid, 'active', 'owner', 'admin']
      )
      if (!mem || !mem.length) return res.json({ code: 403, msg: '仅管理员可修改头像' })

      const ext = path.extname(req.file.originalname).toLowerCase()
      if (!['.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp'].includes(ext)) {
        try { fs.unlinkSync(req.file.path) } catch {}
        return res.json({ code: 400, msg: '仅支持 jpg/png/gif/webp/bmp 格式' })
      }

      const { resolveUploadPath, recordFileUpload, getUserId } = require('./upload.cjs')
      const fileUrl = await resolveUploadPath(req.file, req, false)
      await query('UPDATE chat_rooms SET avatar = ? WHERE id = ?', [fileUrl, rid])
      await recordFileUpload({
        userId: uid,
        fileName: req.file.originalname,
        fileUrl,
        fileSize: req.file.size || 0,
        fileType: path.extname(req.file.originalname),
        mimeType: req.file.mimetype || '',
        category: 'chat_room_avatar'
      })

      res.json({ code: 200, msg: '头像更新成功', data: { avatar: fileUrl } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ========== 群文件 ==========

  // 获取群文件列表
  app.get('/api/chat-rooms/:roomId/files', async (req, res) => {
    try {
      const { page = 1, pageSize = 50, fileType } = req.query
      const rid = Number(req.params.roomId)
      let whereClause = 'WHERE room_id = ?'
      const params = [rid]
      if (fileType) {
        whereClause += ' AND file_type = ?'
        params.push(fileType)
      }
      const list = await query(
        `SELECT id, room_id as roomId, user_id as userId, user_name as userName,
                file_name as fileName, file_url as fileUrl, file_type as fileType,
                file_size as fileSize, mime_type as mimeType,
                create_time as createTime
         FROM chat_room_files
         ${whereClause}
         ORDER BY id DESC LIMIT ? OFFSET ?`,
        [...params, Number(pageSize), (Number(page) - 1) * Number(pageSize)]
      )
      const cnt = await query(
        `SELECT COUNT(*) as total FROM chat_room_files ${whereClause}`,
        params
      )
      res.json({ code: 200, msg: 'success', data: { list, total: cnt[0]?.total || 0 } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // 上传群文件（对接后台文件策略）
  app.post('/api/chat-rooms/:roomId/files', async (req, res) => {
    try {
      const uploadRoutes = require('./upload.cjs')
      const getUserPolicy = uploadRoutes.getUserPolicy
      const createFileFilter = uploadRoutes.createFileFilter
      const resolveUploadPath = uploadRoutes.resolveUploadPath

      const rid = Number(req.params.roomId)
      const { userId, roles } = req.body_parsed || {}

      // 获取用户文件策略
      const uid = Number(req.body?.userId || req.query?.userId || 0)
      const userRoleList = []
      let policy = null
      if (uid) {
        try { policy = await getUserPolicy(uid, userRoleList) } catch {}
      }

      const maxSize = policy ? (policy.max_file_size_mb || 10) * 1024 * 1024 : 50 * 1024 * 1024
      const allowedTypes = policy ? policy.allowed_types : ''
      const bannedTypes = policy ? policy.banned_types : ''

      const uploadDir = path.join(__dirname, '..', 'uploads', 'group-files')
      if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true })

      const storage = multer.diskStorage({
        destination: (_r, _f, cb) => cb(null, uploadDir),
        filename: (_r, file, cb) => {
          const ext = path.extname(file.originalname) || '.bin'
          cb(null, Date.now() + '-' + Math.round(Math.random() * 1e9) + ext)
        }
      })

      const dynamicUpload = multer({
        storage,
        limits: { fileSize: maxSize },
        fileFilter: createFileFilter(allowedTypes, bannedTypes)
      })

      dynamicUpload.single('file')(req, res, async (err) => {
        if (err) return res.json({ code: 400, msg: err.message || '上传失败' })
        if (!req.file) return res.json({ code: 400, msg: '请选择文件' })

        const originalName = req.file.originalname

        const { checkStorageQuota, resolveUploadPath } = require('./upload.cjs')
        const quota = await checkStorageQuota(uid, req.file.size || 0, 'general')
        if (!quota.ok) return res.json({ code: 400, msg: quota.msg })

        const fileUrl = await resolveUploadPath(req.file, req, false)
        const ext = path.extname(originalName).toLowerCase()
        const fileType = getFileType(ext)
        const userName = req.body.userName || ''

        const result = await query(
          `INSERT INTO chat_room_files (room_id, user_id, user_name, file_name, file_url, file_type, file_size, mime_type, create_time)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ${nowExpr})`,
          [rid, uid, userName, originalName, fileUrl, fileType, req.file.size || 0, req.file.mimetype || '']
        )

        const { recordFileUpload, buildFileDesc, updateUserUsedBytes } = require('./upload.cjs')
        await recordFileUpload({
          userId: uid,
          fileName: originalName,
          fileUrl,
          fileSize: req.file.size || 0,
          fileType: ext,
          mimeType: req.file.mimetype || '',
          category: 'group_file',
          description: buildFileDesc({ category: 'general', refType: 'group_file' })
        })
        await updateUserUsedBytes(uid)

        res.json({
          code: 200, msg: '上传成功',
          data: {
             id: result.insertId,
            roomId: rid, userId: uid, userName,
            fileName: originalName, fileUrl, fileType,
            fileSize: req.file.size, mimeType: req.file.mimetype,
            createTime: new Date().toISOString()
          }
        })
      })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // 删除群文件
  app.delete('/api/chat-rooms/:roomId/files/:fileId', async (req, res) => {
    try {
      const fileId = Number(req.params.fileId)
      const { userId } = req.body
      const rows = await query('SELECT * FROM chat_room_files WHERE id = ?', [fileId])
      if (!rows.length) return res.json({ code: 404, msg: '文件不存在' })

      await query('DELETE FROM chat_room_files WHERE id = ?', [fileId])

      const filePath = path.join(__dirname, '..', rows[0].file_url)
      try { fs.unlinkSync(filePath) } catch {}

      res.json({ code: 200, msg: '删除成功' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ========== 入群申请管理 ==========

  // 获取入群申请列表（管理员查看）
  app.get('/api/chat-rooms/:roomId/join-requests', async (req, res) => {
    try {
      const rid = Number(req.params.roomId)
      const status = req.query.status || 'pending'
      const rows = await query(
        `SELECT * FROM chat_room_join_requests WHERE room_id = ? AND status = ? ORDER BY create_time DESC`,
        [rid, status]
      )
      res.json({ code: 200, data: rows || [] })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // 审核入群申请
  app.put('/api/chat-rooms/:roomId/join-requests/:requestId', async (req, res) => {
    try {
      const { userId, status, reviewComment } = req.body
      const uid = Number(userId)
      const rid = Number(req.params.roomId)
      const reqId = Number(req.params.requestId)
      if (!uid || !rid || !reqId) return res.json({ code: 400, msg: '参数错误' })

      const reqRow = await query('SELECT * FROM chat_room_join_requests WHERE id = ? AND room_id = ?', [reqId, rid])
      if (!reqRow || !reqRow.length) return res.json({ code: 404, msg: '申请不存在' })

      await query(
        `UPDATE chat_room_join_requests SET status = ?, reviewed_by = ?, review_comment = ?, review_time = ${nowExpr}
         WHERE id = ?`,
        [status, uid, reviewComment || '', reqId]
      )

      if (status === 'approved') {
        const existing = await query('SELECT id FROM chat_room_members WHERE room_id = ? AND user_id = ?', [rid, reqRow[0].user_id])
        if (!existing || !existing.length) {
          await query(`INSERT INTO chat_room_members (room_id, user_id, role) VALUES (?, ?, 'member')`, [rid, reqRow[0].user_id])
        } else {
          await query(`UPDATE chat_room_members SET status = 'active' WHERE id = ?`, [existing[0].id])
        }
      }

      res.json({ code: 200, msg: status === 'approved' ? '已通过' : '已拒绝' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // 邀请成员加入
  app.post('/api/chat-rooms/:roomId/invite', async (req, res) => {
    try {
      const { userId, targetAccount } = req.body
      const uid = Number(userId)
      const rid = Number(req.params.roomId)
      if (!uid || !rid) return res.json({ code: 400, msg: '参数错误' })
      if (!targetAccount || !targetAccount.trim()) return res.json({ code: 400, msg: '请输入要邀请的账号/ID' })

      const targetUser = await query(
        'SELECT id FROM users WHERE id = ? OR username = ?',
        [Number(targetAccount) || 0, targetAccount.trim()]
      )
      if (!targetUser || !targetUser.length) return res.json({ code: 404, msg: '用户不存在' })

      const targetUid = targetUser[0].id
      const existing = await query(
        'SELECT id, status FROM chat_room_members WHERE room_id = ? AND user_id = ?',
        [rid, targetUid]
      )
      if (existing && existing.length && existing[0].status === 'active') {
        return res.json({ code: 200, msg: '该用户已在群聊中' })
      }

      if (existing && existing.length) {
        await query(`UPDATE chat_room_members SET status = 'active' WHERE id = ?`, [existing[0].id])
      } else {
        await query(`INSERT INTO chat_room_members (room_id, user_id, role) VALUES (?, ?, 'member')`, [rid, targetUid])
      }

      res.json({ code: 200, msg: '邀请成功' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ========== 成员上限升级申请 ==========

  // 提交升级申请
  app.post('/api/chat-rooms/:roomId/limit-upgrade', async (req, res) => {
    try {
      const { userId, requestLimit, reason } = req.body
      const uid = Number(userId)
      const rid = Number(req.params.roomId)
      if (!uid || !rid) return res.json({ code: 400, msg: '参数错误' })
      if (!requestLimit || requestLimit < 1) return res.json({ code: 400, msg: '请输入目标上限' })

      const room = await query('SELECT member_limit, owner_id FROM chat_rooms WHERE id = ?', [rid])
      if (!room || !room.length) return res.json({ code: 404, msg: '聊天室不存在' })

      const currentLimit = room[0].member_limit || 50
      if (requestLimit <= currentLimit) return res.json({ code: 400, msg: '目标上限需大于当前上限' })

      const pending = await query(
        `SELECT id FROM chat_room_limit_upgrades WHERE room_id = ? AND status = 'pending'`,
        [rid]
      )
      if (pending && pending.length) return res.json({ code: 400, msg: '已有待审核的升级申请' })

      await query(
        `INSERT INTO chat_room_limit_upgrades (room_id, user_id, current_limit, request_limit, reason, status)
         VALUES (?, ?, ?, ?, ?, 'pending')`,
        [rid, uid, currentLimit, requestLimit, reason || '']
      )

      res.json({ code: 200, msg: '升级申请已提交' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

}
