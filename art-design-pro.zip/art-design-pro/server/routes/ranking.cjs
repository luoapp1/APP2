const { query } = require('../database.cjs')

module.exports = function (app) {
  app.get('/api/ranking/:type', async (req, res) => {
    try {
      const { type } = req.params
      const pageSize = parseInt(req.query.pageSize) || 50
      const currentUserId = parseInt(req.query.userId) || 0
      let sql = ''

      switch (type) {
        case 'apps':
          sql = `
            SELECT u.id AS user_id, u.username, u.nickname, u.avatar,
                   COUNT(ast.id) AS count
            FROM users u
            INNER JOIN app_store ast ON ast.user_id = u.id
            WHERE ast.status = '1' AND u.status = '1'
            GROUP BY u.id
            ORDER BY count DESC
            LIMIT ${pageSize}
          `
          break
        case 'posts':
          sql = `
            SELECT u.id AS user_id, u.username, u.nickname, u.avatar,
                   COUNT(cp.id) AS count
            FROM users u
            INNER JOIN community_posts cp ON cp.user_id = u.id
            WHERE cp.status = 'published' AND u.status = '1'
            GROUP BY u.id
            ORDER BY count DESC
            LIMIT ${pageSize}
          `
          break
        case 'experience':
          sql = `
            SELECT u.id AS user_id, u.username, u.nickname, u.avatar,
                   u.experience AS count,
                   el.icon AS level_icon
            FROM users u
            LEFT JOIN experience_levels el ON el.level = (
              SELECT MAX(el2.level) FROM experience_levels el2
              WHERE el2.exp_required <= u.experience AND el2.status = '1'
            )
            WHERE u.status = '1'
            ORDER BY u.experience DESC
            LIMIT ${pageSize}
          `
          break
        case 'points':
          sql = `
            SELECT u.id AS user_id, u.username, u.nickname, u.avatar,
                   u.points AS count
            FROM users u
            WHERE u.status = '1'
            ORDER BY u.points DESC
            LIMIT ${pageSize}
          `
          break
        default:
          return res.json({ code: 400, msg: '不支持的排行榜类型', data: null })
      }

      const rows = await query(sql)

      if (currentUserId > 0 && rows.length > 0) {
        const ids = rows.map((r) => r.user_id)
        const placeholders = ids.map(() => '?').join(',')
        const followed = await query(
          `SELECT following_id FROM user_follows WHERE follower_id = ? AND following_id IN (${placeholders})`,
          [currentUserId, ...ids]
        )
        const followedSet = new Set(followed.map((f) => f.following_id))
        rows.forEach((r) => {
          r.is_followed = followedSet.has(r.user_id) ? 1 : 0
        })
      }

      res.json({ code: 200, msg: 'ok', data: { list: rows } })
    } catch (e) {
      console.error('排行榜查询失败:', e)
      res.json({ code: 500, msg: '查询失败', data: null })
    }
  })
}
