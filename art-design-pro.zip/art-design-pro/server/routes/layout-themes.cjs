const { query } = require('../database.cjs')
const { authRequired, requirePermission, sessions, SESSION_TTL } = require('./system.cjs')
const { systemLog, logFromReq } = require('../middleware/security.cjs')

async function getUserId(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return 0
  const session = sessions.get(token)
  if (session) {
    if (Date.now() - session.createdAt > SESSION_TTL) { sessions.delete(token); return 0 }
    return Number(session.userId) || 0
  }
  try {
    const rows = await query('SELECT user_id, created_at FROM sessions WHERE token=?', [token])
    if (rows.length > 0) {
      const createdAt = typeof rows[0].created_at === 'number' ? rows[0].created_at : new Date(rows[0].created_at).getTime()
      if (Date.now() - createdAt > SESSION_TTL) { return 0 }
      return Number(rows[0].user_id) || 0
    }
  } catch {}
  return 0
}

async function isAdmin(userId) {
  if (!userId || userId <= 0) return false
  const rows = await query('SELECT roles FROM users WHERE id=?', [userId])
  if (!rows.length) return false
  try {
    const roles = typeof rows[0].roles === 'string' ? JSON.parse(rows[0].roles) : rows[0].roles
    return Array.isArray(roles) && (roles.includes('R_SUPER') || roles.includes('R_ADMIN'))
  } catch { return false }
}

const DEFAULT_PC_ID = 'pc'
const DEFAULT_MOBILE_ID = 'mobile'

function layoutThemeRoutes(router) {
  router.get('/api/layout-themes', async (req, res) => {
    try {
      const fs = require('fs')
      const path = require('path')
      const themesDir = path.join(__dirname, '..', '..', 'src', 'themes')

      const result = []

      for (const type of ['pc', 'mobile']) {
        const dirPath = path.join(themesDir, type)
        if (!fs.existsSync(dirPath)) continue
        const entries = fs.readdirSync(dirPath, { withFileTypes: true })
        for (const entry of entries) {
          if (!entry.isDirectory()) continue
          const manifestPath = path.join(dirPath, entry.name, 'manifest.json')
          let meta = { id: entry.name, name: entry.name, type, description: '' }
          if (fs.existsSync(manifestPath)) {
            try {
              meta = { ...meta, ...JSON.parse(fs.readFileSync(manifestPath, 'utf8')) }
            } catch {}
          }
          result.push(meta)
        }
      }

      const [pcCfg, mobileCfg] = await Promise.all([
        query("SELECT config_value FROM sys_config WHERE config_key='active_pc_layout'"),
        query("SELECT config_value FROM sys_config WHERE config_key='active_mobile_layout'")
      ])

      res.json({
        code: 200,
        data: {
          themes: result,
          activePc: pcCfg[0]?.config_value || DEFAULT_PC_ID,
          activeMobile: mobileCfg[0]?.config_value || DEFAULT_MOBILE_ID
        }
      })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  router.get('/api/layout-themes/active', async (req, res) => {
    try {
      const device = req.query.device
      const key = device === 'mobile' ? 'active_mobile_layout' : 'active_pc_layout'
      const rows = await query('SELECT config_value FROM sys_config WHERE config_key=?', [key])
      res.json({
        code: 200,
        data: {
          activeId: rows[0]?.config_value || (device === 'mobile' ? DEFAULT_MOBILE_ID : DEFAULT_PC_ID)
        }
      })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  router.post('/api/layout-themes/active', authRequired, requirePermission('edit'), async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!(await isAdmin(userId))) {
        return res.json({ code: 403, msg: '无权限' })
      }

      const { device, themeId } = req.body
      if (!device || !['pc', 'mobile'].includes(device)) {
        return res.json({ code: 400, msg: 'device 参数无效，需要 pc 或 mobile' })
      }
      if (!themeId) {
        return res.json({ code: 400, msg: 'themeId 不能为空' })
      }

      const key = device === 'mobile' ? 'active_mobile_layout' : 'active_pc_layout'
      const existing = await query('SELECT id FROM sys_config WHERE config_key=?', [key])
      if (existing && existing.length > 0) {
        await query('UPDATE sys_config SET config_value=?, update_time=NOW() WHERE config_key=?', [themeId, key])
      } else {
        await query("INSERT INTO sys_config (config_key, config_value, description) VALUES (?,?,?)",
          [key, themeId, `激活的${device === 'mobile' ? '手机' : 'PC'}布局主题ID`])
      }

      logFromReq(req, 'update', 'sys_config', 0,
        `切换${device === 'mobile' ? '手机' : 'PC'}布局主题: ${themeId}`)

      res.json({ code: 200, msg: '保存成功' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })
}

module.exports = layoutThemeRoutes
