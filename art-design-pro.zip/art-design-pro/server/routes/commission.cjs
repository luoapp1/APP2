const crypto = require('crypto')
const { query } = require('../database.cjs')
const { sessions, SESSION_TTL } = require('./system.cjs')
const { logFromReq } = require('../middleware/security.cjs')

async function getUserId(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return 0
  const session = sessions.get(token)
  if (session) {
    if (Date.now() - session.createdAt > SESSION_TTL) { sessions.delete(token); return 0 }
    return Number(session.userId) || 0
  }
  return 0
}

function genCode() { return crypto.randomBytes(8).toString('hex') }

module.exports = function commissionRoutes(app) {
  // 获取返佣规则列表
  app.get('/api/commission/rules', async (req, res) => {
    try {
      const list = await query('SELECT * FROM commission_rules ORDER BY id')
      res.json({ code: 200, data: list })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // 保存返佣规则
  app.post('/api/commission/rule/save', async (req, res) => {
    try {
      const { id, name, order_type, rate, user_level_id, user_level_name, user_id, invite_code_id, status } = req.body
      if (id) {
        await query(
          'UPDATE commission_rules SET name=?, order_type=?, rate=?, user_level_id=?, user_level_name=?, user_id=?, invite_code_id=?, status=? WHERE id=?',
          [name, order_type, rate, user_level_id || 0, user_level_name || '', user_id || 0, invite_code_id || 0, status || '1', Number(id)]
        )
        logFromReq(req, 'update', 'commission_rule', Number(id), `更新返佣规则"${name}"`)
      } else {
        const result = await query(
          'INSERT INTO commission_rules (name, order_type, rate, user_level_id, user_level_name, user_id, invite_code_id, status) VALUES (?,?,?,?,?,?,?,?)',
          [name, order_type, rate, user_level_id || 0, user_level_name || '', user_id || 0, invite_code_id || 0, status || '1']
        )
        logFromReq(req, 'create', 'commission_rule', result.lastInsertRowid || result.insertId, `新增返佣规则"${name}"`)
      }
      res.json({ code: 200, msg: '保存成功' })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // 删除返佣规则
  app.post('/api/commission/rule/delete', async (req, res) => {
    try {
      await query('DELETE FROM commission_rules WHERE id=?', [Number(req.body.id)])
      logFromReq(req, 'delete', 'commission_rule', req.body.id, `删除返佣规则ID:${req.body.id}`)
      res.json({ code: 200, msg: '删除成功' })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // 返佣记录列表
  app.get('/api/commission/records', async (req, res) => {
    try {
      const userId = await getUserId(req)
      const { page = 1, pageSize = 20 } = req.query
      const offset = (Number(page) - 1) * Number(pageSize)
      let where = userId ? 'WHERE referrer_id=? OR user_id=?' : 'WHERE 1=1'
      let params = userId ? [userId, userId] : []

      if (req.query.status) { where += ' AND status=?'; params.push(req.query.status) }

      const total = await query(`SELECT COUNT(*) as total FROM commission_records ${where}`, params)
      const list = await query(
        `SELECT * FROM commission_records ${where} ORDER BY create_time DESC LIMIT ? OFFSET ?`,
        [...params, Number(pageSize), offset]
      )
      res.json({ code: 200, data: { list, total: total[0]?.total || 0 } })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // 计算返佣
  async function calcCommission(orderId, orderType, orderAmount, userId) {
    try {
      const userRows = await query('SELECT id, referrer_id, referrer_code, username FROM users WHERE id=?', [userId])
      if (!userRows.length || !userRows[0].referrer_id) return

      const referrerId = userRows[0].referrer_id
      const referrerRows = await query('SELECT username FROM users WHERE id=?', [referrerId])
      const referrerName = referrerRows.length > 0 ? referrerRows[0].username : ''
      const referrerCode = userRows[0].referrer_code || ''

      // 查找匹配的邀请码ID
      let inviteCodeId = 0
      if (referrerCode) {
        const codeRows = await query('SELECT id FROM invite_codes WHERE code=?', [referrerCode])
        if (codeRows.length) inviteCodeId = codeRows[0].id
      }

      // 查找适用的返佣规则（优先级：邀请码专属用户 > 用户专属 > 等级 > 全局）
      let rules = []
      if (inviteCodeId) {
        rules = await query(
          'SELECT * FROM commission_rules WHERE status=? AND invite_code_id=? AND (order_type=? OR order_type=?)',
          ['1', inviteCodeId, orderType, 'all']
        )
      }
      if (!rules.length) {
        rules = await query(
          'SELECT * FROM commission_rules WHERE status=? AND user_id=? AND invite_code_id=0 AND (order_type=? OR order_type=?)',
          ['1', referrerId, orderType, 'all']
        )
      }
      if (!rules.length) {
        const levelRow = await query('SELECT level_id FROM users WHERE id=?', [referrerId])
        const levelId = levelRow.length > 0 ? levelRow[0].level_id : 0
        if (levelId) {
          rules = await query(
            'SELECT * FROM commission_rules WHERE status=? AND user_level_id=? AND invite_code_id=0 AND (order_type=? OR order_type=?)',
            ['1', levelId, orderType, 'all']
          )
        }
      }
      if (!rules.length) {
        rules = await query(
          "SELECT * FROM commission_rules WHERE status=? AND user_level_id=0 AND user_id=0 AND invite_code_id=0 AND (order_type=? OR order_type=?)",
          ['1', orderType, 'all']
        )
      }

      if (rules.length) {
        const rule = rules[0]
        const amount = (orderAmount * rule.rate / 100).toFixed(2)
        if (Number(amount) <= 0) return

        await query(
          `INSERT INTO commission_records (order_id, order_type, order_amount, user_id, user_name, referrer_id, referrer_name, rate, amount, status)
           VALUES (?,?,?,?,?,?,?,?,?,?)`,
          [orderId, orderType, orderAmount, userId, '', referrerId, referrerName, rule.rate, Number(amount), 'pending']
        )

        // 更新推广人余额
        await query('UPDATE users SET balance=balance+? WHERE id=?', [Number(amount), referrerId])
        await query('UPDATE commission_records SET status=? WHERE order_id=? AND referrer_id=?',
          ['completed', orderId, referrerId])
      }
    } catch (e) { console.error('返佣计算失败:', e.message) }
  }

  // 生成推广链接
  app.post('/api/commission/referral/generate', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const existing = await query('SELECT * FROM referral_links WHERE user_id=?', [userId])
      if (existing.length) {
        return res.json({ code: 200, data: existing[0] })
      }

      const code = genCode()
      const { mode = 'purchase', discount = 0 } = req.body
      await query(
        'INSERT INTO referral_links (user_id, code, mode, discount) VALUES (?,?,?,?)',
        [userId, code, mode, discount]
      )
      res.json({ code: 200, data: { user_id: userId, code, mode, discount } })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // 获取推广链接
  app.get('/api/commission/referral', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const row = await query('SELECT * FROM referral_links WHERE user_id=?', [userId])
      res.json({ code: 200, data: row.length > 0 ? row[0] : null })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // 通过推广码绑定推荐人
  app.post('/api/commission/referral/bind', async (req, res) => {
    try {
      const { code } = req.body
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const ref = await query('SELECT * FROM referral_links WHERE code=?', [code])
      if (!ref.length) return res.json({ code: 404, msg: '推广链接无效' })
      if (ref[0].user_id === userId) return res.json({ code: 400, msg: '不能绑定自己的推广链接' })

      const currentRef = await query('SELECT referrer_id FROM users WHERE id=?', [userId])
      if (currentRef.length && currentRef[0].referrer_id) {
        return res.json({ code: 400, msg: '已绑定推荐人' })
      }

      await query('UPDATE users SET referrer_id=?, referrer_code=? WHERE id=?', [ref[0].user_id, code, userId])
      await query('UPDATE referral_links SET register_count=register_count+1 WHERE id=?', [ref[0].id])

      res.json({ code: 200, msg: '推荐人绑定成功' })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // 提现记录
  app.get('/api/commission/withdraw/list', async (req, res) => {
    try {
      const { page = 1, pageSize = 20, status, userId: queryUserId } = req.query
      const offset = (Number(page) - 1) * Number(pageSize)
      let where = 'WHERE 1=1'
      const params = []

      const currentUserId = await getUserId(req)
      if (currentUserId) {
        const isAdmin = await checkAdmin(req)
        if (!isAdmin) { where += ' AND user_id=?'; params.push(currentUserId) }
      }

      if (status) { where += ' AND status=?'; params.push(status) }
      if (queryUserId && currentUserId !== Number(queryUserId)) { where += ' AND user_id=?'; params.push(Number(queryUserId)) }

      const total = await query(`SELECT COUNT(*) as total FROM withdraw_records ${where}`, params)
      const list = await query(
        `SELECT * FROM withdraw_records ${where} ORDER BY create_time DESC LIMIT ? OFFSET ?`,
        [...params, Number(pageSize), offset]
      )
      res.json({ code: 200, data: { list, total: total[0]?.total || 0 } })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // 申请提现
  app.post('/api/commission/withdraw/apply', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const { amount, method, account, realName } = req.body
      if (!amount || Number(amount) <= 0) return res.json({ code: 400, msg: '提现金额无效' })

      const users = await query('SELECT username, balance FROM users WHERE id=?', [userId])
      if (!users.length) return res.json({ code: 404, msg: '用户不存在' })

      if (users[0].balance < Number(amount)) return res.json({ code: 400, msg: '余额不足' })

      await query(
        `INSERT INTO withdraw_records (user_id, user_name, amount, method, account, real_name, status)
         VALUES (?,?,?,?,?,?,?)`,
        [userId, users[0].username, Number(amount), method || 'alipay', account || '', realName || '', 'pending']
      )
      await query('UPDATE users SET balance=balance-? WHERE id=?', [Number(amount), userId])

      res.json({ code: 200, msg: '提现申请已提交' })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // 审核提现
  app.post('/api/commission/withdraw/review', async (req, res) => {
    try {
      const { id, status, remark } = req.body
      const reviewerId = await getUserId(req)
      const reviewer = await query('SELECT username FROM users WHERE id=?', [reviewerId])
      const reviewerName = reviewer.length > 0 ? reviewer[0].username : ''

      if (status === 'rejected') {
        const record = await query('SELECT user_id, amount FROM withdraw_records WHERE id=?', [Number(id)])
        if (record.length > 0) {
          await query('UPDATE users SET balance=balance+? WHERE id=?', [record[0].user_id, record[0].amount])
        }
      }

      await query(
        'UPDATE withdraw_records SET status=?, remark=?, reviewed_by=?, reviewed_by_name=?, reviewed_at=datetime(\'now\',\'localtime\') WHERE id=?',
        [status, remark || '', reviewerId, reviewerName, Number(id)]
      )
      logFromReq(req, 'update', 'withdraw', Number(id), `审核提现ID:${id} ${status === 'completed' ? '通过' : '拒绝'}${remark ? '(' + remark + ')' : ''}`)
      res.json({ code: 200, msg: status === 'completed' ? '提现已通过' : '提现已拒绝' })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  async function checkAdmin(req) {
    const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '')
    const session = sessions.get(token)
    if (session) { const roles = session.roles || []; return roles.includes('R_SUPER') || roles.includes('R_ADMIN') }
    return false
  }
}
