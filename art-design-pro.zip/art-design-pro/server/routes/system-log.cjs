const { query } = require('../database.cjs')

function systemLogRoutes(router) {
  router.get('/api/system-log/list', async (req, res) => {
    try {
      const { page = 1, pageSize = 20, type, userId, dateRange } = req.query
      const offset = (Number(page) - 1) * Number(pageSize)
      let where = 'WHERE 1=1'
      const params = []

      if (type) { where += ' AND type=?'; params.push(type) }
      if (userId) { where += ' AND user_id=?'; params.push(Number(userId)) }
      if (dateRange && dateRange.length === 2) {
        where += ' AND create_time>=? AND create_time<=?'
        params.push(dateRange[0], dateRange[1])
      }

      const total = await query(`SELECT COUNT(*) as total FROM system_logs ${where}`, params)
      const list = await query(
        `SELECT * FROM system_logs ${where} ORDER BY create_time DESC LIMIT ? OFFSET ?`,
        [...params, Number(pageSize), offset]
      )

      res.json({
        code: 200,
        data: { list, total: total[0]?.total || 0, page: Number(page), pageSize: Number(pageSize) }
      })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  router.get('/api/system-log/stats', async (req, res) => {
    try {
      const typeStats = await query(
        "SELECT type, COUNT(*) as count FROM system_logs WHERE create_time >= datetime('now','-7 days') GROUP BY type ORDER BY count DESC"
      )
      const hourlyStats = await query(
        "SELECT strftime('%Y-%m-%d %H:00:00', create_time) as hour, COUNT(*) as count FROM system_logs WHERE create_time >= datetime('now','-24 hours') GROUP BY hour ORDER BY hour"
      )
      res.json({ code: 200, data: { typeStats, hourlyStats } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  router.get('/api/system-log/:id', async (req, res) => {
    try {
      const rows = await query('SELECT * FROM system_logs WHERE id=?', [Number(req.params.id)])
      res.json({ code: 200, data: rows[0] || null })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })
}

module.exports = systemLogRoutes
