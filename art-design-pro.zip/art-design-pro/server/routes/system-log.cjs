const { query } = require('../database.cjs')
const { LOG_CATEGORY_MAP } = require('../middleware/security.cjs')

const LABEL_MAP = {
  system_log_enabled: '总开关',
  login: '用户登录',
  user: '用户管理',
  role: '角色管理',
  role_permission: '角色权限',
  menu: '菜单管理',
  sys_config: '系统配置',
  email: '邮件配置',
  themes: '主题管理',
  delete_review: '注销审核',
  membership: '会员管理',
  member: '会员信息',
  points: '积分管理',
  experience: '经验等级',
  cardkey: '卡密管理',
  plugin: '插件管理',
  checkin_group: '签到分组',
  checkin_milestone: '签到里程碑',
  checkin: '签到记录',
  title: '称号管理',
  task: '任务管理',
  commission: '返佣记录',
  commission_rule: '返佣规则',
  withdraw: '提现管理',
  coupon: '优惠券管理',
  membership_product: '会员商品',
  purchase: '购买流水',
  order: '订单管理',
  settlement: '结算规则',
  recharge: '充值管理',
  post: '社区帖子',
  section: '板块管理',
  comment: '评论管理',
  app: '应用管理',
  submission: '投稿审核',
  category: '分类管理',
  official_tag: '官方标签',
  avatar_frame: '头像框管理',
  topic: '话题管理',
  moderator: '版主管理',
  file_repo: '文件仓库',
  file_policy: '文件上传策略',
  storage: '对象存储',
  follow: '关注操作',
  like: '点赞操作',
  favorite: '收藏操作',
  notification: '通知消息',
  invite: '邀请码管理',
  verification: '蓝V认证'
}

function systemLogRoutes(router) {
  router.get('/api/system-log/list', async (req, res) => {
    try {
      const { page = 1, pageSize = 20, type, userId, dateRange } = req.query
      const offset = (Number(page) - 1) * Number(pageSize)
      let where = 'WHERE 1=1'
      const params = []

      if (type) { where += ' AND type=?'; params.push(type) }
      if (userId) { where += ' AND user_id=?'; params.push(Number(userId)) }
      if (dateRange && dateRange.length === 2) {
        where += ' AND create_time>=? AND create_time<=?'
        params.push(dateRange[0], dateRange[1])
      }

      const total = await query(`SELECT COUNT(*) as total FROM system_logs ${where}`, params)
      const list = await query(
        `SELECT * FROM system_logs ${where} ORDER BY create_time DESC LIMIT ? OFFSET ?`,
        [...params, Number(pageSize), offset]
      )

      res.json({
        code: 200,
        data: { list, total: total[0]?.total || 0, page: Number(page), pageSize: Number(pageSize) }
      })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  router.get('/api/system-log/stats', async (req, res) => {
    try {
      const typeStats = await query(
        "SELECT type, COUNT(*) as count FROM system_logs WHERE create_time >= DATE_SUB(NOW(), INTERVAL 7 DAY) GROUP BY type ORDER BY count DESC"
      )
      const hourlyStats = await query(
        "SELECT DATE_FORMAT(create_time, '%Y-%m-%d %H:00:00') as hour, COUNT(*) as count FROM system_logs WHERE create_time >= DATE_SUB(NOW(), INTERVAL 24 HOUR) GROUP BY hour ORDER BY hour"
      )
      res.json({ code: 200, data: { typeStats, hourlyStats } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  router.get('/api/system-log/categories', async (req, res) => {
    try {
      const allKeys = ['system_log_enabled']
      for (const k of Object.keys(LOG_CATEGORY_MAP)) {
        allKeys.push(`log_enabled_${k}`)
      }
      const rows = await query(
        `SELECT config_key, config_value, description FROM sys_config WHERE config_key IN (${allKeys.map(() => '?').join(',')})`,
        allKeys
      )
      const valueMap = {}
      for (const r of rows) { valueMap[r.config_key] = r.config_value }

      const groups = {}
      groups['全局'] = [{ key: 'system_log_enabled', label: LABEL_MAP['system_log_enabled'] || '总开关', value: valueMap['system_log_enabled'] !== 'false' }]

      const grouped = {}
      for (const [targetType, group] of Object.entries(LOG_CATEGORY_MAP)) {
        if (!grouped[group]) grouped[group] = []
        grouped[group].push({
          key: `log_enabled_${targetType}`,
          label: LABEL_MAP[targetType] || targetType,
          value: !valueMap[`log_enabled_${targetType}`] || valueMap[`log_enabled_${targetType}`] !== 'false'
        })
      }
      for (const [group, items] of Object.entries(grouped)) {
        groups[group] = items
      }
      for (const [group, items] of Object.entries(groups)) {
        items.sort((a, b) => a.label.localeCompare(b.label))
      }

      res.json({ code: 200, data: groups })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  router.post('/api/system-log/categories/save', async (req, res) => {
    try {
      const { key, value } = req.body
      await query(
        "INSERT INTO sys_config (config_key, config_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE config_value=VALUES(config_value)",
        [key, value ? 'true' : 'false']
      )
      res.json({ code: 200, msg: '保存成功' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  router.get('/api/system-log/:id', async (req, res) => {
    try {
      const rows = await query('SELECT * FROM system_logs WHERE id=?', [Number(req.params.id)])
      res.json({ code: 200, data: rows[0] || null })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })
}

module.exports = systemLogRoutes
