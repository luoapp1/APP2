const { query } = require('../database.cjs')
const { authRequired, sessions, SESSION_TTL } = require('./system.cjs')

async function isAdmin(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return false
  const session = sessions.get(token)
  if (session) { const roles = session.roles || []; return roles.includes('R_SUPER') || roles.includes('R_ADMIN') }
  try {
    const rows = await query('SELECT roles FROM sessions WHERE token=?', [token])
    if (rows.length > 0) { const roles = JSON.parse(rows[0].roles || '[]'); return roles.includes('R_SUPER') || roles.includes('R_ADMIN') }
  } catch {}
  return false
}

module.exports = function emailTemplatesRoutes(app) {
  app.get('/api/email-templates', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const rows = await query('SELECT * FROM email_templates ORDER BY sort_order, id')
      res.json({ code: 200, data: rows })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.get('/api/email-templates/:id', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const rows = await query('SELECT * FROM email_templates WHERE id=?', [req.params.id])
      if (!rows.length) return res.json({ code: 404, message: '模板不存在' })
      res.json({ code: 200, data: rows[0] })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.post('/api/email-templates', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const { name, code, subject, html_content, description, sort_order, status } = req.body
      if (!name || !code) return res.json({ code: 400, message: '名称和代码不能为空' })
      const exist = await query('SELECT id FROM email_templates WHERE code=?', [code])
      if (exist.length) return res.json({ code: 400, message: '该代码已存在' })
      await query(
        `INSERT INTO email_templates (name, code, subject, html_content, description, sort_order, status) VALUES (?,?,?,?,?,?,?)`,
        [name, code, subject || '', html_content || '', description || '', sort_order || 0, status || '1']
      )
      res.json({ code: 200, message: '创建成功' })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.put('/api/email-templates/:id', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const { name, code, subject, html_content, description, sort_order, status } = req.body
      if (!name || !code) return res.json({ code: 400, message: '名称和代码不能为空' })
      const exist = await query('SELECT id FROM email_templates WHERE code=? AND id!=?', [code, req.params.id])
      if (exist.length) return res.json({ code: 400, message: '该代码已存在' })
      await query(
        `UPDATE email_templates SET name=?, code=?, subject=?, html_content=?, description=?, sort_order=?, status=?, update_time=NOW() WHERE id=?`,
        [name, code, subject || '', html_content || '', description || '', sort_order || 0, status || '1', req.params.id]
      )
      res.json({ code: 200, message: '更新成功' })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.delete('/api/email-templates/:id', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      await query('DELETE FROM email_templates WHERE id=?', [req.params.id])
      res.json({ code: 200, message: '删除成功' })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.patch('/api/email-templates/:id/status', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const { status } = req.body
      await query(
        `UPDATE email_templates SET status=?, update_time=NOW() WHERE id=?`,
        [status || '1', req.params.id]
      )
      res.json({ code: 200, message: '状态更新成功' })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.get('/api/email-templates-code/:code', async (req, res) => {
    try {
      const rows = await query('SELECT * FROM email_templates WHERE code=?', [req.params.code])
      if (!rows.length) return res.json({ code: 404, message: '模板不存在' })
      res.json({ code: 200, data: rows[0] })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })
}
