const multer = require('multer')
const path = require('path')
const fs = require('fs')

const uploadDir = path.join(__dirname, '..', 'uploads')
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true })

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, uploadDir),
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname) || '.png'
    const name = Date.now() + '-' + Math.round(Math.random() * 1e9) + ext
    cb(null, name)
  }
})

const imageUpload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const allowed = /\.(jpg|jpeg|png|gif|webp|svg|bmp)$/i
    if (allowed.test(path.extname(file.originalname))) {
      cb(null, true)
    } else {
      cb(new Error('仅支持图片格式: jpg/png/gif/webp/svg/bmp'))
    }
  }
})

const apkStorage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, uploadDir),
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname) || '.apk'
    const name = 'apk-' + Date.now() + '-' + Math.round(Math.random() * 1e9) + ext
    cb(null, name)
  }
})

const apkUpload = multer({
  storage: apkStorage,
  limits: { fileSize: 200 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    if (/\.apk$/i.test(path.extname(file.originalname))) {
      cb(null, true)
    } else {
      cb(new Error('仅支持 .apk 文件'))
    }
  }
})

function uploadRoutes(router) {
  router.post('/api/upload/avatar', imageUpload.single('file'), (req, res) => {
    if (!req.file) return res.json({ code: 400, msg: '请选择文件' })
    const url = '/uploads/' + req.file.filename
    res.json({ code: 200, msg: '上传成功', data: { url } })
  })

  router.post('/api/upload/background', imageUpload.single('file'), (req, res) => {
    if (!req.file) return res.json({ code: 400, msg: '请选择文件' })
    const url = '/uploads/' + req.file.filename
    res.json({ code: 200, msg: '上传成功', data: { url } })
  })

  router.post('/api/upload/apk', apkUpload.single('file'), async (req, res) => {
    try {
      if (!req.file) return res.json({ code: 400, msg: '请选择 .apk 文件' })

      const AppInfoParser = require('app-info-parser')
      const parser = new AppInfoParser(req.file.path)
      const info = await parser.parse()

      const iconData = info.icon
      let iconUrl = ''
      if (iconData) {
        const iconFileName = 'icon-' + Date.now() + '-' + Math.round(Math.random() * 1e9) + '.png'
        const iconPath = path.join(uploadDir, iconFileName)
        fs.writeFileSync(iconPath, Buffer.from(iconData))
        iconUrl = '/uploads/' + iconFileName
      }

      res.json({
        code: 200,
        msg: '解析成功',
        data: {
          fileName: req.file.originalname,
          name: info.label || info.package || '',
          packageName: info.package || '',
          version: info.versionName || '',
          versionCode: String(info.versionCode || ''),
          sizeMb: req.file.size ? (req.file.size / (1024 * 1024)).toFixed(1) : '0',
          icon: iconUrl
        }
      })
    } catch (e) {
      res.json({ code: 500, msg: 'APK 解析失败: ' + e.message })
    }
  })
}

module.exports = uploadRoutes
