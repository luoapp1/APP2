const multer = require('multer')
const path = require('path')
const fs = require('fs')
const { query } = require('../database.cjs')
const { sessions, SESSION_TTL } = require('./system.cjs')
const { progressTasksByAction } = require('./custom-task.cjs')
const { uploadToCloud, getDefaultStorage } = require('./storage-config.cjs')
const { recordFileUpload: recordFile, updateUserUsedBytes, deleteFileRecordsByRef, deleteFileFromStorage, buildFileDesc } = require('../utils/file-helper.cjs')

const uploadDir = path.join(__dirname, '..', 'uploads')
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true })

async function getUserId(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return { userId: 0, roles: [] }
  const session = sessions.get(token)
  if (session) {
    if (Date.now() - session.createdAt > SESSION_TTL) { sessions.delete(token); return { userId: 0, roles: [] } }
    return { userId: Number(session.userId) || 0, roles: session.roles || [] }
  }
  return { userId: 0, roles: [] }
}

async function getUserPolicy(userId, roles) {
  try {
    const user = await query('SELECT level_id FROM users WHERE id=?', [userId])
    const levelId = user.length > 0 ? (user[0].level_id || 0) : 0

    let policy = null
    // 优先级: 角色='*'（所有角色）> 具体角色匹配 > 等级匹配 > 默认策略
    const allRolePolicy = await query("SELECT * FROM file_policies WHERE status='1' AND role_code='*' ORDER BY id LIMIT 1")
    if (allRolePolicy.length) policy = allRolePolicy[0]

    if (!policy && roles && roles.length > 0) {
      const placeholders = roles.map(() => '?').join(',')
      const rows = await query(
        `SELECT * FROM file_policies WHERE status='1' AND role_code IN (${placeholders}) ORDER BY id LIMIT 1`,
        roles
      )
      if (rows.length) policy = rows[0]
    }
    if (!policy && levelId) {
      const rows = await query(
        "SELECT * FROM file_policies WHERE status='1' AND role_code='' AND user_level_id=? ORDER BY id LIMIT 1",
        [levelId]
      )
      if (rows.length) policy = rows[0]
    }
    if (!policy) {
      const rows = await query("SELECT * FROM file_policies WHERE status='1' AND user_level_id=0 AND role_code='' ORDER BY id LIMIT 1")
      if (rows.length) policy = rows[0]
    }
    return policy
  } catch { return null }
}

async function checkStorageQuota(userId, newFileSize, fileCategory) {
  try {
    const user = await query('SELECT level_id, expire_time FROM users WHERE id=?', [userId])
    if (!user.length) return { ok: true }
    const levelId = user[0].level_id || 0

    if (levelId && user[0].expire_time && new Date(user[0].expire_time) < new Date()) {
      const remaining = await query(
        'SELECT um.level_id FROM user_memberships um JOIN membership_levels ml ON um.level_id=ml.id WHERE um.user_id=? AND um.expire_time>NOW() ORDER BY ml.tier DESC LIMIT 1',
        [userId]
      )
      const effectiveId = remaining.length ? remaining[0].level_id : 0
      if (effectiveId && effectiveId !== levelId) {
        await query('UPDATE users SET level_id=?, expire_time=(SELECT expire_time FROM user_memberships WHERE user_id=? AND level_id=? AND expire_time>NOW() ORDER BY expire_time DESC LIMIT 1) WHERE id=?',
          [effectiveId, userId, effectiveId, userId])
      }
    }

    const effectiveLevelId = (user[0].expire_time && new Date(user[0].expire_time) > new Date() && levelId)
      ? levelId
      : (await query(
          'SELECT um.level_id FROM user_memberships um JOIN membership_levels ml ON um.level_id=ml.id WHERE um.user_id=? AND um.expire_time>NOW() ORDER BY ml.tier DESC LIMIT 1',
          [userId]
        ))[0]?.level_id || 0;

    const lv = await query(
      'SELECT data_limit_mb, file_limit_mb FROM membership_levels WHERE id=? AND status=?',
      [effectiveLevelId, '1']
    )
    const dataLimit = lv.length ? (lv[0].data_limit_mb || 0) : 0
    const fileLimit = lv.length ? (lv[0].file_limit_mb || 0) : 0

    const bonusRows = await query(
      'SELECT bonus_data_limit_mb, bonus_file_limit_mb FROM users WHERE id=?',
      [userId]
    )
    const bonusDataMb = bonusRows.length ? (bonusRows[0].bonus_data_limit_mb || 0) : 0
    const bonusFileMb = bonusRows.length ? (bonusRows[0].bonus_file_limit_mb || 0) : 0
    const totalDataLimit = dataLimit + bonusDataMb
    const totalFileLimit = fileLimit + bonusFileMb

    if (!totalDataLimit && !totalFileLimit) return { ok: true }

    const usageRows = await query(
      'SELECT COALESCE(SUM(file_size), 0) as total FROM file_repository WHERE user_id=?',
      [userId]
    )
    const currentUsed = Number(usageRows[0]?.total || 0)
    const afterUpload = currentUsed + (newFileSize || 0)

    if (totalFileLimit > 0 && afterUpload > totalFileLimit * 1024 * 1024) {
      const usedMb = (currentUsed / (1024 * 1024)).toFixed(1)
      return { ok: false, msg: `文件存储已满 (${usedMb}MB / ${totalFileLimit}MB)，无法继续上传` }
    }
    if (totalDataLimit > 0 && afterUpload > totalDataLimit * 1024 * 1024) {
      const usedMb = (currentUsed / (1024 * 1024)).toFixed(1)
      return { ok: false, msg: `数据存储已满 (${usedMb}MB / ${totalDataLimit}MB)，无法继续上传` }
    }
    return { ok: true }
  } catch { return { ok: true } }
}

async function recordFileUpload({ userId, fileName, fileUrl, fileSize, fileType, mimeType, category, refId, refType, description }) {
  return recordFile({ userId, fileName, fileUrl, fileSize, fileType, mimeType, category, refId, refType, description })
}

function createFileFilter(allowedExts, bannedExts) {
  return (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase().replace('.', '')

    if (bannedExts && bannedExts.length > 0) {
      const banned = bannedExts.split(',').map(s => s.trim().toLowerCase()).filter(Boolean)
      if (banned.includes(ext)) {
        return cb(new Error(`禁止上传 .${ext} 格式的文件`))
      }
    }

    if (allowedExts && allowedExts.length > 0) {
      const allowed = allowedExts.split(',').map(s => s.trim().toLowerCase()).filter(Boolean)
      if (!allowed.includes(ext)) {
        return cb(new Error(`仅支持以下格式: ${allowed.join(', ')}`))
      }
    }

    const dangerousMimes = [
      'application/x-msdownload', 'application/x-msdos-program', 'application/x-msi',
      'application/x-sh', 'application/x-bsh', 'application/x-ksh',
      'text/x-shellscript', 'application/x-php', 'application/x-httpd-php',
      'text/x-python', 'application/x-python-code'
    ]
    if (dangerousMimes.some(m => file.mimetype === m)) {
      return cb(new Error('不允许上传可执行文件'))
    }

    cb(null, true)
  }
}

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, uploadDir),
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname) || '.bin'
    const safeName = Date.now() + '-' + Math.round(Math.random() * 1e9) + ext
    cb(null, safeName)
  }
})

const imageUpload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const allowed = /\.(jpg|jpeg|png|gif|webp|svg|bmp)$/i
    if (allowed.test(path.extname(file.originalname))) {
      cb(null, true)
    } else {
      cb(new Error('仅支持图片格式: jpg/png/gif/webp/svg/bmp'))
    }
  }
})

const apkStorage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, uploadDir),
  filename: (_req, file, cb) => {
    const name = 'apk-' + Date.now() + '-' + Math.round(Math.random() * 1e9) + '.apk'
    cb(null, name)
  }
})

const apkUpload = multer({
  storage: apkStorage,
  limits: { fileSize: 200 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    if (/\.apk$/i.test(path.extname(file.originalname))) {
      cb(null, true)
    } else {
      cb(new Error('仅支持 .apk 文件'))
    }
  }
})

function uploadRoutes(router) {
  router.post('/api/upload/avatar', imageUpload.single('file'), async (req, res) => {
    if (!req.file) return res.json({ code: 400, msg: '请选择文件' })
    const { userId } = await getUserId(req)
    if (!userId) return res.json({ code: 401, msg: '请先登录' })
    const quota = await checkStorageQuota(userId, req.file.size || 0, 'avatar')
    if (!quota.ok) return res.json({ code: 400, msg: quota.msg })

    const oldRecords = await query(
      "SELECT id, file_path FROM file_repository WHERE user_id=? AND category='avatar'",
      [userId]
    )
    for (const r of oldRecords) {
      await deleteFileFromStorage(r.file_path)
    }
    await query("DELETE FROM file_repository WHERE user_id=? AND category='avatar'", [userId])

    const url = await resolveUploadPathForUser(req.file, req, userId, 'avatar', 'aw.png')
    const desc = buildFileDesc({ category: 'avatar', refType: 'user', refId: userId })
    await recordFileUpload({
      userId, fileName: 'aw.png', fileUrl: url,
      fileSize: req.file.size || 0,
      fileType: path.extname(req.file.originalname),
      mimeType: req.file.mimetype || '', category: 'avatar',
      refId: userId, refType: 'user', description: desc
    })
    try {
      await query("UPDATE users SET avatar=? WHERE id=?", [url, userId])
    } catch {}
    await updateUserUsedBytes(userId)
    res.json({ code: 200, msg: '上传成功', data: { url } })
  })

  router.post('/api/upload/background', imageUpload.single('file'), async (req, res) => {
    if (!req.file) return res.json({ code: 400, msg: '请选择文件' })
    const { userId } = await getUserId(req)
    if (!userId) return res.json({ code: 401, msg: '请先登录' })
    const quota = await checkStorageQuota(userId, req.file.size || 0, 'background')
    if (!quota.ok) return res.json({ code: 400, msg: quota.msg })

    const oldRecords = await query(
      "SELECT id, file_path FROM file_repository WHERE user_id=? AND category='background'",
      [userId]
    )
    for (const r of oldRecords) {
      await deleteFileFromStorage(r.file_path)
    }
    await query("DELETE FROM file_repository WHERE user_id=? AND category='background'", [userId])

    const url = await resolveUploadPathForUser(req.file, req, userId, 'background', 'bg.png')
    const desc = buildFileDesc({ category: 'background', refType: 'user', refId: userId })
    await recordFileUpload({
      userId, fileName: 'bg.png', fileUrl: url,
      fileSize: req.file.size || 0,
      fileType: path.extname(req.file.originalname),
      mimeType: req.file.mimetype || '', category: 'background',
      refId: userId, refType: 'user', description: desc
    })
    try {
      await query("UPDATE users SET background_image=? WHERE id=?", [url, userId])
    } catch {}
    await updateUserUsedBytes(userId)
    res.json({ code: 200, msg: '上传成功', data: { url } })
  })

  router.post('/api/upload/apk', apkUpload.single('file'), async (req, res) => {
    try {
      if (!req.file) return res.json({ code: 400, msg: '请选择 .apk 文件' })

      const { userId, roles } = await getUserId(req)
      if (userId) {
        const quota = await checkStorageQuota(userId, req.file.size || 0, 'apk')
        if (!quota.ok) return res.json({ code: 400, msg: quota.msg })

        const policy = await getUserPolicy(userId, roles)
        const maxFileSize = policy ? (policy.max_file_size_mb || 10) * 1024 * 1024 : 10 * 1024 * 1024
        if (req.file.size > maxFileSize) {
          return res.json({ code: 400, msg: `文件大小超出限制，最大 ${policy ? policy.max_file_size_mb : 10}MB` })
        }
      }

      const AppInfoParser = require('app-info-parser')
      const parser = new AppInfoParser(req.file.path)
      const info = await parser.parse()

      const iconData = info.icon
      let iconUrl = ''
      if (iconData) {
        let iconBuffer
        if (typeof iconData === 'string' && iconData.startsWith('data:image')) {
          const base64 = iconData.split(',')[1]
          iconBuffer = base64 ? Buffer.from(base64, 'base64') : Buffer.from(iconData)
        } else {
          iconBuffer = Buffer.from(iconData)
        }
        const iconFileName = 'icon-' + Date.now() + '-' + Math.round(Math.random() * 1e9) + '.png'
        const iconPath = path.join(uploadDir, iconFileName)
        fs.writeFileSync(iconPath, iconBuffer)
        iconUrl = '/uploads/' + iconFileName
        await recordFileUpload({
          userId: userId || 0,
          fileName: iconFileName,
          fileUrl: iconUrl,
          fileSize: iconBuffer.length || 0,
          fileType: '.png',
          mimeType: 'image/png',
          category: 'apk_icon'
        })
      }

      if (!iconUrl) {
        try {
          const JSZip = require('jszip')
          const apkBuffer = fs.readFileSync(req.file.path)
          const zip = await JSZip.loadAsync(apkBuffer)
          const iconPatterns = ['ic_launcher', 'ic_launcher_round', 'icon', 'logo']
          const iconDirRegex = /^res\/(mipmap|drawable)-/i
          const candidates = []
          for (const [name] of Object.entries(zip.files)) {
            if (!name.endsWith('.png') && !name.endsWith('.webp')) continue
            if (!iconDirRegex.test(name)) continue
            const baseName = name.split('/').pop().replace(/\.(png|webp)$/i, '').toLowerCase()
            if (!iconPatterns.some(pat => baseName.includes(pat))) continue
            const dimMatch = name.match(/(\d+)x(\d+)/)
            let w = dimMatch ? parseInt(dimMatch[1]) : 0
            let h = dimMatch ? parseInt(dimMatch[2]) : 0
            if (!w) {
              const densityMatch = name.match(/mipmap-([a-z]+)/i)
              const densities = { 'xxxhdpi': 192, 'xxhdpi': 144, 'xhdpi': 96, 'hdpi': 72, 'mdpi': 48, 'ldpi': 36 }
              w = densities[densityMatch?.[1]?.toLowerCase()] || 48
              h = w
            }
            candidates.push({ path: name, width: w, height: h })
          }
          let best = candidates.sort((a, b) => (b.width * b.height) - (a.width * a.height))[0]
          if (best) {
            const iconFile = zip.file(best.path)
            const iconData = await iconFile.async('nodebuffer')
              const iconFileName = 'icon-' + Date.now() + '-' + Math.round(Math.random() * 1e9) + '.png'
              fs.writeFileSync(path.join(uploadDir, iconFileName), iconData)
              iconUrl = '/uploads/' + iconFileName
              await recordFileUpload({
                userId: userId || 0,
                fileName: iconFileName,
                fileUrl: iconUrl,
                fileSize: iconData.length || 0,
                fileType: '.png',
                mimeType: 'image/png',
                category: 'apk_icon'
              })
          }
        } catch {}
      }

      const url = await resolveUploadPath(req.file, req, false)
      try {
        await query(
          `INSERT INTO file_repository (user_id, file_name, file_path, file_size, file_type, mime_type, category)
           VALUES (?,?,?,?,?,?,?)`,
          [userId || 0, req.file.originalname, url, req.file.size || 0,
          '.apk', 'application/vnd.android.package-archive', 'apk']
        )
        if (userId) await updateUserUsedBytes(userId)
      } catch {}

      res.json({
        code: 200,
        msg: '解析成功',
        data: {
          fileName: req.file.originalname,
          name: info.label || info.package || '',
          packageName: info.package || '',
          version: info.versionName || '',
          versionCode: String(info.versionCode || ''),
          sizeMb: req.file.size ? (req.file.size / (1024 * 1024)).toFixed(1) : '0',
          icon: iconUrl,
          downloadUrl: url
        }
      })
    } catch (e) {
      res.json({ code: 500, msg: 'APK 解析失败: ' + e.message })
    }
  })

  // 通用文件上传（带安全校验）
  router.post('/api/upload/file', async (req, res) => {
    try {
      const { userId, roles } = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const policy = await getUserPolicy(userId, roles)
      const maxSize = policy ? (policy.max_file_size_mb || 10) * 1024 * 1024 : 10 * 1024 * 1024
      const allowedTypes = policy ? policy.allowed_types : ''
      const bannedTypes = policy ? policy.banned_types : ''

      const dynamicUpload = multer({
        storage,
        limits: { fileSize: maxSize },
        fileFilter: createFileFilter(allowedTypes, bannedTypes)
      })

      dynamicUpload.single('file')(req, res, async (err) => {
        if (err) {
          return res.json({ code: 400, msg: err.message || '上传失败' })
        }
        if (!req.file) return res.json({ code: 400, msg: '请选择文件' })

        const quota = await checkStorageQuota(userId, req.file.size || 0, 'general')
        if (!quota.ok) return res.json({ code: 400, msg: quota.msg })

        const targetUrl = await resolveUploadPath(req.file, req, true)

        await recordFileUpload({
          userId,
          fileName: req.file.originalname,
          fileUrl: targetUrl,
          fileSize: req.file.size || 0,
          fileType: path.extname(req.file.originalname),
          mimeType: req.file.mimetype || '',
          category: req.body.category || 'general',
          refId: Number(req.body.refId) || 0,
          refType: req.body.refType || '',
          description: req.body.description || buildFileDesc({ category: req.body.category || 'general', refType: req.body.refType || '', refId: Number(req.body.refId) || 0 })
        })
        await updateUserUsedBytes(userId)

        await progressTasksByAction(userId, '', 'upload')

        res.json({
          code: 200, msg: '上传成功',
          data: { url: targetUrl, fileName: req.file.originalname, size: req.file.size }
        })
      })
    } catch (e) {
      res.json({ code: 500, msg: '上传错误: ' + e.message })
    }
  })

  // 获取用户存储配额信息
  router.get('/api/upload/storage-quota', async (req, res) => {
    try {
      const { userId } = await getUserId(req)
      if (!userId) return res.json({ code: 200, data: { dataLimitMb: 0, fileLimitMb: 0, bonusDataLimitMb: 0, bonusFileLimitMb: 0, usedBytes: 0 } })

      const user = await query('SELECT level_id, used_bytes, bonus_data_limit_mb, bonus_file_limit_mb FROM users WHERE id=?', [userId])
      if (!user.length) return res.json({ code: 200, data: { dataLimitMb: 0, fileLimitMb: 0, bonusDataLimitMb: 0, bonusFileLimitMb: 0, usedBytes: 0 } })

      const levelId = user[0].level_id || 0
      const lv = levelId ? await query(
        'SELECT data_limit_mb, file_limit_mb FROM membership_levels WHERE id=? AND status=?',
        [levelId, '1']
      ) : []

      const fileRows = await query(
        'SELECT COALESCE(SUM(file_size), 0) as total FROM file_repository WHERE user_id=?',
        [userId]
      )

      const baseDataMb = lv.length ? (lv[0].data_limit_mb || 0) : 0
      const baseFileMb = lv.length ? (lv[0].file_limit_mb || 0) : 0
      const bonusDataMb = user[0].bonus_data_limit_mb || 0
      const bonusFileMb = user[0].bonus_file_limit_mb || 0

      res.json({
        code: 200,
        data: {
          dataLimitMb: baseDataMb,
          fileLimitMb: baseFileMb,
          bonusDataLimitMb: bonusDataMb,
          bonusFileLimitMb: bonusFileMb,
          totalDataLimitMb: baseDataMb + bonusDataMb,
          totalFileLimitMb: baseFileMb + bonusFileMb,
          usedBytes: Number(fileRows[0]?.total || 0)
        }
      })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // 获取用户上传权限信息
  router.get('/api/upload/quota', async (req, res) => {
    try {
      const { userId, roles } = await getUserId(req)
      if (!userId) return res.json({ code: 200, data: { max_size_mb: 10, allowed_all: true } })

      const policy = await getUserPolicy(userId, roles)
      res.json({
        code: 200,
        data: {
          max_size_mb: policy ? policy.max_file_size_mb : 10,
          allowed_types: policy ? policy.allowed_types : '',
          banned_types: policy ? policy.banned_types : '',
          allowed_all: !policy
        }
      })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  router.post('/api/upload/parse-download-url', async (req, res) => {
    const { downloadUrl } = req.body || {}
    if (!downloadUrl) return res.json({ code: 400, msg: '请提供下载链接' })

    const tmpFile = path.join(uploadDir, 'dl-' + Date.now() + '-' + Math.round(Math.random() * 1e9) + '.apk')
    try {
      const http = require('http')
      const https = require('https')
      const client = downloadUrl.startsWith('https') ? https : http

      await new Promise((resolve, reject) => {
        client.get(downloadUrl, { timeout: 60000 }, (response) => {
          if (response.statusCode >= 300 && response.statusCode < 400 && response.headers.location) {
            const redirectUrl = response.headers.location
            const redirectClient = redirectUrl.startsWith('https') ? https : http
            const stream = fs.createWriteStream(tmpFile)
            redirectClient.get(redirectUrl, { timeout: 60000 }, (resp) => {
              resp.pipe(stream)
              stream.on('finish', resolve)
              stream.on('error', reject)
            }).on('error', reject)
            return
          }
          const stream = fs.createWriteStream(tmpFile)
          response.pipe(stream)
          stream.on('finish', resolve)
          stream.on('error', reject)
        }).on('error', reject).on('timeout', () => reject(new Error('下载超时')))
      })

      const stat = fs.statSync(tmpFile)
      if (stat.size === 0) return res.json({ code: 400, msg: '下载失败，文件为空' })

      const AppInfoParser = require('app-info-parser')
      const parser = new AppInfoParser(tmpFile)
      const info = await parser.parse()

      let iconUrl = ''
      const iconData = info.icon
      if (iconData) {
        let iconBuffer
        if (typeof iconData === 'string' && iconData.startsWith('data:image')) {
          const base64 = iconData.split(',')[1]
          iconBuffer = base64 ? Buffer.from(base64, 'base64') : Buffer.from(iconData)
        } else {
          iconBuffer = Buffer.from(iconData)
        }
        const iconFileName = 'icon-' + Date.now() + '-' + Math.round(Math.random() * 1e9) + '.png'
        fs.writeFileSync(path.join(uploadDir, iconFileName), iconBuffer)
        iconUrl = '/uploads/' + iconFileName
        await recordFileUpload({
          userId: 0,
          fileName: iconFileName,
          fileUrl: iconUrl,
          fileSize: iconBuffer.length || 0,
          fileType: '.png',
          mimeType: 'image/png',
          category: 'apk_icon'
        })
      }

      if (!iconUrl) {
        try {
          const JSZip = require('jszip')
          const apkBuffer = fs.readFileSync(tmpFile)
          const zip = await JSZip.loadAsync(apkBuffer)
          const iconPatterns = ['ic_launcher', 'ic_launcher_round', 'icon', 'logo']
          const iconDirRegex = /^res\/(mipmap|drawable)-/i
          const candidates = []
          for (const [name] of Object.entries(zip.files)) {
            if (!name.endsWith('.png') && !name.endsWith('.webp')) continue
            if (!iconDirRegex.test(name)) continue
            const baseName = name.split('/').pop().replace(/\.(png|webp)$/i, '').toLowerCase()
            if (!iconPatterns.some(pat => baseName.includes(pat))) continue
            const dimMatch = name.match(/(\d+)x(\d+)/)
            let w = dimMatch ? parseInt(dimMatch[1]) : 0
            let h = dimMatch ? parseInt(dimMatch[2]) : 0
            if (!w) {
              const densityMatch = name.match(/mipmap-([a-z]+)/i)
              const densities = { 'xxxhdpi': 192, 'xxhdpi': 144, 'xhdpi': 96, 'hdpi': 72, 'mdpi': 48, 'ldpi': 36 }
              w = densities[densityMatch?.[1]?.toLowerCase()] || 48
              h = w
            }
            candidates.push({ path: name, width: w, height: h })
          }
          const best = candidates.sort((a, b) => (b.width * b.height) - (a.width * a.height))[0]
          if (best) {
            const iconFile = zip.file(best.path)
            const iconBuf = await iconFile.async('nodebuffer')
            const iconFileName = 'icon-' + Date.now() + '-' + Math.round(Math.random() * 1e9) + '.png'
            fs.writeFileSync(path.join(uploadDir, iconFileName), iconBuf)
            iconUrl = '/uploads/' + iconFileName
            await recordFileUpload({
              userId: 0,
              fileName: iconFileName,
              fileUrl: iconUrl,
              fileSize: iconBuf.length || 0,
              fileType: '.png',
              mimeType: 'image/png',
              category: 'apk_icon'
            })
          }
        } catch {}
      }

      res.json({
        code: 200,
        data: {
          name: info.label || info.package || '',
          packageName: info.package || '',
          version: info.versionName || '',
          versionCode: String(info.versionCode || ''),
          sizeMb: stat.size ? (stat.size / (1024 * 1024)).toFixed(1) : '0',
          icon: iconUrl
        }
      })
    } catch (e) {
      res.json({ code: 500, msg: '解析失败: ' + e.message })
    } finally {
      try { if (fs.existsSync(tmpFile)) fs.unlinkSync(tmpFile) } catch {}
    }
  })

  router.post('/api/upload/batch-temp', imageUpload.array('files', 20), async (req, res) => {
    try {
      const { userId } = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const files = req.files || []
      if (!files.length) return res.json({ code: 400, msg: '请选择文件' })

      const tempDir = path.join(uploadDir, 'temp', String(userId))
      if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true })

      const results = []
      for (const f of files) {
        const targetPath = path.join(tempDir, f.filename)
        fs.renameSync(path.join(uploadDir, f.filename), targetPath)
        results.push({
          tempKey: `temp/${userId}/${f.filename}`,
          url: `/uploads/temp/${userId}/${f.filename}`,
          name: f.originalname,
          size: f.size,
          mimeType: f.mimetype
        })
      }
      res.json({ code: 200, data: { files: results } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  router.post('/api/upload/batch-commit', async (req, res) => {
    try {
      const { userId } = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const { files, public: isPublish } = req.body
      if (!files || !Array.isArray(files) || !files.length) {
        return res.json({ code: 400, msg: '请提供文件列表' })
      }

      const totalSize = files.reduce((sum, f) => sum + (Number(f.size) || 0), 0)
      const quota = await checkStorageQuota(userId, totalSize || 0, 'general')
      if (!quota.ok) return res.json({ code: 400, msg: quota.msg })

      const results = []
      for (const item of files) {
        const tempPath = path.join(uploadDir, item.tempKey.replace(/^\/+/, ''))
        if (!fs.existsSync(tempPath)) continue

        const category = item.category || 'other'
        const refType = item.refType || ''
        const refId = Number(item.refId) || 0
        const description = item.description || buildFileDesc(refType, refId, category)

        let finalUrl = item.url || ''
        let fileSize = item.size || 0
        let fileName = item.name || path.basename(tempPath)
        let mimeType = item.mimeType || 'application/octet-stream'

        if (isPublish) {
          const stat = fs.statSync(tempPath)
          fileSize = stat.size

          const fileType = getFileType(fileName)
          const storage = await getDefaultStorage({ userId, roles: [], levelId: 0, backend: false })

          if (storage && storage.type !== 'local') {
            const baseDir = (storage.remote_dir || 'user/{userId}').replace(/^\/+|\/+$/g, '').replace('{userId}', String(userId))
            const remoteKey = `${baseDir}/${fileType}/${path.basename(tempPath)}`
            const result = await uploadToCloud(storage, tempPath, remoteKey)
            if (result && result.url) finalUrl = result.url
            else finalUrl = `/uploads/${item.tempKey.replace(/^\/+/, '')}`
          } else {
            const targetDir = path.join(uploadDir, 'user', String(userId), category)
            if (!fs.existsSync(targetDir)) fs.mkdirSync(targetDir, { recursive: true })
            const targetPath = path.join(targetDir, path.basename(tempPath))
            fs.renameSync(tempPath, targetPath)
            finalUrl = `/uploads/user/${userId}/${category}/${path.basename(tempPath)}`
          }
          try { if (fs.existsSync(tempPath) && finalUrl !== `/uploads/${item.tempKey.replace(/^\/+/, '')}`) fs.unlinkSync(tempPath) } catch {}
        }

        const recordId = await recordFile({
          userId, userName: item.userName || '', fileName, fileUrl: finalUrl,
          fileSize, fileType: path.extname(fileName).slice(1), mimeType,
          category, refId, refType, description
        })
        await updateUserUsedBytes(userId)

        results.push({ id: recordId, url: finalUrl, name: fileName, size: fileSize })
      }

      res.json({ code: 200, data: { files: results } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  router.post('/api/upload/delete-uploaded', async (req, res) => {
    try {
      const { downloadUrl } = req.body
      if (!downloadUrl) return res.json({ code: 400, msg: '缺少文件地址' })

      const rows = await query('SELECT * FROM file_repository WHERE file_path=?', [downloadUrl])
      if (!rows.length) return res.json({ code: 200, msg: '文件记录不存在' })

      const record = rows[0]
      await deleteFileFromStorage(record.file_path)
      await query('DELETE FROM file_repository WHERE id=?', [record.id])
      if (record.user_id) await updateUserUsedBytes(record.user_id)
      res.json({ code: 200, msg: '已删除' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })
}

async function deleteFromCloud(storage, key) {
  try {
    if (storage.type === 'oss') {
      const OSS = require('ali-oss')
      const client = new OSS({
        region: storage.region,
        accessKeyId: storage.access_key,
        accessKeySecret: storage.secret_key,
        bucket: storage.bucket,
        endpoint: storage.endpoint
      })
      await client.delete(key)
    } else if (storage.type === 'cos') {
      const COS = require('cos-nodejs-sdk-v5')
      const cos = new COS({ SecretId: storage.access_key, SecretKey: storage.secret_key })
      await new Promise((resolve, reject) => {
        cos.deleteObject({ Bucket: storage.bucket, Region: storage.region, Key: key }, (err) => {
          if (err) return reject(err)
          resolve()
        })
      })
    } else if (storage.type === 'minio') {
      const Minio = require('minio')
      const minioClient = new Minio.Client({
        endPoint: storage.endpoint.replace(/^https?:\/\//, '').split(':')[0],
        port: parseInt(storage.endpoint.split(':').pop()) || 9000,
        useSSL: storage.endpoint.startsWith('https'),
        accessKey: storage.access_key,
        secretKey: storage.secret_key
      })
      await minioClient.removeObject(storage.bucket, key)
    } else {
      const { S3Client, DeleteObjectCommand } = require('@aws-sdk/client-s3')
      const s3 = new S3Client({
        region: storage.region,
        endpoint: storage.endpoint,
        credentials: { accessKeyId: storage.access_key, secretAccessKey: storage.secret_key },
        forcePathStyle: true
      })
      await s3.send(new DeleteObjectCommand({ Bucket: storage.bucket, Key: key }))
    }
  } catch (e) {
    console.error(`[deleteFromCloud] ${storage.type} 删除失败:`, e.message)
  }
}

async function resolveUploadPathForUser(file, req, userId, category, fixedName) {
  const defaultUrl = '/uploads/' + file.filename
  try {
    let userCtx = { userId, roles: [], levelId: 0, backend: false }
    try {
      const auth = await getUserId(req)
      const user = await query('SELECT level_id FROM users WHERE id=?', [userId])
      const levelId = user.length > 0 ? (user[0].level_id || 0) : 0
      userCtx = { userId, roles: auth.roles || [], levelId, backend: false }
    } catch {}

    const storage = await getDefaultStorage(userCtx)
    if (!storage) {
      const userDir = path.join(uploadDir, 'user', String(userId), category)
      if (!fs.existsSync(userDir)) fs.mkdirSync(userDir, { recursive: true })
      const targetPath = path.join(userDir, fixedName)
      if (fs.existsSync(targetPath)) fs.unlinkSync(targetPath)
      fs.renameSync(path.join(uploadDir, file.filename), targetPath)
      return `/uploads/user/${userId}/${category}/${fixedName}`
    }

    if (storage.type === 'local') {
      const localDir = storage.local_dir
        ? path.join(uploadDir, storage.local_dir.replace(/^\/+|\/+$/g, ''), 'user', String(userId), category)
        : path.join(uploadDir, 'user', String(userId), category)
      if (!fs.existsSync(localDir)) fs.mkdirSync(localDir, { recursive: true })
      const targetPath = path.join(localDir, fixedName)
      if (fs.existsSync(targetPath)) fs.unlinkSync(targetPath)
      fs.renameSync(path.join(uploadDir, file.filename), targetPath)
      const relPath = '/' + path.relative(path.join(uploadDir, '..'), targetPath)
      return relPath
    }

    const baseDir = (storage.remote_dir || 'user/{userId}')
      .replace(/^\/+|\/+$/g, '')
      .replace('{userId}', String(userId))
    const remoteKey = `${baseDir}/${category}/${fixedName}`
    const localPath = path.join(uploadDir, file.filename)
    const result = await uploadToCloud(storage, localPath, remoteKey)
    try { fs.unlinkSync(localPath) } catch {}
    if (result && result.url) return result.url
    return defaultUrl
  } catch (e) {
    console.error(`[resolveUploadPathForUser] failed:`, e.message)
    return defaultUrl
  }
}

async function resolveUploadPath(file, req, isBackend) {
  const defaultUrl = '/uploads/' + file.filename
  try {
    let userId = 0
    let userCtx = { userId: 0, roles: [], levelId: 0, backend: false }
    try {
      const auth = await getUserId(req)
      userId = auth.userId || 0
      const user = await query('SELECT level_id FROM users WHERE id=?', [userId])
      const levelId = user.length > 0 ? (user[0].level_id || 0) : 0
      userCtx = { userId, roles: auth.roles || [], levelId, backend: isBackend }
    } catch {}

    const storage = await getDefaultStorage(userCtx)
    if (!storage) return defaultUrl

    const localPath = path.join(__dirname, '..', 'uploads', file.filename)

    if (storage.type === 'local') {
      const localDir = storage.local_dir || ''
      if (localDir) {
        const targetDir = path.join(__dirname, '..', 'uploads', localDir.replace(/^\/+|\/+$/g, ''))
        if (!fs.existsSync(targetDir)) fs.mkdirSync(targetDir, { recursive: true })
        fs.renameSync(localPath, path.join(targetDir, file.filename))
        return '/uploads/' + localDir.replace(/^\/+|\/+$/g, '') + '/' + file.filename
      }
      return defaultUrl
    }

    const baseDir = (storage.remote_dir || 'user/{userId}').replace(/^\/+|\/+$/g, '').replace('{userId}', String(userId || 0))
    const fileType = getFileType(file.originalname)
    const remoteKey = `${baseDir}/${fileType}/${file.filename}`

    const result = await uploadToCloud(storage, localPath, remoteKey)
    try { fs.unlinkSync(localPath) } catch {}

    if (result && result.url) {
      console.log(`[CloudSync] ${result.url}`)
      return result.url
    }

    console.error(`[CloudSync] 上传失败，回退到本地路径`)
    return defaultUrl
  } catch (e) {
    console.error(`[resolveUploadPath] 失败:`, e.message)
    return defaultUrl
  }
}

function getFileType(filename) {
  const ext = path.extname(filename).toLowerCase()
  const imageExts = ['.png', '.jpg', '.jpeg', '.gif', '.webp', '.svg', '.bmp', '.ico', '.tiff', '.tif', '.heic', '.heif']
  const videoExts = ['.mp4', '.avi', '.mov', '.mkv', '.webm', '.flv', '.wmv', '.m4v', '.3gp', '.ts']
  const audioExts = ['.mp3', '.wav', '.ogg', '.flac', '.aac', '.wma', '.m4a', '.opus']
  const archiveExts = ['.zip', '.rar', '.7z', '.tar', '.gz', '.bz2', '.xz', '.tgz']
  const docExts = ['.pdf', '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx', '.txt', '.csv', '.md', '.json', '.xml', '.html', '.htm', '.css', '.js', '.ts']
  if (ext === '.apk') return 'apk'
  if (imageExts.includes(ext)) return 'img'
  if (videoExts.includes(ext)) return 'video'
  if (audioExts.includes(ext)) return 'audio'
  if (archiveExts.includes(ext)) return 'zip'
  if (docExts.includes(ext)) return 'doc'
  return 'other'
}

module.exports = uploadRoutes
module.exports.getUserId = getUserId
module.exports.getUserPolicy = getUserPolicy
module.exports.createFileFilter = createFileFilter
module.exports.resolveUploadPath = resolveUploadPath
module.exports.resolveUploadPathForUser = resolveUploadPathForUser
module.exports.checkStorageQuota = checkStorageQuota
module.exports.deleteFromCloud = deleteFromCloud
module.exports.recordFileUpload = recordFileUpload
module.exports.updateUserUsedBytes = updateUserUsedBytes
module.exports.buildFileDesc = buildFileDesc
