const multer = require('multer')
const path = require('path')
const fs = require('fs')
const { query } = require('../database.cjs')
const { sessions, SESSION_TTL } = require('./system.cjs')

const uploadDir = path.join(__dirname, '..', 'uploads')
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true })

async function getUserId(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return { userId: 0, roles: [] }
  const session = sessions.get(token)
  if (session) {
    if (Date.now() - session.createdAt > SESSION_TTL) { sessions.delete(token); return { userId: 0, roles: [] } }
    return { userId: Number(session.userId) || 0, roles: session.roles || [] }
  }
  return { userId: 0, roles: [] }
}

async function getUserPolicy(userId, roles) {
  try {
    const user = await query('SELECT level_id FROM users WHERE id=?', [userId])
    const levelId = user.length > 0 ? (user[0].level_id || 0) : 0

    let policy = null
    // 优先级：角色专属 > 等级匹配 > 默认
    if (roles && roles.length > 0) {
      const placeholders = roles.map(() => '?').join(',')
      const rows = await query(
        `SELECT * FROM file_policies WHERE status='1' AND role_code IN (${placeholders}) ORDER BY id LIMIT 1`,
        roles
      )
      if (rows.length) policy = rows[0]
    }
    if (!policy && levelId) {
      const rows = await query("SELECT * FROM file_policies WHERE status='1' AND user_level_id=?", [levelId])
      if (rows.length) policy = rows[0]
    }
    if (!policy) {
      const rows = await query("SELECT * FROM file_policies WHERE status='1' AND user_level_id=0 AND role_code='' LIMIT 1")
      if (rows.length) policy = rows[0]
    }
    return policy
  } catch { return null }
}

function createFileFilter(allowedExts, bannedExts) {
  return (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase().replace('.', '')

    if (bannedExts && bannedExts.length > 0) {
      const banned = bannedExts.split(',').map(s => s.trim().toLowerCase()).filter(Boolean)
      if (banned.includes(ext)) {
        return cb(new Error(`禁止上传 .${ext} 格式的文件`))
      }
    }

    if (allowedExts && allowedExts.length > 0) {
      const allowed = allowedExts.split(',').map(s => s.trim().toLowerCase()).filter(Boolean)
      if (!allowed.includes(ext)) {
        return cb(new Error(`仅支持以下格式: ${allowed.join(', ')}`))
      }
    }

    const dangerousMimes = [
      'application/x-msdownload', 'application/x-msdos-program', 'application/x-msi',
      'application/x-sh', 'application/x-bsh', 'application/x-ksh',
      'text/x-shellscript', 'application/x-php', 'application/x-httpd-php',
      'text/x-python', 'application/x-python-code'
    ]
    if (dangerousMimes.some(m => file.mimetype === m)) {
      return cb(new Error('不允许上传可执行文件'))
    }

    cb(null, true)
  }
}

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, uploadDir),
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname) || '.bin'
    const safeName = Date.now() + '-' + Math.round(Math.random() * 1e9) + ext
    cb(null, safeName)
  }
})

const imageUpload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const allowed = /\.(jpg|jpeg|png|gif|webp|svg|bmp)$/i
    if (allowed.test(path.extname(file.originalname))) {
      cb(null, true)
    } else {
      cb(new Error('仅支持图片格式: jpg/png/gif/webp/svg/bmp'))
    }
  }
})

const apkStorage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, uploadDir),
  filename: (_req, file, cb) => {
    const name = 'apk-' + Date.now() + '-' + Math.round(Math.random() * 1e9) + '.apk'
    cb(null, name)
  }
})

const apkUpload = multer({
  storage: apkStorage,
  limits: { fileSize: 200 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    if (/\.apk$/i.test(path.extname(file.originalname))) {
      cb(null, true)
    } else {
      cb(new Error('仅支持 .apk 文件'))
    }
  }
})

function uploadRoutes(router) {
  router.post('/api/upload/avatar', imageUpload.single('file'), async (req, res) => {
    if (!req.file) return res.json({ code: 400, msg: '请选择文件' })
    const url = '/uploads/' + req.file.filename

    // 记录文件到仓库
    try {
      const { userId } = await getUserId(req)
      await query(
        `INSERT INTO file_repository (user_id, file_name, file_path, file_size, file_type, mime_type, category)
         VALUES (?,?,?,?,?,?,?)`,
        [userId || 0, req.file.originalname, url, req.file.size || 0,
         path.extname(req.file.originalname), req.file.mimetype || '', 'avatar']
      )
    } catch {}

    res.json({ code: 200, msg: '上传成功', data: { url } })
  })

  router.post('/api/upload/background', imageUpload.single('file'), async (req, res) => {
    if (!req.file) return res.json({ code: 400, msg: '请选择文件' })
    const url = '/uploads/' + req.file.filename

    try {
      const { userId } = await getUserId(req)
      await query(
        `INSERT INTO file_repository (user_id, file_name, file_path, file_size, file_type, mime_type, category)
         VALUES (?,?,?,?,?,?,?)`,
        [userId || 0, req.file.originalname, url, req.file.size || 0,
         path.extname(req.file.originalname), req.file.mimetype || '', 'background']
      )
    } catch {}

    res.json({ code: 200, msg: '上传成功', data: { url } })
  })

  router.post('/api/upload/apk', apkUpload.single('file'), async (req, res) => {
    try {
      if (!req.file) return res.json({ code: 400, msg: '请选择 .apk 文件' })

      const AppInfoParser = require('app-info-parser')
      const parser = new AppInfoParser(req.file.path)
      const info = await parser.parse()

      const iconData = info.icon
      let iconUrl = ''
      if (iconData) {
        const iconFileName = 'icon-' + Date.now() + '-' + Math.round(Math.random() * 1e9) + '.png'
        const iconPath = path.join(uploadDir, iconFileName)
        fs.writeFileSync(iconPath, Buffer.from(iconData))
        iconUrl = '/uploads/' + iconFileName
      }

      // 记录文件到仓库
      try {
        const { userId } = await getUserId(req)
        await query(
          `INSERT INTO file_repository (user_id, file_name, file_path, file_size, file_type, mime_type, category)
           VALUES (?,?,?,?,?,?,?)`,
          [userId || 0, req.file.originalname, '/uploads/' + req.file.filename, req.file.size || 0,
           '.apk', 'application/vnd.android.package-archive', 'apk']
        )
      } catch {}

      res.json({
        code: 200,
        msg: '解析成功',
        data: {
          fileName: req.file.originalname,
          name: info.label || info.package || '',
          packageName: info.package || '',
          version: info.versionName || '',
          versionCode: String(info.versionCode || ''),
          sizeMb: req.file.size ? (req.file.size / (1024 * 1024)).toFixed(1) : '0',
          icon: iconUrl
        }
      })
    } catch (e) {
      res.json({ code: 500, msg: 'APK 解析失败: ' + e.message })
    }
  })

  // 通用文件上传（带安全校验）
  router.post('/api/upload/file', async (req, res) => {
    try {
      const { userId, roles } = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const policy = await getUserPolicy(userId, roles)
      const maxSize = policy ? (policy.max_file_size_mb || 10) * 1024 * 1024 : 10 * 1024 * 1024
      const allowedTypes = policy ? policy.allowed_types : ''
      const bannedTypes = policy ? policy.banned_types : ''

      const dynamicUpload = multer({
        storage,
        limits: { fileSize: maxSize },
        fileFilter: createFileFilter(allowedTypes, bannedTypes)
      })

      dynamicUpload.single('file')(req, res, async (err) => {
        if (err) {
          return res.json({ code: 400, msg: err.message || '上传失败' })
        }
        if (!req.file) return res.json({ code: 400, msg: '请选择文件' })

        const url = '/uploads/' + req.file.filename
        try {
          await query(
            `INSERT INTO file_repository (user_id, file_name, file_path, file_size, file_type, mime_type, category)
             VALUES (?,?,?,?,?,?,?)`,
            [userId, req.file.originalname, url, req.file.size || 0,
             path.extname(req.file.originalname), req.file.mimetype || '', 'general']
          )
        } catch {}

        res.json({
          code: 200, msg: '上传成功',
          data: { url, fileName: req.file.originalname, size: req.file.size }
        })
      })
    } catch (e) {
      res.json({ code: 500, msg: '上传错误: ' + e.message })
    }
  })

  // 获取用户上传权限信息
  router.get('/api/upload/quota', async (req, res) => {
    try {
      const { userId, roles } = await getUserId(req)
      if (!userId) return res.json({ code: 200, data: { max_size_mb: 10, allowed_all: true } })

      const policy = await getUserPolicy(userId, roles)
      res.json({
        code: 200,
        data: {
          max_size_mb: policy ? policy.max_file_size_mb : 10,
          allowed_types: policy ? policy.allowed_types : '',
          banned_types: policy ? policy.banned_types : '',
          allowed_all: !policy
        }
      })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })
}

module.exports = uploadRoutes
