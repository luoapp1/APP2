const { query, dbType } = require('../database.cjs')
const nowExpr = dbType === 'mysql' ? 'NOW()' : "datetime('now','localtime')"

function notificationRoutes(router) {

  router.get('/api/notifications', async (req, res) => {
    try {
      const { userId = 0, page = 1, pageSize = 20, type } = req.query
      const uid = Number(userId)
      let whereClause = '(target_user_id = 0 OR target_user_id = ?)'
      const params = [uid]
      if (type) {
        whereClause += ' AND type = ?'
        params.push(type)
      }
      const list = await query(
        `SELECT id, title, content, type, is_read as isRead, create_time as createTime
         FROM sys_notifications
         WHERE ${whereClause}
         ORDER BY id DESC LIMIT ? OFFSET ?`,
        [...params, Number(pageSize), (Number(page) - 1) * Number(pageSize)]
      )
      const cnt = await query(
        `SELECT COUNT(*) as total FROM sys_notifications
         WHERE ${whereClause}`,
        params
      )
      const unread = await query(
        `SELECT COUNT(*) as cnt FROM sys_notifications
         WHERE ${whereClause} AND is_read = 0`,
        params
      )
      res.json({ code: 200, msg: 'success', data: { list, total: cnt[0]?.total || 0, unread: unread[0]?.cnt || 0 } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  router.post('/api/notifications/read-all', async (req, res) => {
    try {
      const { userId, type } = req.body
      let whereClause = '(target_user_id = 0 OR target_user_id = ?) AND is_read = 0'
      const params = [Number(userId) || 0]
      if (type) {
        whereClause += ' AND type = ?'
        params.push(type)
      }
      await query(
        `UPDATE sys_notifications SET is_read = 1 WHERE ${whereClause}`,
        params
      )
      res.json({ code: 200, msg: '已全部标为已读' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  router.get('/api/messages/conversations', async (req, res) => {
    try {
      const { userId } = req.query
      const uid = Number(userId)
      if (!uid) return res.json({ code: 400, msg: '请先登录' })

      const partners = await query(
        `SELECT DISTINCT
           CASE WHEN from_user_id = ? THEN to_user_id ELSE from_user_id END as partnerId
         FROM private_messages
         WHERE from_user_id = ? OR to_user_id = ?`,
        [uid, uid, uid]
      )

      if (!partners || partners.length === 0) {
        return res.json({ code: 200, msg: 'success', data: [] })
      }

      const hidden = await query(
        'SELECT partner_id FROM hidden_conversations WHERE user_id = ?',
        [uid]
      )
      const hiddenIds = new Set(hidden.map((r) => r.partner_id))

      const result = []
      for (const p of partners) {
        const pid = p.partnerId
        if (!pid) continue
        if (hiddenIds.has(pid)) continue
        const pUser = await query('SELECT id, username, avatar FROM users WHERE id = ?', [pid])
        const lastMsg = await query(
          `SELECT content, create_time FROM private_messages
           WHERE (from_user_id = ? AND to_user_id = ?) OR (from_user_id = ? AND to_user_id = ?)
           ORDER BY id DESC LIMIT 1`,
          [uid, pid, pid, uid]
        )
        const unreadCount = await query(
          `SELECT COUNT(*) as cnt FROM private_messages
           WHERE from_user_id = ? AND to_user_id = ? AND is_read = 0`,
          [pid, uid]
        )
        result.push({
          userId: pid,
          userName: pUser[0]?.username || '',
          userAvatar: pUser[0]?.avatar || '',
          lastTime: lastMsg[0]?.create_time || '',
          lastContent: lastMsg[0]?.content || '',
          unread: unreadCount[0]?.cnt || 0
        })
      }

      result.sort((a, b) => {
        if (!a.lastTime) return 1
        if (!b.lastTime) return -1
        return new Date(b.lastTime).getTime() - new Date(a.lastTime).getTime()
      })

      res.json({ code: 200, msg: 'success', data: result })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  router.get('/api/messages/:targetUserId', async (req, res) => {
    try {
      const { userId } = req.query
      const uid = Number(userId)
      const tid = Number(req.params.targetUserId)
      if (!uid || !tid) return res.json({ code: 400, msg: '参数错误' })

      await query(
        `UPDATE private_messages SET is_read = 1
         WHERE from_user_id = ? AND to_user_id = ? AND is_read = 0`,
        [tid, uid]
      )

      const messages = await query(
        `SELECT id, from_user_id as fromUserId, from_user_name as fromUserName,
                from_user_avatar as fromUserAvatar, to_user_id as toUserId,
                content, is_read as isRead, create_time as createTime
         FROM private_messages
         WHERE (from_user_id = ? AND to_user_id = ?)
            OR (from_user_id = ? AND to_user_id = ?)
         ORDER BY id ASC`,
        [uid, tid, tid, uid]
      )

      res.json({ code: 200, msg: 'success', data: messages })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  router.post('/api/messages/:targetUserId', async (req, res) => {
    try {
      const { userId, userName, userAvatar, content } = req.body
      const uid = Number(userId)
      const tid = Number(req.params.targetUserId)
      if (!uid || !tid || !content) return res.json({ code: 400, msg: '参数不完整' })

      const avatar = userAvatar || '#448AFF'
      const result = await query(
        `INSERT INTO private_messages (from_user_id, from_user_name, from_user_avatar, to_user_id, content)
         VALUES (?, ?, ?, ?, ?)`,
        [uid, userName || '用户', avatar, tid, content]
      )

      await query(
        `DELETE FROM hidden_conversations
         WHERE (user_id = ? AND partner_id = ?) OR (user_id = ? AND partner_id = ?)`,
        [uid, tid, tid, uid]
      )

      res.json({
        code: 200,
        msg: '发送成功',
        data: {
          id: result.lastInsertRowid || result.insertId,
          fromUserId: uid,
          fromUserName: userName,
          fromUserAvatar: avatar,
          toUserId: tid,
          content,
          isRead: 0,
          createTime: new Date().toISOString()
        }
      })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  router.delete('/api/messages/conversations/:partnerId', async (req, res) => {
    try {
      const { userId } = req.query
      const uid = Number(userId)
      const pid = Number(req.params.partnerId)
      if (!uid || !pid) return res.json({ code: 400, msg: '参数错误' })

      await query(
        `INSERT OR IGNORE INTO hidden_conversations (user_id, partner_id) VALUES (?, ?)`,
        [uid, pid]
      )
      res.json({ code: 200, msg: '已删除对话' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })
}

module.exports = notificationRoutes
