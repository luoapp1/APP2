const { query, dbType } = require('../database.cjs')
const nowExpr = dbType === 'mysql' ? 'NOW()' : "datetime('now','localtime')"

function officialTagRoutes(router) {

  router.get('/api/official-tags/list', async (req, res) => {
    try {
      const list = await query(
        `SELECT id, name, color, bg_color as bgColor, sort_order as sortOrder, status, create_time as createTime
         FROM app_official_tags ORDER BY sort_order ASC, id ASC`
      )
      res.json({ code: 200, msg: 'success', data: list })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  router.post('/api/official-tags/save', async (req, res) => {
    try {
      const { id, name, color, bgColor, sortOrder, status } = req.body
      if (id) {
        await query(
          `UPDATE app_official_tags SET name=?, color=?, bg_color=?, sort_order=?, status=? WHERE id=?`,
          [name, color || '#2563eb', bgColor || '#dbeafe', Number(sortOrder) || 0, status || '1', Number(id)]
        )
        res.json({ code: 200, msg: '更新成功', data: { id: Number(id) } })
      } else {
        const result = await query(
          `INSERT INTO app_official_tags (name, color, bg_color, sort_order, status) VALUES (?,?,?,?,?)`,
          [name, color || '#2563eb', bgColor || '#dbeafe', Number(sortOrder) || 0, status || '1']
        )
        res.json({ code: 200, msg: '新增成功', data: { id: result.lastInsertRowid || result.insertId } })
      }
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  router.delete('/api/official-tags/:id', async (req, res) => {
    try {
      await query('DELETE FROM app_official_tags WHERE id=?', [Number(req.params.id)])
      res.json({ code: 200, msg: '删除成功', data: { success: true } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })
}

module.exports = officialTagRoutes
