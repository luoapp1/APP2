const { query } = require('../database.cjs')
const { progressTasksByAction } = require('./custom-task.cjs')

function postFavoriteRoutes(router) {
  router.get('/api/post-favorite/list', async (req, res) => {
    try {
      const userId = req.query.userId || req.headers['x-user-id']
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const rows = await query(
        `SELECT f.*, p.title, p.content, p.section_id, p.create_time as post_time, u.username as author
         FROM post_favorites f
         JOIN community_posts p ON f.post_id=p.id
         LEFT JOIN users u ON p.user_id=u.id
         WHERE f.user_id=? ORDER BY f.create_time DESC`,
        [Number(userId)]
      )
      res.json({ code: 200, data: rows })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  router.post('/api/post-favorite/toggle', async (req, res) => {
    try {
      const { userId, postId } = req.body
      if (!userId || !postId) return res.json({ code: 400, msg: '参数不完整' })

      const existing = await query(
        'SELECT id FROM post_favorites WHERE user_id=? AND post_id=?',
        [Number(userId), Number(postId)]
      )

      if (existing && existing.length > 0) {
        await query('DELETE FROM post_favorites WHERE id=?', [existing[0].id])
        res.json({ code: 200, msg: '已取消收藏', data: { favorited: false } })
      } else {
        await query(
          'INSERT INTO post_favorites (user_id, post_id) VALUES (?,?)',
          [Number(userId), Number(postId)]
        )
        progressTasksByAction(Number(userId), '', 'favorite')
        res.json({ code: 200, msg: '收藏成功', data: { favorited: true } })
      }
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  router.get('/api/post-favorite/check', async (req, res) => {
    try {
      const { userId, postId } = req.query
      if (!userId || !postId) return res.json({ code: 400, msg: '参数不完整' })

      const rows = await query(
        'SELECT id FROM post_favorites WHERE user_id=? AND post_id=?',
        [Number(userId), Number(postId)]
      )
      res.json({ code: 200, data: { favorited: rows && rows.length > 0 } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })
}

module.exports = postFavoriteRoutes
