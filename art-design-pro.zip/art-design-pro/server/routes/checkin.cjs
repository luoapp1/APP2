const { query } = require('../database.cjs')
const { authRequired, sessions, SESSION_TTL } = require('./system.cjs')
const { progressTasksByAction } = require('./custom-task.cjs')

async function getUserId(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return 0
  const session = sessions.get(token)
  if (session) {
    if (Date.now() - session.createdAt > SESSION_TTL) { sessions.delete(token); return 0 }
    return Number(session.userId) || 0
  }
  try {
    const rows = await query('SELECT user_id, created_at FROM sessions WHERE token=?', [token])
    if (rows.length > 0) {
      const createdAt = typeof rows[0].created_at === 'number' ? rows[0].created_at : new Date(rows[0].created_at).getTime()
      if (Date.now() - createdAt > SESSION_TTL) { return 0 }
      return Number(rows[0].user_id) || 0
    }
  } catch {}
  return 0
}

const BASE_POINTS = 5
const BASE_EXP = 2

function calcReward(consecutiveDays) {
  const bonus = Math.min(consecutiveDays - 1, 6) * 2
  return { points: BASE_POINTS + bonus, experience: BASE_EXP + Math.floor(bonus / 2) }
}

module.exports = function checkinRoutes(app) {
  app.post('/api/checkin', authRequired, async (req, res) => {
    try {
      const userId = await getUserId(req)
      const today = new Date().toISOString().substring(0, 10)
      const existing = await query('SELECT id FROM checkin_records WHERE user_id=? AND checkin_date=?', [userId, today])
      if (existing.length > 0) return res.json({ code: 400, message: '今日已签到' })
      const user = await query('SELECT username, points, experience, last_checkin_date, consecutive_checkins FROM users WHERE id=?', [userId])
      if (user.length === 0) return res.json({ code: 404, message: '用户不存在' })
      const yesterday = new Date(Date.now() - 86400000).toISOString().substring(0, 10)
      const lastDate = user[0].last_checkin_date
      let consecutive = user[0].consecutive_checkins || 0
      if (lastDate === yesterday) { consecutive += 1 }
      else if (lastDate === today) { /* 不应到达 */ }
      else { consecutive = 1 }

      const reward = calcReward(consecutive)
      await query('INSERT INTO checkin_records (user_id, user_name, checkin_date, consecutive_days, points_earned, experience_earned) VALUES (?,?,?,?,?,?)',
        [userId, user[0].username, today, consecutive, reward.points, reward.experience])
      await query('UPDATE users SET points=points+?, experience=experience+?, last_checkin_date=?, consecutive_checkins=? WHERE id=?',
        [reward.points, reward.experience, today, consecutive, userId])
      await query(`INSERT INTO points_records (user_id, user_name, type, points, balance, source, description) VALUES (?,?,'earn',?, (SELECT points FROM users WHERE id=?), '每日签到', ?)`,
        [userId, user[0].username, reward.points, userId, `连续签到第${consecutive}天`])
      progressTasksByAction(userId, user[0].username, 'checkin')
      res.json({ code: 200, message: '签到成功', data: { consecutive, pointsEarned: reward.points, experienceEarned: reward.experience } })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.get('/api/checkin/status', authRequired, async (req, res) => {
    try {
      const userId = await getUserId(req)
      const today = new Date().toISOString().substring(0, 10)
      const checked = await query('SELECT id, consecutive_days, points_earned, experience_earned FROM checkin_records WHERE user_id=? AND checkin_date=?', [userId, today])
      const user = await query('SELECT consecutive_checkins FROM users WHERE id=?', [userId])
      const consecutive = user.length > 0 ? user[0].consecutive_checkins : 0
      res.json({ code: 200, data: { checkedToday: checked.length > 0, consecutive, todayRecord: checked.length > 0 ? checked[0] : null, nextReward: calcReward(consecutive + 1) } })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.get('/api/checkin/history', authRequired, async (req, res) => {
    try {
      const userId = await getUserId(req)
      const { page = 1, pageSize = 31 } = req.query
      const offset = (page - 1) * pageSize
      const list = await query('SELECT * FROM checkin_records WHERE user_id=? ORDER BY checkin_date DESC LIMIT ? OFFSET ?', [userId, parseInt(pageSize), offset])
      const cnt = await query('SELECT COUNT(*) as total FROM checkin_records WHERE user_id=?', [userId])
      res.json({ code: 200, data: { list, total: cnt[0].total } })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })
}
