const { query, dbType } = require('../database.cjs')
const nowExpr = dbType === 'mysql' ? 'NOW()' : "datetime('now','localtime')"

function menuRoutes(router) {
  // GET /api/menu/list — flat list
  router.get('/api/menu/list', async (req, res) => {
    try {
      const rows = await query(
        `SELECT id, parent_id as parentId, name, path, component, redirect, title, icon,
                sort_order as sortOrder, is_hidden as isHidden, is_full_page as isFullPage,
                is_keep_alive as isKeepAlive, is_fixed_tab as isFixedTab, auth_list as authList,
                roles, enabled, create_time as createTime, update_time as updateTime
         FROM menus WHERE enabled = 1 ORDER BY sort_order, id`
      )
      const list = rows.map(r => {
        try { r.authList = r.authList ? JSON.parse(r.authList) : null } catch { r.authList = null }
        try { r.roles = r.roles ? JSON.parse(r.roles) : null } catch { r.roles = null }
        return r
      })
      res.json({ code: 200, msg: 'success', data: list })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // POST /api/menu/save
  router.post('/api/menu/save', async (req, res) => {
    try {
      const { id, parentId, name, path, component, redirect, title, icon, sortOrder,
              isHidden, isFullPage, isKeepAlive, isFixedTab, authList, roles, enabled } = req.body
      if (id) {
        await query(
          `UPDATE menus SET parent_id=?, name=?, path=?, component=?, redirect=?, title=?, icon=?,
           sort_order=?, is_hidden=?, is_full_page=?, is_keep_alive=?, is_fixed_tab=?,
           auth_list=?, roles=?, enabled=?, update_time=${nowExpr} WHERE id=?`,
          [parentId || 0, name, path, component || '', redirect || '', title, icon || '',
           sortOrder || 0, isHidden ? 1 : 0, isFullPage ? 1 : 0, isKeepAlive ? 1 : 0,
           isFixedTab ? 1 : 0, authList ? JSON.stringify(authList) : null,
           roles ? JSON.stringify(roles) : null, enabled !== false ? 1 : 0, id]
        )
        res.json({ code: 200, msg: '更新成功', data: { id } })
      } else {
        const result = await query(
          `INSERT INTO menus (parent_id, name, path, component, redirect, title, icon,
           sort_order, is_hidden, is_full_page, is_keep_alive, is_fixed_tab, auth_list, roles, enabled)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [parentId || 0, name, path, component || '', redirect || '', title, icon || '',
           sortOrder || 0, isHidden ? 1 : 0, isFullPage ? 1 : 0, isKeepAlive ? 1 : 0,
           isFixedTab ? 1 : 0, authList ? JSON.stringify(authList) : null,
           roles ? JSON.stringify(roles) : null, enabled !== false ? 1 : 0]
        )
        res.json({ code: 200, msg: '新增成功', data: { id: result.lastInsertRowid || result.insertId } })
      }
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // DELETE /api/menu/:id
  router.delete('/api/menu/:id', async (req, res) => {
    try {
      await query('DELETE FROM menus WHERE id=? OR parent_id=?', [req.params.id, req.params.id])
      await query('DELETE FROM role_permissions WHERE menu_id=?', [req.params.id])
      res.json({ code: 200, msg: '删除成功', data: { success: true } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })
}

module.exports = menuRoutes
