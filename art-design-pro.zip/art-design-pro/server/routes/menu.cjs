const { query, dbType } = require('../database.cjs')
const nowExpr = dbType === 'mysql' ? 'NOW()' : "datetime('now','localtime')"
const { systemLog } = require('../middleware/security.cjs')

function getUserInfo(req) {
  const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '')
  return { userId: 0, userName: token ? 'admin' : 'system' }
}

async function logAction(req, type, targetType, targetId, detail) {
  const { userId, userName } = getUserInfo(req)
  const ip = req.headers['x-forwarded-for'] || req.socket?.remoteAddress || ''
  await systemLog(type, userId, userName, targetType, targetId, detail, ip)
}

function menuRoutes(router) {
  // GET /api/menu/list — flat list
  router.get('/api/menu/list', async (req, res) => {
    try {
      const rows = await query(
        `SELECT id, parent_id as parentId, name, path, component, redirect, title, icon,
                sort_order as sortOrder, is_hidden as isHidden, is_full_page as isFullPage,
                is_keep_alive as isKeepAlive, is_fixed_tab as isFixedTab, auth_list as authList,
                roles, enabled, create_time as createTime, update_time as updateTime
         FROM menus WHERE enabled = 1 ORDER BY sort_order, id`
      )
      const list = rows.map(r => {
        try { r.authList = r.authList ? JSON.parse(r.authList) : null } catch { r.authList = null }
        try { r.roles = r.roles ? JSON.parse(r.roles) : null } catch { r.roles = null }
        return r
      })
      res.json({ code: 200, msg: 'success', data: list })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // POST /api/menu/save
  router.post('/api/menu/save', async (req, res) => {
    try {
      const { id, parentId, name, path, component, redirect, title, icon, sortOrder,
              isHidden, isFullPage, isKeepAlive, isFixedTab, authList, roles, enabled } = req.body

      if (parentId && Number(parentId) === Number(id)) {
        return res.json({ code: 400, msg: '不能将菜单设置为自己的子菜单' })
      }

      if (id) {
        const oldRows = await query('SELECT * FROM menus WHERE id=?', [id])
        const oldData = oldRows.length ? JSON.stringify(oldRows[0]) : '{}'

        await query(
          `UPDATE menus SET parent_id=?, name=?, path=?, component=?, redirect=?, title=?, icon=?,
           sort_order=?, is_hidden=?, is_full_page=?, is_keep_alive=?, is_fixed_tab=?,
           auth_list=?, roles=?, enabled=?, update_time=${nowExpr} WHERE id=?`,
          [parentId || 0, name, path, component || '', redirect || '', title, icon || '',
           sortOrder || 0, isHidden ? 1 : 0, isFullPage ? 1 : 0, isKeepAlive ? 1 : 0,
           isFixedTab ? 1 : 0, authList ? JSON.stringify(authList) : null,
           roles ? JSON.stringify(roles) : null, enabled !== false ? 1 : 0, id]
        )
        await logAction(req, 'update', 'menu', id,
          `更新菜单"${title || name}"。旧数据:${oldData}`)
        res.json({ code: 200, msg: '更新成功', data: { id } })
      } else {
        const result = await query(
          `INSERT INTO menus (parent_id, name, path, component, redirect, title, icon,
           sort_order, is_hidden, is_full_page, is_keep_alive, is_fixed_tab, auth_list, roles, enabled)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [parentId || 0, name, path, component || '', redirect || '', title, icon || '',
           sortOrder || 0, isHidden ? 1 : 0, isFullPage ? 1 : 0, isKeepAlive ? 1 : 0,
           isFixedTab ? 1 : 0, authList ? JSON.stringify(authList) : null,
           roles ? JSON.stringify(roles) : null, enabled !== false ? 1 : 0]
        )
        const newId = result.lastInsertRowid || result.insertId
        await logAction(req, 'create', 'menu', newId,
          `新建菜单"${title || name}"，路径:${path}`)
        res.json({ code: 200, msg: '新增成功', data: { id: newId } })
      }
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // DELETE /api/menu/:id
  router.delete('/api/menu/:id', async (req, res) => {
    try {
      const oldRows = await query('SELECT * FROM menus WHERE id=?', [req.params.id])
      const oldData = oldRows.length ? JSON.stringify(oldRows[0]) : '{}'
      const menuName = oldRows.length ? (oldRows[0].title || oldRows[0].name) : String(req.params.id)

      await query('DELETE FROM menus WHERE id=? OR parent_id=?', [req.params.id, req.params.id])
      await query('DELETE FROM role_permissions WHERE menu_id=?', [req.params.id])
      await logAction(req, 'delete', 'menu', Number(req.params.id),
        `删除菜单"${menuName}"。被删除数据:${oldData}`)
      res.json({ code: 200, msg: '删除成功', data: { success: true } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // POST /api/menu/restore/:logId — 从日志恢复菜单
  router.post('/api/menu/restore/:logId', async (req, res) => {
    try {
      const logRows = await query('SELECT * FROM system_logs WHERE id=?', [Number(req.params.logId)])
      if (!logRows.length) return res.json({ code: 404, msg: '日志记录不存在' })

      const log = logRows[0]
      if (log.target_type !== 'menu') return res.json({ code: 400, msg: '该日志不是菜单操作' })

      const detail = log.detail || ''

      if (log.type === 'update' || log.type === 'delete') {
        const oldMatch = detail.match(/旧数据[：:]\s*(\{[\s\S]*\})/)
        const deletedMatch = detail.match(/被删除数据[：:]\s*(\{[\s\S]*\})/)
        const jsonStr = (oldMatch ? oldMatch[1] : deletedMatch ? deletedMatch[1] : null)
        if (!jsonStr) return res.json({ code: 400, msg: '无法从日志中提取旧数据' })

        const old = JSON.parse(jsonStr)
        const restoreId = old.id

        const existing = await query('SELECT id FROM menus WHERE id=?', [restoreId])
        if (existing.length) {
          await query(
            `UPDATE menus SET parent_id=?, name=?, path=?, component=?, redirect=?, title=?, icon=?,
             sort_order=?, is_hidden=?, is_full_page=?, is_keep_alive=?, is_fixed_tab=?,
             auth_list=?, roles=?, enabled=?, update_time=${nowExpr} WHERE id=?`,
            [old.parent_id || 0, old.name, old.path || '', old.component || '', old.redirect || '',
             old.title, old.icon || '', old.sort_order || 0, old.is_hidden || 0, old.is_full_page || 0,
             old.is_keep_alive !== 0 ? 1 : 0, old.is_fixed_tab || 0, old.auth_list || null,
             old.roles || null, old.enabled !== 0 ? 1 : 0, restoreId]
          )
          await logAction(req, 'restore', 'menu', restoreId,
            `通过日志#${log.id}恢复菜单"${old.title || old.name}"`)
          return res.json({ code: 200, msg: '已恢复（更新）', data: { id: restoreId } })
        } else {
          await query(
            `INSERT INTO menus (id, parent_id, name, path, component, redirect, title, icon,
             sort_order, is_hidden, is_full_page, is_keep_alive, is_fixed_tab, auth_list, roles, enabled, create_time, update_time)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [restoreId, old.parent_id || 0, old.name, old.path || '', old.component || '',
             old.redirect || '', old.title, old.icon || '', old.sort_order || 0, old.is_hidden || 0,
             old.is_full_page || 0, old.is_keep_alive !== 0 ? 1 : 0, old.is_fixed_tab || 0,
             old.auth_list || null, old.roles || null, old.enabled !== 0 ? 1 : 0,
             old.create_time || nowExpr, nowExpr]
          )
          await logAction(req, 'restore', 'menu', restoreId,
            `通过日志#${log.id}恢复已删除菜单"${old.title || old.name}"`)
          return res.json({ code: 200, msg: '已恢复（重建）', data: { id: restoreId } })
        }
      }

      if (log.type === 'create') {
        return res.json({ code: 400, msg: '新建操作无需恢复，如需撤销请删除该菜单' })
      }

      res.json({ code: 400, msg: `不支持的操作类型: ${log.type}` })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })
}

module.exports = menuRoutes
