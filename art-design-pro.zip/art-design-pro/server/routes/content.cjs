const { query } = require('../database.cjs')

const SESSION_TTL = 24 * 60 * 60 * 1000
const sessions = new Map()

async function getUserId(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return 0
  const session = sessions.get(token)
  if (session) {
    if (Date.now() - session.createdAt > SESSION_TTL) { sessions.delete(token); return 0 }
    return session.userId
  }
  try {
    const rows = await query('SELECT user_id, roles, created_at FROM sessions WHERE token=?', [token])
    if (rows.length) {
      const r = rows[0]
      const ca = typeof r.created_at === 'number' ? r.created_at : new Date(r.created_at).getTime()
      if (Date.now() - ca > SESSION_TTL) { query('DELETE FROM sessions WHERE token=?', [token]).catch(() => {}); return 0 }
      sessions.set(token, { userId: r.user_id, roles: JSON.parse(r.roles || '[]'), createdAt: ca })
      return r.user_id
    }
  } catch {}
  return 0
}

async function getUserRoles(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return []
  const session = sessions.get(token)
  if (session) return session.roles || []
  try {
    const rows = await query('SELECT roles FROM sessions WHERE token=?', [token])
    if (rows.length) {
      try { return JSON.parse(rows[0].roles || '[]') } catch { return [] }
    }
  } catch {}
  return []
}

async function isAdmin(req) {
  const roles = await getUserRoles(req)
  return roles.some(r => r === 'R_SUPER' || r === 'R_ADMIN')
}

async function getUserLevel(userId) {
  if (!userId) return null
  try {
    const rows = await query('SELECT level_id, level_name, expire_time FROM users WHERE id=?', [userId])
    if (!rows.length) return null
    const u = rows[0]
    if (u.expire_time && new Date(u.expire_time) < new Date()) return null
    if (!u.level_id) return null
    const lvl = await query('SELECT tier FROM membership_levels WHERE id=?', [u.level_id])
    return { levelId: u.level_id, levelName: u.level_name, tier: lvl.length ? lvl[0].tier : 1 }
  } catch { return null }
}

function contentRoutes(app) {

  // ==================== Content Visibility Check ====================
  app.get('/api/content/visibility/:type/:id', async (req, res) => {
    try {
      const { type, id } = req.params
      const userId = await getUserId(req)
      const table = type === 'app' ? 'app_store' : 'community_posts'

      const rows = await query(
        `SELECT content_permission, content_price, content_price_type, access_password, access_password_tips, user_id
         FROM ${table} WHERE id=?`, [id]
      )
      if (!rows.length) return res.json({ code: 404, msg: '内容不存在' })

      const item = rows[0]
      const perm = item.content_permission || 'public'
      const resp = { code: 200, data: { permission: perm, accessible: true } }

      if (perm === 'public') return res.json(resp)

      if (perm === 'login') {
        resp.data.accessible = !!userId
        return res.json(resp)
      }

      if (perm === 'comment') {
        if (!userId) { resp.data.accessible = false; return res.json(resp) }
        const commentTable = type === 'app' ? 'app_comments' : 'community_comments'
        const contentField = type === 'app' ? 'app_id' : 'post_id'
        const comments = await query(`SELECT id FROM ${commentTable} WHERE ${contentField}=? AND user_id=?`, [id, userId])
        resp.data.accessible = comments.length > 0
        return res.json(resp)
      }

      if (perm === 'paid') {
        if (!userId) { resp.data.accessible = false; resp.data.price = item.content_price; return res.json(resp) }
        resp.data.price = item.content_price || 0
        resp.data.priceType = item.content_price_type || 'balance'
        const pur = await query('SELECT id FROM content_purchases WHERE content_type=? AND content_id=? AND user_id=?', [type, Number(id), userId])
        resp.data.accessible = pur.length > 0 || Number(item.user_id) === userId
        resp.data.purchased = pur.length > 0
        return res.json(resp)
      }

      if (perm === 'level1' || perm === 'level2') {
        if (!userId) { resp.data.accessible = false; return res.json(resp) }
        const lvl = await getUserLevel(userId)
        if (!lvl) { resp.data.accessible = false; return res.json(resp) }
        if (perm === 'level1') resp.data.accessible = lvl.tier >= 1
        else resp.data.accessible = lvl.tier >= 2
        return res.json(resp)
      }

      if (perm === 'password') {
        resp.data.accessible = false
        resp.data.passwordSet = !!item.access_password
        resp.data.passwordTips = item.access_password_tips || ''
        return res.json(resp)
      }

      res.json(resp)
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== Password Verify ====================
  app.post('/api/content/verify-password/:type/:id', async (req, res) => {
    try {
      const { type, id } = req.params
      const { password } = req.body
      const table = type === 'app' ? 'app_store' : 'community_posts'
      const rows = await query(`SELECT access_password FROM ${table} WHERE id=?`, [id])
      if (!rows.length) return res.json({ code: 404, msg: '内容不存在' })
      if (rows[0].access_password === password) {
        return res.json({ code: 200, msg: '验证成功', data: { valid: true } })
      }
      res.json({ code: 400, msg: '密码错误', data: { valid: false } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== Content Purchase ====================
  app.post('/api/content/purchase/:type/:id', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const { type, id } = req.params

      const table = type === 'app' ? 'app_store' : 'community_posts'
      const rows = await query(
        `SELECT content_price, content_price_type, content_permission, user_id, title, name
         FROM ${table} WHERE id=?`, [id]
      )
      if (!rows.length) return res.json({ code: 404, msg: '内容不存在' })

      const item = rows[0]
      if (item.content_permission !== 'paid') return res.json({ code: 400, msg: '此内容非付费内容' })
      const price = Number(item.content_price) || 0
      const priceType = item.content_price_type || 'balance'
      if (price <= 0) return res.json({ code: 400, msg: '价格异常' })

      const existing = await query('SELECT id FROM content_purchases WHERE content_type=? AND content_id=? AND user_id=?', [type, Number(id), userId])
      if (existing.length) return res.json({ code: 400, msg: '已购买过此内容' })
      if (Number(item.user_id) === userId) return res.json({ code: 400, msg: '自己的内容无需购买' })

      const user = await query('SELECT balance, points FROM users WHERE id=?', [userId])
      if (!user.length) return res.json({ code: 404, msg: '用户不存在' })

      const u = user[0]
      if (priceType === 'balance') {
        if (Number(u.balance) < price) return res.json({ code: 400, msg: '余额不足' })
        await query('UPDATE users SET balance = balance - ? WHERE id=?', [price, userId])
      } else {
        if (Number(u.points || 0) < price) return res.json({ code: 400, msg: '积分不足' })
        await query('UPDATE users SET points = points - ? WHERE id=?', [price, userId])
      }

      // Split profit calculation
      let commissionAmount = 0
      let commissionRate = 0
      const authorId = Number(item.user_id)
      if (authorId) {
        const typeMap = { community_posts: 'post', app_store: 'app' }
        const specificType = typeMap[type] || 'content'
        const ruleResult = await query(
          `SELECT rate FROM commission_rules
           WHERE status='1' AND ((order_type=? OR order_type='all') AND (user_id=? OR user_id=0) AND invite_code_id=0)
           ORDER BY user_id DESC LIMIT 1`, [specificType, authorId]
        )
        if (!ruleResult.length) {
          const fallback = await query(
            `SELECT rate FROM commission_rules
             WHERE status='1' AND ((order_type='content' OR order_type='all') AND (user_id=? OR user_id=0) AND invite_code_id=0)
             ORDER BY user_id DESC LIMIT 1`, [authorId]
          )
          if (fallback.length) commissionRate = Number(fallback[0].rate)
        } else {
          commissionRate = Number(ruleResult[0].rate)
        }
        if (!commissionRate) {
          const authorLevel = await query('SELECT level_id FROM users WHERE id=?', [authorId])
          if (authorLevel.length && authorLevel[0].level_id) {
            const lvlRule = await query(
              `SELECT rate FROM commission_rules
               WHERE status='1' AND ((order_type=? OR order_type='content' OR order_type='all') AND user_level_id=? AND user_id=0 AND invite_code_id=0)
               LIMIT 1`, [specificType, authorLevel[0].level_id]
            )
            if (lvlRule.length) commissionRate = Number(lvlRule[0].rate)
          }
        }
        if (!commissionRate) {
          const globalRule = await query(
            `SELECT rate FROM commission_rules
             WHERE status='1' AND ((order_type=? OR order_type='content' OR order_type='all') AND user_level_id=0 AND user_id=0 AND invite_code_id=0)
             ORDER BY rate DESC LIMIT 1`, [specificType]
          )
          if (globalRule.length) commissionRate = Number(globalRule[0].rate)
        }
        commissionAmount = parseFloat((price * commissionRate / 100).toFixed(2))
        if (commissionAmount > 0) {
          await query('UPDATE users SET balance = balance + ? WHERE id=?', [commissionAmount, authorId])
          await query(
            `INSERT INTO commission_records (order_id, order_type, order_amount, user_id, user_name, referrer_id, referrer_name, rate, amount, status)
             VALUES (?,?,?,?,?,?,?,?,?,'completed')`,
            [id, type, price, authorId, '', 0, '', commissionRate, commissionAmount]
          )
        }
      }

      await query(
        `INSERT INTO content_purchases (user_id, content_type, content_id, author_id, amount, pay_type, commission_amount, commission_rate)
         VALUES (?,?,?,?,?,?,?,?)`,
        [userId, type, Number(id), authorId, price, priceType, commissionAmount, commissionRate]
      )

      res.json({ code: 200, msg: '购买成功' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== Purchase Status ====================
  app.get('/api/content/purchased/:type/:id', async (req, res) => {
    try {
      const userId = await getUserId(req)
      const { type, id } = req.params
      if (!userId) return res.json({ code: 200, data: { purchased: false } })
      const pur = await query('SELECT id FROM content_purchases WHERE content_type=? AND content_id=? AND user_id=?', [type, Number(id), userId])
      res.json({ code: 200, data: { purchased: pur.length > 0 } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== Purchase History ====================
  app.get('/api/content/purchases/my', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const page = Number(req.query.page) || 1
      const size = Number(req.query.size) || 20
      const offset = (page - 1) * size
      const rows = await query(
        `SELECT cp.*, COALESCE(cp2.title, a.name) as content_title
         FROM content_purchases cp
         LEFT JOIN community_posts cp2 ON cp.content_type='post' AND cp.content_id=cp2.id
         LEFT JOIN app_store a ON cp.content_type='app' AND cp.content_id=a.id
         WHERE cp.user_id=?
         ORDER BY cp.create_time DESC LIMIT ? OFFSET ?`,
        [userId, size, offset]
      )
      const total = await query('SELECT COUNT(*) as c FROM content_purchases WHERE user_id=?', [userId])
      res.json({ code: 200, data: { records: rows, total: total[0].c, page, size } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== Membership Products CRUD ====================
  app.get('/api/membership/products', async (req, res) => {
    try {
      const levelId = Number(req.query.levelId) || 0
      let where = ''
      const params = []
      if (levelId) { where = 'WHERE level_id=?'; params.push(levelId) }
      const rows = await query(`SELECT * FROM membership_products ${where} ORDER BY level_id, price`, params)
      res.json({ code: 200, data: rows })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/membership/product/save', async (req, res) => {
    try {
      if (!(await isAdmin(req))) return res.json({ code: 403, msg: '无权限' })
      const { id, levelId, name, price, originalPrice, durationDays, isPromo, promoEndTime, status } = req.body
      if (id) {
        await query(
          `UPDATE membership_products SET level_id=?, name=?, price=?, original_price=?, duration_days=?, is_promo=?, promo_end_time=?, status=?
           WHERE id=?`,
          [levelId || 0, name || '', price || 0, originalPrice || 0, durationDays || 30, isPromo ? 1 : 0, promoEndTime || null, status || '1', id]
        )
      } else {
        await query(
          `INSERT INTO membership_products (level_id, name, price, original_price, duration_days, is_promo, promo_end_time, status)
           VALUES (?,?,?,?,?,?,?,?)`,
          [levelId || 0, name || '', price || 0, originalPrice || 0, durationDays || 30, isPromo ? 1 : 0, promoEndTime || null, status || '1']
        )
      }
      res.json({ code: 200, msg: '保存成功' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.delete('/api/membership/product/:id', async (req, res) => {
    try {
      if (!(await isAdmin(req))) return res.json({ code: 403, msg: '无权限' })
      await query('DELETE FROM membership_products WHERE id=?', [req.params.id])
      res.json({ code: 200, msg: '删除成功' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== Membership Purchase ====================
  app.post('/api/membership/buy', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const { productId } = req.body

      const product = await query('SELECT * FROM membership_products WHERE id=? AND status=?', [productId, '1'])
      if (!product.length) return res.json({ code: 404, msg: '商品不存在或已下架' })

      const prod = product[0]
      const actualPrice = prod.is_promo && (!prod.promo_end_time || new Date(prod.promo_end_time) > new Date()) ? Number(prod.price) : (Number(prod.original_price) || Number(prod.price))

      const user = await query('SELECT balance FROM users WHERE id=?', [userId])
      if (Number(user[0].balance) < actualPrice) return res.json({ code: 400, msg: '余额不足' })

      const level = await query('SELECT * FROM membership_levels WHERE id=?', [prod.level_id])
      if (!level.length) return res.json({ code: 404, msg: '会员等级不存在' })

      await query('UPDATE users SET balance = balance - ? WHERE id=?', [actualPrice, userId])

      const now = new Date()
      const purchaseType = await determinePurchaseType(userId, prod.level_id)
      let expireTime

      if (purchaseType === 'upgrade') {
        expireTime = new Date(now.getTime() + prod.duration_days * 86400000)
      } else {
        const current = await query('SELECT expire_time FROM users WHERE id=?', [userId])
        const currentExpire = current[0]?.expire_time ? new Date(current[0].expire_time) : now
        if (currentExpire < now) currentExpire.setTime(now.getTime())
        expireTime = new Date(currentExpire.getTime() + prod.duration_days * 86400000)
      }

      await query('UPDATE users SET level_id=?, level_name=?, expire_time=? WHERE id=?',
        [prod.level_id, level[0].name, expireTime.toISOString(), userId])

      await query(
        `INSERT INTO membership_purchases (user_id, product_id, level_id, level_name, amount, pay_type, purchase_type, duration_days, expire_time)
         VALUES (?,?,?,?,?,?,?,?,?)`,
        [userId, productId, prod.level_id, level[0].name, actualPrice, 'balance', purchaseType, prod.duration_days, expireTime.toISOString()]
      )

      res.json({ code: 200, msg: '购买成功', data: { levelName: level[0].name, expireTime: expireTime.toISOString() } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  async function determinePurchaseType(userId, newLevelId) {
    const user = await query('SELECT level_id FROM users WHERE id=?', [userId])
    if (!user.length) return 'buy'
    const currentId = user[0].level_id
    if (!currentId) return 'buy'
    const newLevel = await query('SELECT tier FROM membership_levels WHERE id=?', [newLevelId])
    const currLevel = await query('SELECT tier FROM membership_levels WHERE id=?', [currentId])
    const newTier = newLevel.length ? newLevel[0].tier : 1
    const currTier = currLevel.length ? currLevel[0].tier : 1
    if (newLevelId === currentId) return 'renew'
    if (newTier > currTier) return 'upgrade'
    return 'buy'
  }

  // ==================== Membership Purchase History ====================
  app.get('/api/membership/purchases/my', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const rows = await query(
        `SELECT mp.*, mp2.name as product_name
         FROM membership_purchases mp
         LEFT JOIN membership_products mp2 ON mp.product_id=mp2.id
         WHERE mp.user_id=?
         ORDER BY mp.create_time DESC`,
        [userId]
      )
      res.json({ code: 200, data: rows })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== Admin: Membership Products List ====================
  app.get('/api/admin/membership/purchases', async (req, res) => {
    try {
      if (!(await isAdmin(req))) return res.json({ code: 403, msg: '无权限' })
      const page = Number(req.query.page) || 1
      const size = Number(req.query.size) || 20
      const offset = (page - 1) * size
      const rows = await query(
        `SELECT mp.*, u.nickname as userName
         FROM membership_purchases mp
         LEFT JOIN users u ON mp.user_id=u.id
         ORDER BY mp.create_time DESC LIMIT ? OFFSET ?`,
        [size, offset]
      )
      const total = await query('SELECT COUNT(*) as c FROM membership_purchases')
      res.json({ code: 200, data: { records: rows, total: total[0].c, page, size } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== Admin: Content Purchases List ====================
  app.get('/api/admin/content/purchases', async (req, res) => {
    try {
      if (!(await isAdmin(req))) return res.json({ code: 403, msg: '无权限' })
      const page = Number(req.query.page) || 1
      const size = Number(req.query.size) || 20
      const offset = (page - 1) * size
      const rows = await query(
        `SELECT cp.*, u.nickname as userName
         FROM content_purchases cp
         LEFT JOIN users u ON cp.user_id=u.id
         ORDER BY cp.create_time DESC LIMIT ? OFFSET ?`,
        [size, offset]
      )
      const total = await query('SELECT COUNT(*) as c FROM content_purchases')
      res.json({ code: 200, data: { records: rows, total: total[0].c, page, size } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== My Earnings (Author) ====================
  app.get('/api/content/earnings/my', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const total = await query(
        'SELECT COALESCE(SUM(commission_amount),0) as total FROM content_purchases WHERE author_id=?',
        [userId]
      )
      const records = await query(
        `SELECT cp.*, COALESCE(cp2.title, a.name) as content_title
         FROM content_purchases cp
         LEFT JOIN community_posts cp2 ON cp.content_type='post' AND cp.content_id=cp2.id
         LEFT JOIN app_store a ON cp.content_type='app' AND cp.content_id=a.id
         WHERE cp.author_id=?
         ORDER BY cp.create_time DESC LIMIT 50`,
        [userId]
      )
      res.json({ code: 200, data: { total: total[0]?.total || 0, records } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== SysConfig: Split Profit Toggle ====================
  app.get('/api/content/config', async (req, res) => {
    try {
      const rows = await query("SELECT config_key, config_value FROM sys_config WHERE config_key IN ('content_split_enabled','content_split_global_rate')")
      const config = {}
      rows.forEach(r => { config[r.config_key] = r.config_value })
      res.json({ code: 200, data: config })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })
}

module.exports = { contentRoutes }
