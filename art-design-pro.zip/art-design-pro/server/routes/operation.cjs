const { query, dbType } = require('../database.cjs')
const nowExpr = dbType === 'mysql' ? 'NOW()' : "datetime('now','localtime')"

function operationRoutes(router) {
  // ==================== 卡密管理 ====================

  // GET /api/operation/cardkey/list
  router.get('/api/operation/cardkey/list', async (req, res) => {
    try {
      const { current = 1, size = 20, cardNo, type, status } = req.query
      const page = parseInt(current) || 1
      const pageSize = parseInt(size) || 20
      const offset = (page - 1) * pageSize

      let where = ['1=1']
      let params = []
      if (cardNo) { where.push('card_no LIKE ?'); params.push(`%${cardNo}%`) }
      if (type) { where.push('type = ?'); params.push(type) }
      if (status) { where.push('status = ?'); params.push(status) }

      const whereClause = where.join(' AND ')
      const totalRow = await query(`SELECT COUNT(*) as cnt FROM card_keys WHERE ${whereClause}`, params)
      const total = totalRow[0].cnt

      const records = await query(
        `SELECT id, card_no as cardNo, password, type, target_id as targetId, target_name as targetName,
                value, extra_points as extraPoints, extra_experience as extraExperience,
                duration, duration_unit as durationUnit, status, create_by as createBy,
                create_time as createTime, redeem_by as redeemBy, redeem_time as redeemTime
         FROM card_keys WHERE ${whereClause} ORDER BY id DESC LIMIT ${pageSize} OFFSET ${offset}`,
        params
      )

      res.json({ code: 200, msg: 'success', data: { records, current: page, size: pageSize, total } })
    } catch (e) {
      console.error('卡密列表查询失败:', e.message)
      res.json({ code: 500, msg: '查询失败: ' + e.message })
    }
  })

  // POST /api/operation/cardkey/create
  router.post('/api/operation/cardkey/create', async (req, res) => {
    try {
      const { type, targetId, value, count = 1, duration = 0, durationUnit = '', prefix = '', extraPoints = 0, extraExperience = 0 } = req.body
      const ids = []
      let targetName = ''

      if (type === 'membership' && targetId) {
        const lvs = await query('SELECT name FROM membership_levels WHERE id = ?', [Number(targetId)])
        targetName = lvs && lvs.length > 0 ? lvs[0].name : ''
      } else if (type === 'points') {
        targetName = `${value || 0}积分`
      } else if (type === 'experience') {
        targetName = `${value || 0}经验值`
      } else if (type === 'balance') {
        targetName = `${value || 0}元余额`
      }

      for (let i = 0; i < Number(count); i++) {
        const ts = Date.now().toString(36).toUpperCase() + Math.random().toString(36).substring(2, 6).toUpperCase()
        const cardNo = prefix ? `${prefix}-${ts}` : `CDKEY-${ts}`
        const pwd = Math.random().toString(36).substring(2, 10).toUpperCase()
        const result = await query(
          `INSERT INTO card_keys (card_no, password, type, target_id, target_name, value, extra_points, extra_experience, duration, duration_unit)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [cardNo, pwd, type || 'membership', Number(targetId) || 0, targetName, Number(value) || 0, Number(extraPoints) || 0, Number(extraExperience) || 0, Number(duration) || 0, durationUnit || '']
        )
        ids.push(result.lastInsertRowid || result.insertId)
      }

      res.json({ code: 200, msg: `成功生成 ${count} 张卡密`, data: { ids } })
    } catch (e) {
      console.error('生成卡密失败:', e.message)
      res.json({ code: 500, msg: '生成失败: ' + e.message })
    }
  })

  // DELETE /api/operation/cardkey/:id
  router.delete('/api/operation/cardkey/:id', async (req, res) => {
    try {
      await query('DELETE FROM card_keys WHERE id = ?', [Number(req.params.id)])
      res.json({ code: 200, msg: '删除成功', data: { success: true } })
    } catch (e) {
      console.error('删除卡密失败:', e.message)
      res.json({ code: 500, msg: '删除失败: ' + e.message })
    }
  })

  // POST /api/cardkey/redeem — 公开卡密兑换
  router.post('/api/cardkey/redeem', async (req, res) => {
    try {
      const { cardNo, password, userId, userName } = req.body
      if (!cardNo || !password) return res.json({ code: 400, msg: '请输入卡号和密码' })

      const cards = await query(
        `SELECT id, card_no as cardNo, type, target_id as targetId, target_name as targetName,
                value, extra_points as extraPoints, extra_experience as extraExperience,
                duration, duration_unit as durationUnit, status
         FROM card_keys WHERE card_no=? AND password=?`,
        [cardNo, password]
      )
      if (!cards || cards.length === 0) return res.json({ code: 404, msg: '卡密不存在或密码错误' })

      const card = cards[0]
      if (card.status === '1') return res.json({ code: 400, msg: '该卡密已被使用' })

      // 兑换奖励
      const rewards = []
      if (card.type === 'membership' && card.targetId) {
        const lvs = await query('SELECT id, name FROM membership_levels WHERE id=?', [card.targetId])
        if (lvs && lvs.length > 0) {
          const expireTime = new Date()
          if (card.duration && card.durationUnit) {
            const unitMap = { day: 'd', week: 'w', month: 'M', year: 'y' }
            const u = unitMap[card.durationUnit] || 'M'
            if (u === 'd') expireTime.setDate(expireTime.getDate() + card.duration)
            else if (u === 'w') expireTime.setDate(expireTime.getDate() + card.duration * 7)
            else if (u === 'M') expireTime.setMonth(expireTime.getMonth() + card.duration)
            else if (u === 'y') expireTime.setFullYear(expireTime.getFullYear() + card.duration)
          }
          await query(
            `UPDATE users SET level_id=?, level_name=?, expire_time=?, update_time=${nowExpr} WHERE id=?`,
            [card.targetId, lvs[0].name, expireTime, Number(userId)]
          )
          rewards.push(`会员等级升级为${lvs[0].name}`)
        }
      } else if (card.type === 'points') {
        const currentPoints = await query('SELECT points FROM users WHERE id=?', [Number(userId)])
        const newPoints = (currentPoints[0]?.points || 0) + (card.value || 0)
        await query(`UPDATE users SET points=?, update_time=${nowExpr} WHERE id=?`, [newPoints, Number(userId)])
        await query(
          `INSERT INTO points_records (user_id, user_name, type, points, balance, source, description)
           VALUES (?, ?, 'earn', ?, ?, '卡密兑换', ?)`,
          [Number(userId), userName || '', card.value || 0, newPoints, `使用卡密 ${cardNo} 获得${card.value}积分`]
        )
        rewards.push(`${card.value}积分`)
      } else if (card.type === 'experience') {
        const currentExp = await query('SELECT experience FROM users WHERE id=?', [Number(userId)])
        const newExp = (currentExp[0]?.experience || 0) + (card.value || 0)
        await query(`UPDATE users SET experience=?, update_time=${nowExpr} WHERE id=?`, [newExp, Number(userId)])
        rewards.push(`${card.value}经验值`)
      } else if (card.type === 'balance') {
        const currentBal = await query('SELECT balance FROM users WHERE id=?', [Number(userId)])
        const newBal = Number(currentBal[0]?.balance || 0) + (card.value || 0)
        await query(`UPDATE users SET balance=?, update_time=${nowExpr} WHERE id=?`, [newBal, Number(userId)])
        rewards.push(`${card.value}元余额`)
      }

      // 额外奖励
      if (card.extraPoints) {
        const p = await query('SELECT points FROM users WHERE id=?', [Number(userId)])
        const np = (p[0]?.points || 0) + card.extraPoints
        await query(`UPDATE users SET points=?, update_time=${nowExpr} WHERE id=?`, [np, Number(userId)])
        await query(
          `INSERT INTO points_records (user_id, user_name, type, points, balance, source, description)
           VALUES (?, ?, 'earn', ?, ?, '卡密兑换', ?)`,
          [Number(userId), userName || '', card.extraPoints, np, `使用卡密 ${cardNo} 额外获得${card.extraPoints}积分`]
        )
        rewards.push(`额外${card.extraPoints}积分`)
      }
      if (card.extraExperience) {
        const e = await query('SELECT experience FROM users WHERE id=?', [Number(userId)])
        const ne = (e[0]?.experience || 0) + card.extraExperience
        await query(`UPDATE users SET experience=?, update_time=${nowExpr} WHERE id=?`, [ne, Number(userId)])
        rewards.push(`额外${card.extraExperience}经验值`)
      }

      await query(
        `UPDATE card_keys SET status='1', redeem_by=?, redeem_time=${nowExpr} WHERE id=?`,
        [userName || '', card.id]
      )

      // 发送兑换成功通知（不含密码）
      if (userId && rewards.length > 0) {
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id)
           VALUES (?, ?, 'system', ?)`,
          ['卡密兑换成功', `您使用卡密 ${cardNo} 兑换成功，获得：${rewards.join('、')}`, Number(userId)]
        )
      }

      res.json({ code: 200, msg: '兑换成功', data: { rewards, cardNo } })
    } catch (e) {
      console.error('兑换卡密失败:', e.message)
      res.json({ code: 500, msg: '兑换失败: ' + e.message })
    }
  })

  // ==================== 会员等级管理 ====================

  // GET /api/operation/membership-level/list
  router.get('/api/operation/membership-level/list', async (req, res) => {
    try {
      const records = await query(
        `SELECT id, name, level, tier, parent_level_id as parentLevelId, price, points_required as pointsRequired, discount_rate as discountRate,
                points_multiplier as pointsMultiplier, points_discount_rate as pointsDiscountRate,
                benefits, icon, icon_color as iconColor,
                status, create_time as createTime
         FROM membership_levels ORDER BY level ASC`
      )
      res.json({ code: 200, msg: 'success', data: { records, current: 1, size: 100, total: records.length } })
    } catch (e) {
      console.error('会员等级查询失败:', e.message)
      res.json({ code: 500, msg: '查询失败: ' + e.message })
    }
  })

  // POST /api/operation/membership-level/save
  router.post('/api/operation/membership-level/save', async (req, res) => {
    try {
      const { id, name, level, tier, parentLevelId, price, pointsRequired, discountRate, pointsMultiplier, pointsDiscountRate, benefits, icon, iconColor, status } = req.body

      if (id) {
        await query(
          `UPDATE membership_levels SET name=?, level=?, tier=?, parent_level_id=?, price=?, points_required=?, discount_rate=?, points_multiplier=?, points_discount_rate=?, benefits=?, icon=?, icon_color=?, status=? WHERE id=?`,
          [name, Number(level) || 0, Number(tier) || 1, Number(parentLevelId) || 0, Number(price) || 0, Number(pointsRequired) || 0, Number(discountRate) || 1, Number(pointsMultiplier) || 1, Number(pointsDiscountRate) || 1, benefits || '', icon || '', iconColor || '', status || '1', Number(id)]
        )
        res.json({ code: 200, msg: '更新成功', data: { id: Number(id) } })
      } else {
        const result = await query(
          `INSERT INTO membership_levels (name, level, tier, parent_level_id, price, points_required, discount_rate, points_multiplier, points_discount_rate, benefits, icon, icon_color, status)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [name, Number(level) || 0, Number(tier) || 1, Number(parentLevelId) || 0, Number(price) || 0, Number(pointsRequired) || 0, Number(discountRate) || 1, Number(pointsMultiplier) || 1, Number(pointsDiscountRate) || 1, benefits || '', icon || '', iconColor || '', status || '1']
        )
        res.json({ code: 200, msg: '添加成功', data: { id: result.lastInsertRowid || result.insertId } })
      }
    } catch (e) {
      console.error('保存会员等级失败:', e.message)
      res.json({ code: 500, msg: '保存失败: ' + e.message })
    }
  })

  // DELETE /api/operation/membership-level/:id
  router.delete('/api/operation/membership-level/:id', async (req, res) => {
    try {
      await query('DELETE FROM membership_levels WHERE id = ?', [Number(req.params.id)])
      res.json({ code: 200, msg: '删除成功', data: { success: true } })
    } catch (e) {
      console.error('删除会员等级失败:', e.message)
      res.json({ code: 500, msg: '删除失败: ' + e.message })
    }
  })

  // ==================== 会员列表 ====================

  // GET /api/operation/member/list
  router.get('/api/operation/member/list', async (req, res) => {
    try {
      const { current = 1, size = 20, userName, level } = req.query
      const page = parseInt(current) || 1
      const pageSize = parseInt(size) || 20
      const offset = (page - 1) * pageSize

      let where = ['1=1']
      let params = []
      if (userName) { where.push('username LIKE ?'); params.push(`%${userName}%`) }
      if (level !== undefined && level !== '') { where.push('level_id = ?'); params.push(Number(level)) }

      const whereClause = where.join(' AND ')
      const totalRow = await query(`SELECT COUNT(*) as cnt FROM users WHERE ${whereClause}`, params)
      const total = totalRow[0].cnt

      const records = await query(
        `SELECT id as userId, username as userName, level_id as level, level_name as levelName,
                points, points as totalPoints, expire_time as expireTime,
                create_time as createTime, update_time as updateTime
         FROM users WHERE ${whereClause} ORDER BY id DESC LIMIT ${pageSize} OFFSET ${offset}`,
        params
      )

      res.json({ code: 200, msg: 'success', data: { records, current: page, size: pageSize, total } })
    } catch (e) {
      console.error('会员列表查询失败:', e.message)
      res.json({ code: 500, msg: '查询失败: ' + e.message })
    }
  })

  // POST /api/operation/member/update-level
  router.post('/api/operation/member/update-level', async (req, res) => {
    try {
      const { userId, level } = req.body
      const lvs = await query('SELECT id, name FROM membership_levels WHERE id = ?', [Number(level)])
      const lv = lvs && lvs.length > 0 ? lvs[0] : null
      const nowExpr = dbType === 'mysql' ? 'NOW()' : "datetime('now','localtime')"
      await query(`UPDATE users SET level_id = ?, level_name = ?, update_time = ${nowExpr} WHERE id = ?`, [
        Number(level), lv ? lv.name : '普通会员', Number(userId)
      ])
      res.json({ code: 200, msg: '更新成功', data: { success: true } })
    } catch (e) {
      console.error('更新会员等级失败:', e.message)
      res.json({ code: 500, msg: '更新失败: ' + e.message })
    }
  })

  // ==================== 积分记录 ====================

  // GET /api/operation/points-record/list
  router.get('/api/operation/points-record/list', async (req, res) => {
    try {
      const { current = 1, size = 20, userName, type } = req.query
      const page = parseInt(current) || 1
      const pageSize = parseInt(size) || 20
      const offset = (page - 1) * pageSize

      let where = ['1=1']
      let params = []
      if (userName) { where.push('user_name LIKE ?'); params.push(`%${userName}%`) }
      if (type) { where.push('type = ?'); params.push(type) }

      const whereClause = where.join(' AND ')
      const totalRow = await query(`SELECT COUNT(*) as cnt FROM points_records WHERE ${whereClause}`, params)
      const total = totalRow[0].cnt

      const records = await query(
        `SELECT id, user_id as userId, user_name as userName, type, points, balance,
                source, description, create_time as createTime
         FROM points_records WHERE ${whereClause} ORDER BY id DESC LIMIT ${pageSize} OFFSET ${offset}`,
        params
      )

      res.json({ code: 200, msg: 'success', data: { records, current: page, size: pageSize, total } })
    } catch (e) {
      console.error('积分记录查询失败:', e.message)
      res.json({ code: 500, msg: '查询失败: ' + e.message })
    }
  })

  // POST /api/operation/points-record/adjust
  router.post('/api/operation/points-record/adjust', async (req, res) => {
    try {
      const { userId, points, description } = req.body
      const users = await query('SELECT id, username, points FROM users WHERE id = ?', [Number(userId)])
      if (!users || users.length === 0) return res.json({ code: 404, msg: '用户不存在' })

      const user = users[0]
      const newBalance = user.points + Number(points)
      const nowExpr = dbType === 'mysql' ? 'NOW()' : "datetime('now','localtime')"

      await query(`UPDATE users SET points = ?, update_time = ${nowExpr} WHERE id = ?`, [newBalance, Number(userId)])
      await query(
        `INSERT INTO points_records (user_id, user_name, type, points, balance, source, description)
         VALUES (?, ?, 'adjust', ?, ?, '管理员调整', ?)`,
        [Number(userId), user.username, Number(points), newBalance, description || '']
      )

      res.json({ code: 200, msg: '调整成功', data: { success: true } })
    } catch (e) {
      console.error('调整积分失败:', e.message)
      res.json({ code: 500, msg: '调整失败: ' + e.message })
    }
  })

  // ==================== 经验等级管理 ====================

  // GET /api/operation/experience-level/list
  router.get('/api/operation/experience-level/list', async (req, res) => {
    try {
      const records = await query(
        `SELECT id, name, level, exp_required as expRequired, icon, icon_color as iconColor,
                benefits, status, create_time as createTime
         FROM experience_levels ORDER BY level ASC`
      )
      res.json({ code: 200, msg: 'success', data: { records, current: 1, size: 100, total: records.length } })
    } catch (e) {
      console.error('经验等级查询失败:', e.message)
      res.json({ code: 500, msg: '查询失败: ' + e.message })
    }
  })

  // POST /api/operation/experience-level/save
  router.post('/api/operation/experience-level/save', async (req, res) => {
    try {
      const { id, name, level, expRequired, icon, iconColor, benefits, status } = req.body

      if (id) {
        await query(
          `UPDATE experience_levels SET name=?, level=?, exp_required=?, icon=?, icon_color=?, benefits=?, status=? WHERE id=?`,
          [name, Number(level) || 0, Number(expRequired) || 0, icon || '', iconColor || '', benefits || '', status || '1', Number(id)]
        )
        res.json({ code: 200, msg: '更新成功', data: { id: Number(id) } })
      } else {
        const result = await query(
          `INSERT INTO experience_levels (name, level, exp_required, icon, icon_color, benefits, status)
           VALUES (?, ?, ?, ?, ?, ?, ?)`,
          [name, Number(level) || 0, Number(expRequired) || 0, icon || '', iconColor || '', benefits || '', status || '1']
        )
        res.json({ code: 200, msg: '添加成功', data: { id: result.lastInsertRowid || result.insertId } })
      }
    } catch (e) {
      console.error('保存经验等级失败:', e.message)
      res.json({ code: 500, msg: '保存失败: ' + e.message })
    }
  })

  // DELETE /api/operation/experience-level/:id
  router.delete('/api/operation/experience-level/:id', async (req, res) => {
    try {
      await query('DELETE FROM experience_levels WHERE id = ?', [Number(req.params.id)])
      res.json({ code: 200, msg: '删除成功', data: { success: true } })
    } catch (e) {
      console.error('删除经验等级失败:', e.message)
      res.json({ code: 500, msg: '删除失败: ' + e.message })
    }
  })
}

module.exports = operationRoutes
