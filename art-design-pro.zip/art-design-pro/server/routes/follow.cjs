const { query } = require('../database.cjs')
const { authRequired, sessions, SESSION_TTL } = require('./system.cjs')
const { progressTasksByAction } = require('./custom-task.cjs')

async function getUserId(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return 0
  const session = sessions.get(token)
  if (session) {
    if (Date.now() - session.createdAt > SESSION_TTL) { sessions.delete(token); return 0 }
    return Number(session.userId) || 0
  }
  try {
    const rows = await query('SELECT user_id, created_at FROM sessions WHERE token=?', [token])
    if (rows.length > 0) {
      const createdAt = typeof rows[0].created_at === 'number' ? rows[0].created_at : new Date(rows[0].created_at).getTime()
      if (Date.now() - createdAt > SESSION_TTL) { return 0 }
      return Number(rows[0].user_id) || 0
    }
  } catch {}
  return 0
}

module.exports = function followRoutes(app) {
  // 关注用户
  app.post('/api/user/:id/follow', authRequired, async (req, res) => {
    try {
      const followerId = await getUserId(req)
      const followingId = parseInt(req.params.id)
      if (followerId === followingId) return res.json({ code: 400, message: '不能关注自己' })
      const existing = await query('SELECT id FROM user_follows WHERE follower_id=? AND following_id=?', [followerId, followingId])
      if (existing.length > 0) return res.json({ code: 400, message: '已关注该用户' })
      await query('INSERT INTO user_follows (follower_id, following_id) VALUES (?,?)', [followerId, followingId])
      await query('UPDATE users SET follow_count=follow_count+1 WHERE id=?', [followerId])
      await query('UPDATE users SET fans_count=fans_count+1 WHERE id=?', [followingId])

      const follower = await query('SELECT username, nickname FROM users WHERE id=?', [followerId])
      const followerName = follower.length > 0 ? (follower[0].nickname || follower[0].username) : ''
      await query(`INSERT INTO sys_notifications (title, content, type, target_user_id) VALUES ('新粉丝',?,'system',?)`,
        [`${followerName} 关注了您`, followingId])
      progressTasksByAction(followerId, followerName, 'follow')
      res.json({ code: 200, message: '关注成功' })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.delete('/api/user/:id/follow', authRequired, async (req, res) => {
    try {
      const followerId = await getUserId(req)
      const result = await query('DELETE FROM user_follows WHERE follower_id=? AND following_id=?', [followerId, parseInt(req.params.id)])
      if (result.changes > 0) {
        await query('UPDATE users SET follow_count=MAX(0,follow_count-1) WHERE id=?', [followerId])
        await query('UPDATE users SET fans_count=MAX(0,fans_count-1) WHERE id=?', [parseInt(req.params.id)])
      }
      res.json({ code: 200, message: '取消关注成功' })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.get('/api/user/:id/follow-status', authRequired, async (req, res) => {
    try {
      const followerId = await getUserId(req)
      const rows = await query('SELECT id FROM user_follows WHERE follower_id=? AND following_id=?', [followerId, parseInt(req.params.id)])
      res.json({ code: 200, data: { isFollowing: rows.length > 0 } })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.get('/api/user/:id/following', async (req, res) => {
    try {
      const userId = parseInt(req.params.id)
      const { page = 1, pageSize = 20 } = req.query
      const offset = (page - 1) * pageSize
      const list = await query(
        `SELECT u.id, u.username, u.nickname, u.avatar, u.signature, u.fans_count, u.is_verified, u.active_title_name,
                uf.create_time as follow_time FROM user_follows uf JOIN users u ON uf.following_id=u.id
         WHERE uf.follower_id=? ORDER BY uf.create_time DESC LIMIT ? OFFSET ?`,
        [userId, parseInt(pageSize), offset])
      const cnt = await query('SELECT COUNT(*) as total FROM user_follows WHERE follower_id=?', [userId])
      res.json({ code: 200, data: { list, total: cnt[0].total } })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.get('/api/user/:id/followers', async (req, res) => {
    try {
      const userId = parseInt(req.params.id)
      const { page = 1, pageSize = 20 } = req.query
      const offset = (page - 1) * pageSize
      const list = await query(
        `SELECT u.id, u.username, u.nickname, u.avatar, u.signature, u.fans_count, u.is_verified, u.active_title_name,
                uf.create_time as follow_time FROM user_follows uf JOIN users u ON uf.follower_id=u.id
         WHERE uf.following_id=? ORDER BY uf.create_time DESC LIMIT ? OFFSET ?`,
        [userId, parseInt(pageSize), offset])
      const cnt = await query('SELECT COUNT(*) as total FROM user_follows WHERE following_id=?', [userId])
      res.json({ code: 200, data: { list, total: cnt[0].total } })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })
}
