const { query } = require('../database.cjs')
const { authRequired, sessions, SESSION_TTL } = require('./system.cjs')

async function getUserId(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return 0
  const session = sessions.get(token)
  if (session) {
    if (Date.now() - session.createdAt > SESSION_TTL) { sessions.delete(token); return 0 }
    return Number(session.userId) || 0
  }
  try {
    const rows = await query('SELECT user_id, roles, created_at FROM sessions WHERE token=?', [token])
    if (rows.length > 0) {
      const createdAt = typeof rows[0].created_at === 'number' ? rows[0].created_at : new Date(rows[0].created_at).getTime()
      if (Date.now() - createdAt > SESSION_TTL) { return 0 }
      return Number(rows[0].user_id) || 0
    }
  } catch {}
  return 0
}

async function isAdmin(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return false
  const session = sessions.get(token)
  if (session) { const roles = session.roles || []; return roles.includes('R_SUPER') || roles.includes('R_ADMIN') }
  try {
    const rows = await query('SELECT roles FROM sessions WHERE token=?', [token])
    if (rows.length > 0) { const roles = JSON.parse(rows[0].roles || '[]'); return roles.includes('R_SUPER') || roles.includes('R_ADMIN') }
  } catch {}
  return false
}

/**
 * 获取当前用户拉黑的所有用户 ID 列表
 * @param {number} userId
 * @returns {number[]}
 */
async function getBlockedUserIds(userId) {
  if (!userId || userId <= 0) return []
  const rows = await query("SELECT blocked_id FROM user_blocks WHERE blocker_id=? AND status='active'", [userId])
  return rows.map(r => r.blocked_id)
}

/**
 * 获取拉黑了当前用户的所有用户 ID 列表（即被谁拉黑了）
 * @param {number} userId
 * @returns {number[]}
 */
async function getBlockerUserIds(userId) {
  if (!userId || userId <= 0) return []
  const rows = await query("SELECT blocker_id FROM user_blocks WHERE blocked_id=? AND status='active'", [userId])
  return rows.map(r => r.blocker_id)
}

function userBlockRoutes(app) {
  // ===== 拉黑（举报并拉黑） =====
  app.post('/api/user/:id/block', authRequired, async (req, res) => {
    try {
      const blockerId = await getUserId(req)
      const blockedId = parseInt(req.params.id)
      if (blockerId === blockedId) return res.json({ code: 400, message: '不能拉黑自己' })
      const { reason } = req.body || {}

      const existing = await query('SELECT id, status FROM user_blocks WHERE blocker_id=? AND blocked_id=?', [blockerId, blockedId])
      if (existing.length > 0) {
        if (existing[0].status === 'active') return res.json({ code: 400, message: '已拉黑该用户' })
        await query("UPDATE user_blocks SET status='active', reason=?, reviewed=0, create_time=NOW() WHERE id=?", [reason || '', existing[0].id])
      } else {
        await query("INSERT INTO user_blocks (blocker_id, blocked_id, reason, status, create_time) VALUES (?,?,?,'active',NOW())", [blockerId, blockedId, reason || ''])
      }

      res.json({ code: 200, message: '拉黑成功' })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  // ===== 取消拉黑 =====
  app.delete('/api/user/:id/block', authRequired, async (req, res) => {
    try {
      const blockerId = await getUserId(req)
      const blockedId = parseInt(req.params.id)
      await query("UPDATE user_blocks SET status='cancelled' WHERE blocker_id=? AND blocked_id=? AND status='active'", [blockerId, blockedId])
      res.json({ code: 200, message: '取消拉黑成功' })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  // ===== 获取拉黑列表 =====
  app.get('/api/user/blocked', authRequired, async (req, res) => {
    try {
      const userId = await getUserId(req)
      const { page = 1, pageSize = 20 } = req.query
      const offset = (page - 1) * pageSize
      const list = await query(
        `SELECT ub.id, ub.blocked_id, ub.reason, ub.create_time, u.username, u.nickname, u.avatar
         FROM user_blocks ub JOIN users u ON ub.blocked_id=u.id
         WHERE ub.blocker_id=? AND ub.status='active'
         ORDER BY ub.create_time DESC LIMIT ? OFFSET ?`,
        [userId, parseInt(pageSize), offset])
      const cnt = await query("SELECT COUNT(*) as total FROM user_blocks WHERE blocker_id=? AND status='active'", [userId])
      res.json({ code: 200, data: { list, total: cnt[0].total } })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  // ===== 检查拉黑状态 =====
  app.get('/api/user/block-status/:id', authRequired, async (req, res) => {
    try {
      const userId = await getUserId(req)
      const targetId = parseInt(req.params.id)
      const rows = await query("SELECT id FROM user_blocks WHERE blocker_id=? AND blocked_id=? AND status='active'", [userId, targetId])
      res.json({ code: 200, data: { isBlocked: rows.length > 0 } })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  // ===== 检查是否被对方拉黑 =====
  app.get('/api/user/:id/blocked-by-me', authRequired, async (req, res) => {
    try {
      const userId = await getUserId(req)
      const targetId = parseInt(req.params.id)
      const rows = await query("SELECT id FROM user_blocks WHERE blocker_id=? AND blocked_id=? AND status='active'", [targetId, userId])
      res.json({ code: 200, data: { isBlockedBy: rows.length > 0 } })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  // ===== 管理员查看所有举报列表 =====
  app.get('/api/admin/user-blocks', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const { status = 'active', page = 1, pageSize = 20 } = req.query
      const offset = (page - 1) * pageSize
      const list = await query(
        `SELECT ub.*, 
                b1.username as blocker_name, b1.nickname as blocker_nickname, b1.avatar as blocker_avatar,
                b2.username as blocked_name, b2.nickname as blocked_nickname, b2.avatar as blocked_avatar
         FROM user_blocks ub 
         JOIN users b1 ON ub.blocker_id=b1.id 
         JOIN users b2 ON ub.blocked_id=b2.id
         WHERE ub.status=?
         ORDER BY ub.create_time DESC LIMIT ? OFFSET ?`,
        [status, parseInt(pageSize), offset])
      const cnt = await query('SELECT COUNT(*) as total FROM user_blocks WHERE status=?', [status])
      res.json({ code: 200, data: { list, total: cnt[0].total } })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  // ===== 管理员审核举报 =====
  app.post('/api/admin/user-blocks/:id/review', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const { notes } = req.body || {}
      const blockId = parseInt(req.params.id)
      await query('UPDATE user_blocks SET reviewed=1, review_notes=? WHERE id=?', [notes || '', blockId])
      res.json({ code: 200, message: '审核完成' })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })
}

module.exports = { userBlockRoutes, getBlockedUserIds, getBlockerUserIds }
