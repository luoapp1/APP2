/**
 * 数据库配置文件 (MySQL)
 */
module.exports = {
  mysql: {
    host: '127.0.0.1',
    port: 3306,
    user: 'root',
    password: '',
    database: 'art_design_pro'
  },
  encryptionKey: 'art-design-pro-enc-key-2026!@#SECURE'
}
