/**
 * 数据库配置文件
 * 在单个文件中切换数据库类型，修改 dbType 和对应的连接信息即可
 *
 * 支持的类型: sqlite | mysql | postgresql
 */
module.exports = {
  // 数据库类型
  dbType: 'sqlite',

  // SQLite 配置 (仅 dbType === 'sqlite' 时生效)
  sqlite: {
    // 数据库文件路径，相对于 server 目录或绝对路径
    filePath: './data.db'
  },

  // MySQL 配置 (仅 dbType === 'mysql' 时生效)
  mysql: {
    host: '127.0.0.1',
    port: 3306,
    user: 'artpro',
    password: 'artpro2026',
    database: 'art_design_pro'
  },

  // PostgreSQL 配置 (仅 dbType === 'postgresql' 时生效)
  postgresql: {
    host: '127.0.0.1',
    port: 5432,
    user: 'postgres',
    password: 'postgres',
    database: 'art_design_pro'
  }
}
