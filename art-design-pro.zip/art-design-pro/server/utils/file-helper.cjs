const fs = require('fs')
const path = require('path')
const { query } = require('../database.cjs')
const { decryptStorageConfig } = require('./storage-decrypt.cjs')

const UPLOADS_DIR = path.join(__dirname, '..', 'uploads')

async function getStorage() {
  try {
    const configs = await query(
      'SELECT * FROM storage_configs WHERE status=? ORDER BY is_default DESC, id ASC LIMIT 1',
      ['1']
    )
    if (!configs.length) return null
    return decryptStorageConfig(configs[0])
  } catch { return null }
}

async function deleteSingleFromCloud(storage, key) {
  try {
    if (storage.type === 'oss') {
      const OSS = require('ali-oss')
      const client = new OSS({
        region: storage.region,
        accessKeyId: storage.access_key,
        accessKeySecret: storage.secret_key,
        bucket: storage.bucket,
        endpoint: storage.endpoint
      })
      await client.delete(key)
    } else if (storage.type === 'cos') {
      const COS = require('cos-nodejs-sdk-v5')
      const cos = new COS({ SecretId: storage.access_key, SecretKey: storage.secret_key })
      await new Promise((resolve, reject) => {
        cos.deleteObject({ Bucket: storage.bucket, Region: storage.region, Key: key }, (err) => {
          if (err) return reject(err)
          resolve()
        })
      })
    } else if (storage.type === 'minio') {
      const Minio = require('minio')
      const minioClient = new Minio.Client({
        endPoint: storage.endpoint.replace(/^https?:\/\//, '').split(':')[0],
        port: parseInt(storage.endpoint.split(':').pop()) || 9000,
        useSSL: storage.endpoint.startsWith('https'),
        accessKey: storage.access_key,
        secretKey: storage.secret_key
      })
      await minioClient.removeObject(storage.bucket, key)
    } else {
      const { S3Client, DeleteObjectCommand } = require('@aws-sdk/client-s3')
      const s3 = new S3Client({
        region: storage.region,
        endpoint: storage.endpoint,
        credentials: { accessKeyId: storage.access_key, secretAccessKey: storage.secret_key },
        forcePathStyle: true
      })
      await s3.send(new DeleteObjectCommand({ Bucket: storage.bucket, Key: key }))
    }
  } catch (e) {
    console.error(`[file-helper] deleteFromCloud (${storage.type}) failed:`, e.message)
  }
}

async function deleteFileFromStorage(filePath) {
  if (!filePath) return
  try {
    if (filePath.startsWith('http')) {
      const storage = await getStorage()
      if (!storage) return
      const urlObj = new URL(filePath)
      const key = decodeURIComponent(urlObj.pathname.replace(/^\//, ''))
      await deleteSingleFromCloud(storage, key)
    } else {
      const localPath = path.join(UPLOADS_DIR, path.basename(filePath))
      if (fs.existsSync(localPath)) fs.unlinkSync(localPath)
    }
  } catch (e) {
    console.error('[file-helper] deleteFileFromStorage failed:', e.message)
  }
}

async function updateUserUsedBytes(userId) {
  if (!userId) return
  try {
    const rows = await query(
      'SELECT COALESCE(SUM(file_size), 0) as total FROM file_repository WHERE user_id=?',
      [userId]
    )
    await query('UPDATE users SET used_bytes=? WHERE id=?', [rows[0]?.total || 0, userId])
  } catch {}
}

async function deleteFileRecordsByRef(refId, refType) {
  if (!refId || !refType) return 0
  try {
    const records = await query(
      'SELECT id, file_path, user_id FROM file_repository WHERE ref_id=? AND ref_type=?',
      [refId, refType]
    )
    let totalDeleted = 0
    const affectedUsers = new Set()
    for (const rec of records) {
      await deleteFileFromStorage(rec.file_path)
      affectedUsers.add(rec.user_id)
    }
    await query('DELETE FROM file_repository WHERE ref_id=? AND ref_type=?', [refId, refType])
    for (const uid of affectedUsers) {
      await updateUserUsedBytes(uid)
    }
    totalDeleted = records.length
    console.log(`[file-helper] Deleted ${totalDeleted} file records for ref ${refType}#${refId}`)
    return totalDeleted
  } catch (e) {
    console.error('[file-helper] deleteFileRecordsByRef failed:', e.message)
    return 0
  }
}

async function deleteFileRecordById(recordId) {
  if (!recordId) return false
  try {
    const rows = await query('SELECT id, file_path, user_id FROM file_repository WHERE id=?', [recordId])
    if (!rows.length) return false
    const rec = rows[0]
    await deleteFileFromStorage(rec.file_path)
    await query('DELETE FROM file_repository WHERE id=?', [recordId])
    if (rec.user_id) await updateUserUsedBytes(rec.user_id)
    return true
  } catch (e) {
    console.error('[file-helper] deleteFileRecordById failed:', e.message)
    return false
  }
}

async function deleteFileRecordsByIds(ids) {
  const filtered = (ids || []).filter(Number).map(Number)
  if (!filtered.length) return 0
  let count = 0
  for (const id of filtered) {
    if (await deleteFileRecordById(id)) count++
  }
  return count
}

async function deleteFileIdsForRef(refId, refType, keepFileIds) {
  if (!refId || !refType) return 0
  try {
    const keepSet = new Set((keepFileIds || []).map(Number).filter(Boolean))
    let sql = 'SELECT id, file_path, user_id FROM file_repository WHERE ref_id=? AND ref_type=?'
    const params = [refId, refType]
    if (keepSet.size > 0) {
      sql += ` AND id NOT IN (${Array.from(keepSet).map(() => '?').join(',')})`
      params.push(...Array.from(keepSet))
    }
    const records = await query(sql, params)
    if (!records.length) return 0
    const affectedUsers = new Set()
    for (const rec of records) {
      await deleteFileFromStorage(rec.file_path)
      affectedUsers.add(rec.user_id)
    }
    if (keepSet.size > 0) {
      await query(
        `DELETE FROM file_repository WHERE ref_id=? AND ref_type=? AND id NOT IN (${Array.from(keepSet).map(() => '?').join(',')})`,
        [refId, refType, ...Array.from(keepSet)]
      )
    } else {
      await query('DELETE FROM file_repository WHERE ref_id=? AND ref_type=?', [refId, refType])
    }
    for (const uid of affectedUsers) {
      await updateUserUsedBytes(uid)
    }
    console.log(`[file-helper] Deleted ${records.length} file records for ref ${refType}#${refId} (kept ${keepSet.size})`)
    return records.length
  } catch (e) {
    console.error('[file-helper] deleteFileIdsForRef failed:', e.message)
    return 0
  }
}

async function recordFileUpload({
  userId, userName, fileName, fileUrl, fileSize, fileType, mimeType,
  category, refId, refType, description
}) {
  const result = await query(
    `INSERT INTO file_repository (user_id, user_name, file_name, file_path, file_size, file_type, mime_type, category, ref_id, ref_type, description)
     VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
    [
      userId || 0,
      userName || '',
      fileName || '',
      fileUrl || '',
      fileSize || 0,
      (fileType || '').replace(/^\./, ''),
      mimeType || '',
      category || 'general',
      refId || 0,
      refType || '',
      description || ''
    ]
  )
  if (userId) await updateUserUsedBytes(userId)
  return result.insertId
}

function buildFileDesc({ refType, refId, refName, category }) {
  const typeNames = {
    avatar: '用户头像',
    background: '用户背景',
    app_icon: '应用图标',
    app_screenshot: '应用截图',
    app_file: '应用文件',
    app_content: '应用内容图片',
    post_image: '帖子图片',
    post_content: '帖子内容图片',
    post_attachment: '帖子附件',
    comment_image: '评论图片',
    mall_product: '商城商品图片',
    mall_detail: '商城详情图片',
    topic_icon: '话题图标',
    section_icon: '板块图标',
    avatar_frame: '头像框图片',
    checkin: '签到图片',
    coupon: '优惠券图片',
    title: '称号图片',
    membership: '会员图片',
    game: '游戏图片',
    chat: '聊天图片',
    chat_image: '聊天图片',
    chat_room_avatar: '聊天室头像',
    plugin: '插件文件',
    general: '通用文件',
    apk: 'APK安装包',
    apk_icon: 'APK图标'
  }
  const typeName = typeNames[category] || category || '文件'
  let desc = typeName
  if (refType && refId) {
    const refTypeNames = {
      user: '用户',
      app: '应用',
      submission: '投稿',
      post: '帖子',
      comment: '评论',
      mall_product: '商城商品',
      mall_order: '商城订单',
      topic: '话题',
      section: '板块'
    }
    const refTypeName = refTypeNames[refType] || refType
    desc = `${refTypeName}${refName ? '《' + refName + '》' : '#' + refId}的${typeName}`
  }
  return desc
}

module.exports = {
  getStorage,
  deleteSingleFromCloud,
  deleteFileFromStorage,
  deleteFileRecordsByRef,
  deleteFileRecordById,
  deleteFileRecordsByIds,
  deleteFileIdsForRef,
  recordFileUpload,
  updateUserUsedBytes,
  buildFileDesc,
  UPLOADS_DIR
}
