const { decrypt, maskKey } = require('./crypto.cjs')

const SENSITIVE_FIELDS = ['access_key', 'secret_key']

function decryptStorageConfig(cfg) {
  if (!cfg) return cfg
  const result = JSON.parse(JSON.stringify(cfg))
  for (const field of SENSITIVE_FIELDS) {
    if (result[field] !== undefined && result[field] !== null) {
      try {
        result[field] = decrypt(result[field])
      } catch (e) {
        console.error(`[StorageDecrypt] 字段 ${field} 解密失败 (config id=${cfg.id}):`, e.message)
        throw new Error(`存储配置密钥解密失败，可能密钥已更换或数据损坏`)
      }
    }
  }
  return result
}

function decryptStorageConfigs(rows) {
  return rows.map(decryptStorageConfig)
}

function sanitizeConfigForLog(cfg) {
  if (!cfg) return cfg
  const sanitized = JSON.parse(JSON.stringify(cfg))
  for (const field of SENSITIVE_FIELDS) {
    if (sanitized[field]) {
      sanitized[field] = maskKey(sanitized[field])
    }
  }
  return sanitized
}

function sanitizeConfigForResponse(cfg, isAdmin) {
  if (!cfg) return cfg
  if (isAdmin) return decryptStorageConfig(cfg)
  const sanitized = JSON.parse(JSON.stringify(cfg))
  for (const field of SENSITIVE_FIELDS) {
    sanitized[field] = undefined
  }
  return sanitized
}

module.exports = { decryptStorageConfig, decryptStorageConfigs, sanitizeConfigForLog, sanitizeConfigForResponse }
