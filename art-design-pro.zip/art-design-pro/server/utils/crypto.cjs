const crypto = require('crypto')
const config = require('../config.cjs')

const CIPHER_ALGO = 'aes-256-cbc'
const FIXED_IV_HEX = '4a7b2e9f1c8d3a5b6e0f2d7c9a1b3e5f'
const FIXED_IV = Buffer.from(FIXED_IV_HEX, 'hex')
const MIN_KEY_LENGTH = 32

let ENCRYPTION_KEY = null

function getEncryptionKey() {
  if (ENCRYPTION_KEY) return ENCRYPTION_KEY

  const envKey = process.env.STORAGE_ENCRYPTION_KEY || ''
  const cfgKey = config.encryptionKey || ''

  const key = envKey || cfgKey
  if (!key) {
    const msg = '未配置 STORAGE_ENCRYPTION_KEY 环境变量，拒绝启动。请在环境变量中设置 STORAGE_ENCRYPTION_KEY (至少32位随机字符串)'
    console.error('[Crypto] 致命错误: ' + msg)
    throw new Error(msg)
  }
  if (key.length < MIN_KEY_LENGTH) {
    console.warn('[Crypto] 警告: encryptionKey 长度仅 ' + key.length + ' 位，建议使用至少 ' + MIN_KEY_LENGTH + ' 位随机字符串')
  }

  const rawKey = Buffer.from(key, 'utf8')
  ENCRYPTION_KEY = rawKey.length >= 32 ? rawKey.slice(0, 32) : Buffer.concat([rawKey, Buffer.alloc(32 - rawKey.length, 0x00)])
  return ENCRYPTION_KEY
}

function encrypt(plainText) {
  if (plainText === null || plainText === undefined) return plainText
  if (typeof plainText !== 'string') {
    console.warn('[Crypto] encrypt 接收到非字符串类型:', typeof plainText)
    return plainText
  }
  if (plainText === '') return plainText

  try {
    const key = getEncryptionKey()
    const cipher = crypto.createCipheriv(CIPHER_ALGO, key, FIXED_IV)
    let encrypted = cipher.update(plainText, 'utf8', 'hex')
    encrypted += cipher.final('hex')
    return encrypted
  } catch (e) {
    console.error('[Crypto] 加密失败:', e.message)
    throw new Error('数据加密失败')
  }
}

function decrypt(cipherText) {
  if (cipherText === null || cipherText === undefined) return cipherText
  if (typeof cipherText !== 'string') {
    console.warn('[Crypto] decrypt 接收到非字符串类型:', typeof cipherText)
    return cipherText
  }
  if (cipherText === '') return cipherText

  if (!/^[0-9a-fA-F]+$/.test(cipherText)) {
    console.warn('[Crypto] decrypt 接收到非 hex 格式密文，可能是未加密的旧数据')
    return cipherText
  }

  try {
    const key = getEncryptionKey()
    const decipher = crypto.createDecipheriv(CIPHER_ALGO, key, FIXED_IV)
    let decrypted = decipher.update(cipherText, 'hex', 'utf8')
    decrypted += decipher.final('utf8')
    return decrypted
  } catch (e) {
    console.error('[Crypto] 解密失败，密文可能损坏或密钥不匹配:', e.message)
    console.error('[Crypto] 密文前 20 位:', cipherText.substring(0, 20) + '...')
    throw new Error('数据解密失败')
  }
}

function maskKey(key) {
  if (!key || key.length <= 6) return '***'
  return key.substring(0, 3) + '***' + key.substring(key.length - 3)
}

function encryptStorageConfig(cfg) {
  if (!cfg) return cfg
  const result = JSON.parse(JSON.stringify(cfg))
  const encryptFields = ['access_key', 'secret_key']
  for (const field of encryptFields) {
    if (result[field]) {
      try {
        result[field] = encrypt(result[field])
      } catch (e) {
        console.error(`[Crypto] 加密字段 ${field} 失败:`, e.message)
        throw e
      }
    }
  }
  return result
}

module.exports = { encrypt, decrypt, maskKey, encryptStorageConfig }
