// DB Interceptor — 数据库查询拦截器
// 让插件可以在 SQL 执行前注入额外条件

class DbInterceptor {
  constructor() {
    this._beforeQuery = []
    this._beforeCommit = []
    this._afterRollback = []
    this._pendingChanges = { inserts: {}, updates: {}, deletes: {} }
  }

  /**
   * 注册查询前拦截器
   * handler({ table, sql, params, context }) → { sql?, params? } | void
   */
  onBeforeQuery(handler) {
    this._beforeQuery.push(handler)
  }

  /**
   * 注册事务提交前拦截器
   * handler({ changes }) → void
   */
  onBeforeCommit(handler) {
    this._beforeCommit.push(handler)
  }

  /**
   * 注册事务回滚后拦截器
   * handler({ error }) → void
   */
  onAfterRollback(handler) {
    this._afterRollback.push(handler)
  }

  /**
   * 对 SQL 应用所有拦截器，返回修改后的 SQL 和 params
   */
  interceptQuery(table, sql, params, context) {
    let modifiedSql = sql
    let modifiedParams = params
    for (const handler of this._beforeQuery) {
      const result = handler({ table, sql: modifiedSql, params: modifiedParams, context })
      if (result) {
        if (result.sql !== undefined) modifiedSql = result.sql
        if (result.params !== undefined) modifiedParams = result.params
      }
    }
    return { sql: modifiedSql, params: modifiedParams }
  }

  /**
   * 记录变更（由业务代码在 SQL 执行后调用）
   */
  trackChange(type, table, record) {
    if (!this._pendingChanges[type]) return
    if (!this._pendingChanges[type][table]) {
      this._pendingChanges[type][table] = []
    }
    this._pendingChanges[type][table].push(record)
  }

  /**
   * 触发事务提交前钩子
   */
  notifyBeforeCommit() {
    const changes = this._pendingChanges
    for (const handler of this._beforeCommit) {
      try {
        handler({ changes })
      } catch (e) {
        console.error('[DbInterceptor] beforeCommit 处理器出错:', e.message)
      }
    }
    this._clearChanges()
  }

  /**
   * 触发事务回滚后钩子
   */
  notifyAfterRollback(error) {
    for (const handler of this._afterRollback) {
      try {
        handler({ error })
      } catch (e) {
        console.error('[DbInterceptor] afterRollback 处理器出错:', e.message)
      }
    }
    this._clearChanges()
  }

  _clearChanges() {
    this._pendingChanges = { inserts: {}, updates: {}, deletes: {} }
  }
}

const dbInterceptor = new DbInterceptor()

module.exports = { DbInterceptor, dbInterceptor }
