// Scheduler — 插件任务调度器（Cron / 队列 / 延迟）

const { eventBus } = require('./event-bus.cjs')

class Scheduler {
  constructor() {
    this._cronJobs = []
    this._queues = new Map()
    this._delayedJobs = []
    this._cronInstance = null
    this._running = false
  }

  // ===== Cron 定时任务 =====

  registerCron({ name, cron, timezone, handler }) {
    if (typeof handler !== 'function') {
      throw new Error(`Cron 任务 ${name} 缺少 handler 函数`)
    }
    this._cronJobs.push({ name, cron, timezone: timezone || 'Asia/Shanghai', handler })
    if (this._running) this._startCronJob(this._cronJobs[this._cronJobs.length - 1])
  }

  _startCronJob(job) {
    try {
      const cron = require('node-cron')
      const task = cron.schedule(job.cron, () => {
        eventBus.emit('system:cronTick', { jobName: job.name, scheduledTime: new Date().toISOString() })
        try {
          job.handler()
        } catch (e) {
          console.error(`[Scheduler] Cron 任务 ${job.name} 出错:`, e.message)
        }
      }, { timezone: job.timezone })
      job._task = task
    } catch (e) {
      console.warn(`[Scheduler] node-cron 不可用，手动模拟 Cron "${job.name}"`, e.message)
      this._fallbackCron(job)
    }
  }

  _fallbackCron(job) {
    const interval = 60 * 1000 // 默认每分钟检查一次
    const timer = setInterval(() => {
      try {
        job.handler()
      } catch (e) {
        console.error(`[Scheduler] 模拟 Cron ${job.name} 出错:`, e.message)
      }
    }, interval)
    job._timer = timer
  }

  // ===== 队列任务 =====

  registerQueue(name, { concurrency = 1, handler } = {}) {
    if (typeof handler !== 'function') {
      throw new Error(`队列 ${name} 缺少 handler 函数`)
    }
    this._queues.set(name, {
      handler,
      concurrency,
      running: 0,
      pending: []
    })
  }

  enqueue(name, data) {
    const queue = this._queues.get(name)
    if (!queue) throw new Error(`队列 ${name} 未注册`)
    return new Promise((resolve, reject) => {
      queue.pending.push({ data, resolve, reject })
      this._processQueue(name)
    })
  }

  _processQueue(name) {
    const queue = this._queues.get(name)
    if (!queue) return
    while (queue.running < queue.concurrency && queue.pending.length > 0) {
      const job = queue.pending.shift()
      queue.running++
      Promise.resolve()
        .then(() => queue.handler(job.data))
        .then(result => job.resolve(result))
        .catch(err => job.reject(err))
        .finally(() => {
          queue.running--
          this._processQueue(name)
        })
    }
  }

  // ===== 延迟任务 =====

  schedule({ name, delay, handler }) {
    if (typeof handler !== 'function') {
      throw new Error(`延迟任务 ${name} 缺少 handler 函数`)
    }
    const timer = setTimeout(() => {
      try {
        handler()
      } catch (e) {
        console.error(`[Scheduler] 延迟任务 ${name} 出错:`, e.message)
      }
      this._delayedJobs = this._delayedJobs.filter(j => j._timer !== timer)
    }, delay)
    this._delayedJobs.push({ name, handler, _timer: timer })
    return { name, cancel: () => clearTimeout(timer) }
  }

  // ===== 生命周期 =====

  start() {
    this._running = true
    for (const job of this._cronJobs) {
      if (!job._task && !job._timer) this._startCronJob(job)
    }
  }

  stop() {
    this._running = false
    for (const job of this._cronJobs) {
      if (job._task) { job._task.stop(); delete job._task }
      if (job._timer) { clearInterval(job._timer); delete job._timer }
    }
    for (const job of this._delayedJobs) {
      if (job._timer) clearTimeout(job._timer)
    }
    this._delayedJobs = []
  }

  getStatus() {
    return {
      cronJobs: this._cronJobs.length,
      queues: Array.from(this._queues.keys()),
      delayedJobs: this._delayedJobs.length,
      running: this._running
    }
  }
}

const scheduler = new Scheduler()

module.exports = { Scheduler, scheduler }
