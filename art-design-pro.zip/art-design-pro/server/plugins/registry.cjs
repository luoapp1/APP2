// Registries — 菜单/UI插槽/权限/i18n/邮件/通知 统一注册表

class MenuRegistry {
  constructor() {
    this._menus = { adminSidebar: [], userDropdown: [] }
    this._batchActions = new Map()
    this._detailTabs = new Map()
    this._dashboardWidgets = []
  }

  register(menus) {
    if (menus.adminSidebar) this._menus.adminSidebar.push(...menus.adminSidebar)
    if (menus.userDropdown) this._menus.userDropdown.push(...menus.userDropdown)
  }

  registerBatchAction(scope, action) {
    if (!this._batchActions.has(scope)) this._batchActions.set(scope, [])
    this._batchActions.get(scope).push(action)
  }

  registerDetailTab(scope, tab) {
    if (!this._detailTabs.has(scope)) this._detailTabs.set(scope, [])
    this._detailTabs.get(scope).push(tab)
  }

  registerDashboardWidget(widget) {
    this._dashboardWidgets.push(widget)
  }

  getMenus() { return this._menus }
  getBatchActions(scope) { return this._batchActions.get(scope) || [] }
  getDetailTabs(scope) { return this._detailTabs.get(scope) || [] }
  getDashboardWidgets() { return this._dashboardWidgets }

  update(name, changes) {
    for (const group of Object.values(this._menus)) {
      const idx = group.findIndex(m => m.label === name || m.path === name)
      if (idx !== -1) Object.assign(group[idx], changes)
    }
  }

  remove(name) {
    for (const group of Object.values(this._menus)) {
      const idx = group.findIndex(m => m.label === name || m.path === name)
      if (idx !== -1) group.splice(idx, 1)
    }
  }
}

class SlotRegistry {
  constructor() {
    this._slots = new Map()
    this._globalStyles = []
  }

  register(name, opts) {
    this._slots.set(name, opts)
  }

  get(name) {
    return this._slots.get(name)
  }

  getAll() {
    return Array.from(this._slots.entries()).map(([name, opts]) => ({ name, ...opts }))
  }

  injectStyle(css) {
    this._globalStyles.push(css)
  }

  getStyles() {
    return this._globalStyles
  }
}

class PermissionRegistry {
  constructor() {
    this._nodes = []
    this._roleExtensions = new Map()
  }

  register(nodes) {
    this._nodes.push(...nodes)
  }

  getAllNodes() {
    return this._nodes
  }

  /**
   * 返回 Express 中间件，校验当前用户是否拥有指定权限节点
   */
  guard(node) {
    return (req, res, next) => {
      const user = req.user
      if (!user) return res.status(401).json({ code: 401, msg: '未登录' })
      if (user.roles && user.roles.includes('admin')) return next()
      const permNode = this._nodes.find(n => n.node === node)
      if (!permNode) return next() // 未注册的权限节点放行
      const allowedRoles = permNode.defaultRoles || []
      if (user.roles && user.roles.some(r => allowedRoles.includes(r))) return next()
      return res.status(403).json({ code: 403, msg: '无权限执行此操作' })
    }
  }

  hasPermission(user, node) {
    if (!user) return false
    if (user.roles && user.roles.includes('admin')) return true
    const permNode = this._nodes.find(n => n.node === node)
    if (!permNode) return true
    const allowed = permNode.defaultRoles || []
    return user.roles && user.roles.some(r => allowed.includes(r))
  }

  extendRole(role, capabilities) {
    const existing = this._roleExtensions.get(role) || {}
    this._roleExtensions.set(role, { ...existing, ...capabilities })
  }

  getRoleCapabilities(role) {
    return this._roleExtensions.get(role) || {}
  }
}

class I18nRegistry {
  constructor() {
    this._bundles = new Map()
    this._defaultLocale = 'zh-CN'
  }

  register(pluginName, { dir, defaultLocale }) {
    this._bundles.set(pluginName, { dir, defaultLocale: defaultLocale || 'zh-CN', messages: {} })
  }

  loadMessages(pluginName, locale, messages) {
    const bundle = this._bundles.get(pluginName)
    if (bundle) bundle.messages[locale] = messages
  }

  t(pluginName, key, params) {
    const bundle = this._bundles.get(pluginName)
    if (!bundle) return key
    const locale = bundle.defaultLocale
    const msg = (bundle.messages[locale] && bundle.messages[locale][key]) || key
    if (params) {
      return msg.replace(/\{(\w+)\}/g, (_, k) => params[k] != null ? params[k] : `{${k}}`)
    }
    return msg
  }

  getAllBundles() {
    return Array.from(this._bundles.entries()).map(([name, b]) => ({ name, ...b }))
  }
}

class MailTemplateRegistry {
  constructor() {
    this._templates = new Map()
  }

  registerTemplate(name, opts) {
    this._templates.set(name, opts)
  }

  getTemplate(name) {
    return this._templates.get(name)
  }

  async send(template, opts) {
    const tpl = this._templates.get(template)
    if (!tpl) throw new Error(`邮件模板 "${template}" 未注册`)
    // 实际发送委托给系统的邮件路由处理
    const subject = tpl.subject?.[opts.locale || 'zh-CN'] || template
    return { sent: true, template, subject, to: opts.to }
  }
}

class NotifyChannelRegistry {
  constructor() {
    this._channels = new Map()
  }

  registerChannel(channel) {
    this._channels.set(channel.name, channel)
  }

  async send(channel, opts) {
    const ch = this._channels.get(channel)
    if (!ch) throw new Error(`通知通道 "${channel}" 未注册`)
    return ch.send(opts)
  }

  getChannel(name) {
    return this._channels.get(name)
  }

  getAllChannels() {
    return Array.from(this._channels.values())
  }
}

const menuRegistry = new MenuRegistry()
const slotRegistry = new SlotRegistry()
const permRegistry = new PermissionRegistry()
const i18nRegistry = new I18nRegistry()
const mailRegistry = new MailTemplateRegistry()
const notifyRegistry = new NotifyChannelRegistry()

module.exports = {
  MenuRegistry, SlotRegistry, PermissionRegistry,
  I18nRegistry, MailTemplateRegistry, NotifyChannelRegistry,
  menuRegistry, slotRegistry, permRegistry,
  i18nRegistry, mailRegistry, notifyRegistry
}
