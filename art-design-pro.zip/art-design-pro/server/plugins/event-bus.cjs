// EventBus — 插件事件系统
// 支持 on/off/emit/once 和中断（PluginError）功能

class EventBus {
  constructor() {
    this._handlers = new Map()
  }

  on(event, handler) {
    if (!this._handlers.has(event)) {
      this._handlers.set(event, [])
    }
    this._handlers.get(event).push(handler)
  }

  off(event, handler) {
    const handlers = this._handlers.get(event)
    if (!handlers) return
    const idx = handlers.indexOf(handler)
    if (idx !== -1) handlers.splice(idx, 1)
  }

  once(event, handler) {
    const wrapper = (...args) => {
      this.off(event, wrapper)
      handler(...args)
    }
    this.on(event, wrapper)
  }

  emit(event, payload) {
    const handlers = this._handlers.get(event)
    if (!handlers || handlers.length === 0) return
    for (const handler of handlers) {
      try {
        handler(payload)
      } catch (e) {
        if (e.name === 'PluginError') throw e
        console.error(`[EventBus] 事件 ${event} 处理器出错:`, e.message)
      }
    }
  }

  /**
   * 触发可中断事件 — 任意监听器抛出 PluginError 则中止并向上抛出
   */
  emitInterruptible(event, payload) {
    const handlers = this._handlers.get(event)
    if (!handlers || handlers.length === 0) return
    for (const handler of handlers) {
      handler(payload)
    }
  }

  clear() {
    this._handlers.clear()
  }

  eventNames() {
    return Array.from(this._handlers.keys())
  }

  listenerCount(event) {
    return (this._handlers.get(event) || []).length
  }
}

class PluginError extends Error {
  constructor(message, statusCode = 400) {
    super(message)
    this.name = 'PluginError'
    this.statusCode = statusCode
  }
}

const eventBus = new EventBus()

module.exports = { EventBus, PluginError, eventBus }
