// ServiceRegistry — 服务注册/替换/装饰

class ServiceRegistry {
  constructor() {
    this._services = new Map()      // name → impl
    this._decorators = new Map()    // name → { before, after }
    this._formFields = new Map()
    this._validators = new Map()
    this._paymentGateways = new Map()
    this._authMethods = new Map()
    this._captchaProviders = new Map()
    this._sharedData = new Map()
  }

  // ===== 基础服务 =====

  register(name, impl) {
    this._services.set(name, impl)
  }

  override(name, impl) {
    if (!this._services.has(name)) {
      console.warn(`[ServiceRegistry] 服务 "${name}" 不存在，将直接注册`)
    }
    this._services.set(name, impl)
  }

  /**
   * 装饰已有服务 — 在调用前后插入逻辑
   * decorator: { before?, after? }
   */
  decorate(name, decorator) {
    if (!this._services.has(name)) {
      throw new Error(`服务 "${name}" 不存在，无法装饰`)
    }
    this._decorators.set(name, {
      ...(this._decorators.get(name) || {}),
      ...decorator
    })
  }

  async callOriginal(name, ...args) {
    const impl = this._services.get(name)
    if (!impl) throw new Error(`服务 "${name}" 未注册`)
    return impl(...args)
  }

  /**
   * 调用服务（经过装饰器链）
   */
  async call(name, ...args) {
    const impl = this._services.get(name)
    if (!impl) throw new Error(`服务 "${name}" 未注册`)
    const decorator = this._decorators.get(name)

    if (decorator?.before) {
      const modifiedArgs = await decorator.before(...args)
      if (modifiedArgs !== undefined) args = Array.isArray(modifiedArgs) ? modifiedArgs : [modifiedArgs]
    }

    let result = await impl(...args)

    if (decorator?.after) {
      result = await decorator.after(result, ...args)
    }

    return result
  }

  // ===== 表单字段 =====

  registerFormField(name, { component, props, defaultValue }) {
    this._formFields.set(name, { name, component, props: props || {}, defaultValue })
  }

  getFormField(name) {
    return this._formFields.get(name)
  }

  getAllFormFields() {
    return Array.from(this._formFields.values())
  }

  // ===== 验证器 =====

  registerValidator(name, { validate }) {
    this._validators.set(name, { validate })
  }

  async validate(name, ...args) {
    const validator = this._validators.get(name)
    if (!validator) return { valid: true }
    return validator.validate(...args)
  }

  // ===== 支付网关 =====

  registerPaymentGateway(gw) {
    this._paymentGateways.set(gw.name, gw)
  }

  getPaymentGateway(name) {
    return this._paymentGateways.get(name)
  }

  getAllPaymentGateways() {
    return Array.from(this._paymentGateways.values())
  }

  // ===== 认证方式 =====

  registerAuthMethod(method) {
    this._authMethods.set(method.name, method)
  }

  getAuthMethod(name) {
    return this._authMethods.get(name)
  }

  // ===== 验证码 =====

  registerCaptchaProvider(provider) {
    this._captchaProviders.set(provider.name, provider)
  }

  getCaptchaProvider(name) {
    return this._captchaProviders.get(name)
  }

  // ===== 插件间 API 调用 =====

  /**
   * 调用其他插件暴露的 API
   */
  callPlugin(pluginName, method, ...args) {
    const exposed = this._services.get(`_plugin:${pluginName}`)
    if (!exposed) throw new Error(`插件 "${pluginName}" 未暴露 API`)
    if (typeof exposed[method] !== 'function') {
      throw new Error(`插件 "${pluginName}" 未暴露方法 "${method}"`)
    }
    return exposed[method](...args)
  }

  // ===== 共享数据 =====

  setShared(key, value) {
    this._sharedData.set(key, value)
  }

  getShared(key) {
    return this._sharedData.get(key)
  }

  delShared(key) {
    this._sharedData.delete(key)
  }
}

const serviceRegistry = new ServiceRegistry()

module.exports = { ServiceRegistry, serviceRegistry }
