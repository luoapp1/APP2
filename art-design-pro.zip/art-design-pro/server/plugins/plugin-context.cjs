// PluginContext — 构建完整的插件上下文对象

const path = require('path')
const fs = require('fs')
const { eventBus } = require('./event-bus.cjs')
const { scheduler } = require('./scheduler.cjs')
const { serviceRegistry } = require('./service-registry.cjs')
const { dbInterceptor } = require('./db-interceptor.cjs')
const {
  menuRegistry, slotRegistry, permRegistry,
  i18nRegistry, mailRegistry, notifyRegistry
} = require('./registry.cjs')

/**
 * 构建完整的 PluginContext 对象，传递给插件的 server.js
 */
function buildPluginContext(db, app, manifest, pluginDir, pluginId) {
  const pluginName = manifest.name

  const logger = {
    info: (...args) => console.log(`[plugin:${pluginName}]`, ...args),
    warn: (...args) => console.warn(`[plugin:${pluginName}]`, ...args),
    error: (...args) => console.error(`[plugin:${pluginName}]`, ...args),
    debug: (...args) => process.env.NODE_ENV === 'development'
      ? console.debug(`[plugin:${pluginName}]`, ...args)
      : undefined
  }

  const cache = {
    _store: new Map(),
    get(key) { return this._store.get(key) },
    set(key, value, ttl) {
      this._store.set(key, value)
      if (ttl) {
        setTimeout(() => this._store.delete(key), ttl)
      }
    },
    del(key) { this._store.delete(key) },
    clear() { this._store.clear() }
  }

  // 加载 i18n 文件
  if (manifest.extends?.i18n) {
    const i18nDir = path.join(pluginDir, manifest.extends.i18n.dir || 'i18n')
    const defaultLocale = manifest.extends.i18n.defaultLocale || 'zh-CN'
    i18nRegistry.register(pluginName, { dir: i18nDir, defaultLocale })
    if (fs.existsSync(i18nDir)) {
      const files = fs.readdirSync(i18nDir)
      for (const file of files) {
        if (file.endsWith('.json')) {
          const locale = file.replace('.json', '')
          try {
            const messages = JSON.parse(fs.readFileSync(path.join(i18nDir, file), 'utf-8'))
            i18nRegistry.loadMessages(pluginName, locale, messages)
          } catch (e) {
            logger.warn(`i18n 文件加载失败: ${file}`, e.message)
          }
        }
      }
    }
  }

  // 注册前端 slots
  if (manifest.frontend?.slots) {
    for (const [slotName, slotOpts] of Object.entries(manifest.frontend.slots)) {
      slotRegistry.register(slotName, {
        ...slotOpts,
        pluginName
      })
    }
  }

  return {
    app,
    db,
    router: require('express').Router(),

    events: {
      on: (event, handler) => eventBus.on(event, handler),
      off: (event, handler) => eventBus.off(event, handler),
      emit: (event, payload) => eventBus.emit(event, payload),
      once: (event, handler) => eventBus.once(event, handler)
    },

    scheduler: {
      registerCron: (opts) => scheduler.registerCron(opts),
      registerQueue: (name, opts) => scheduler.registerQueue(name, opts),
      enqueue: (name, data) => scheduler.enqueue(name, data),
      schedule: (opts) => scheduler.schedule(opts)
    },

    menus: {
      register: (menus) => menuRegistry.register(menus),
      registerBatchAction: (scope, action) => menuRegistry.registerBatchAction(scope, action),
      registerDetailTab: (scope, tab) => menuRegistry.registerDetailTab(scope, tab),
      registerDashboardWidget: (widget) => menuRegistry.registerDashboardWidget(widget),
      update: (name, changes) => menuRegistry.update(name, changes),
      remove: (name) => menuRegistry.remove(name)
    },

    slots: {
      injectStyle: (css) => slotRegistry.injectStyle(css),
      render: (name, data) => ({ name, data })
    },

    perms: {
      register: (nodes) => permRegistry.register(nodes),
      guard: (node) => permRegistry.guard(node),
      extendRole: (role, caps) => permRegistry.extendRole(role, caps),
      hasPermission: (user, node) => permRegistry.hasPermission(user, node)
    },

    services: {
      register: (name, impl) => serviceRegistry.register(name, impl),
      override: (name, impl) => serviceRegistry.override(name, impl),
      decorate: (name, decorator) => serviceRegistry.decorate(name, decorator),
      callOriginal: (name, ...args) => serviceRegistry.callOriginal(name, ...args),
      callPlugin: (name, method, ...args) => serviceRegistry.callPlugin(name, method, ...args),
      setShared: (key, value) => serviceRegistry.setShared(key, value),
      getShared: (key) => serviceRegistry.getShared(key),
      registerFormField: (name, opts) => serviceRegistry.registerFormField(name, opts),
      registerValidator: (name, opts) => serviceRegistry.registerValidator(name, opts),
      registerPaymentGateway: (gw) => serviceRegistry.registerPaymentGateway(gw),
      registerAuthMethod: (method) => serviceRegistry.registerAuthMethod(method),
      registerCaptchaProvider: (provider) => serviceRegistry.registerCaptchaProvider(provider)
    },

    i18n: {
      t: (key, params) => i18nRegistry.t(pluginName, key, params)
    },

    mail: {
      registerTemplate: (name, opts) => mailRegistry.registerTemplate(name, opts),
      send: (template, opts) => mailRegistry.send(template, opts)
    },

    notify: {
      registerChannel: (channel) => notifyRegistry.registerChannel(channel),
      send: (channel, opts) => notifyRegistry.send(channel, opts)
    },

    dbInterceptor: {
      onBeforeQuery: (handler) => dbInterceptor.onBeforeQuery(handler),
      onBeforeCommit: (handler) => dbInterceptor.onBeforeCommit(handler),
      onAfterRollback: (handler) => dbInterceptor.onAfterRollback(handler)
    },

    pluginConfig: manifest,
    pluginDir,
    pluginId,
    logger,
    cache
  }
}

module.exports = { buildPluginContext }
