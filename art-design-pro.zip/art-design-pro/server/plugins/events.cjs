// 标准系统事件定义 — 统一事件名称与 emit 辅助函数

const { eventBus } = require('./event-bus.cjs')

// ========= 用户事件 =========
const USER_EVENTS = {
  BEFORE_REGISTER: 'user:beforeRegister',
  REGISTERED: 'user:registered',
  BEFORE_LOGIN: 'user:beforeLogin',
  LOGIN: 'user:login',
  PROFILE_UPDATED: 'user:profileUpdated',
  PASSWORD_CHANGED: 'user:passwordChanged',
  CREATED: 'user:created',
  DELETED: 'user:deleted',
  DELETE_REQUESTED: 'user:deleteRequested'
}

// ========= 社区事件 =========
const POST_EVENTS = {
  BEFORE_CREATE: 'post:beforeCreate',
  CREATED: 'post:created',
  BEFORE_UPDATE: 'post:beforeUpdate',
  UPDATED: 'post:updated',
  BEFORE_DELETE: 'post:beforeDelete',
  DELETED: 'post:deleted',
  LIKE_TOGGLED: 'post:likeToggled',
  FAVORITE_TOGGLED: 'post:favoriteToggled',
  PINNED: 'post:pinned',
  GLOBAL_PINNED: 'post:globalPinned',
  ESSENCED: 'post:essenced',
  HOT_TOGGLED: 'post:hotToggled',
  LOCKED: 'post:locked',
  BADGE_CHANGED: 'post:badgeChanged',
  VIEWED: 'post:viewed',
  PUBLISHED: 'post:published',
  REJECTED: 'post:rejected',
  RESTORED: 'post:restored'
}

const COMMENT_EVENTS = {
  CREATED: 'comment:created',
  DELETED: 'comment:deleted'
}

const SECTION_EVENTS = {
  CREATED: 'section:created',
  UPDATED: 'section:updated',
  DELETED: 'section:deleted'
}

// ========= 任务事件 =========
const TASK_EVENTS = {
  PROGRESS: 'task:progress',
  COMPLETED: 'task:completed'
}

// ========= 签到事件 =========
const CHECKIN_EVENTS = {
  DONE: 'checkin:done',
  GROUP_SAVED: 'checkinGroup:saved',
  GROUP_DELETED: 'checkinGroup:deleted',
  MILESTONE_SAVED: 'checkinMilestone:saved',
  MILESTONE_DELETED: 'checkinMilestone:deleted'
}

// ========= 系统事件 =========
const SYSTEM_EVENTS = {
  BOOT: 'system:boot',
  BEFORE_SHUTDOWN: 'system:beforeShutdown',
  PLUGIN_INSTALLED: 'system:pluginInstalled',
  PLUGIN_UNINSTALLED: 'system:pluginUninstalled',
  PLUGIN_TOGGLED: 'system:pluginToggled',
  PLUGIN_CONFIG_SAVED: 'system:pluginConfigSaved',
  DB_MIGRATED: 'system:dbMigrated'
}

/**
 * 安全地 emit 事件，忽略未绑定 handler 时的 PluginError
 */
function emitSafe(event, payload) {
  try {
    eventBus.emit(event, payload)
  } catch (e) {
    if (e.name !== 'PluginError') throw e
  }
}

module.exports = {
  eventBus,
  emitSafe,
  USER_EVENTS,
  POST_EVENTS,
  COMMENT_EVENTS,
  SECTION_EVENTS,
  TASK_EVENTS,
  CHECKIN_EVENTS,
  SYSTEM_EVENTS
}
