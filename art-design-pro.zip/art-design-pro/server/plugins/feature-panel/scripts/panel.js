(function() {
  'use strict';

  var PLUGIN_NAME = 'feature-panel';
  var config = (window.__PLUGIN_CONFIG__ && window.__PLUGIN_CONFIG__[PLUGIN_NAME]) || null;

  if (!config) {
    config = {
      items: [
        { label: '签到', icon: 'checkin', color: '#FF6B35', url: '/app/checkin' },
        { label: '投稿', icon: 'submit', color: '#3B82F6', url: '/appstore/submissions' },
        { label: '收藏', icon: 'fav', color: '#EF4444', url: '/appstore/favorites' },
        { label: '排行', icon: 'rank', color: '#EC4899', url: '/appstore/category' },
        { label: '交流群', icon: 'group', color: '#22C55E', url: '/community' }
      ],
      links: [
        { label: '新贴', url: '/community' },
        { label: '发帖子', url: '/community/create' },
        { label: '热门话题', url: '/community/hot' }
      ],
      banner: { show: true, text: '新手必看教程——发帖指引之基础篇', url: '/help/guide', closable: true },
      mineBanner: { show: true, text: '全站规则，快来看看，不然就亏大了', url: '/help/rules' }
    };
  }

  var ICONS = {
    checkin: '<svg viewBox="0 0 24 24" fill="none"><rect x="3" y="4" width="18" height="18" rx="2" fill="white"/><path d="M8 2v4M16 2v4M3 10h18" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M10 15l2 2 4-5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    submit: '<svg viewBox="0 0 24 24" fill="none"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4M17 8l-5-5-5 5M12 3v12" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    fav: '<svg viewBox="0 0 24 24" fill="white"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>',
    rank: '<svg viewBox="0 0 24 24" fill="white"><rect x="3" y="10" width="5" height="10" rx="1"/><rect x="10" y="5" width="4" height="15" rx="1"/><rect x="17" y="2" width="4" height="18" rx="1"/></svg>',
    group: '<svg viewBox="0 0 24 24" fill="none"><circle cx="9" cy="7" r="4" fill="white"/><path d="M1 21v-2c0-2.2 1.8-4 4-4h8c2.2 0 4 1.8 4 4v2" fill="white"/><circle cx="17" cy="8" r="3" fill="white" opacity=".7"/><path d="M19 21v-2c0-2.2-1.8-4-4-4" stroke="white" stroke-width="2" fill="none" opacity=".7"/></svg>',
    settings: '<svg viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="3" stroke="white" stroke-width="2"/><path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42" stroke="white" stroke-width="2" stroke-linecap="round"/></svg>',
    bell: '<svg viewBox="0 0 24 24" fill="none"><path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9M13.73 21a2 2 0 01-3.46 0" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    shop: '<svg viewBox="0 0 24 24" fill="none"><path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4zM3 6h18M16 10a4 4 0 01-8 0" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>'
  };

  function buildPanel() {
    var panel = document.createElement('div');
    panel.className = 'fp-panel';
    panel.setAttribute('data-plugin-panel', PLUGIN_NAME);

    if (config.cardShow !== false) {
      var card = document.createElement('div');
      card.className = 'fp-card';

      var itemsRow = document.createElement('div');
      itemsRow.className = 'fp-items';

      (config.items || []).forEach(function(item) {
        if (item.show === false) return;
        var el = document.createElement('div');
        el.className = 'fp-item';
        el.setAttribute('data-fp-url', item.url || '#');

      var iconWrap = document.createElement('div');
      iconWrap.className = 'fp-icon-wrap';
      iconWrap.style.background = item.color || '#6B7280';
      iconWrap.innerHTML = ICONS[item.icon] || '<svg viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="10" stroke="white" stroke-width="2"/></svg>';

      var label = document.createElement('span');
      label.className = 'fp-label';
      label.textContent = item.label || '';

      el.appendChild(iconWrap);
      el.appendChild(label);
      itemsRow.appendChild(el);
    });

    card.appendChild(itemsRow);

    if (config.links && config.links.length > 0) {
      var linkRow = document.createElement('div');
      linkRow.className = 'fp-links';
      config.links.forEach(function(link) {
        if (link.show === false) return;
        var a = document.createElement('span');
        a.className = 'fp-link-item';
        a.textContent = link.label;
        a.setAttribute('data-fp-url', link.url || '#');
        linkRow.appendChild(a);
      });
      card.appendChild(linkRow);
    }

    panel.appendChild(card);
    }

    if (config.banner && config.banner.show !== false) {
      var banner = document.createElement('div');
      banner.className = 'fp-banner';
      banner.setAttribute('data-fp-url', config.banner.url || '#');

      var bannerIcon = document.createElement('div');
      bannerIcon.className = 'fp-banner-icon';
      bannerIcon.innerHTML = '<svg viewBox="0 0 24 24" fill="none"><path d="M11 5.882V19.24a1.76 1.76 0 01-3.417.592l-2.147-6.15M18 13a3 3 0 100-6M5.436 13.683A4.001 4.001 0 017 6h1.832c4.1 0 7.625-1.234 9.168-3v14c-1.543-1.766-5.067-3-9.168-3H7a3.988 3.988 0 01-1.564-.317z" stroke="white" stroke-width="2" fill="none"/></svg>';

      var bannerText = document.createElement('span');
      bannerText.className = 'fp-banner-text';
      bannerText.textContent = config.banner.text || '';

      banner.appendChild(bannerIcon);
      banner.appendChild(bannerText);

      if (config.banner.closable !== false) {
        var closeBtn = document.createElement('span');
        closeBtn.className = 'fp-banner-close';
        closeBtn.innerHTML = '<svg viewBox="0 0 24 24" fill="none"><path d="M6 6l12 12M18 6L6 18" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';
        closeBtn.addEventListener('click', function(e) {
          e.stopPropagation();
          banner.style.display = 'none';
        });
        banner.appendChild(closeBtn);
      }

      panel.appendChild(banner);
    }

    return panel;
  }

  function navigate(url) {
    if (!url || url === '#') return;
    if (url.startsWith('http')) {
      window.open(url, '_blank');
      return;
    }
    var base = window.location.origin;
    var hash = window.location.hash;
    if (hash && hash.startsWith('#/')) {
      var parts = hash.split('#/');
      if (parts.length === 2) {
        base = parts[0];
      }
    }
    var target = base + (url.startsWith('/') ? '' : '/') + url;
    if (target.indexOf('#') === -1) {
      target = target.replace(/\/$/, '') + '/#/' + url.replace(/^\//, '');
    }
    window.location.href = target;
  }

  function bindEvents(panel) {
    panel.querySelectorAll('[data-fp-url]').forEach(function(el) {
      el.addEventListener('click', function(e) {
        var url = el.getAttribute('data-fp-url');
        navigate(url);
      });
    });
  }

  function tryInsert() {
    if (document.querySelector('[data-plugin-panel="' + PLUGIN_NAME + '"]')) return;

    var main = document.querySelector('.main');
    if (!main) return;

    var hot = main.querySelector('.section');
    if (!hot) return;

    var panel = buildPanel();
    bindEvents(panel);
    main.insertBefore(panel, hot);
  }

  function init() {
    tryInsert();

    var observer = new MutationObserver(function() {
      tryInsert();
    });

    var main = document.querySelector('.main');
    if (main) {
      observer.observe(main, { childList: true, subtree: false });
    }

    var retries = 0;
    var interval = setInterval(function() {
      retries++;
      tryInsert();
      if (document.querySelector('[data-plugin-panel="' + PLUGIN_NAME + '"]') || retries > 20) {
        clearInterval(interval);
      }
    }, 500);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function() {
      setTimeout(init, 300);
    });
  } else {
    setTimeout(init, 300);
  }
})();
