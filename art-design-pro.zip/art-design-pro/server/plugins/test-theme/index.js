(function() {
  console.log('[TestPlugin] Plugin loaded successfully');
})();
