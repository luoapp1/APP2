// dashboard-summary slot script
// 在仪表板顶部插入演示插件状态面板
(function() {
  var el = document.createElement('div')
  el.className = 'plugin-demo-panel'
  el.innerHTML = '<h4>Demo插件状态</h4><p>- 用户注册监听: 已启用</p><p>- 每日定时统计: 已配置(08:00)</p><p>- 邮件队列: 并发3</p>'
  return el
})()
