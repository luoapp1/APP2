// post-detail-sidebar slot script
// 在帖子详情页侧边栏插入演示相关信息
(function() {
  var el = document.createElement('div')
  el.className = 'plugin-demo-panel'
  el.innerHTML = '<h4>Demo插件信息</h4><p>此帖子已被Demo插件监控</p><p><small>Powered by demo-all-features v1.0.0</small></p>'
  return el
})()
