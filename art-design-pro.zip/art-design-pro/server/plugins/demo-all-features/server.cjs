// demo-all-features 插件 — 展示所有 46 种后端扩展机制

module.exports = async function(ctx) {
  const { app, db, router, events, scheduler, menus, slots, perms, services, i18n, mail, notify, dbInterceptor, pluginConfig, pluginDir, logger, cache } = ctx

  // MySQL query helper
  const sql = (q, params = []) => {
    // Plugin demo uses query from database module
    const { query } = require('../../database.cjs')
    return query(q, params)
  }

  logger.info('demo-all-features 插件已加载')

  // ===== 1. EventBus: 监听系统事件 =====
  events.on('user:registered', (payload) => {
    logger.info(`新用户注册: ${payload.username} (ID: ${payload.userId})`)
  })

  events.on('user:login', (payload) => {
    logger.info(`用户登录: ${payload.username}`)
    cache.set(`last_login_${payload.userId}`, new Date().toISOString(), 3600000)
  })

  events.on('post:created', (payload) => {
    logger.info(`新帖子发布: "${payload.title}" by 用户${payload.userId}`)
  })

  events.on('post:likeToggled', (payload) => {
    logger.info(`帖子${payload.postId} ${payload.isLiked ? '被' : '取消'}点赞 by 用户${payload.userId}`)
  })

  events.on('post:deleted', (payload) => {
    logger.info(`帖子${payload.postId} "${payload.title}" 被删除`)
  })

  events.on('comment:created', (payload) => {
    logger.info(`新评论: 帖子${payload.postId}, 用户${payload.userName}`)
  })

  events.on('task:completed', (payload) => {
    logger.info(`任务完成: ${payload.taskName}, 用户${payload.userName}`)
  })

  events.on('pluginConfig:changed', (payload) => {
    logger.info(`插件配置变更: ${payload.pluginName}`)
  })

  // 监听系统关机和启动
  events.on('system:beforeShutdown', () => {
    logger.info('demo-all-features 正在清理资源...')
    cache.clear()
  })

  // ===== 2. EventBus: 注册 event 拦截钩子 (beforeRegister) =====
  events.on('user:beforeRegister', (payload) => {
    logger.info(`准备注册用户: ${payload.username}`)
    // 演示：可以在这里做用户名黑名单检查等
    // 如果要拒绝注册，throw new Error('PluginError: 用户名已被禁用')
  })

  // ===== 3. Scheduler: 定时任务 =====
  scheduler.registerCron({
    name: 'demo-daily-stats',
    cron: '0 8 * * *',
    handler: async () => {
      const stats = sql('SELECT COUNT(*) as total FROM users')
      logger.info(`每日统计: 当前用户总数 ${stats[0]?.total || 0}`)
      cache.set('daily_user_count', stats[0]?.total || 0)
    }
  })

  // ===== 4. Scheduler: 队列任务 =====
  scheduler.registerQueue('demo-email-queue', {
    concurrency: 3,
    handler: async (data) => {
      logger.info(`发送邮件: to=${data.email}, subject=${data.subject}`)
      return { success: true, sent: new Date().toISOString() }
    }
  })

  // ===== 5. Scheduler: 延迟任务 (启动后30秒执行) =====
  scheduler.schedule({
    name: 'demo-init-task',
    delay: 30000,
    handler: async () => {
      const tables = await sql("SHOW TABLES")
      logger.info(`数据库表数量: ${tables.length}`)
    }
  })

  // ===== 6. ServiceRegistry: 注册自定义服务 =====
  services.register('demo:messaging', {
    sendMessage: (to, content) => {
      logger.info(`发送消息: to=${to}, content=${content}`)
      return { sent: true, timestamp: Date.now() }
    },
    getHistory: (userId) => {
      return cache.get(`msg_history_${userId}`) || []
    }
  })

  // ===== 7. ServiceRegistry: 注册表单字段 =====
  services.registerFormField('demo_message', {
    type: 'text',
    label: i18n.t('form.demo_message') || '演示留言',
    required: true,
    maxlength: 500,
    placeholder: '请输入留言内容'
  })

  // ===== 8. ServiceRegistry: 注册自定义验证器 =====
  services.registerValidator('demo:email_format', {
    validate: (value) => {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
      if (!emailRegex.test(value)) {
        return { valid: false, message: '邮箱格式不正确' }
      }
      return { valid: true }
    }
  })

  // ===== 9. ServiceRegistry: 注册支付网关 =====
  services.registerPaymentGateway({
    name: 'demo-wallet',
    label: '演示钱包支付',
    supportRefund: true,
    pay: async (order) => {
      logger.info(`演示钱包支付: 订单${order.id}, 金额${order.amount}`)
      return { success: true, transactionId: `demo_${Date.now()}` }
    },
    refund: async (transactionId) => {
      logger.info(`演示钱包退款: ${transactionId}`)
      return { success: true }
    }
  })

  // ===== 10. ServiceRegistry: 注册认证方式 =====
  services.registerAuthMethod({
    name: 'demo-social-login',
    label: '社交账号登录(演示)',
    enabled: true,
    config: { provider: 'demo-oauth', clientId: 'demo-client' }
  })

  // ===== 11. ServiceRegistry: 注册验证码提供者 =====
  services.registerCaptchaProvider({
    name: 'demo-geetest',
    label: '极验验证(演示)',
    verify: async (params) => {
      return { success: true, score: 0.95 }
    }
  })

  // ===== 12. ServiceRegistry: 装饰已有服务 =====
  services.decorate('demo:messaging', {
    sendMessage: (original, to, content) => {
      logger.info(`[装饰器] 发送前检查: to=${to}`)
      return original(to, content)
    }
  })

  // ===== 13. ServiceRegistry: 共享数据 =====
  services.setShared('demo:startTime', new Date().toISOString())
  services.setShared('demo:version', pluginConfig.version)

  // ===== 14. Plugin-to-Plugin API =====
  // 如果 feature-panel 插件存在，调用它的API
  try {
    const fpHello = services.callPlugin('feature-panel', 'hello', 'from demo-all-features')
    if (fpHello) logger.info(`feature-panel 返回: ${JSON.stringify(fpHello)}`)
  } catch (e) {
    logger.debug('feature-panel 未安装或未导出 hello 方法')
  }

  // ===== 15. Permission 注册 =====
  perms.register([
    { node: 'demo:view', name: '查看演示', roles: ['admin', 'editor'] },
    { node: 'demo:manage', name: '管理演示', roles: ['admin'] }
  ])

  perms.extendRole('editor', {
    canViewDemo: true,
    canEditDemoConfig: false
  })

  // ===== 16. Menu 注册 =====
  menus.register([
    { scope: 'adminSidebar', name: '功能演示', icon: 'Monitor', path: '/demo/features', sort: 99 }
  ])

  menus.registerBatchAction('posts', {
    name: '标记演示',
    action: async (ids) => {
      logger.info(`批量标记演示: ${ids.join(',')}`)
      for (const id of ids) {
        sql('UPDATE community_posts SET custom_badge=? WHERE id=?', ['演示', id])
      }
      return { success: true, count: ids.length }
    }
  })

  menus.registerDetailTab('user', {
    name: '演示记录',
    component: 'DemoUserRecords',
    sort: 99
  })

  menus.registerDashboardWidget({
    name: '演示统计',
    component: 'DemoStatsWidget',
    width: 6,
    sort: 100
  })

  // ===== 17. Slot 注册 (前端插槽) =====
  slots.injectStyle(`
    .plugin-demo-badge {
      display: inline-block;
      padding: 2px 8px;
      background: linear-gradient(135deg, #10B981, #059669);
      color: white;
      border-radius: 4px;
      font-size: 12px;
      margin-left: 8px;
    }
    .plugin-demo-panel {
      background: #f0fdf4;
      border: 1px solid #10B981;
      border-radius: 8px;
      padding: 16px;
      margin: 12px 0;
    }
  `)

  // ===== 18. I18n (已在 buildPluginContext 中自动加载) =====
  const welcome = i18n.t('welcome')
  logger.info(`i18n 欢迎语: ${welcome}`)

  // ===== 19. Mail 模板注册 =====
  mail.registerTemplate('demo-welcome', {
    subject: '欢迎使用演示插件',
    html: (data) => `<h2>欢迎, ${data.username}!</h2><p>演示插件已启用。</p>`,
    text: (data) => `欢迎, ${data.username}! 演示插件已启用。`
  })

  // ===== 20. Notify 通知渠道 =====
  notify.registerChannel({
    name: 'demo-websocket',
    label: 'WebSocket 推送(演示)',
    send: async (notification) => {
      logger.info(`[WebSocket] 推送通知: ${notification.title} -> user ${notification.userId}`)
      return { delivered: true }
    }
  })

  // ===== 21. DB Interceptor: 查询拦截 =====
  dbInterceptor.onBeforeQuery((sql, params) => {
    // 记录所有查询（仅开发环境）
    if (process.env.NODE_ENV === 'development') {
      cache.set('_last_query', { sql, time: Date.now() })
    }
    return { sql, params }
  })

  // ===== 22. DB Interceptor: 事务钩子 =====
  dbInterceptor.onBeforeCommit(() => {
    logger.debug('事务即将提交')
  })
  dbInterceptor.onAfterRollback(() => {
    logger.warn('事务已回滚')
  })

  // ===== 23. Plugin Config 访问 =====
  logger.info(`当前配置: siteName=${pluginConfig.config?.siteName || '未设置'}`)
  logger.info(`主题色: ${pluginConfig.config?.themeColor || '#10B981'}`)

  // ===== 24. Plugin-to-Plugin API 暴露 =====
  // 本插件暴露的 API 供其他插件调用
  return {
    name: 'demo-all-features',
    version: '1.0.0',
    getStats: async () => {
      const userCount = sql('SELECT COUNT(*) as c FROM users')
      const postCount = sql("SELECT COUNT(*) as c FROM community_posts WHERE status='published'")
      return {
        users: userCount[0]?.c || 0,
        posts: postCount[0]?.c || 0,
        uptime: Date.now() - new Date(services.getShared('demo:startTime')).getTime()
      }
    },
    enqueueEmail: async (email, subject) => {
      return scheduler.enqueue('demo-email-queue', { email, subject })
    },
    getConfig: () => JSON.parse(JSON.stringify(pluginConfig.config || {})),
    sendMessage: (to, content) => services.call('demo:messaging', 'sendMessage', to, content),
    echo: (msg) => `[demo-all-features echo]: ${msg}`
  }
}
