const { query } = require('./database.cjs')

function lightGrays() {
  return {
    gray100: '#f9fafb', gray200: '#f2f4f5', gray300: '#e6eaeb',
    gray400: '#dbdfe1', gray500: '#949eb7', gray600: '#7987a1',
    gray700: '#4d5875', gray800: '#383853', gray900: '#323251'
  }
}

function darkGrays() {
  return {
    gray100: '#110f0f', gray200: '#17171c', gray300: '#393946',
    gray400: '#505062', gray500: '#73738c', gray600: '#8f8fa3',
    gray700: '#ababba', gray800: '#c7c7d1', gray900: '#e3e3e8'
  }
}

function lightUI(boxColor) {
  return {
    bgColor: '#fafbfc', boxColor: boxColor || '#ffffff',
    hoverColor: '#edeff0', activeColor: '#f2f4f5', elActiveColor: '#f2f4f5',
    defaultBorder: '#e2e8ee', dashedBorder: '#dbdfe9',
    cardBorder: 'rgba(0, 0, 0, 0.08)',
    shadowColor: 'rgba(0, 0, 0, 0.08)', borderRadius: '0.25',
    fontFamily: 'system-ui, -apple-system, "Segoe UI", Roboto, sans-serif'
  }
}

function darkUI(boxColor) {
  return {
    bgColor: '#070707', boxColor: boxColor || '#161618',
    hoverColor: '#252530', activeColor: '#202226', elActiveColor: '#2e2e38',
    defaultBorder: 'rgba(255, 255, 255, 0.1)', dashedBorder: '#363843',
    cardBorder: 'rgba(255, 255, 255, 0.08)',
    shadowColor: 'rgba(0, 0, 0, 0.3)', borderRadius: '0.25',
    fontFamily: 'system-ui, -apple-system, "Segoe UI", Roboto, sans-serif'
  }
}

function buildTheme(mainColor, primary, secondary, error, info, success_val, warning, danger) {
  const lightGray = lightGrays()
  const darkGray = darkGrays()
  const lightUI_vals = lightUI()
  const darkUI_vals = darkUI()

  const lightTokens = {
    mainColor, primary, secondary,
    ...lightGray,
    ...lightUI_vals,
    error, info, success: success_val, warning, danger
  }

  const darkTokens = {
    mainColor, primary, secondary,
    ...darkGray,
    ...darkUI_vals,
    error, info, success: success_val, warning, danger
  }

  const mobileLightTokens = {
    ...lightTokens,
    boxColor: '#fcfcfd',
    borderRadius: '0.3',
    fontFamily: '"PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", system-ui, sans-serif',
    shadowColor: 'rgba(0, 0, 0, 0.06)'
  }

  const mobileDarkTokens = {
    ...darkTokens,
    boxColor: '#1a1a1c',
    borderRadius: '0.3',
    fontFamily: '"PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", system-ui, sans-serif'
  }

  return {
    vars: lightTokens,
    varsDark: darkTokens,
    varsMobile: mobileLightTokens,
    varsMobileDark: mobileDarkTokens
  }
}

const PRESETS = [
  {
    name: '经典蓝',
    description: '清爽专业，适合企业办公后台',
    thumbnail: '',
    theme: buildTheme(
      '#5D87FF',
      'oklch(0.7 0.23 260)',
      'oklch(0.72 0.19 231.6)',
      'oklch(0.73 0.15 25.3)',
      'oklch(0.58 0.03 254.1)',
      'oklch(0.78 0.17 166.1)',
      'oklch(0.78 0.14 75.5)',
      'oklch(0.68 0.22 25.3)'
    )
  },
  {
    name: '墨玉黑',
    description: '深邃科技风格',
    thumbnail: '',
    theme: buildTheme(
      '#6366F1',
      'oklch(0.65 0.22 270)',
      'oklch(0.68 0.16 250)',
      'oklch(0.7 0.18 20)',
      'oklch(0.55 0.04 255)',
      'oklch(0.75 0.18 160)',
      'oklch(0.76 0.15 72)',
      'oklch(0.65 0.24 22)'
    )
  },
  {
    name: '森林绿',
    description: '清新自然，护眼舒适',
    thumbnail: '',
    theme: buildTheme(
      '#059669',
      'oklch(0.72 0.17 166)',
      'oklch(0.7 0.14 180)',
      'oklch(0.72 0.16 28)',
      'oklch(0.58 0.03 252)',
      'oklch(0.78 0.18 164)',
      'oklch(0.77 0.15 78)',
      'oklch(0.66 0.22 28)'
    )
  },
  {
    name: '樱桃粉',
    description: '柔和温暖，亲和力强',
    thumbnail: '',
    theme: buildTheme(
      '#EC4899',
      'oklch(0.7 0.18 350)',
      'oklch(0.72 0.15 340)',
      'oklch(0.73 0.16 26)',
      'oklch(0.57 0.03 256)',
      'oklch(0.78 0.16 164)',
      'oklch(0.78 0.13 74)',
      'oklch(0.67 0.21 26)'
    )
  }
]

async function seedThemes() {
  try {
    const cnt = await query('SELECT COUNT(*) as cnt FROM themes')
    if (cnt[0].cnt > 0) {
      console.log('主题数据已存在，跳过种子')
      return
    }
    for (let i = 0; i < PRESETS.length; i++) {
      const p = PRESETS[i]
      const nowExpr = "NOW()"
      await query(
        `INSERT INTO themes (name, description, is_preset, is_active, thumbnail, vars, vars_dark, vars_mobile, vars_mobile_dark, create_time, update_time)
         VALUES (?, ?, 1, ?, ?, ?, ?, ?, ?, ${nowExpr}, ${nowExpr})`,
        [
          p.name, p.description, i === 0 ? 1 : 0, p.thumbnail,
          JSON.stringify(p.theme.vars),
          JSON.stringify(p.theme.varsDark),
          JSON.stringify(p.theme.varsMobile),
          JSON.stringify(p.theme.varsMobileDark)
        ]
      )
    }
    console.log('预设主题种子数据已初始化（4 套）')
  } catch (e) {
    console.error('主题种子数据错误:', e.message)
  }
}

async function seedThemeMenu() {
  try {
    const menuCnt = await query("SELECT COUNT(*) as cnt FROM menus WHERE name='Themes'")
    if (!menuCnt[0].cnt) {
      const parentId = await query("SELECT id FROM menus WHERE name='Operation'")
      if (parentId.length) {
        const maxSort = await query("SELECT MAX(sort_order) as m FROM menus WHERE parent_id=?", [parentId[0].id])
        const nextSort = (maxSort[0]?.m || 0) + 1
        await query(
          `INSERT INTO menus (parent_id, name, path, component, redirect, title, icon, sort_order, is_hidden, is_keep_alive, is_fixed_tab, roles, enabled)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`,
          [parentId[0].id, 'Themes', 'themes', '/operation/themes/index', '', '主题管理', 'ri:palette-line', nextSort, 0, 0, 0, 'R_SUPER,R_ADMIN', 1]
        )
      }
      console.log('主题管理菜单已添加')
    }
  } catch (e) {
    console.error('主题管理菜单错误:', e.message)
  }
}

module.exports = { seedThemes, seedThemeMenu, PRESETS }
