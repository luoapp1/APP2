const { query } = require('./database.cjs')
const bcrypt = require('bcryptjs')

async function seedTestData() {
  console.log('插入测试数据...')
  const now = () => new Date().toISOString().slice(0, 19).replace('T', ' ')
  const randomBool = () => Math.random() > 0.5 ? 1 : 0

  // === 用户 (20个) ===
  const userCnt = await query("SELECT COUNT(*) as cnt FROM users WHERE username != 'alexmorgan'")
  if (!userCnt[0].cnt) {
    console.log('  创建用户...')
    const hash = bcrypt.hashSync('123456', 10)
    const users = [
      ['bobwang', 'bob123', hash, 'Bob Wang', '13800138001', 'bob@test.com', 1, '', 1500, 88.50, 3200, 2, '黄金会员', '["R_USER"]', 1],
      ['lisa_chen', 'lisa123', hash, 'Lisa Chen', '13800138002', 'lisa@test.com', 0, '', 800, 25.00, 1500, 1, '普通会员', '["R_USER"]', 1],
      ['tech_guru', 'tech123', hash, 'Tech Guru', '13800138003', 'tech@test.com', 1, '', 5000, 200.00, 8000, 3, '钻石会员', '["R_USER"]', 1],
      ['design_master', 'dm123', hash, 'Design Master', '13800138004', 'dm@test.com', 0, '', 300, 10.00, 600, 1, '普通会员', '["R_USER"]', 1],
      ['code_ninja', 'cn123', hash, 'Code Ninja', '13800138005', 'code@test.com', 1, '', 2200, 150.00, 4500, 2, '黄金会员', '["R_USER"]', 1],
      ['pixel_art', 'pa123', hash, 'Pixel Art', '13800138006', 'pixel@test.com', 0, '', 450, 30.00, 900, 1, '普通会员', '["R_USER"]', 1],
      ['ui_lover', 'ui123', hash, 'UI Lover', '13800138007', 'ui@test.com', 0, '', 12000, 500.00, 12000, 4, '至尊会员', '["R_USER"]', 1],
      ['frontend_dev', 'fd123', hash, 'Frontend Dev', '13800138008', 'fd@test.com', 1, '', 6000, 180.00, 6000, 3, '钻石会员', '["R_USER"]', 1],
      ['backend_guru', 'bg123', hash, 'Backend Guru', '13800138009', 'bg@test.com', 1, '', 3500, 95.00, 3500, 2, '黄金会员', '["R_USER"]', 1],
      ['data_wizard', 'dw123', hash, 'Data Wizard', '13800138010', 'dw@test.com', 1, '', 780, 42.00, 780, 1, '普通会员', '["R_USER"]', 1],
      ['mobile_dev', 'md123', hash, 'Mobile Dev', '13800138011', 'md@test.com', 1, '', 200, 5.00, 200, 1, '普通会员', '["R_USER"]', 1],
      ['cloud_arch', 'ca123', hash, 'Cloud Arch', '13800138012', 'ca@test.com', 1, '', 9500, 350.00, 9500, 3, '钻石会员', '["R_USER"]', 1],
      ['ai_explorer', 'ai123', hash, 'AI Explorer', '13800138013', 'ai@test.com', 0, '', 3000, 120.00, 3000, 2, '黄金会员', '["R_USER"]', 1],
      ['game_dev', 'gd123', hash, 'Game Dev', '13800138014', 'gd@test.com', 1, '', 1800, 66.00, 1800, 1, '普通会员', '["R_USER"]', 1],
      ['security_pro', 'sp123', hash, 'Security Pro', '13800138015', 'sp@test.com', 1, '', 4200, 155.00, 4200, 2, '黄金会员', '["R_USER"]', 1],
    ]
    for (const u of users) {
      await query(
        `INSERT INTO users (username, nickname, password, password_hash, phone, email, gender, avatar, points, balance, experience, level_id, level_name, roles, status, create_time)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW() - INTERVAL ${Math.floor(Math.random() * 60)} DAY)`, u
      )
    }
    // 注册3个已注销用户
    await query(`INSERT INTO users (username, nickname, password, password_hash, roles, status, create_time) VALUES ('deleted1', 'Deleted1', 'x', 'x', '["R_USER"]', '4', NOW() - INTERVAL 30 DAY)`)
    await query(`INSERT INTO users (username, nickname, password, password_hash, roles, status, create_time) VALUES ('deleted2', 'Deleted2', 'x', 'x', '["R_USER"]', '4', NOW() - INTERVAL 20 DAY)`)
    await query(`INSERT INTO users (username, nickname, password, password_hash, roles, status, create_time) VALUES ('deleted3', 'Deleted3', 'x', 'x', '["R_USER"]', '4', NOW() - INTERVAL 10 DAY)`)
  }

  // === 应用商店 ===
  const appCnt = await query('SELECT COUNT(*) as cnt FROM app_store')
  if (!appCnt[0].cnt) {
    console.log('  创建应用...')
    const apps = [
      ['Pro Photo Editor', 'AIGram.pro.editor', '1.2.3', '120', 'camera', '专业级照片编辑工具，AI智能修图', '["photo","editor","AI"]', 'bobwang', '工具', 1],
      ['Pixel Draw', 'Pixel.Draw.app', '2.0.1', '101', 'brush', '像素风绘画应用，支持图层和动画', '["draw","pixel","art"]', 'pixel_art', '工具', 1],
      ['Code Helper', 'Code.Helper.pro', '3.5.0', '200', 'code', '智能代码助手，支持多种编程语言', '["code","dev","tool"]', 'code_ninja', '工具', 1],
      ['Music Maker', 'Music.Maker.studio', '1.0.0', '80', 'music', 'AI驱动的音乐创作工作室', '["music","create","AI"]', 'tech_guru', '创作', 1],
      ['Video Snap', 'Video.Snap.lite', '4.2.1', '95', 'video', '短视频快速剪辑和滤镜工具', '["video","edit","social"]', 'frontend_dev', '创作', 1],
      ['Task Flow', 'Task.Flow.org', '2.8.0', '60', 'task', '团队协作和任务管理平台', '["productivity","team"]', 'backend_guru', '效率', 1],
      ['Mind Map Pro', 'Mind.Map.visual', '1.5.2', '75', 'mindmap', '思维导图可视化工具', '["mindmap","study","visual"]', 'design_master', '效率', 1],
      ['Weather AI', 'Weather.AI.now', '3.1.0', '45', 'weather', 'AI精准天气预报', '["weather","AI","life"]', 'ai_explorer', '生活', 1],
      ['Fitness Coach', 'Fitness.Coach.pro', '2.3.4', '110', 'fitness', '个人AI健身教练', '["fitness","health","AI"]', 'ui_lover', '生活', 1],
      ['待审核应用', 'com.demo.pending', '0.1.0', '30', 'default', '这是一个待审核的应用', '["test"]', 'mobile_dev', '工具', 0],
      ['已拒绝应用', 'com.demo.rejected', '0.1.0', '20', 'default', '这是一个被拒绝的应用', '["test"]', 'game_dev', '工具', 2],
    ]
    for (const a of apps) {
      await query(
        `INSERT INTO app_store (name, package_name, version, version_code, icon_bg_color, description, tags, developer, category, status, user_id, downloads, rating, create_time)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW() - INTERVAL ${Math.floor(Math.random() * 90)} DAY)`,
        [...a, Math.floor(Math.random() * 20) + 1, Math.random() * 5000, (Math.random() * 2 + 2.5).toFixed(1)]
      )
    }
  }

  // === 应用分类 ===
  const catCnt = await query('SELECT COUNT(*) as cnt FROM app_categories')
  if (!catCnt[0].cnt) {
    console.log('  创建应用分类...')
    const cats = ['工具', '创作', '效率', '生活', '游戏', '教育', '社交']
    for (const c of cats) {
      await query(`INSERT INTO app_categories (name, sort_order, status) VALUES (?, ?, '1')`, [c, cats.indexOf(c) + 1])
    }
  }

  // === 官方标签 ===
  const tagCnt = await query('SELECT COUNT(*) as cnt FROM app_official_tags')
  if (!tagCnt[0].cnt) {
    console.log('  创建官方标签...')
    const tags = ['热门', '推荐', '新品', '精品']
    for (const t of tags) {
      await query(`INSERT INTO app_official_tags (name, sort_order) VALUES (?, ${tags.indexOf(t) + 1})`, [t])
    }
  }

  // === 社区帖子 ===
  const postCnt = await query('SELECT COUNT(*) as cnt FROM community_posts')
  if (!postCnt[0].cnt) {
    console.log('  创建社区帖子...')
    const posts = [
      [2, '分享我的设计作品集', '<p>花了一个月时间整理的作品集，包含平面设计、UI设计和品牌设计作品</p>', 1, 'published', 150, 45, 12],
      [3, 'AI绘画入门指南', '<p>从零开始学习AI绘画，介绍主流工具和使用技巧</p>', 2, 'published', 320, 88, 25],
      [5, 'React 19 新特性解读', '<p>React 19带来了很多令人兴奋的新特性，让我们一起看看</p>', 3, 'published', 200, 55, 18],
      [2, '我的应用开发历程', '<p>从想法到上线，分享我的独立开发经历</p>', 4, 'published', 90, 30, 8],
      [8, 'Vue3 + TypeScript 实战', '<p>结合项目实战讲解Vue3 Composition API和TypeScript</p>', 5, 'published', 180, 42, 15],
      [14, '设计师如何提升审美', '<p>分享一些提升设计审美的方法和资源</p>', 6, 'published', 250, 60, 20],
      [10, 'Cloud Native架构实践', '<p>微服务、容器化、K8s等云原生技术的最佳实践</p>', 7, 'published', 130, 35, 10],
      [13, '移动开发趋势2026', '<p>Flutter、React Native、SwiftUI等跨平台框架对比</p>', 8, 'published', 160, 40, 14],
      [6, '像素艺术创作技巧', '<p>分享一些像素画创作的实用技巧和工具推荐</p>', 9, 'published', 110, 28, 9],
      [3, '面试经历分享', '<p>最近面了几家大厂，分享一些经验和教训</p>', 10, 'published', 280, 70, 22],
      [9, '独立游戏开发日记', '<p>记录我的第一款独立游戏的开发过程</p>', 11, 'published', 75, 20, 6],
      [7, '开源项目推荐合集', '<p>整理了一些高质量的2026年值得关注的开源项目</p>', 12, 'published', 400, 110, 35],
    ]
    for (const p of posts) {
      await query(
        `INSERT INTO community_posts (user_id, title, content, section_id, status, view_count, like_count, comment_count, is_essence, is_pinned, is_global_pinned, create_time)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ${randomBool()}, ${randomBool()}, ${randomBool()}, NOW() - INTERVAL ${Math.floor(Math.random() * 30)} DAY)`, p
      )
    }
  }

  // === 社区评论 ===
  const commentCnt = await query('SELECT COUNT(*) as cnt FROM community_comments')
  if (!commentCnt[0].cnt) {
    console.log('  创建社区评论...')
    const userIds = [2,3,5,8,9,10,13,14,15,16,17,18]
    for (let i = 1; i <= 40; i++) {
      const uid = userIds[Math.floor(Math.random() * userIds.length)]
      const pid = Math.floor(Math.random() * 12) + 1
      await query(
        `INSERT INTO community_comments (user_id, post_id, content, create_time)
         VALUES (?, ?, ?, NOW() - INTERVAL ${Math.floor(Math.random() * 20)} DAY)`,
        [uid, pid, `这是第${i}条测试评论，内容非常精彩！`]
      )
    }
  }

  // === 社区话题 ===
  const topicCnt = await query('SELECT COUNT(*) as cnt FROM community_topics')
  if (!topicCnt[0].cnt) {
    console.log('  创建社区话题...')
    const topics = ['AI绘画', '前端开发', '设计灵感', '独立开发', 'UI/UX', '科技资讯', '摄影分享', '生活记录']
    for (const t of topics) {
      await query(`INSERT INTO community_topics (name, description, create_time) VALUES (?, ?, NOW())`, [t, `${t}相关话题讨论区`])
    }
  }

  // === 社区版块 ===
  const secCnt = await query('SELECT COUNT(*) as cnt FROM community_sections')
  if (!secCnt[0].cnt) {
    console.log('  创建社区版块...')
    const sections = ['综合讨论', '技术交流', '设计创作', '资源分享', '反馈建议']
    for (const s of sections) {
      await query(`INSERT INTO community_sections (name, description, sort_order, status) VALUES (?, ?, ?, '1')`, [s, `${s}版块`, sections.indexOf(s) + 1])
    }
  }

  // === 社区举报 ===
  const reportCnt = await query('SELECT COUNT(*) as cnt FROM community_reports')
  if (!reportCnt[0].cnt) {
    console.log('  创建社区举报...')
    for (let i = 0; i < 8; i++) {
      await query(
        `INSERT INTO community_reports (reporter_id, reporter_name, target_type, target_id, report_reason, status, create_time)
         VALUES (?, ?, 'post', ?, ?, ?, NOW() - INTERVAL ${Math.floor(Math.random() * 15)} DAY)`,
        [2 + Math.floor(Math.random() * 14), '用户' + (2 + Math.floor(Math.random() * 14)), 1 + Math.floor(Math.random() * 12), ['垃圾广告', '违规内容', '人身攻击', '版权侵权'][i % 4], ['pending', 'resolved', 'ignored'][i % 3]]
      )
    }
  }

  // === 点赞记录 ===
  const likeCnt = await query('SELECT COUNT(*) as cnt FROM community_likes')
  if (!likeCnt[0].cnt) {
    console.log('  创建点赞记录...')
    for (let i = 0; i < 30; i++) {
      await query(
        `INSERT IGNORE INTO community_likes (user_id, post_id, create_time)
         VALUES (?, ?, NOW() - INTERVAL ${Math.floor(Math.random() * 20)} DAY)`,
        [2 + Math.floor(Math.random() * 14), 1 + Math.floor(Math.random() * 12)]
      )
    }
  }

  // === 商城商品 ===
  const mallCnt = await query('SELECT COUNT(*) as cnt FROM mall_products')
  if (!mallCnt[0].cnt) {
    console.log('  创建商城商品...')
    const catMap = { education: 1, design: 2, dev: 3, service: 4 }
    const products = [
      ['AI绘画大师课程', '高级', 299.00, 199.00, catMap['education'], '["热门"]'],
      ['Vue3实战视频教程', '中级', 99.00, 79.00, catMap['education'], '["推荐"]'],
      ['设计素材大礼包', '基础', 49.00, 39.00, catMap['design'], '["精品"]'],
      ['代码审查服务', '高级', 199.00, 149.00, catMap['service'], '["热门"]'],
      ['UI Kit Pro', '中级', 129.00, 99.00, catMap['design'], '["推荐"]'],
      ['图标合集 5000+', '基础', 29.00, 19.00, catMap['design'], '["新品"]'],
      ['API接口开放平台', '高级', 999.00, 799.00, catMap['dev'], '["精品"]'],
      ['移动端组件库', '中级', 199.00, 149.00, catMap['dev'], '["推荐"]'],
    ]
    for (const p of products) {
      await query(
        `INSERT INTO mall_products (name, subtitle, original_price, price, category_id, tags, status, sales_count, create_time)
         VALUES (?, ?, ?, ?, ?, ?, '1', ${Math.floor(Math.random() * 100)}, NOW())`, p
      )
    }
  }

  // === 商城分类 ===
  const mallCatCnt = await query('SELECT COUNT(*) as cnt FROM mall_categories')
  if (!mallCatCnt[0].cnt) {
    console.log('  创建商城分类...')
    const cats = ['education', 'design', 'dev', 'service']
    for (const c of cats) {
      await query(`INSERT INTO mall_categories (name, sort_order, status) VALUES (?, ?, '1')`, [c, cats.indexOf(c) + 1])
    }
  }

  // === 商城订单 ===
  const mallOrderCnt = await query('SELECT COUNT(*) as cnt FROM mall_orders')
  if (!mallOrderCnt[0].cnt) {
    console.log('  创建商城订单...')
    for (let i = 0; i < 15; i++) {
      const uid = 2 + Math.floor(Math.random() * 14)
      const amount = Math.floor(Math.random() * 500) + 20
      await query(
        `INSERT INTO mall_orders (order_no, user_id, total_amount, status, payment_method, create_time)
         VALUES (CONCAT('MAL', UNIX_TIMESTAMP(), ${i}), ?, ?, ?, ?, NOW() - INTERVAL ${Math.floor(Math.random() * 30)} DAY)`,
        [uid, amount, ['paid', 'paid', 'paid', 'shipped', 'completed', 'cancelled'][i % 6], ['wechat', 'alipay'][i % 2]]
      )
    }
  }

  // === 商城评价 ===
  const mallReviewCnt = await query('SELECT COUNT(*) as cnt FROM mall_reviews')
  if (!mallReviewCnt[0].cnt) {
    console.log('  创建商城评价...')
    for (let i = 0; i < 10; i++) {
      await query(
        `INSERT INTO mall_reviews (user_id, product_id, order_id, rating, content, create_time)
         VALUES (?, ?, ?, ?, ?, NOW())`,
        [2 + Math.floor(Math.random() * 14), 1 + Math.floor(Math.random() * 8), i + 1, Math.floor(Math.random() * 2) + 4, `质量不错，第${i+1}次购买了！`]
      )
    }
  }

  // === 优惠券 ===
  const couponCnt = await query('SELECT COUNT(*) as cnt FROM coupons')
  if (!couponCnt[0].cnt) {
    console.log('  创建优惠券...')
    const coupons = [
      ['新人专享券', 10, 100, 'fixed', 5, 1],
      ['满减优惠券', 50, 200, 'fixed', 10, 1],
      ['VIP折扣券', 0, 0, 'percentage', 15, 1],
      ['节日特惠券', 30, 500, 'fixed', 20, 1],
      ['限时体验券', 0, 0, 'percentage', 8, 1],
    ]
    for (const c of coupons) {
      await query(
        `INSERT INTO coupons (name, min_order, max_discount, type, value, status, total_count, claimed_count, create_time)
         VALUES (?, ?, ?, ?, ?, ?, 100, ${Math.floor(Math.random() * 50)}, NOW())`, c
      )
    }
  }

  // === 用户优惠券 ===
  const userCouponCnt = await query('SELECT COUNT(*) as cnt FROM user_coupons')
  if (!userCouponCnt[0].cnt) {
    console.log('  创建用户优惠券...')
    for (let i = 0; i < 20; i++) {
      await query(
        `INSERT INTO user_coupons (user_id, coupon_id, status, coupon_data, expire_time, receive_time)
         VALUES (?, ?, ?, '{}', NOW() + INTERVAL 30 DAY, NOW())`,
        [2 + Math.floor(Math.random() * 14), 1 + Math.floor(Math.random() * 5), ['unused', 'used'][i % 3 === 0 ? 1 : 0]]
      )
    }
  }

  // === 卡密 ===
  const cardKeyCnt = await query('SELECT COUNT(*) as cnt FROM card_keys')
  if (!cardKeyCnt[0].cnt) {
    console.log('  创建卡密...')
    for (let i = 0; i < 20; i++) {
      const cardNo = 'CDK-' + Math.random().toString(36).substring(2, 10).toUpperCase()
      const status = i < 12 ? '0' : (i < 16 ? '1' : '2')
      const pwd = Math.random().toString(36).substring(2, 8)
      await query(
        `INSERT INTO card_keys (card_no, password, type, value, status, create_time)
         VALUES (?, ?, 'points', ?, ?, NOW())`, [cardNo, pwd, Math.floor(Math.random() * 500) + 100, status]
      )
      if (status === '1') {
        await query(`UPDATE card_keys SET redeem_time = NOW() WHERE card_no = ?`, [cardNo])
      }
    }
  }

  // === 签到记录 ===
  const ckCnt = await query('SELECT COUNT(*) as cnt FROM checkin_records')
  if (!ckCnt[0].cnt) {
    console.log('  创建签到记录...')
    const done = new Set()
    for (let day = 0; day < 30; day++) {
      for (let u = 0; u < Math.floor(Math.random() * 8) + 3; u++) {
        const uid = 2 + Math.floor(Math.random() * 14)
        const key = `${uid}-${day}`
        if (done.has(key)) continue
        done.add(key)
        const d = `NOW() - INTERVAL ${day} DAY`
        await query(
          `INSERT IGNORE INTO checkin_records (user_id, checkin_date, points_earned, consecutive_days, create_time)
           VALUES (?, ${d}, ${Math.floor(Math.random() * 20) + 5}, ${Math.floor(Math.random() * 15) + 1}, ${d})`,
          [uid]
        )
      }
    }
  }

  // === 聊天室 ===
  const chatRoomCnt = await query('SELECT COUNT(*) as cnt FROM chat_rooms')
  if (!chatRoomCnt[0].cnt) {
    console.log('  创建聊天室...')
    const rooms = [
      ['设计交流群', 4, 'design_master', 1],
      ['技术讨论组', 5, 'code_ninja', 1],
      ['综合聊天室', 2, 'bobwang', 1],
      ['AI爱好者', 13, 'ai_explorer', 1],
    ]
    for (const r of rooms) {
      const res = await query(
        `INSERT INTO chat_rooms (name, owner_id, max_members, status, create_time)
         VALUES (?, ?, 200, ?, NOW())`, [r[0], r[1], r[3]]
      )
      const roomId = res.insertId
      // 添加成员
      for (let u = 2; u <= 16; u++) {
        if (Math.random() > 0.3) {
          await query(`INSERT IGNORE INTO chat_room_members (room_id, user_id, role, join_time) VALUES (?, ?, ?, NOW())`, [roomId, u, u === r[1] ? 'owner' : 'member'])
        }
      }
      // 添加消息
      for (let m = 0; m < Math.floor(Math.random() * 15) + 5; m++) {
        await query(
          `INSERT IGNORE INTO chat_room_messages (room_id, from_user_id, content, message_type, create_time)
           VALUES (?, ?, ?, 'text', NOW() - INTERVAL ${Math.floor(Math.random() * 48)} HOUR)`,
          [roomId, 2 + Math.floor(Math.random() * 15), `这是聊天消息 #${m + 1}`]
        )
      }
    }
  }

  // === 聊天礼物 ===
  const giftCnt = await query('SELECT COUNT(*) as cnt FROM chat_gift_records')
  if (!giftCnt[0].cnt) {
    console.log('  创建聊天礼物记录...')
    // 先创建礼物类型
    await query(`INSERT IGNORE INTO chat_gifts (name, price, status) VALUES ('flower', 5, 'active')`)
    await query(`INSERT IGNORE INTO chat_gifts (name, price, status) VALUES ('heart', 10, 'active')`)
    await query(`INSERT IGNORE INTO chat_gifts (name, price, status) VALUES ('star', 20, 'active')`)
    await query(`INSERT IGNORE INTO chat_gifts (name, price, status) VALUES ('rocket', 50, 'active')`)
    const giftIds = { flower: 1, heart: 2, star: 3, rocket: 4 }
    for (let i = 0; i < 10; i++) {
      const giftType = ['flower', 'heart', 'star', 'rocket'][i % 4]
      await query(
        `INSERT INTO chat_gift_records (room_id, gift_id, from_user_id, to_user_id, quantity, create_time)
         VALUES (?, ?, ?, ?, ?, NOW())`,
        [1 + Math.floor(Math.random() * 4), giftIds[giftType], 2 + Math.floor(Math.random() * 14), 2 + Math.floor(Math.random() * 14), Math.floor(Math.random() * 9) + 1]
      )
    }
  }

  // === 充值订单 ===
  const rechargeCnt = await query('SELECT COUNT(*) as cnt FROM recharge_orders')
  if (!rechargeCnt[0].cnt) {
    console.log('  创建充值订单...')
    for (let i = 0; i < 12; i++) {
      const amount = [10, 30, 50, 98, 198, 298][i % 6]
      const status = i < 9 ? 'paid' : 'pending'
      const paidTime = status === 'paid' ? `NOW() - INTERVAL ${Math.floor(Math.random() * 30)} DAY` : 'NULL'
      await query(
        `INSERT INTO recharge_orders (order_no, user_id, amount, status, paid_time, create_time)
         VALUES ('RCH${Date.now()}${i}', ?, ?, ?, ${paidTime}, NOW() - INTERVAL ${Math.floor(Math.random() * 30)} DAY)`,
        [2 + Math.floor(Math.random() * 14), amount, status]
      )
    }
  }

  // === 关注关系 ===
  const followCnt = await query('SELECT COUNT(*) as cnt FROM user_follows')
  if (!followCnt[0].cnt) {
    console.log('  创建关注关系...')
    for (let i = 0; i < 25; i++) {
      const fid = 2 + Math.floor(Math.random() * 15)
      let tid = 2 + Math.floor(Math.random() * 15)
      if (tid === fid) tid = tid === 16 ? 2 : tid + 1
      await query(`INSERT IGNORE INTO user_follows (follower_id, following_id, create_time) VALUES (?, ?, NOW())`, [fid, tid])
    }
  }

  // === 黑名单 ===
  const blockCnt = await query('SELECT COUNT(*) as cnt FROM user_blocks')
  if (!blockCnt[0].cnt) {
    console.log('  创建拉黑记录...')
    for (let i = 0; i < 5; i++) {
      await query(`INSERT INTO user_blocks (blocker_id, blocked_id, create_time) VALUES (?, ?, NOW())`, [2 + i, 10 + i])
    }
  }

  // === 私信 ===
  const pmCnt = await query('SELECT COUNT(*) as cnt FROM private_messages')
  if (!pmCnt[0].cnt) {
    console.log('  创建私信...')
    for (let i = 0; i < 15; i++) {
      await query(
        `INSERT INTO private_messages (from_user_id, to_user_id, content, create_time)
         VALUES (?, ?, ?, NOW() - INTERVAL ${Math.floor(Math.random() * 7)} DAY)`,
        [2 + Math.floor(Math.random() * 14), 2 + Math.floor(Math.random() * 14), `你好，这是私信消息 #${i + 1}`]
      )
    }
  }

  // === 文件仓库 ===
  const fileCnt = await query('SELECT COUNT(*) as cnt FROM file_repository')
  if (!fileCnt[0].cnt) {
    console.log('  创建文件仓库...')
    const files = [
      ['uploads/avatar1.png', 'avatar1.png', 102400, 'image/png', 'avatar'],
      ['uploads/design.psd', 'design.psd', 2048000, 'application/psd', 'design'],
      ['uploads/report.pdf', 'report.pdf', 512000, 'application/pdf', 'document'],
      ['uploads/video.mp4', 'video.mp4', 10485760, 'video/mp4', 'video'],
      ['uploads/config.json', 'config.json', 2048, 'application/json', 'data'],
      ['uploads/image1.jpg', 'image1.jpg', 307200, 'image/jpeg', 'image'],
      ['uploads/icon.svg', 'icon.svg', 8192, 'image/svg+xml', 'icon'],
    ]
    for (const f of files) {
      await query(
        `INSERT INTO file_repository (file_path, file_name, file_size, mime_type, file_type, user_id, create_time)
         VALUES (?, ?, ?, ?, ?, ?, NOW())`, [...f, 2 + Math.floor(Math.random() * 14)]
      )
    }
  }

  // === 任务记录 ===
  const taskCnt = await query('SELECT COUNT(*) as cnt FROM custom_tasks')
  if (!taskCnt[0].cnt) {
    console.log('  创建任务记录...')
    const tasks = [
      ['每日签到', 10, 1, 'daily'],
      ['发帖奖励', 20, 1, 'post'],
      ['评论互动', 5, 1, 'comment'],
      ['邀请好友', 50, 1, 'invite'],
      ['完善资料', 30, 0, 'profile'],
    ]
    for (const t of tasks) {
      await query(
        `INSERT INTO custom_tasks (name, points_reward, status, task_type, create_time) VALUES (?, ?, ?, ?, NOW())`, t
      )
    }
    // 任务完成记录
    for (let i = 0; i < 20; i++) {
      await query(
        `INSERT INTO task_records (user_id, task_id, create_time) VALUES (?, ?, NOW() - INTERVAL ${Math.floor(Math.random() * 14)} DAY)`,
        [2 + Math.floor(Math.random() * 14), 1 + Math.floor(Math.random() * 5)]
      )
    }
  }

  // === 邀请码 ===
  const inviteCnt = await query('SELECT COUNT(*) as cnt FROM invite_codes')
  if (!inviteCnt[0].cnt) {
    console.log('  创建邀请码...')
    for (let i = 0; i < 10; i++) {
      const code = 'INV-' + Math.random().toString(36).substring(2, 8).toUpperCase()
      const status = i < 6 ? '1' : '0'
      await query(
        `INSERT INTO invite_codes (code, created_by, type, max_uses, use_count, status, create_time)
         VALUES (?, 1, 'admin', 10, ${status === '0' ? 10 : Math.floor(Math.random() * 5)}, ?, NOW())`, [code, status]
      )
    }
  }

  // === 蓝V认证 ===
  const verifyCnt = await query('SELECT COUNT(*) as cnt FROM verification_requests')
  if (!verifyCnt[0].cnt) {
    console.log('  创建蓝V认证申请...')
    for (let i = 0; i < 5; i++) {
      await query(
        `INSERT INTO verification_requests (user_id, real_name, id_card, organization, reason, status, create_time)
         VALUES (?, ?, ?, ?, ?, ?, NOW() - INTERVAL ${Math.floor(Math.random() * 20)} DAY)`,
        [2 + i, `用户${i+1}`, `4401${Math.floor(Math.random() * 100000000)}`, ['科技有限公司', '网络科技公司', '设计工作室'][i % 3], '申请蓝V认证', ['pending', 'approved', 'approved', 'rejected', 'pending'][i]]
      )
    }
  }

  // === 注销审核 ===
  const delCnt = await query('SELECT COUNT(*) as cnt FROM user_delete_requests')
  if (!delCnt[0].cnt) {
    console.log('  创建注销申请...')
    for (let i = 0; i < 3; i++) {
      await query(
        `INSERT INTO user_delete_requests (user_id, admin_note, status, create_time)
         VALUES (?, ?, ?, NOW() - INTERVAL ${Math.floor(Math.random() * 10)} DAY)`,
        [2 + Math.floor(Math.random() * 14), ['不再使用', '隐私原因', '账号太多'][i], ['pending', 'approved', 'rejected'][i]]
      )
    }
  }

  // === 称号 ===
  const titleCnt = await query('SELECT COUNT(*) as cnt FROM custom_titles')
  if (!titleCnt[0].cnt) {
    console.log('  创建称号...')
    const titles = [
      ['设计达人', '#FF4757', 'ri:palette-line'],
      ['技术大牛', '#0984E3', 'ri:code-box-line'],
      ['社区之星', '#FDCB6E', 'ri:star-line'],
      ['创作先锋', '#00B894', 'ri:quill-pen-line'],
      ['活跃分子', '#6C5CE7', 'ri:flashlight-line'],
      ['分享达人', '#E17055', 'ri:share-line'],
    ]
    for (const t of titles) {
      await query(`INSERT INTO custom_titles (name, color, icon, status) VALUES (?, ?, ?, '1')`, t)
    }
    // 分配称号给用户
    for (let i = 0; i < 8; i++) {
      await query(
        `INSERT IGNORE INTO user_titles (user_id, title_id, grant_time) VALUES (?, ?, NOW())`,
        [2 + Math.floor(Math.random() * 14), 1 + Math.floor(Math.random() * 6)]
      )
    }
  }

  // === 插件 ===
  const plugCnt = await query('SELECT COUNT(*) as cnt FROM plugins')
  if (!plugCnt[0].cnt) {
    console.log('  创建插件...')
    const plugins = [
      ['SEO优化', '内置SEO优化工具', '1.0.0', 1],
      ['数据统计', '网站数据统计分析', '1.2.0', 1],
      ['广告管理', '广告位管理插件', '0.9.0', 1],
      ['第三方登录', '支持微信/QQ/微博登录', '2.0.1', 0],
      ['地图组件', '集成高德地图组件', '1.1.0', 1],
    ]
    for (const p of plugins) {
      await query(`INSERT INTO plugins (name, description, version, enabled, create_time) VALUES (?, ?, ?, ?, NOW())`, p)
    }
  }

  // === 头像框 ===
  const avatarCnt = await query('SELECT COUNT(*) as cnt FROM avatar_frames')
  if (!avatarCnt[0].cnt) {
    console.log('  创建头像框...')
    const frames = [
      ['金色边框', 1],
      ['炫彩边框', 1],
      ['简约边框', 1],
      ['节日边框', 1],
    ]
    for (const f of frames) {
      await query(`INSERT INTO avatar_frames (name, status, create_time) VALUES (?, ?, NOW())`, f)
    }
    // 分配
    for (let i = 0; i < 5; i++) {
      await query(`INSERT IGNORE INTO user_avatar_frames (user_id, frame_id, obtain_time) VALUES (?, ?, NOW())`, [2 + Math.floor(Math.random() * 14), 1 + Math.floor(Math.random() * 4)])
    }
  }

  // === 推广返佣 ===
  const commCnt = await query('SELECT COUNT(*) as cnt FROM commission_records')
  if (!commCnt[0].cnt) {
    console.log('  创建推广返佣记录...')
    for (let i = 0; i < 8; i++) {
      const uid = 2 + Math.floor(Math.random() * 14)
      await query(
        `INSERT INTO commission_records (user_id, user_name, referrer_id, referrer_name, order_id, order_amount, amount, status, create_time)
         VALUES (?, ?, ?, ?, ${i + 1}, ${Math.floor(Math.random() * 200) + 50}, ${(Math.random() * 20 + 5).toFixed(2)}, 'completed', NOW() - INTERVAL ${Math.floor(Math.random() * 30)} DAY)`,
        [uid, `user${uid}`, uid + 1, `user${uid + 1}`]
      )
    }
  }
  // 返佣规则
  const ruleCnt = await query('SELECT COUNT(*) as cnt FROM commission_rules')
  if (!ruleCnt[0].cnt) {
    await query(`INSERT INTO commission_rules (user_level_id, rate, name, status) VALUES (1, 10, '一级返佣', '1')`)
    await query(`INSERT INTO commission_rules (user_level_id, rate, name, status) VALUES (2, 5, '二级返佣', '1')`)
  }

  // === 积分记录 ===
  const pointsCnt = await query('SELECT COUNT(*) as cnt FROM points_records')
  if (!pointsCnt[0].cnt) {
    console.log('  创建积分记录...')
    for (let i = 0; i < 30; i++) {
      const points = Math.floor(Math.random() * 50) + 10
      await query(
        `INSERT INTO points_records (user_id, points, type, description, create_time)
         VALUES (?, ?, ?, ?, NOW() - INTERVAL ${Math.floor(Math.random() * 30)} DAY)`,
        [2 + Math.floor(Math.random() * 14), points, ['checkin', 'post', 'comment', 'invite', 'purchase'][i % 5], `获得积分 +${points}`]
      )
    }
  }

  // === 提现记录 ===
  const wdCnt = await query('SELECT COUNT(*) as cnt FROM withdraw_records')
  if (!wdCnt[0].cnt) {
    console.log('  创建提现记录...')
    for (let i = 0; i < 8; i++) {
      const uid = 2 + Math.floor(Math.random() * 14)
      await query(
        `INSERT INTO withdraw_records (user_id, user_name, amount, status, method, create_time)
         VALUES (?, ?, ?, ?, ?, NOW() - INTERVAL ${Math.floor(Math.random() * 20)} DAY)`,
        [uid, `user${uid}`, (Math.random() * 100 + 10).toFixed(2), ['pending', 'completed', 'rejected'][i % 3], ['alipay', 'wechat'][i % 2]]
      )
    }
  }

  // === 内容购买 ===
  const cpCnt = await query('SELECT COUNT(*) as cnt FROM content_purchases')
  if (!cpCnt[0].cnt) {
    console.log('  创建内容购买记录...')
    for (let i = 0; i < 8; i++) {
      await query(
        `INSERT INTO content_purchases (user_id, content_id, content_type, amount, create_time)
         VALUES (?, ?, 'app', ${(Math.random() * 50 + 5).toFixed(2)}, NOW() - INTERVAL ${Math.floor(Math.random() * 30)} DAY)`,
        [2 + Math.floor(Math.random() * 14), 1 + Math.floor(Math.random() * 10)]
      )
    }
  }

  // === 经验记录 ===
  const expRecordCnt = await query('SELECT COUNT(*) as cnt FROM experience_records')
  if (!expRecordCnt[0].cnt) {
    console.log('  创建经验记录...')
    for (let i = 0; i < 20; i++) {
      await query(
        `INSERT INTO experience_records (user_id, amount, source, description, create_time)
         VALUES (?, ?, ?, ?, NOW() - INTERVAL ${Math.floor(Math.random() * 30)} DAY)`,
        [2 + Math.floor(Math.random() * 14), Math.floor(Math.random() * 100) + 10, ['daily', 'post', 'comment', 'checkin'][i % 4], `经验值增加`]
      )
    }
  }

  // === 订单 ===
  const orderCnt = await query('SELECT COUNT(*) as cnt FROM orders')
  if (!orderCnt[0].cnt) {
    console.log('  创建订单...')
    for (let i = 0; i < 10; i++) {
      await query(
        `INSERT INTO orders (order_no, buyer_id, order_type, total_amount, status, create_time)
         VALUES (CONCAT('ORD', UNIX_TIMESTAMP(), ${i}), ?, 'purchase', ?, ?, NOW() - INTERVAL ${Math.floor(Math.random() * 30)} DAY)`,
        [2 + Math.floor(Math.random() * 14), (Math.random() * 200 + 20).toFixed(2), ['paid', 'paid', 'completed', 'cancelled'][i % 4]]
      )
    }
  }

  // === 系统通知 ===
  const notifCnt = await query('SELECT COUNT(*) as cnt FROM sys_notifications')
  if (!notifCnt[0].cnt) {
    console.log('  创建系统通知...')
    for (let i = 0; i < 8; i++) {
      await query(
        `INSERT INTO sys_notifications (title, content, type, create_time)
         VALUES (?, ?, ?, NOW() - INTERVAL ${Math.floor(Math.random() * 14)} DAY)`,
        [`系统通知 #${i + 1}`, `这是一条重要的系统通知内容。`, ['system', 'announcement', 'update'][i % 3]]
      )
    }
  }

  // === 敏感词 ===
  const sensCnt = await query('SELECT COUNT(*) as cnt FROM sensitive_words')
  if (!sensCnt[0].cnt) {
    console.log('  创建敏感词...')
    const words = ['广告推广', '虚假信息', '恶意攻击', '非法内容', '侵权内容']
    for (const w of words) {
      await query(`INSERT INTO sensitive_words (word, category, create_time) VALUES (?, 'text', NOW())`, [w])
    }
  }

  // === 邮件配置 ===
  const emailCfgCnt = await query('SELECT COUNT(*) as cnt FROM email_config')
  if (!emailCfgCnt[0].cnt) {
    console.log('  创建邮件配置...')
    await query(`INSERT INTO email_config (host, port, user, password, from_name, enabled) VALUES ('smtp.example.com', 465, 'noreply@example.com', '******', 'ArtDesignPro', 1)`)
  }

  // === 邮件模板 ===
  const etplCnt = await query('SELECT COUNT(*) as cnt FROM email_templates')
  if (!etplCnt[0].cnt) {
    console.log('  创建邮件模板...')
    const tpls = ['注册验证', '密码重置', '订单通知', '活动推送']
    for (const t of tpls) {
      await query(`INSERT INTO email_templates (name, subject, html_content, status) VALUES (?, ?, ?, '1')`, [t, `${t}邮件`, `<p>${t}邮件模板内容</p>`])
    }
  }

  // === 邮件推送配置 ===
  const epushCnt = await query('SELECT COUNT(*) as cnt FROM email_push_config')
  if (!epushCnt[0].cnt) {
    await query(`INSERT INTO email_push_config (code, name, enabled) VALUES ('user_register', '用户注册', 1)`)
    await query(`INSERT INTO email_push_config (code, name, enabled) VALUES ('order_create', '订单创建', 1)`)
  }

  // === 存储配置 ===
  const storageCnt = await query('SELECT COUNT(*) as cnt FROM storage_configs')
  if (!storageCnt[0].cnt) {
    await query(`INSERT INTO storage_configs (name, type, endpoint, bucket, access_key, secret_key, region, is_default) VALUES ('默认存储', 'local', '', 'uploads', '', '', '', 1)`)
  }

  // === 推广链接 ===
  const refCnt = await query('SELECT COUNT(*) as cnt FROM referral_links')
  if (!refCnt[0].cnt) {
    console.log('  创建推广链接...')
    for (let i = 0; i < 5; i++) {
      await query(
        `INSERT IGNORE INTO referral_links (user_id, code, create_time) VALUES (?, ?, NOW())`,
        [2 + Math.floor(Math.random() * 14), 'REF-' + Math.random().toString(36).substring(2, 9)]
      )
    }
  }

  // === 会员购买 ===
  const memBuyCnt = await query('SELECT COUNT(*) as cnt FROM membership_purchases')
  if (!memBuyCnt[0].cnt) {
    console.log('  创建会员购买记录...')
    for (let i = 0; i < 6; i++) {
      await query(
        `INSERT INTO membership_purchases (user_id, level_id, level_name, amount, expire_time, create_time)
         VALUES (?, ?, ?, ?, NOW() + INTERVAL 365 DAY, NOW() - INTERVAL ${Math.floor(Math.random() * 60)} DAY)`,
        [2 + Math.floor(Math.random() * 14), 2 + Math.floor(Math.random() * 3), ['黄金会员', '钻石会员', '至尊会员'][i % 3], [299, 599, 999][i % 3]]
      )
    }
  }

  // === 结算配置 ===
  const settCnt = await query('SELECT COUNT(*) as cnt FROM settlement_config')
  if (!settCnt[0].cnt) {
    await query(`INSERT INTO settlement_config (level_name, confirm_days, enabled) VALUES ('默认结算', 7, 1)`)
  }

  // === 文件策略 ===
  const fpCnt = await query('SELECT COUNT(*) as cnt FROM file_policies')
  if (!fpCnt[0].cnt) {
    await query(`INSERT INTO file_policies (name, max_file_size_mb, allowed_types, status) VALUES ('默认策略', 10, 'jpg,png,gif,pdf,zip', 1)`)
    await query(`INSERT INTO file_policies (name, max_file_size_mb, allowed_types, status) VALUES ('图片策略', 5, 'jpg,png,gif,webp', 1)`)
  }

  // === 主题 ===
  const themeCnt = await query('SELECT COUNT(*) as cnt FROM themes')
  if (!themeCnt[0].cnt) {
    await query(`INSERT INTO themes (name, is_active) VALUES ('默认主题', 1)`)
  }

  // === 签到分组 ===
  const ckGroupCnt = await query('SELECT COUNT(*) as cnt FROM checkin_groups')
  if (!ckGroupCnt[0].cnt) {
    await query(`INSERT INTO checkin_groups (name, points, status) VALUES ('默认分组', 10, '1')`)
  }

  // === 应用评论 ===
  const appCommentCnt = await query('SELECT COUNT(*) as cnt FROM app_comments')
  if (!appCommentCnt[0].cnt) {
    console.log('  创建应用评论...')
    for (let i = 0; i < 12; i++) {
      await query(
        `INSERT IGNORE INTO app_comments (user_id, app_id, content, rating, create_time)
         VALUES (?, ?, ?, ?, NOW() - INTERVAL ${Math.floor(Math.random() * 60)} DAY)`,
        [2 + Math.floor(Math.random() * 14), 1 + Math.floor(Math.random() * 9), ['很好用', '推荐！', '不错', '还可以', '需要改进', '很棒的应用'][i % 6], Math.floor(Math.random() * 2) + 4]
      )
    }
  }

  // === 应用购买 ===
  const appBuyCnt = await query('SELECT COUNT(*) as cnt FROM app_purchases')
  if (!appBuyCnt[0].cnt) {
    console.log('  创建应用购买记录...')
    for (let i = 0; i < 6; i++) {
      await query(
        `INSERT IGNORE INTO app_purchases (user_id, app_id, paid_price, create_time)
         VALUES (?, ?, ?, NOW() - INTERVAL ${Math.floor(Math.random() * 60)} DAY)`,
        [2 + Math.floor(Math.random() * 14), 1 + Math.floor(Math.random() * 9), (Math.random() * 30 + 5).toFixed(2)]
      )
    }
  }

  // === 应用收藏 ===
  const appFavCnt = await query('SELECT COUNT(*) as cnt FROM app_favorites')
  if (!appFavCnt[0].cnt) {
    console.log('  创建应用收藏...')
    for (let i = 0; i < 15; i++) {
      await query(
        `INSERT IGNORE INTO app_favorites (user_id, app_id, create_time)
         VALUES (?, ?, NOW() - INTERVAL ${Math.floor(Math.random() * 60)} DAY)`,
        [2 + Math.floor(Math.random() * 14), 1 + Math.floor(Math.random() * 9)]
      )
    }
  }

  // === 应用版本 ===
  const appVerCnt = await query('SELECT COUNT(*) as cnt FROM app_versions')
  if (!appVerCnt[0].cnt) {
    console.log('  创建应用版本...')
    for (let i = 0; i < 8; i++) {
      const aid = 1 + Math.floor(Math.random() * 9)
      const ver = `${(Math.random() * 3 + 1).toFixed(1)}.${Math.floor(Math.random() * 9)}.${Math.floor(Math.random() * 9)}`
      await query(
        `INSERT INTO app_versions (app_id, version, version_code, update_content, create_time)
         VALUES (?, ?, ?, ?, NOW() - INTERVAL ${Math.floor(Math.random() * 60)} DAY)`,
        [aid, ver, Math.floor(Math.random() * 999), 'Bug修复和性能优化']
      )
    }
  }

  console.log('测试数据全部插入完成!')
  process.exit(0)
}

seedTestData().catch(e => { console.error(e); process.exit(1) })
