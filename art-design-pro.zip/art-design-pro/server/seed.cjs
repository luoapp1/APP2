const { query } = require('./database.cjs')
const bcrypt = require('bcryptjs')

async function seed() {
  try {
    const roles = await query('SELECT COUNT(*) as cnt FROM roles')
    if (roles && roles.length > 0 && roles[0].cnt > 0) {
      console.log('数据库已有角色数据，跳过种子数据')
      return
    }
  } catch (e) {
    console.log('检查现有数据失败，继续播种:', e.message)
  }

  console.log('初始化种子数据到 MySQL...')

  // 角色
  console.log('创建角色...')
  const roleData = [
    ['超级管理员', 'R_SUPER', '系统超级管理员', 1],
    ['管理员', 'R_ADMIN', '系统管理员', 1],
    ['普通用户', 'R_USER', '普通用户', 1]
  ]
  for (const r of roleData) {
    await query(
      `INSERT INTO roles (role_name, role_code, description, enabled) VALUES (?, ?, ?, ?)`, r
    )
  }

  // 菜单 - 合并所有阶段菜单
  console.log('创建菜单...')
  const menuCnt = await query('SELECT COUNT(*) as cnt FROM menus')
  if (!menuCnt[0].cnt) {
    const menus = [
      // === 一级菜单 ===
      [0, 'Dashboard', '/dashboard', '/index/index', '/dashboard/console', 'menus.dashboard.title', 'ri:pie-chart-line', 1, 0, 0, 0, 0, null, '["R_SUPER","R_ADMIN"]', 1],
      [0, 'Operation', '/operation', '/index/index', '', 'menus.operation.title', 'ri:settings-3-line', 2, 0, 0, 0, 0, null, '["R_SUPER","R_ADMIN"]', 1],
      [0, 'System', '/system', '/index/index', '', 'menus.system.title', 'ri:user-3-line', 3, 0, 0, 0, 0, null, '["R_SUPER","R_ADMIN"]', 1],
      [0, 'Result', '/result', '/index/index', '', 'menus.result.title', 'ri:checkbox-circle-line', 5, 0, 0, 0, 0, null, null, 1],
      [0, 'Exception', '/exception', '/index/index', '', 'menus.exception.title', 'ri:error-warning-line', 6, 0, 0, 0, 0, null, null, 1],
      [0, 'AppStore', '/appstore', '/index/index', '', 'menus.appstore.title', 'ri:apps-2-line', 4, 0, 0, 0, 0, null, '["R_SUPER","R_ADMIN","R_USER"]', 1],
      // === Dashboard 子菜单 ===
      [1, 'Console', 'console', '/dashboard/console', '', 'menus.dashboard.console', '', 1, 0, 0, 1, 1, null, null, 1],
      // === Operation 子菜单 ===
      [2, 'CardKey', 'cardkey', '/operation/cardkey/index', '', 'menus.operation.cardkey', '', 1, 0, 0, 1, 0, null, null, 1],
      [2, 'Membership', 'membership', '/operation/membership/index', '', 'menus.operation.membership', '', 2, 0, 0, 1, 0, null, null, 1],
      [2, 'Coupon', 'coupon', '/operation/coupon/index', '', 'menus.operation.coupon', '', 3, 0, 0, 1, 0, null, null, 1],
      [2, 'Points', 'points', '/operation/points/index', '', 'menus.operation.points', '', 4, 0, 0, 1, 0, null, null, 1],
      [2, 'ExperienceLevel', 'experience', '/operation/experience/index', '', 'menus.operation.experience', '', 5, 0, 0, 1, 0, null, null, 1],
      [2, 'Plugins', 'plugins', '/operation/plugins/index', '', 'menus.operation.plugins', '', 6, 0, 0, 1, 0, null, null, 1],
      [2, 'TitleManage', 'title', '/operation/title/index', '', '称号管理', '', 7, 0, 0, 1, 0, null, null, 1],
      [2, 'CommissionManage', 'commission', '/operation/commission/index', '', '推广返佣', '', 8, 0, 0, 1, 0, null, null, 1],
      [2, 'FilePolicyManage', 'filepolicy', '/operation/filepolicy/index', '', '文件上传策略', '', 9, 0, 0, 1, 0, null, null, 1],
      [2, 'Settlement', 'settlement', '/operation/settlement/index', '', '结算规则', 'ri:exchange-funds-line', 10, 0, 0, 1, 0, null, null, 1],
      [2, 'MembershipProducts', 'membership-products', '/operation/membership-products/index', '', '会员商品', '', 11, 0, 0, 1, 0, null, null, 1],
      [2, 'MembershipPurchases', 'membership-purchases', '/operation/membership-purchases/index', '', '购买记录', '', 12, 0, 0, 1, 0, null, null, 1],
      [2, 'ContentPurchases', 'content-purchases', '/operation/content-purchases/index', '', '付费内容订单', '', 13, 0, 0, 1, 0, null, null, 1],
      // === System 子菜单 ===
      [3, 'User', 'user', '/system/user', '', 'menus.system.user', '', 1, 0, 0, 1, 0, null, null, 1],
      [3, 'Role', 'role', '/system/role', '', 'menus.system.role', '', 2, 0, 0, 1, 0, null, null, 1],
      [3, 'UserCenter', 'user-center', '/system/user-center', '', 'menus.system.userCenter', '', 3, 1, 0, 1, 1, null, null, 1],
      [3, 'Menus', 'menu', '/system/menu', '', 'menus.system.menu', '', 4, 0, 0, 1, 0, JSON.stringify([{title:'新增',authMark:'add'},{title:'编辑',authMark:'edit'},{title:'删除',authMark:'delete'}]), null, 1],
      [3, 'DeleteReview', 'delete-review', '/system/user/delete-review', '', '注销审核', '', 5, 0, 0, 1, 0, null, null, 1],
      [3, 'Verification', 'verification', '/system/verification/index', '', '蓝V认证审核', '', 6, 0, 0, 1, 0, null, null, 1],
      [3, 'InviteManage', 'invite', '/system/invite/index', '', '邀请码管理', '', 7, 0, 0, 1, 0, null, null, 1],
      [3, 'EmailConfig', 'email', '/system/email/index', '', '邮件配置', '', 8, 0, 0, 1, 0, null, null, 1],
      [3, 'FileRepository', 'filerepo', '/system/filerepo/index', '', '文件仓库', '', 9, 0, 0, 1, 0, null, null, 1],
      [3, 'RecycleBin', 'recycle', '/system/recycle/index', '', '回收站', '', 10, 0, 0, 1, 0, null, null, 1],
      [3, 'SystemLog', 'syslog', '/system/syslog/index', '', '系统日志', '', 11, 0, 0, 1, 0, null, null, 1],
      [3, 'SysConfig', 'sysconfig', '/system/sysconfig/index', '', '系统配置', '', 12, 0, 0, 1, 0, null, null, 1],
      [3, 'CustomTask', 'task', '/system/task/index', '', '任务管理', '', 13, 0, 0, 1, 0, null, null, 1],
      [3, 'EmailTemplates', 'email-templates', '/appstore/email-templates', '', '邮件卡片', '', 14, 0, 0, 1, 0, null, null, 1],
      [3, 'EmailPush', 'email-push', '/appstore/email-push', '', '邮件推送', '', 15, 0, 0, 1, 0, null, null, 1],
      [3, 'StorageConfig', 'storage-config', '/appstore/storage-config', '', '对象存储', '', 16, 0, 0, 1, 0, null, null, 1],
      // === AppStore 子菜单 ===
      [6, 'AppStoreList', 'list', '/appstore/list', '', 'menus.appstore.list', '', 1, 0, 0, 1, 0, null, null, 1],
      [6, 'AppStoreDetail', 'detail/:id', '/appstore/detail', '', 'menus.appstore.detail', '', 2, 1, 0, 0, 0, null, null, 1],
      [6, 'AppCategory', 'category-manage', '/appstore/category', '', 'menus.appstore.category', 'ri:apps-2-line', 3, 0, 0, 1, 0, null, '["R_SUPER","R_ADMIN"]', 1],
      [6, 'AppReports', 'reports', '/appstore/reports', '', 'menus.appstore.reports', 'ri:apps-2-line', 4, 0, 0, 1, 0, null, '["R_SUPER","R_ADMIN"]', 1],
      [6, 'MySubmissions', 'my-submissions', '/appstore/submissions', '', 'menus.appstore.mySubmissions', '', 5, 0, 0, 1, 0, null, '["R_SUPER","R_ADMIN","R_USER"]', 1],
      [6, 'SubmissionReview', 'review', '/appstore/review', '', 'menus.appstore.review', '', 6, 0, 0, 1, 0, null, '["R_SUPER","R_ADMIN"]', 1],
      [6, 'SubmissionReviewMobile', 'review-mobile', '/appstore/review/mobile', '', 'menus.appstore.review', '', 7, 1, 0, 1, 0, null, '["R_SUPER","R_ADMIN"]', 1],
      [6, 'OfficialTags', 'official-tags', '/appstore/official-tags', '', 'menus.appstore.officialTags', '', 8, 0, 0, 1, 0, null, '["R_SUPER","R_ADMIN"]', 1],
    ]
    const sa = JSON.stringify
    // 社区权限菜单（隐藏）
    menus.push(
      [6, 'SectionManage', 'section-manage', '', '', '板块管理', '', 9, 1, 0, 0, 0, sa([{title:'新增',authMark:'add'},{title:'编辑',authMark:'edit'},{title:'删除',authMark:'delete'},{title:'管理版主',authMark:'moderate'},{title:'启停',authMark:'toggle'},{title:'处理解锁',authMark:'unlock'}]), '["R_SUPER","R_ADMIN"]', 1],
      [6, 'CommunityPostManage', 'community-posts', '', '', '帖子管理', '', 10, 1, 0, 0, 0, sa([{title:'置顶',authMark:'pin'},{title:'加精',authMark:'essence'},{title:'热帖',authMark:'boost'},{title:'锁定',authMark:'lock'},{title:'审核',authMark:'approve'},{title:'编辑',authMark:'edit'},{title:'删除',authMark:'delete'}]), '["R_SUPER","R_ADMIN"]', 1],
      [6, 'CommunityReportManage', 'community-reports', '', '', '举报管理', '', 11, 1, 0, 0, 0, sa([{title:'处理',authMark:'handle'},{title:'忽略',authMark:'ignore'},{title:'删除',authMark:'delete'}]), '["R_SUPER","R_ADMIN"]', 1],
      [6, 'CommunityCommentManage', 'community-comments', '', '', '评论管理', '', 12, 1, 0, 0, 0, sa([{title:'置顶',authMark:'pin'},{title:'删除',authMark:'delete'}]), '["R_SUPER","R_ADMIN"]', 1],
    )
    // === Result 子菜单 ===
    menus.push(
      [4, 'Success', 'success', '/result/success/index', '', 'menus.result.success', '', 1, 0, 1, 0, 0, null, null, 1],
      [4, 'Fail', 'fail', '/result/fail/index', '', 'menus.result.fail', '', 2, 0, 1, 0, 0, null, null, 1],
    )
    // === Exception 子菜单 ===
    menus.push(
      [5, 'Exception403', '403', '/exception/403/index', '', 'menus.exception.forbidden', '', 1, 0, 1, 0, 0, null, null, 1],
      [5, 'Exception404', '404', '/exception/404/index', '', 'menus.exception.notFound', '', 2, 0, 1, 0, 0, null, null, 1],
      [5, 'Exception500', '500', '/exception/500/index', '', 'menus.exception.serverError', '', 3, 0, 1, 0, 0, null, null, 1],
    )

    for (const m of menus) {
      await query(
        `INSERT INTO menus (parent_id, name, path, component, redirect, title, icon,
         sort_order, is_hidden, is_full_page, is_keep_alive, is_fixed_tab, auth_list, roles, enabled)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`, m
      )
    }
  }

  // 角色权限 — R_SUPER 和 R_ADMIN 拥有所有菜单
  console.log('创建角色权限...')
  const permCnt = await query('SELECT COUNT(*) as cnt FROM role_permissions')
  if (!permCnt[0].cnt) {
    const allMenus = await query('SELECT id FROM menus')
    const superRole = await query("SELECT id FROM roles WHERE role_code='R_SUPER'")
    const adminRole = await query("SELECT id FROM roles WHERE role_code='R_ADMIN'")
    const ignoreSQL = 'INSERT IGNORE INTO'

    if (superRole.length > 0) {
      for (const m of allMenus) {
        await query(`${ignoreSQL} role_permissions (role_id, menu_id) VALUES (?, ?)`, [superRole[0].id, m.id])
      }
    }
    if (adminRole.length > 0) {
      for (const m of allMenus) {
        await query(`${ignoreSQL} role_permissions (role_id, menu_id) VALUES (?, ?)`, [adminRole[0].id, m.id])
      }
    }
  }

  // 会员等级 - 只创建基础等级
  console.log('创建会员等级...')
  const lvCnt = await query('SELECT COUNT(*) as cnt FROM membership_levels')
  if (!lvCnt[0].cnt) {
    const lvs = [
      ['普通会员', 0, 0, 0, 1.0, 1.0, '#FFFFFF', '#508DFF', '基础权益', 'ri:user-line', '#909399', '1'],
      ['黄金会员', 1, 299, 3000, 0.9, 1.5, '#FFFFFF', '#508DFF', '9折优惠,1.5倍积分,专属客服', 'ri:vip-crown-line', '#ffb100', '1'],
      ['钻石会员', 2, 599, 6000, 0.8, 2.0, '#FFFFFF', '#508DFF', '8折优惠,2倍积分,专属客服,优先发货,生日礼包', 'ri:vip-diamond-line', '#377dff', '1'],
      ['至尊会员', 3, 999, 10000, 0.7, 3.0, '#FFFFFF', '#508DFF', '7折优惠,3倍积分,专属客服,优先发货,生日礼包,年度礼品', 'ri:star-line', '#ff6b6b', '1']
    ]
    for (const l of lvs) {
      await query(
        `INSERT INTO membership_levels (name, level, price, points_required, discount_rate, points_multiplier, text_color, bg_color, benefits, icon, icon_color, status)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`, l
      )
    }
  }

  // 超级管理员账号
  console.log('创建超级管理员账号...')
  const userCnt = await query('SELECT COUNT(*) as cnt FROM users')
  if (!userCnt[0].cnt) {
    const hash = bcrypt.hashSync('123456', 10)
    await query(
      `INSERT INTO users (username, password, password_hash, nickname, phone, email, gender, avatar, points, balance, experience, level_id, level_name, roles, status)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      ['alexmorgan', '123456', hash, 'Alex Morgan', '18670001591', 'alexmorgan@company.com', '男', '', 0, 0, 0, 0, '普通会员', '["R_SUPER"]', '1']
    )
  }

  console.log('种子数据初始化完成 (3 角色 + 菜单 + 权限 + 4 会员等级 + 7 经验等级 + 1 超级管理员)')

  // 经验等级
  console.log('创建经验等级...')
  const expCnt = await query('SELECT COUNT(*) as cnt FROM experience_levels')
  if (!expCnt[0].cnt) {
    const expLevels = [
      ['Lv.1', 1, 0, 'ri:star-line', '#00BFA5', '#FFFFFF', '#508DFF', '基础等级', '1'],
      ['Lv.2', 2, 100, 'ri:star-line', '#42A5F5', '#FFFFFF', '#508DFF', '解锁评论功能', '1'],
      ['Lv.3', 3, 500, 'ri:star-half-line', '#7C4DFF', '#FFFFFF', '#508DFF', '解锁发帖功能', '1'],
      ['Lv.4', 4, 1000, 'ri:star-half-fill', '#FFB74D', '#FFFFFF', '#508DFF', '解锁自定义头像', '1'],
      ['Lv.5', 5, 2000, 'ri:star-fill', '#FF6B6B', '#FFFFFF', '#508DFF', '解锁高级搜索', '1'],
      ['Lv.6', 6, 5000, 'ri:vip-crown-line', '#FFD700', '#FFFFFF', '#508DFF', '专属标识,优先客服', '1'],
      ['Lv.7', 7, 10000, 'ri:vip-crown-fill', '#FF4081', '#FFFFFF', '#508DFF', '全部权益,年度礼品', '1']
    ]
    for (const e of expLevels) {
      await query(
        `INSERT INTO experience_levels (name, level, exp_required, icon, icon_color, text_color, bg_color, benefits, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`, e
      )
    }
  }

  // 系统配置
  console.log('创建系统配置...')
  const cfgCnt = await query('SELECT COUNT(*) as cnt FROM sys_config')
  if (!cfgCnt[0].cnt) {
    const configs = [
      ['system_log_enabled', 'true', '系统日志总开关'],
      ['log_enabled_login', 'true', '登录日志开关'],
      ['log_enabled_user', 'true', '用户操作日志开关'],
      ['log_enabled_operation', 'true', '运营管理日志开关'],
      ['log_enabled_content', 'true', '内容管理日志开关'],
      ['log_enabled_system', 'true', '系统配置日志开关'],
      ['invite_user_enabled', 'false', '用户生成邀请码开关'],
      ['invite_user_max', '5', '用户最大可生成邀请码数'],
      ['register_invite_required', 'false', '注册必须邀请码'],
      ['commission_enabled', 'false', '推广返佣开关'],
      ['commission_mode', 'purchase', '返佣模式'],
      ['points_transfer_enabled', 'false', '积分转账开关'],
      ['points_transfer_fee', '0', '积分转账手续费比例%'],
      ['balance_transfer_enabled', 'false', '余额转账开关'],
      ['balance_transfer_fee', '0', '余额转账手续费比例%'],
      ['points_purchase_enabled', 'false', '积分购买开关'],
      ['points_purchase_rate', '1', '1元等于多少积分'],
      ['content_split_enabled', 'true', '创作分成开关'],
      ['content_split_global_rate', '70', '创作分成全局比例%'],
      ['checkin_enabled', 'true', '签到功能开关']
    ]
    for (const c of configs) {
      await query(
        `INSERT INTO sys_config (config_key, config_value, description) VALUES (?, ?, ?)`, c
      )
    }
  }

  console.log('种子数据初始化完成 (3 角色 + 菜单 + 权限 + 4 会员等级 + 7 经验等级 + 系统配置 + 1 超级管理员)')
}

seed().catch(e => { console.error('种子数据错误:', e.message); process.exit(1) })
