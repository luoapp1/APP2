const { query, dbType } = require('./database.cjs')

async function seed() {
  try {
    const levels = await query('SELECT COUNT(*) as cnt FROM membership_levels')
    const cnt = levels && levels.length > 0 ? levels[0].cnt : 0
    if (cnt && cnt > 0) {
      console.log('数据库已有数据，跳过种子数据')
      return
    }
  } catch (e) {
    console.log('检查现有数据失败，继续播种:', e.message)
  }

  console.log('初始化种子数据到 ' + dbType.toUpperCase() + '...')

  // 角色
  try {
    const roleCnt = await query('SELECT COUNT(*) as cnt FROM roles')
    if (!roleCnt[0].cnt) {
      const roleData = [
        ['超级管理员', 'R_SUPER', '系统超级管理员', 1],
        ['管理员', 'R_ADMIN', '系统管理员', 1],
        ['普通用户', 'R_USER', '普通用户', 1]
      ]
      for (const r of roleData) {
        await query(
          `INSERT INTO roles (role_name, role_code, description, enabled) VALUES (?, ?, ?, ?)`, r
        )
      }
    }
  } catch {}

  // 菜单
  try {
    const menuCnt = await query('SELECT COUNT(*) as cnt FROM menus')
    if (!menuCnt[0].cnt) {
      const menus = [
        [0, 'Dashboard', '/dashboard', '/index/index', '/dashboard/console', 'menus.dashboard.title', 'ri:pie-chart-line', 1, 0, 0, 0, 0, null, '["R_SUPER","R_ADMIN"]', 1],
        [1, 'Console', 'console', '/dashboard/console', '', 'menus.dashboard.console', '', 1, 0, 0, 1, 1, null, null, 1],
        [0, 'Operation', '/operation', '/index/index', '', 'menus.operation.title', 'ri:settings-3-line', 2, 0, 0, 0, 0, null, '["R_SUPER","R_ADMIN"]', 1],
        [3, 'CardKey', 'cardkey', '/operation/cardkey/index', '', 'menus.operation.cardkey', '', 1, 0, 0, 1, 0, null, null, 1],
        [3, 'Membership', 'membership', '/operation/membership/index', '', 'menus.operation.membership', '', 2, 0, 0, 1, 0, null, null, 1],
        [3, 'Points', 'points', '/operation/points/index', '', 'menus.operation.points', '', 3, 0, 0, 1, 0, null, null, 1],
        [3, 'ExperienceLevel', 'experience', '/operation/experience/index', '', 'menus.operation.experience', '', 4, 0, 0, 1, 0, null, null, 1],
        [3, 'Plugins', 'plugins', '/operation/plugins/index', '', 'menus.operation.plugins', '', 5, 0, 0, 1, 0, null, null, 1],
        [0, 'System', '/system', '/index/index', '', 'menus.system.title', 'ri:user-3-line', 3, 0, 0, 0, 0, null, '["R_SUPER","R_ADMIN"]', 1],
        [7, 'User', 'user', '/system/user', '', 'menus.system.user', '', 1, 0, 0, 1, 0, null, null, 1],
        [7, 'Role', 'role', '/system/role', '', 'menus.system.role', '', 2, 0, 0, 1, 0, null, null, 1],
        [7, 'UserCenter', 'user-center', '/system/user-center', '', 'menus.system.userCenter', '', 3, 1, 0, 1, 1, null, null, 1],
          [7, 'Menus', 'menu', '/system/menu', '', 'menus.system.menu', '', 4, 0, 0, 1, 0, JSON.stringify([{title:'新增',authMark:'add'},{title:'编辑',authMark:'edit'},{title:'删除',authMark:'delete'}]), null, 1],
        [7, 'DeleteReview', 'delete-review', '/system/user/delete-review', '', '注销审核', '', 5, 0, 0, 1, 0, null, null, 1],
        [0, 'Result', '/result', '/index/index', '', 'menus.result.title', 'ri:checkbox-circle-line', 5, 0, 0, 0, 0, null, null, 1],
        [16, 'Success', 'success', '/result/success/index', '', 'menus.result.success', '', 1, 0, 1, 0, 0, null, null, 1],
        [16, 'Fail', 'fail', '/result/fail/index', '', 'menus.result.fail', '', 2, 0, 1, 0, 0, null, null, 1],
        [0, 'Exception', '/exception', '/index/index', '', 'menus.exception.title', 'ri:error-warning-line', 6, 0, 0, 0, 0, null, null, 1],
        [19, 'Exception403', '403', '/exception/403/index', '', 'menus.exception.forbidden', '', 1, 0, 1, 0, 0, null, null, 1],
        [19, 'Exception404', '404', '/exception/404/index', '', 'menus.exception.notFound', '', 2, 0, 1, 0, 0, null, null, 1],
        [19, 'Exception500', '500', '/exception/500/index', '', 'menus.exception.serverError', '', 3, 0, 1, 0, 0, null, null, 1]
      ]
      for (const m of menus) {
        await query(
          `INSERT INTO menus (parent_id, name, path, component, redirect, title, icon,
           sort_order, is_hidden, is_full_page, is_keep_alive, is_fixed_tab, auth_list, roles, enabled)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`, m
        )
      }
    }
  } catch {}

  // 角色权限 — R_SUPER 拥有所有菜单
  try {
    const permCnt = await query('SELECT COUNT(*) as cnt FROM role_permissions')
    if (!permCnt[0].cnt) {
      const allMenus = await query('SELECT id FROM menus')
      for (const m of allMenus) {
        await query('INSERT INTO role_permissions (role_id, menu_id) VALUES (?, ?)', [1, m.id])
      }
    }
  } catch {}

  // 会员等级
  const lvs = [
    ['普通会员', 0, 0, 0, 1.0, 1.0, '基础权益', 'ri:user-line', '#909399', '1'],
    ['黄金会员', 1, 299, 3000, 0.9, 1.5, '9折优惠,1.5倍积分,专属客服', 'ri:vip-crown-line', '#ffb100', '1'],
    ['钻石会员', 2, 599, 6000, 0.8, 2.0, '8折优惠,2倍积分,专属客服,优先发货,生日礼包', 'ri:vip-diamond-line', '#377dff', '1'],
    ['至尊会员', 3, 999, 10000, 0.7, 3.0, '7折优惠,3倍积分,专属客服,优先发货,生日礼包,年度礼品', 'ri:star-line', '#ff6b6b', '1']
  ]
  for (const l of lvs) {
    await query(
      `INSERT INTO membership_levels (name, level, price, points_required, discount_rate, points_multiplier, benefits, icon, icon_color, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`, l
    )
  }

  // 用户
  const users = [
    ['alexmorgan', '123456', '18670001591', 'alexmorgan@company.com', '男', 'avatar:1', 3250, 2, '钻石会员', '2027-06-01 00:00:00', '["R_SUPER"]'],
    ['sophiabaker', '123456', '17766664444', 'sophiabaker@company.com', '女', 'avatar:2', 1800, 1, '黄金会员', '2027-03-20 00:00:00', '["R_ADMIN"]'],
    ['liampark', '123456', '18670001597', 'liampark@company.com', '男', 'avatar:3', 450, 0, '普通会员', null, '["R_ADMIN"]'],
    ['emilywang', '123456', '18888881111', 'emilywang@company.com', '女', 'avatar:4', 8200, 3, '至尊会员', '2028-01-01 00:00:00', '["R_ADMIN"]'],
    ['davidchen', '123456', '16655550001', 'davidchen@company.com', '男', 'avatar:5', 2200, 1, '黄金会员', '2027-07-15 00:00:00', '["R_USER"]'],
    ['saraliu', '123456', '15533330002', 'saraliu@company.com', '女', 'avatar:6', 120, 0, '普通会员', null, '["R_USER"]'],
    ['mikezhang', '123456', '13322220003', 'mikezhang@company.com', '男', 'avatar:7', 5500, 2, '钻石会员', '2027-09-10 00:00:00', '["R_USER"]'],
    ['lisawu', '123456', '13711110004', 'lisawu@company.com', '女', 'avatar:8', 680, 0, '普通会员', null, '["R_USER"]']
  ]
  for (const u of users) {
    await query(
      `INSERT INTO users (username, password, phone, email, gender, avatar, points, level_id, level_name, expire_time, roles) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`, u
    )
  }

  // 卡密
  const cards = [
    ['ART-1001-ABCD-EFGH', 'A1B2C3D4', 'membership', 1, '黄金会员', 1, 12, '月', '0', '2026-06-01 10:00:00'],
    ['ART-1002-IJKL-MNOP', 'E5F6G7H8', 'points', 0, '500积分', 500, 0, '', '0', '2026-06-02 11:00:00'],
    ['ART-1003-QRST-UVWX', 'I9J0K1L2', 'membership', 2, '钻石会员', 1, 6, '月', '0', '2026-06-03 12:00:00'],
    ['ART-1004-YZAB-CDEF', 'M3N4O5P6', 'points', 0, '2000积分', 2000, 0, '', '0', '2026-06-04 13:00:00'],
    ['ART-1005-GHIJ-KLMN', 'Q7R8S9T0', 'membership', 0, '普通会员', 1, 12, '月', '0', '2026-06-05 14:00:00'],
    ['ART-1006-OPQR-STUV', 'U1V2W3X4', 'points', 0, '1000积分', 1000, 0, '', '0', '2026-06-06 15:00:00'],
    ['ART-1007-WXYZ-ABCD', 'Y5Z6A7B8', 'membership', 1, '黄金会员', 1, 3, '月', '0', '2026-06-07 16:00:00'],
    ['ART-1008-EFGH-IJKL', 'C9D0E1F2', 'points', 0, '3000积分', 3000, 0, '', '0', '2026-06-08 17:00:00'],
    ['ART-1009-MNOP-QRST', 'G3H4I5J6', 'membership', 2, '钻石会员', 1, 1, '年', '0', '2026-06-09 18:00:00'],
    ['ART-1010-UVWX-YZAB', 'K7L8M9N0', 'points', 0, '5000积分', 5000, 0, '', '0', '2026-06-10 19:00:00'],
    ['ART-1011-CDEF-GHIJ', 'O1P2Q3R4', 'membership', 0, '普通会员', 1, 1, '年', '0', '2026-06-11 20:00:00'],
    ['ART-1012-KLMN-OPQR', 'S5T6U7V8', 'points', 0, '800积分', 800, 0, '', '0', '2026-06-12 21:00:00']
  ]
  for (const c of cards) {
    await query(
      `INSERT INTO card_keys (card_no, password, type, target_id, target_name, value, duration, duration_unit, status, create_by, create_time) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, '管理员', ?)`, c
    )
  }

  // 积分记录
  const pointsRecords = [
    [1, 'alexmorgan', 'earn', 500, 3750, '卡密兑换', '卡密 ART-1005 兑换500积分', '2026-06-15 10:00:00'],
    [1, 'alexmorgan', 'redeem', -300, 3250, '商城兑换', '兑换优惠券', '2026-06-14 15:00:00'],
    [2, 'sophiabaker', 'earn', 200, 2000, '签到奖励', '连续签到7天奖励', '2026-06-15 08:00:00'],
    [2, 'sophiabaker', 'redeem', -200, 1800, '会员升级', '积分兑换会员升级抵扣', '2026-06-13 11:00:00'],
    [3, 'liampark', 'earn', 100, 550, '每日签到', '每日签到奖励', '2026-06-15 09:00:00'],
    [3, 'liampark', 'redeem', -50, 450, '抽奖消耗', '积分抽奖', '2026-06-12 14:00:00'],
    [4, 'emilywang', 'earn', 1000, 9200, '卡密兑换', '卡密 ART-1002 兑换1000积分', '2026-06-15 11:00:00'],
    [4, 'emilywang', 'earn', 500, 8200, '活动奖励', '618活动积分奖励', '2026-06-10 10:00:00'],
    [5, 'davidchen', 'earn', 300, 2500, '购物返积分', '购物消费返积分', '2026-06-14 16:00:00'],
    [5, 'davidchen', 'redeem', -100, 2200, '兑换礼品', '积分兑换实物礼品', '2026-06-10 09:00:00'],
    [6, 'saraliu', 'earn', 50, 170, '新用户奖励', '新用户注册积分奖励', '2026-06-10 12:00:00'],
    [6, 'saraliu', 'adjust', 100, 120, '管理员调整', '管理员手动调整积分', '2026-06-08 11:00:00'],
    [7, 'mikezhang', 'earn', 800, 6300, '卡密兑换', '卡密 ART-1003 兑换800积分', '2026-06-15 14:00:00'],
    [7, 'mikezhang', 'redeem', -500, 5500, '积分兑换会员', '积分兑换钻石会员', '2026-06-01 10:00:00'],
    [8, 'lisawu', 'earn', 200, 880, '分享奖励', '分享APP给好友奖励', '2026-06-13 13:00:00'],
    [8, 'lisawu', 'expire', -200, 680, '积分过期', '2025年度积分自动过期', '2025-12-31 23:59:59']
  ]
  for (const p of pointsRecords) {
    await query(
      `INSERT INTO points_records (user_id, user_name, type, points, balance, source, description, create_time) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`, p
    )
  }

  // 经验等级
  try {
    const expCnt = await query('SELECT COUNT(*) as cnt FROM experience_levels')
    if (!expCnt[0].cnt) {
      const expLevels = [
        ['Lv.1', 1, 0, 'ri:star-line', '#00BFA5', '基础等级', '1'],
        ['Lv.2', 2, 100, 'ri:star-line', '#42A5F5', '解锁评论功能', '1'],
        ['Lv.3', 3, 500, 'ri:star-half-line', '#7C4DFF', '解锁发帖功能', '1'],
        ['Lv.4', 4, 1000, 'ri:star-half-fill', '#FFB74D', '解锁自定义头像', '1'],
        ['Lv.5', 5, 2000, 'ri:star-fill', '#FF6B6B', '解锁高级搜索', '1'],
        ['Lv.6', 6, 5000, 'ri:vip-crown-line', '#FFD700', '专属标识,优先客服', '1'],
        ['Lv.7', 7, 10000, 'ri:vip-crown-fill', '#FF4081', '全部权益,年度礼品', '1']
      ]
      for (const e of expLevels) {
        await query(
          `INSERT INTO experience_levels (name, level, exp_required, icon, icon_color, benefits, status) VALUES (?, ?, ?, ?, ?, ?, ?)`, e
        )
      }
    }
  } catch {}

  // 插件
  try {
    const pluginCnt = await query('SELECT COUNT(*) as cnt FROM plugins')
    if (!pluginCnt[0].cnt) {
      await query(
        `INSERT INTO plugins (name, description, version, author, component_name, status) VALUES (?, ?, ?, ?, ?, ?)`,
        ['游戏中心', '游戏大厅插件示例', '1.0.0', 'Admin', 'GamePlugin', '1']
      )
    }
  } catch {}

  console.log('种子数据初始化完成 (12 卡密 + 4 等级 + 8 用户 + 16 积分记录 + 1 应用)')

  // 应用商店
  const screenshots = JSON.stringify([
    { image: '', text: '全网爱优腾可看', bgColor: '#00BFA5' },
    { image: '', text: '无广告在线秒播', bgColor: '#2979FF' },
    { image: '', text: '免费无限制下载', bgColor: '#7C4DFF' }
  ])
  const tags = JSON.stringify(['星选', '官方版', '视频播放', '64Bit'])
  await query(
    `INSERT INTO app_store (name, package_name, version, version_code, icon, icon_bg_color, size_mb, downloads, rating, description, update_content, screenshots, tags, coin_count, coin_people, developer, category, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    ['神奇影视', 'com.yfoo.miracle.film', '1.3.0', '130', '', '#00BFA5', 32.5, 0, 0,
     '神奇影视是一款非常牛哔的追剧神器，提供了丰富的影视内容，无论是想看电影、电视剧、综艺、动漫，皆可免费在线观看，多个影视线路，根本不愁没有看到的影视资源。',
     '暂无',
     screenshots, tags, 144, 68, '神奇影视团队', '视频播放', '1']
  )

  // 应用评论
  const comments = [
    [1, '527', '#FF5777', 'vivo v2118a', '1.3.0', '这是啥破软件呢，一个都播放不出来', 2, 0, 0, '2025-02-15 10:00:00'],
    [1, '707235406', '#448AFF', 'oneplus pkg110', '1.3.0', '看不了啊', 1, 1, 0, '2024-12-20 15:30:00'],
    [1, '阿水', '#FFB74D', 'xiaomi 14', '1.3.0', '免费无广的影视播放软件，非常好用', 5, 3, 5.0, '2025-04-10 09:00:00']
  ]
  for (const c of comments) {
    await query(
      `INSERT INTO app_comments (app_id, user_name, user_avatar, device, version, content, likes, replies, rating, create_time) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`, c
    )
  }

  // AppStore 菜单 (如果不存在则创建)
  const appstoreMenuCnt = await query("SELECT COUNT(*) as cnt FROM menus WHERE name='AppStore'")
  if (!appstoreMenuCnt[0].cnt) {
    // 找到当前最大 sort_order 用于新菜单
    const maxSort = await query('SELECT MAX(sort_order) as ms FROM menus WHERE parent_id=0')
    const nextSort = (maxSort[0]?.ms || 0) + 1
    await query(
       `INSERT INTO menus (parent_id, name, path, component, redirect, title, icon, sort_order, is_hidden, is_full_page, is_keep_alive, is_fixed_tab, auth_list, roles, enabled)
        VALUES (0, 'AppStore', '/appstore', '/index/index', '', 'menus.appstore.title', 'ri:apps-2-line', ?, 0, 0, 0, 0, NULL, '["R_SUPER","R_ADMIN","R_USER"]', 1)`,
       [nextSort]
     )
    const appstoreId = (await query("SELECT id FROM menus WHERE name='AppStore'"))[0].id
    await query(
      `INSERT INTO menus (parent_id, name, path, component, redirect, title, icon, sort_order, is_hidden, is_full_page, is_keep_alive, is_fixed_tab, auth_list, roles, enabled)
       VALUES (?, 'AppStoreList', 'list', '/appstore/list', '', 'menus.appstore.list', '', 1, 0, 0, 1, 0, NULL, NULL, 1)`,
      [appstoreId]
    )
    await query(
      `INSERT INTO menus (parent_id, name, path, component, redirect, title, icon, sort_order, is_hidden, is_full_page, is_keep_alive, is_fixed_tab, auth_list, roles, enabled)
       VALUES (?, 'AppStoreDetail', 'detail/:id', '/appstore/detail', '', 'menus.appstore.detail', '', 2, 1, 0, 0, 0, NULL, NULL, 1)`,
       [appstoreId]
    )
    await query(
      `INSERT INTO menus (parent_id, name, path, component, redirect, title, icon, sort_order, is_hidden, is_full_page, is_keep_alive, is_fixed_tab, auth_list, roles, enabled)
       VALUES (?, 'AppCategory', 'category-manage', '/appstore/category', '', 'menus.appstore.category', 'ri:apps-2-line', 3, 0, 0, 1, 0, NULL, '["R_SUPER","R_ADMIN"]', 1)`,
      [appstoreId]
    )
    await query(
      `INSERT INTO menus (parent_id, name, path, component, redirect, title, icon, sort_order, is_hidden, is_full_page, is_keep_alive, is_fixed_tab, auth_list, roles, enabled)
       VALUES (?, 'AppReports', 'reports', '/appstore/reports', '', 'menus.appstore.reports', 'ri:apps-2-line', 4, 0, 0, 1, 0, NULL, '["R_SUPER","R_ADMIN"]', 1)`,
      [appstoreId]
    )
    await query(
      `INSERT INTO menus (parent_id, name, path, component, redirect, title, icon, sort_order, is_hidden, is_full_page, is_keep_alive, is_fixed_tab, auth_list, roles, enabled)
       VALUES (?, 'MySubmissions', 'my-submissions', '/appstore/submissions', '', 'menus.appstore.mySubmissions', '', 5, 0, 0, 1, 0, NULL, '["R_SUPER","R_ADMIN","R_USER"]', 1)`,
      [appstoreId]
    )
     await query(
       `INSERT INTO menus (parent_id, name, path, component, redirect, title, icon, sort_order, is_hidden, is_full_page, is_keep_alive, is_fixed_tab, auth_list, roles, enabled)
        VALUES (?, 'SubmissionReview', 'review', '/appstore/review', '', 'menus.appstore.review', '', 6, 0, 0, 1, 0, NULL, '["R_SUPER","R_ADMIN"]', 1)`,
       [appstoreId]
     )
     await query(
       `INSERT INTO menus (parent_id, name, path, component, redirect, title, icon, sort_order, is_hidden, is_full_page, is_keep_alive, is_fixed_tab, auth_list, roles, enabled)
        VALUES (?, 'SubmissionReviewMobile', 'review-mobile', '/appstore/review/mobile', '', 'menus.appstore.review', '', 7, 1, 0, 1, 0, NULL, '["R_SUPER","R_ADMIN"]', 1)`,
       [appstoreId]
     )
     await query(
       `INSERT INTO menus (parent_id, name, path, component, redirect, title, icon, sort_order, is_hidden, is_full_page, is_keep_alive, is_fixed_tab, auth_list, roles, enabled)
        VALUES (?, 'OfficialTags', 'official-tags', '/appstore/official-tags', '', 'menus.appstore.officialTags', '', 8, 0, 0, 1, 0, NULL, '["R_SUPER","R_ADMIN"]', 1)`,
       [appstoreId]
     )
     // 社区权限菜单（隐藏，仅用于权限分配）
     await query(
       `INSERT INTO menus (parent_id, name, path, component, redirect, title, icon, sort_order, is_hidden, is_full_page, is_keep_alive, is_fixed_tab, auth_list, roles, enabled)
        VALUES (?, 'SectionManage', 'section-manage', '', '', '板块管理', '', 9, 1, 0, 0, 0, ?, '["R_SUPER","R_ADMIN"]', 1)`,
        [appstoreId, JSON.stringify([{title:'新增',authMark:'add'},{title:'编辑',authMark:'edit'},{title:'删除',authMark:'delete'},{title:'管理版主',authMark:'moderate'},{title:'启停',authMark:'toggle'},{title:'处理解锁',authMark:'unlock'}])]
     )
     await query(
       `INSERT INTO menus (parent_id, name, path, component, redirect, title, icon, sort_order, is_hidden, is_full_page, is_keep_alive, is_fixed_tab, auth_list, roles, enabled)
        VALUES (?, 'CommunityPostManage', 'community-posts', '', '', '帖子管理', '', 10, 1, 0, 0, 0, ?, '["R_SUPER","R_ADMIN"]', 1)`,
       [appstoreId, JSON.stringify([{title:'置顶',authMark:'pin'},{title:'加精',authMark:'essence'},{title:'热帖',authMark:'hot'},{title:'审核',authMark:'approve'},{title:'编辑',authMark:'edit'},{title:'删除',authMark:'delete'}])]
     )
     await query(
       `INSERT INTO menus (parent_id, name, path, component, redirect, title, icon, sort_order, is_hidden, is_full_page, is_keep_alive, is_fixed_tab, auth_list, roles, enabled)
        VALUES (?, 'CommunityReportManage', 'community-reports', '', '', '举报管理', '', 11, 1, 0, 0, 0, ?, '["R_SUPER","R_ADMIN"]', 1)`,
       [appstoreId, JSON.stringify([{title:'处理',authMark:'handle'},{title:'删除',authMark:'delete'}])]
     )
     await query(
       `INSERT INTO menus (parent_id, name, path, component, redirect, title, icon, sort_order, is_hidden, is_full_page, is_keep_alive, is_fixed_tab, auth_list, roles, enabled)
        VALUES (?, 'CommunityCommentManage', 'community-comments', '', '', '评论管理', '', 12, 1, 0, 0, 0, ?, '["R_SUPER","R_ADMIN"]', 1)`,
       [appstoreId, JSON.stringify([{title:'置顶',authMark:'pin'},{title:'删除',authMark:'delete'}])]
     )
     // 给 R_SUPER 分配权限
     const superRole = await query("SELECT id FROM roles WHERE role_code='R_SUPER'")
     if (superRole[0]) {
       const newMenus = await query("SELECT id FROM menus WHERE name IN ('AppStore','AppStoreList','AppStoreDetail','AppCategory','AppReports','MySubmissions','SubmissionReview','SubmissionReviewMobile','OfficialTags','SectionManage','CommunityPostManage','CommunityReportManage','CommunityCommentManage')")
      for (const m of newMenus) {
        await query('INSERT OR IGNORE INTO role_permissions (role_id, menu_id) VALUES (?, ?)', [superRole[0].id, m.id])
      }
      const adminRole = await query("SELECT id FROM roles WHERE role_code='R_ADMIN'")
      if (adminRole[0]) {
        for (const m of newMenus) {
          await query('INSERT OR IGNORE INTO role_permissions (role_id, menu_id) VALUES (?, ?)', [adminRole[0].id, m.id])
        }
      }
    }
    console.log('应用商店菜单已创建')
  }
}

seed().catch(e => { console.error('种子数据错误:', e.message); process.exit(1) })

// 应用商店种子（始终执行，与主seed独立）
async function seedAppStore() {
  try {
    // APP数据
    const appCnt = await query('SELECT COUNT(*) as cnt FROM app_store')
    if (!appCnt[0].cnt) {
      const screenshots = JSON.stringify([
        { image: '', text: '全网爱优腾可看', bgColor: '#00BFA5' },
        { image: '', text: '无广告在线秒播', bgColor: '#2979FF' },
        { image: '', text: '免费无限制下载', bgColor: '#7C4DFF' }
      ])
      const tags = JSON.stringify(['星选', '官方版', '视频播放', '64Bit'])
      await query(
        `INSERT INTO app_store (name, package_name, version, version_code, icon, icon_bg_color, size_mb, downloads, rating, description, update_content, screenshots, tags, coin_count, coin_people, developer, category, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        ['神奇影视', 'com.yfoo.miracle.film', '1.3.0', '130', '', '#00BFA5', 32.5, 0, 0,
         '神奇影视是一款非常牛哔的追剧神器，提供了丰富的影视内容，无论是想看电影、电视剧、综艺、动漫，皆可免费在线观看，多个影视线路，根本不愁没有看到的影视资源。',
         '暂无', screenshots, tags, 144, 68, '神奇影视团队', '视频播放', '1']
      )

      const comments = [
        [1, '527', '#FF5777', 'vivo v2118a', '1.3.0', '这是啥破软件呢，一个都播放不出来', 2, 0, 0, '2025-02-15 10:00:00'],
        [1, '707235406', '#448AFF', 'oneplus pkg110', '1.3.0', '看不了啊', 1, 1, 0, '2024-12-20 15:30:00'],
        [1, '阿水', '#FFB74D', 'xiaomi 14', '1.3.0', '免费无广的影视播放软件，非常好用', 5, 3, 5.0, '2025-04-10 09:00:00']
      ]
      for (const c of comments) {
        await query(
          `INSERT INTO app_comments (app_id, user_name, user_avatar, device, version, content, likes, replies, rating, create_time) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`, c
        )
      }
      console.log('应用商店种子数据已初始化')

      // 版本数据
      const versions = [
        [1, '1.3.3', '133', 33.2, 1700, 0, '修复若干问题，提升稳定性', '["官方"]', 1, 1, 'alexmorgan', '2026-06-20 08:00:00'],
        [1, '1.3.1', '131', 32.5, 1100, 0, '优化播放体验', '["官方"]', 0, 1, 'alexmorgan', '2026-05-15 10:00:00'],
        [1, '1.3.0', '130', 32.5, 9000, 0, '全新UI界面', '["官方"]', 0, 1, 'alexmorgan', '2025-08-07 14:00:00'],
        [1, '1.2.0', '120', 32.5, 42000, 7.1, '新增投币功能', '["星选"]', 0, 1, 'alexmorgan', '2025-03-01 09:00:00']
      ]
      for (const v of versions) {
        await query(
          `INSERT INTO app_versions (app_id, version, version_code, size_mb, downloads, rating, update_content, tags, is_current, user_id, user_name, create_time) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`, v
        )
      }
    }

    // 菜单
    const menuCnt = await query("SELECT COUNT(*) as cnt FROM menus WHERE name='AppStore'")
    if (!menuCnt[0].cnt) {
      const maxSort = await query('SELECT MAX(sort_order) as ms FROM menus WHERE parent_id=0')
      const nextSort = (maxSort[0]?.ms || 0) + 1
      await query(
        `INSERT INTO menus (parent_id, name, path, component, redirect, title, icon, sort_order, is_hidden, is_full_page, is_keep_alive, is_fixed_tab, auth_list, roles, enabled)
         VALUES (0, 'AppStore', '/appstore', '/index/index', '', 'menus.appstore.title', 'ri:apps-2-line', ?, 0, 0, 0, 0, NULL, '["R_SUPER","R_ADMIN","R_USER"]', 1)`,
        [nextSort]
      )
      const appstoreId = (await query("SELECT id FROM menus WHERE name='AppStore'"))[0].id
      await query(
        `INSERT INTO menus (parent_id, name, path, component, redirect, title, icon, sort_order, is_hidden, is_full_page, is_keep_alive, is_fixed_tab, auth_list, roles, enabled)
         VALUES (?, 'AppStoreList', 'list', '/appstore/list', '', 'menus.appstore.list', '', 1, 0, 0, 1, 0, NULL, NULL, 1)`,
        [appstoreId]
      )
      await query(
        `INSERT INTO menus (parent_id, name, path, component, redirect, title, icon, sort_order, is_hidden, is_full_page, is_keep_alive, is_fixed_tab, auth_list, roles, enabled)
         VALUES (?, 'AppStoreDetail', 'detail/:id', '/appstore/detail', '', 'menus.appstore.detail', '', 2, 1, 0, 0, 0, NULL, NULL, 1)`,
        [appstoreId]
      )
      await query(
        `INSERT INTO menus (parent_id, name, path, component, redirect, title, icon, sort_order, is_hidden, is_full_page, is_keep_alive, is_fixed_tab, auth_list, roles, enabled)
         VALUES (?, 'AppCategory', 'category-manage', '/appstore/category', '', 'menus.appstore.category', 'ri:apps-2-line', 3, 0, 0, 1, 0, NULL, '["R_SUPER","R_ADMIN"]', 1)`,
        [appstoreId]
      )
      await query(
        `INSERT INTO menus (parent_id, name, path, component, redirect, title, icon, sort_order, is_hidden, is_full_page, is_keep_alive, is_fixed_tab, auth_list, roles, enabled)
         VALUES (?, 'AppReports', 'reports', '/appstore/reports', '', 'menus.appstore.reports', 'ri:apps-2-line', 4, 0, 0, 1, 0, NULL, '["R_SUPER","R_ADMIN"]', 1)`,
        [appstoreId]
      )
      await query(
        `INSERT INTO menus (parent_id, name, path, component, redirect, title, icon, sort_order, is_hidden, is_full_page, is_keep_alive, is_fixed_tab, auth_list, roles, enabled)
         VALUES (?, 'MySubmissions', 'my-submissions', '/appstore/submissions', '', 'menus.appstore.mySubmissions', '', 5, 0, 0, 1, 0, NULL, '["R_SUPER","R_ADMIN","R_USER"]', 1)`,
        [appstoreId]
      )
      await query(
        `INSERT INTO menus (parent_id, name, path, component, redirect, title, icon, sort_order, is_hidden, is_full_page, is_keep_alive, is_fixed_tab, auth_list, roles, enabled)
         VALUES (?, 'SubmissionReview', 'review', '/appstore/review', '', 'menus.appstore.review', '', 6, 0, 0, 1, 0, NULL, '["R_SUPER","R_ADMIN"]', 1)`,
        [appstoreId]
      )
      await query(
        `INSERT INTO menus (parent_id, name, path, component, redirect, title, icon, sort_order, is_hidden, is_full_page, is_keep_alive, is_fixed_tab, auth_list, roles, enabled)
         VALUES (?, 'SubmissionReviewMobile', 'review-mobile', '/appstore/review/mobile', '', 'menus.appstore.review', '', 7, 1, 0, 1, 0, NULL, '["R_SUPER","R_ADMIN"]', 1)`,
        [appstoreId]
      )
      await query(
        `INSERT INTO menus (parent_id, name, path, component, redirect, title, icon, sort_order, is_hidden, is_full_page, is_keep_alive, is_fixed_tab, auth_list, roles, enabled)
         VALUES (?, 'OfficialTags', 'official-tags', '/appstore/official-tags', '', 'menus.appstore.officialTags', '', 8, 0, 0, 1, 0, NULL, '["R_SUPER","R_ADMIN"]', 1)`,
        [appstoreId]
      )
      const sa = JSON.stringify
      await query(
        `INSERT INTO menus (parent_id, name, path, component, redirect, title, icon, sort_order, is_hidden, is_full_page, is_keep_alive, is_fixed_tab, auth_list, roles, enabled)
         VALUES (?, 'SectionManage', 'section-manage', '', '', '板块管理', '', 9, 1, 0, 0, 0, ?, '["R_SUPER","R_ADMIN"]', 1)`,
        [appstoreId, sa([{title:'新增',authMark:'add'},{title:'编辑',authMark:'edit'},{title:'删除',authMark:'delete'},{title:'管理版主',authMark:'moderate'},{title:'启停',authMark:'toggle'},{title:'处理解锁',authMark:'unlock'}])]
      )
      await query(
        `INSERT INTO menus (parent_id, name, path, component, redirect, title, icon, sort_order, is_hidden, is_full_page, is_keep_alive, is_fixed_tab, auth_list, roles, enabled)
         VALUES (?, 'CommunityPostManage', 'community-posts', '', '', '帖子管理', '', 10, 1, 0, 0, 0, ?, '["R_SUPER","R_ADMIN"]', 1)`,
        [appstoreId, sa([{title:'置顶',authMark:'pin'},{title:'加精',authMark:'essence'},{title:'热帖',authMark:'hot'},{title:'审核',authMark:'approve'},{title:'编辑',authMark:'edit'},{title:'删除',authMark:'delete'}])]
      )
      await query(
        `INSERT INTO menus (parent_id, name, path, component, redirect, title, icon, sort_order, is_hidden, is_full_page, is_keep_alive, is_fixed_tab, auth_list, roles, enabled)
         VALUES (?, 'CommunityReportManage', 'community-reports', '', '', '举报管理', '', 11, 1, 0, 0, 0, ?, '["R_SUPER","R_ADMIN"]', 1)`,
        [appstoreId, sa([{title:'处理',authMark:'handle'},{title:'删除',authMark:'delete'}])]
      )
      await query(
        `INSERT INTO menus (parent_id, name, path, component, redirect, title, icon, sort_order, is_hidden, is_full_page, is_keep_alive, is_fixed_tab, auth_list, roles, enabled)
         VALUES (?, 'CommunityCommentManage', 'community-comments', '', '', '评论管理', '', 12, 1, 0, 0, 0, ?, '["R_SUPER","R_ADMIN"]', 1)`,
        [appstoreId, sa([{title:'置顶',authMark:'pin'},{title:'删除',authMark:'delete'}])]
      )
      const superRole = await query("SELECT id FROM roles WHERE role_code='R_SUPER'")
      if (superRole[0]) {
      const newMenus = await query("SELECT id FROM menus WHERE name IN ('AppStore','AppStoreList','AppStoreDetail','AppCategory','AppReports','MySubmissions','SubmissionReview','SubmissionReviewMobile','OfficialTags','SectionManage','CommunityPostManage','CommunityReportManage','CommunityCommentManage')")
        for (const m of newMenus) {
          const { dbType } = require('./database.cjs')
          const ignoreSQL = dbType === 'mysql' ? 'INSERT IGNORE INTO' : 'INSERT OR IGNORE INTO'
          await query(`${ignoreSQL} role_permissions (role_id, menu_id) VALUES (?, ?)`, [superRole[0].id, m.id])
        }
        const adminRole2 = await query("SELECT id FROM roles WHERE role_code='R_ADMIN'")
        if (adminRole2[0]) {
          const { dbType: dbType2 } = require('./database.cjs')
          const ignoreSQL2 = dbType2 === 'mysql' ? 'INSERT IGNORE INTO' : 'INSERT OR IGNORE INTO'
          for (const m of newMenus) {
            await query(`${ignoreSQL2} role_permissions (role_id, menu_id) VALUES (?, ?)`, [adminRole2[0].id, m.id])
          }
        }
      }
      console.log('应用商店菜单已创建')
    }
  } catch (e) {
    console.error('应用商店种子数据错误:', e.message)
  }
}

setTimeout(() => seedAppStore(), 3000)

// 通知种子数据
async function seedNotifications() {
  try {
    const notifCnt = await query('SELECT COUNT(*) as cnt FROM sys_notifications')
    if (notifCnt[0].cnt > 0) return
    const notifs = [
      ['今日签到成功', '系统奖励您30金币和5积分，记得每天签到获取更多奖励哦！', 'system', 0, '2026-06-28 08:00:00'],
      ['欢迎来到应用商店', '感谢您的加入！浏览优质应用，每日签到获得丰厚奖励。', 'system', 0, '2026-06-20 10:00:00'],
      ['应用上新通知', '热门应用「神奇影视」已更新至1.3.3版本，快来体验吧！', 'system', 0, '2026-06-15 14:00:00'],
      ['系统维护公告', '今晚22:00-23:00系统将进行例行维护，期间可能短暂无法访问。', 'system', 0, '2026-06-10 18:00:00'],
      ['积分活动通知', '端午节限时活动，签到双倍积分，兑换商城8折优惠！', 'system', 0, '2026-05-30 09:00:00'],
      ['安全提醒', '请勿向他人透露您的账号密码，谨防诈骗。', 'system', 0, '2026-05-20 12:00:00'],
      ['会员升级通知', '恭喜您升级为黄金会员！享受9折优惠和1.5倍积分特权。', 'system', 1, '2026-05-15 16:00:00'],
      ['新功能上线', '发现页已全新改版，新增通知和私信功能，快去体验吧！', 'system', 0, '2026-06-30 07:00:00']
    ]
    for (const n of notifs) {
      await query(
        `INSERT INTO sys_notifications (title, content, type, target_user_id, create_time) VALUES (?, ?, ?, ?, ?)`, n
      )
    }
    console.log('通知种子数据已初始化')
  } catch (e) {
    console.error('通知种子数据错误:', e.message)
  }
}

// 私信种子数据
async function seedMessages() {
  try {
    const msgCnt = await query('SELECT COUNT(*) as cnt FROM private_messages')
    if (msgCnt[0].cnt > 1) return
    // 删除测试数据，插入种子数据
    await query('DELETE FROM private_messages')
    const msgs = [
      ['alexmorgan', 'sophiabaker', '你好，有新应用要上线吗？', '2026-06-28 09:00:00'],
      ['sophiabaker', 'alexmorgan', '正在准备中，预计下周可以提交', '2026-06-28 09:05:00'],
      ['alexmorgan', 'sophiabaker', '好的，期待你的新作品', '2026-06-28 09:06:00'],
      ['lisawu', 'alexmorgan', '快手搜索芥末空间官方', '2026-06-25 14:00:00'],
      ['alexmorgan', 'lisawu', '收到，我去看看', '2026-06-25 14:15:00'],
      ['davidchen', 'alexmorgan', '大佬，你那个应用评分好高啊', '2026-06-20 11:00:00'],
      ['alexmorgan', 'davidchen', '谢谢，你也可以做到的', '2026-06-20 11:10:00'],
      ['emilywang', 'alexmorgan', '在吗？有个合作想和你谈', '2026-06-18 16:00:00']
    ]
    for (const m of msgs) {
      const fromUser = await query('SELECT id, username, avatar FROM users WHERE username = ?', [m[0]])
      const toUser = await query('SELECT id, username FROM users WHERE username = ?', [m[1]])
      if (fromUser[0] && toUser[0]) {
        await query(
          `INSERT INTO private_messages (from_user_id, from_user_name, from_user_avatar, to_user_id, content, create_time) VALUES (?, ?, ?, ?, ?, ?)`,
          [fromUser[0].id, m[0], fromUser[0].avatar || '', toUser[0].id, m[2], m[3]]
        )
      }
    }
    console.log('私信种子数据已初始化')
  } catch (e) {
    console.error('私信种子数据错误:', e.message)
  }
}

setTimeout(() => seedNotifications(), 1000)
setTimeout(() => seedMessages(), 1500)
setTimeout(() => seedCommunity(), 2000)
setTimeout(() => seedNewMenus(), 2500)

async function seedNewMenus() {
  try {
    const existing = await query("SELECT id FROM menus WHERE name='TitleManage'")
    if (existing.length) return

    const opRow = await query("SELECT id FROM menus WHERE name='Operation'")
    const sysRow = await query("SELECT id FROM menus WHERE name='System'")
    const opId = opRow.length > 0 ? opRow[0].id : 3
    const sysId = sysRow.length > 0 ? sysRow[0].id : 9

    const menus = [
      [opId, 'TitleManage', 'title', '/operation/title/index', '', '称号管理', '', 6, 0, 0, 1, 0, null, null, 1],
      [sysId, 'Verification', 'verification', '/system/verification/index', '', '蓝V认证审核', '', 6, 0, 0, 1, 0, null, null, 1],
      [sysId, 'InviteManage', 'invite', '/system/invite/index', '', '邀请码管理', '', 7, 0, 0, 1, 0, null, null, 1],
      [sysId, 'EmailConfig', 'email', '/system/email/index', '', '邮件配置', '', 8, 0, 0, 1, 0, null, null, 1],
      [sysId, 'FileRepository', 'filerepo', '/system/filerepo/index', '', '文件仓库', '', 9, 0, 0, 1, 0, null, null, 1],
      [sysId, 'RecycleBin', 'recycle', '/system/recycle/index', '', '回收站', '', 10, 0, 0, 1, 0, null, null, 1]
    ]
    for (const m of menus) {
      await query(
        `INSERT INTO menus (parent_id, name, path, component, redirect, title, icon,
         sort_order, is_hidden, is_full_page, is_keep_alive, is_fixed_tab, auth_list, roles, enabled)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`, m
      )
    }
    const superRole = await query("SELECT id FROM roles WHERE role_code='R_SUPER'")
    if (superRole.length > 0) {
      const newIds = await query("SELECT id FROM menus WHERE name IN ('TitleManage','Verification','InviteManage','EmailConfig','FileRepository','RecycleBin')")
      for (const m of newIds) {
        await query('INSERT OR IGNORE INTO role_permissions (role_id, menu_id) VALUES (?, ?)', [superRole[0].id, m.id])
      }
    }
    console.log('新功能菜单种子数据已初始化')
  } catch (e) { console.log('新增菜单种子跳过:', e.message) }
}

async function seedPhase3Menus() {
  try {
    const existing = await query("SELECT id FROM menus WHERE name='SystemLog'")
    if (existing.length) return

    const sysRow = await query("SELECT id FROM menus WHERE name='System'")
    const opRow = await query("SELECT id FROM menus WHERE name='Operation'")
    const sysId = sysRow.length > 0 ? sysRow[0].id : 9
    const opId = opRow.length > 0 ? opRow[0].id : 3

    const menus = [
      [sysId, 'SystemLog', 'syslog', '/system/syslog/index', '', '系统日志', '', 11, 0, 0, 1, 0, null, null, 1],
      [sysId, 'SysConfig', 'sysconfig', '/system/sysconfig/index', '', '系统配置', '', 12, 0, 0, 1, 0, null, null, 1],
      [sysId, 'CustomTask', 'task', '/system/task/index', '', '任务管理', '', 13, 0, 0, 1, 0, null, null, 1],
      [opId, 'CommissionManage', 'commission', '/system/commission/index', '', '推广返佣', '', 9, 0, 0, 1, 0, null, null, 1],
      [opId, 'FilePolicyManage', 'filepolicy', '/system/filepolicy/index', '', '文件上传策略', '', 10, 0, 0, 1, 0, null, null, 1]
    ]
    for (const m of menus) {
      await query(
        `INSERT INTO menus (parent_id, name, path, component, redirect, title, icon,
         sort_order, is_hidden, is_full_page, is_keep_alive, is_fixed_tab, auth_list, roles, enabled)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`, m
      )
    }
    const superRole = await query("SELECT id FROM roles WHERE role_code='R_SUPER'")
    if (superRole.length > 0) {
      const newIds = await query("SELECT id FROM menus WHERE name IN ('SystemLog','SysConfig','CustomTask','CommissionManage','FilePolicyManage')")
      for (const m of newIds) {
        await query('INSERT OR IGNORE INTO role_permissions (role_id, menu_id) VALUES (?, ?)', [superRole[0].id, m.id])
      }
    }
    console.log('Phase3 菜单种子数据已初始化')
  } catch (e) { console.log('Phase3 菜单种子跳过:', e.message) }
}

setTimeout(() => seedPhase3Menus(), 3500)

async function seedPhase4Menus() {
  try {
    const existing = await query("SELECT id FROM menus WHERE name='CommissionManage'")
    if (existing.length) return

    const opRow = await query("SELECT id FROM menus WHERE name='Operation'")
    const opId = opRow.length > 0 ? opRow[0].id : 3

    const menus = [
      [opId, 'CommissionManage', 'commission', '/system/commission/index', '', '推广返佣', '', 9, 0, 0, 1, 0, null, null, 1],
      [opId, 'FilePolicyManage', 'filepolicy', '/system/filepolicy/index', '', '文件上传策略', '', 10, 0, 0, 1, 0, null, null, 1]
    ]
    for (const m of menus) {
      await query(
        `INSERT INTO menus (parent_id, name, path, component, redirect, title, icon,
         sort_order, is_hidden, is_full_page, is_keep_alive, is_fixed_tab, auth_list, roles, enabled)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`, m
      )
    }
    const superRole = await query("SELECT id FROM roles WHERE role_code='R_SUPER'")
    if (superRole.length > 0) {
      const newIds = await query("SELECT id FROM menus WHERE name IN ('CommissionManage','FilePolicyManage')")
      for (const m of newIds) {
        await query('INSERT OR IGNORE INTO role_permissions (role_id, menu_id) VALUES (?, ?)', [superRole[0].id, m.id])
      }
    }
    console.log('Phase4 菜单种子数据已初始化')
  } catch (e) { console.log('Phase4 菜单种子跳过:', e.message) }
}

setTimeout(() => seedPhase4Menus(), 4000)

async function seedPhase5Menus() {
  try {
    const existing = await query("SELECT id FROM menus WHERE name='MembershipProducts'")
    if (existing.length) return

    const opRow = await query("SELECT id FROM menus WHERE name='Operation'")
    const opId = opRow.length > 0 ? opRow[0].id : 3

    const menus = [
      [opId, 'MembershipProducts', 'membership-products', '/operation/membership-products/index', '', '会员商品', '', 11, 0, 0, 1, 0, null, null, 1],
      [opId, 'MembershipPurchases', 'membership-purchases', '/operation/membership-purchases/index', '', '购买记录', '', 12, 0, 0, 1, 0, null, null, 1],
      [opId, 'ContentPurchases', 'content-purchases', '/operation/content-purchases/index', '', '付费内容订单', '', 13, 0, 0, 1, 0, null, null, 1]
    ]
    for (const m of menus) {
      await query(
        `INSERT INTO menus (parent_id, name, path, component, redirect, title, icon,
         sort_order, is_hidden, is_full_page, is_keep_alive, is_fixed_tab, auth_list, roles, enabled)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`, m
      )
    }
    const superRole = await query("SELECT id FROM roles WHERE role_code='R_SUPER'")
    if (superRole.length > 0) {
      const newIds = await query("SELECT id FROM menus WHERE name IN ('MembershipProducts','MembershipPurchases','ContentPurchases')")
      for (const m of newIds) {
        await query('INSERT OR IGNORE INTO role_permissions (role_id, menu_id) VALUES (?, ?)', [superRole[0].id, m.id])
      }
    }
    console.log('Phase5 菜单种子数据已初始化')
  } catch (e) { console.log('Phase5 菜单种子跳过:', e.message) }
}

setTimeout(() => seedPhase5Menus(), 5000)

async function seedCommunity() {
  try {
    const sectionCnt = await query('SELECT COUNT(*) as cnt FROM community_sections')
    if (!sectionCnt[0].cnt) {
      await query(
        `INSERT INTO community_sections (name, icon_bg_color, description, today_heat, total_heat, post_count, view_count, sort_order) VALUES
         ('综合讨论', '#23C7C3', '各类话题综合讨论区', 739675, 825896, 328, 925600, 1),
         ('实用软件', '#3B82F6', '实用软件应用分享交流', 58960, 4198200, 196, 1818300, 2),
         ('绿色软件', '#10B981', '绿色便携软件资源分享', 26580, 1176500, 143, 912800, 3),
         ('技术交流', '#8B5CF6', '技术开发与编程交流', 14320, 854200, 98, 659500, 4),
         ('资源分享', '#F97316', '各类资源文件分享下载', 39820, 2112300, 231, 1208000, 5),
         ('游戏天地', '#EC4899', '游戏攻略与交流', 27560, 1187600, 165, 915400, 6)`
      )
      console.log('社区板块种子数据已初始化')
    }

    const postCnt = await query('SELECT COUNT(*) as cnt FROM community_posts')
    if (!postCnt[0].cnt) {
      await query(
        `INSERT INTO community_posts (section_id, user_id, user_name, title, content, device, tags, official_tags, images, like_count, comment_count, coin_count, view_count, is_pinned, is_essence, is_hot, has_resource, resource_type, resource_price, resource_price_type) VALUES
         (1, 1, 'AlexMorgan', '【公告】欢迎来到综合讨论区', '欢迎各位加入社区！在这里可以畅所欲言，分享你的想法和资源。请遵守社区规则，友好交流。', 'iPhone 15 Pro Max', '["公告","社区规则"]', '["官方公告","置顶"]', '[]', 328, 56, 0, 12800, 1, 1, 1, 0, '', 0, 'free'),
         (1, 2, '黯笙', 'TikTok v36.2.4 抖音国际版 去广告解锁区域', '#黯笙爱分享 #资源分享 #软件仓库 #绿色软件 #资源 抖音App是全球最受欢迎的短视频应用，抖音国际版TikTok在海外的规模越来越大，拥有数百个精彩视频', 'Xiaomi 23054RA19C', '["TikTok","国际版","去广告"]', '["实用软件","绿色软件"]', '["https://monkeycode-temporary.oss-cn-hangzhou.aliyuncs.com/temporary/placeholder1.jpg"]', 225, 1923, 111, 35800, 0, 1, 1, 1, '应用', 1, 'balance'),
         (1, 3, 'TechLover', 'Instagram v312.0.0 照片墙 社交应用', '#实用软件 #社交应用 Instagram是一款运行在移动端和Web上的社交应用，以快速、美妙和有趣的方式分享照片和视频', 'Samsung Galaxy S24', '["Instagram","社交","照片"]', '["精华","实用软件"]', '[]', 189, 486, 56, 18200, 0, 1, 1, 1, '应用', 1, 'balance'),
         (1, 4, '老司机', 'TikTok Plugin v2.4.1 抖音国际版插件', '最新版本TikTok插件工具箱，支持无水印下载、去广告、区域解锁、视频解析等功能。完美兼容最新版TikTok。', 'vivo X100 Pro', '["TikTok","插件","工具箱"]', '["绿色软件","热帖"]', '["https://monkeycode-temporary.oss-cn-hangzhou.aliyuncs.com/temporary/placeholder2.jpg"]', 523, 728, 145, 45600, 0, 0, 1, 1, '插件', 2, 'balance'),
         (1, 5, '资源帝', 'Snapchat v13.30.0 快拍分享 多图滤镜', '#社交应用 #摄影 #滤镜 Snapchat是一款由斯坦福大学学生开发的图片分享应用，用户可以拍照、录制视频、添加文字和图画', 'OPPO Find N3', '["Snapchat","摄影","社交"]', '["实用软件"]', '[]', 412, 315, 89, 22300, 0, 0, 1, 1, '应用', 1, 'balance'),
         (1, 6, '软件猎人', 'YouTube ReVanced v19.11 去广告背景播放', '#破解资源 #视频 #去广告 YouTube ReVanced Extended是一款经过修改的YouTube客户端，支持背景播放、去广告、下载视频等功能。', '一加12', '["YouTube","去广告","背景播放"]', '["绿色软件","热帖"]', '["https://monkeycode-temporary.oss-cn-hangzhou.aliyuncs.com/temporary/placeholder1.jpg"]', 678, 892, 201, 52100, 0, 1, 1, 1, '应用', 3, 'balance')`
      )
      console.log('社区帖子种子数据已初始化')
    }
  } catch (e) {
    console.error('社区种子数据错误:', e.message)
  }
}
