const crypto = require('crypto')
const xss = require('xss')
const { query } = require('../database.cjs')

const xssOptions = {
  whiteList: {},
  stripIgnoreTag: true,
  stripIgnoreTagBody: ['script', 'style']
}

function sanitize(obj) {
  if (typeof obj === 'string') return xss(obj, xssOptions)
  if (Array.isArray(obj)) return obj.map(sanitize)
  if (obj && typeof obj === 'object') {
    const clean = {}
    for (const k of Object.keys(obj)) clean[k] = sanitize(obj[k])
    return clean
  }
  return obj
}

function sanitizeBody(req, res, next) {
  if (req.body) req.body = sanitize(req.body)
  if (req.query) req.query = sanitize(req.query)
  next()
}

async function isLogEnabled() {
  try {
    const rows = await query("SELECT config_value FROM sys_config WHERE config_key='system_log_enabled'")
    if (rows && rows.length > 0) return rows[0].config_value === 'true'
  } catch {}
  return true
}

async function systemLog(type, userId, userName, targetType, targetId, detail, ip = '') {
  try {
    const enabled = await isLogEnabled()
    if (!enabled) return
    await query(
      `INSERT INTO system_logs (user_id, user_name, type, target_type, target_id, detail, ip, create_time)
       VALUES (?,?,?,?,?,?,?,datetime('now','localtime'))`,
      [userId || 0, userName || 'system', type, targetType || '', targetId || 0, detail || '', ip]
    )
  } catch (e) { /* 静默失败 */ }
}

function logFromReq(req, type, targetType, targetId, detail) {
  const userId = req.user ? req.user.userId : 0
  const userName = req.user ? req.user.userName : 'anonymous'
  const ip = req.headers['x-forwarded-for'] || req.socket?.remoteAddress || ''
  systemLog(type, userId, userName, targetType, targetId, detail, ip)
}

module.exports = {
  sanitizeBody,
  sanitize,
  systemLog,
  logFromReq
}
