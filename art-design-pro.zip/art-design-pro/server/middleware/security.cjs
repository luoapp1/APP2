const crypto = require('crypto')
const xss = require('xss')
const { query } = require('../database.cjs')

const xssOptions = {
  whiteList: {},
  stripIgnoreTag: true,
  stripIgnoreTagBody: ['script', 'style']
}

function sanitize(obj) {
  if (typeof obj === 'string') return xss(obj, xssOptions)
  if (Array.isArray(obj)) return obj.map(sanitize)
  if (obj && typeof obj === 'object') {
    const clean = {}
    for (const k of Object.keys(obj)) clean[k] = sanitize(obj[k])
    return clean
  }
  return obj
}

function sanitizeBody(req, res, next) {
  if (req.body) req.body = sanitize(req.body)
  if (req.query) req.query = sanitize(req.query)
  next()
}

const LOG_CATEGORY_MAP = {
  login: '系统管理',
  user: '系统管理',
  role: '系统管理',
  role_permission: '系统管理',
  menu: '系统管理',
  sys_config: '系统管理',
  email: '系统管理',
  delete_review: '系统管理',
  membership: '运营管理',
  member: '运营管理',
  points: '运营管理',
  experience: '运营管理',
  cardkey: '运营管理',
  plugin: '运营管理',
  checkin_group: '运营管理',
  checkin_milestone: '运营管理',
  checkin: '运营管理',
  title: '运营管理',
  task: '运营管理',
  commission: '运营管理',
  commission_rule: '运营管理',
  withdraw: '运营管理',
  coupon: '运营管理',
  membership_product: '运营管理',
  purchase: '运营管理',
  order: '运营管理',
  settlement: '运营管理',
  recharge: '运营管理',
  post: '内容管理',
  section: '内容管理',
  comment: '内容管理',
  app: '内容管理',
  submission: '内容管理',
  category: '内容管理',
  official_tag: '内容管理',
  avatar_frame: '内容管理',
  topic: '内容管理',
  moderator: '内容管理',
  file_repo: '文件存储',
  file_policy: '文件存储',
  storage: '文件存储',
  follow: '用户交互',
  like: '用户交互',
  favorite: '用户交互',
  notification: '用户交互',
  invite: '用户交互',
  verification: '用户交互'
}

function getLogCategory(targetType) {
  return LOG_CATEGORY_MAP[targetType] || '其他'
}

async function isLogEnabled(targetType, category) {
  try {
    const rows = await query("SELECT config_value FROM sys_config WHERE config_key='system_log_enabled'")
    if (rows && rows.length > 0 && rows[0].config_value !== 'true') return false
    if (targetType) {
      const typeRows = await query("SELECT config_value FROM sys_config WHERE config_key=?", [`log_enabled_${targetType}`])
      if (typeRows && typeRows.length > 0 && typeRows[0].config_value !== 'true') return false
    }
    if (category) {
      const catRows = await query("SELECT config_value FROM sys_config WHERE config_key=?", [`log_enabled_${category}`])
      if (catRows && catRows.length > 0 && catRows[0].config_value !== 'true') return false
    }
  } catch {}
  return true
}

async function systemLog(type, userId, userName, targetType, targetId, detail, ip = '') {
  try {
    const category = getLogCategory(targetType)
    const enabled = await isLogEnabled(targetType, category)
    if (!enabled) return
    await query(
      `INSERT INTO system_logs (user_id, user_name, type, target_type, target_id, detail, ip, create_time)
       VALUES (?,?,?,?,?,?,?,NOW())`,
      [userId || 0, userName || 'system', type, targetType || '', targetId || 0, detail || '', ip]
    )
  } catch (e) { /* 静默失败 */ }
}

function logFromReq(req, type, targetType, targetId, detail) {
  const userId = req.user ? req.user.userId : 0
  const userName = req.user ? req.user.userName : 'anonymous'
  const ip = req.headers['x-forwarded-for'] || req.socket?.remoteAddress || ''
  systemLog(type, userId, userName, targetType, targetId, detail, ip)
}

module.exports = {
  sanitizeBody,
  sanitize,
  systemLog,
  logFromReq,
  LOG_CATEGORY_MAP
}
