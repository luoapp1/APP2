/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: art_design_pro
-- ------------------------------------------------------
-- Server version	10.11.14-MariaDB-0+deb12u2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `app_categories`
--

DROP TABLE IF EXISTS `app_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `icon` varchar(255) DEFAULT '',
  `sort_order` int(11) DEFAULT 0,
  `status` char(1) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_categories`
--

LOCK TABLES `app_categories` WRITE;
/*!40000 ALTER TABLE `app_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `app_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_comments`
--

DROP TABLE IF EXISTS `app_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_id` int(11) NOT NULL,
  `parent_id` int(11) DEFAULT 0,
  `user_id` int(11) DEFAULT 0,
  `user_name` varchar(100) DEFAULT '',
  `user_avatar` varchar(20) DEFAULT '#FF5777',
  `device` varchar(200) DEFAULT '',
  `version` varchar(50) DEFAULT '',
  `content` text DEFAULT NULL,
  `likes` int(11) DEFAULT 0,
  `replies` int(11) DEFAULT 0,
  `reported` int(11) DEFAULT 0,
  `is_pinned` tinyint(1) DEFAULT 0,
  `rating` decimal(2,1) DEFAULT 0.0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_app_comments_app_id` (`app_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_comments`
--

LOCK TABLES `app_comments` WRITE;
/*!40000 ALTER TABLE `app_comments` DISABLE KEYS */;
INSERT INTO `app_comments` VALUES
(1,2,0,0,'匿名用户','#FFB74D','','','Great E2E app!',0,0,0,0,5.0,'2026-07-10 19:37:24');
/*!40000 ALTER TABLE `app_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_favorites`
--

DROP TABLE IF EXISTS `app_favorites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_favorites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `app_id` int(11) NOT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`app_id`),
  KEY `idx_app_favorites_user` (`user_id`),
  KEY `idx_app_favorites_app` (`app_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_favorites`
--

LOCK TABLES `app_favorites` WRITE;
/*!40000 ALTER TABLE `app_favorites` DISABLE KEYS */;
/*!40000 ALTER TABLE `app_favorites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_official_tags`
--

DROP TABLE IF EXISTS `app_official_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_official_tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `color` varchar(20) DEFAULT '#2563eb',
  `bg_color` varchar(20) DEFAULT '#dbeafe',
  `sort_order` int(11) DEFAULT 0,
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_official_tags`
--

LOCK TABLES `app_official_tags` WRITE;
/*!40000 ALTER TABLE `app_official_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `app_official_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_purchases`
--

DROP TABLE IF EXISTS `app_purchases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_purchases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `price_type` varchar(20) DEFAULT 'free',
  `original_price` decimal(10,2) DEFAULT 0.00,
  `paid_price` decimal(10,2) DEFAULT 0.00,
  `discount_rate` decimal(3,1) DEFAULT 1.0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_app_purchases_app` (`app_id`),
  KEY `idx_app_purchases_user` (`user_id`),
  KEY `idx_app_purchases_user_app` (`user_id`,`app_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_purchases`
--

LOCK TABLES `app_purchases` WRITE;
/*!40000 ALTER TABLE `app_purchases` DISABLE KEYS */;
/*!40000 ALTER TABLE `app_purchases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_store`
--

DROP TABLE IF EXISTS `app_store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `package_name` varchar(200) DEFAULT '',
  `version` varchar(50) DEFAULT '1.0.0',
  `version_code` varchar(50) DEFAULT '100',
  `icon` varchar(500) DEFAULT '',
  `icon_bg_color` varchar(20) DEFAULT '#00BFA5',
  `size_mb` decimal(10,1) DEFAULT 0.0,
  `downloads` int(11) DEFAULT 0,
  `rating` decimal(2,1) DEFAULT 0.0,
  `description` text DEFAULT NULL,
  `update_content` text DEFAULT NULL,
  `screenshots` text DEFAULT NULL,
  `tags` text DEFAULT NULL,
  `download_url` varchar(500) DEFAULT '',
  `coin_count` int(11) DEFAULT 0,
  `coin_people` int(11) DEFAULT 0,
  `developer` varchar(100) DEFAULT '',
  `category` varchar(100) DEFAULT '工具',
  `categories` text DEFAULT NULL,
  `category_id` int(11) DEFAULT 0,
  `status` varchar(2) DEFAULT '1',
  `is_pinned` tinyint(1) DEFAULT 0,
  `user_id` int(11) DEFAULT 0,
  `official_tags` text DEFAULT NULL,
  `content_permission` varchar(20) DEFAULT 'public',
  `content_price` decimal(10,2) DEFAULT 0.00,
  `content_price_type` varchar(20) DEFAULT 'free',
  `access_password` varchar(100) DEFAULT '',
  `access_password_tips` varchar(500) DEFAULT '',
  `is_featured` tinyint(1) DEFAULT 0,
  `is_official` tinyint(1) DEFAULT 0,
  `has_ads` int(11) DEFAULT 0,
  `requires_network` int(11) DEFAULT 1,
  `has_paid_content` int(11) DEFAULT 0,
  `is_free` int(11) DEFAULT 1,
  `price_type` varchar(20) DEFAULT 'free',
  `price_amount` decimal(10,2) DEFAULT 0.00,
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_app_store_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_store`
--

LOCK TABLES `app_store` WRITE;
/*!40000 ALTER TABLE `app_store` DISABLE KEYS */;
INSERT INTO `app_store` VALUES
(1,'E2E App','com.e2e.test','1.0.0','100','','#00BFA5',0.0,0,0.0,'Test app',NULL,NULL,NULL,'',0,0,'','工具',NULL,0,'0',0,0,NULL,'public',0.00,'free','','',0,0,0,1,0,1,'free',0.00,'2026-07-10 19:34:30','2026-07-10 19:34:30'),
(2,'E2E Test App','com.e2e.app','1.0.0','100','','#00BFA5',0.0,0,5.0,'Real E2E test application',NULL,NULL,NULL,'',0,0,'','工具',NULL,0,'0',0,0,NULL,'public',0.00,'free','','',0,0,0,1,0,1,'free',0.00,'2026-07-10 19:37:24','2026-07-10 19:37:24'),
(3,'E2E Test App','com.e2e.app','1.0.0','100','','#00BFA5',0.0,0,0.0,'Real E2E test application',NULL,'[]','[]','',0,0,'','工具',NULL,0,'1',0,0,'[]','public',0.00,'free','','',0,0,0,1,0,1,'free',0.00,'2026-07-10 20:00:22','2026-07-10 20:07:11');
/*!40000 ALTER TABLE `app_store` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_tips`
--

DROP TABLE IF EXISTS `app_tips`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_tips` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(64) DEFAULT '',
  `amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `tip_type` varchar(20) DEFAULT 'balance',
  `message` varchar(255) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_app_tips_app` (`app_id`),
  KEY `idx_app_tips_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_tips`
--

LOCK TABLES `app_tips` WRITE;
/*!40000 ALTER TABLE `app_tips` DISABLE KEYS */;
/*!40000 ALTER TABLE `app_tips` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_uploads`
--

DROP TABLE IF EXISTS `app_uploads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_uploads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_id` int(11) DEFAULT 0,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `name` varchar(200) NOT NULL,
  `package_name` varchar(200) DEFAULT '',
  `category` varchar(100) DEFAULT '工具',
  `description` text DEFAULT NULL,
  `icon` varchar(500) DEFAULT '',
  `icon_bg_color` varchar(20) DEFAULT '#00BFA5',
  `version` varchar(50) DEFAULT '1.0.0',
  `version_code` varchar(50) DEFAULT '100',
  `size_mb` decimal(10,1) DEFAULT 0.0,
  `download_url` varchar(500) DEFAULT '',
  `screenshots` text DEFAULT NULL,
  `tags` text DEFAULT NULL,
  `version_type` varchar(20) DEFAULT '',
  `has_ads` int(11) DEFAULT 0,
  `requires_network` int(11) DEFAULT 1,
  `has_paid_content` int(11) DEFAULT 0,
  `is_free` int(11) DEFAULT 1,
  `downloads` int(11) DEFAULT 0,
  `rating` decimal(2,1) DEFAULT 0.0,
  `coin_count` int(11) DEFAULT 0,
  `coin_people` int(11) DEFAULT 0,
  `review_count` int(11) DEFAULT 0,
  `five_star_count` int(11) DEFAULT 0,
  `status` varchar(2) DEFAULT '0',
  `submission_status` varchar(20) DEFAULT 'draft',
  `review_comment` text DEFAULT NULL,
  `review_by` varchar(100) DEFAULT '',
  `review_time` datetime DEFAULT NULL,
  `price_type` varchar(20) DEFAULT 'free',
  `price_amount` decimal(10,2) DEFAULT 0.00,
  `official_tags` text DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_app_uploads_user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_uploads`
--

LOCK TABLES `app_uploads` WRITE;
/*!40000 ALTER TABLE `app_uploads` DISABLE KEYS */;
INSERT INTO `app_uploads` VALUES
(1,0,0,'','E2E App','com.e2e.test','工具','Test app','','#00BFA5','1.0.0','100',0.0,'',NULL,NULL,'',0,1,0,1,0,0.0,0,0,0,0,'0','draft',NULL,'',NULL,'free',0.00,NULL,'2026-07-10 19:34:30','2026-07-10 19:34:30'),
(2,3,0,'','E2E Test App','com.e2e.app','工具','Real E2E test application','','#00BFA5','1.0.0','100',0.0,'',NULL,NULL,'',0,1,0,1,0,0.0,0,0,0,0,'0','approved','','alexmorgan','2026-07-10 20:07:11','free',0.00,NULL,'2026-07-10 19:37:24','2026-07-10 20:07:11'),
(3,0,0,'','test_crud_app','com.test.crud','工具','CRUD test app','','#4ECDC4','1.0.0','1',10.0,'https://example.com/test.apk','\"[]\"','\"[]\"','',0,0,0,1,0,0.0,0,0,0,0,'0','draft',NULL,'',NULL,'free',0.00,'\"[]\"','2026-07-10 20:09:51','2026-07-10 20:09:51'),
(4,0,0,'','test_crud_app','com.test.crud','工具','CRUD test','','#4ECDC4','1.0.0','1',10.0,'https://example.com/test.apk','\"[]\"','\"[]\"','',0,0,0,1,0,0.0,0,0,0,0,'0','draft',NULL,'',NULL,'free',0.00,'\"[]\"','2026-07-10 20:11:45','2026-07-10 20:11:45'),
(5,0,0,'','test_crud_app','com.test.crud','工具','CRUD test','','#4ECDC4','1.0.0','1',10.0,'https://example.com/test.apk','\"[]\"','\"[]\"','',0,0,0,1,0,0.0,0,0,0,0,'0','draft',NULL,'',NULL,'free',0.00,'\"[]\"','2026-07-10 20:13:26','2026-07-10 20:13:26'),
(6,0,0,'','test_crud_app','com.test.crud','工具','CRUD test','','#4ECDC4','1.0.0','1',10.0,'https://example.com/test.apk','\"[]\"','\"[]\"','',0,0,0,1,0,0.0,0,0,0,0,'0','draft',NULL,'',NULL,'free',0.00,'\"[]\"','2026-07-10 20:13:56','2026-07-10 20:13:56'),
(7,0,0,'','test_crud_app','com.test.crud','工具','CRUD test','','#4ECDC4','1.0.0','1',10.0,'https://example.com/test.apk','\"[]\"','\"[]\"','',0,0,0,1,0,0.0,0,0,0,0,'0','draft',NULL,'',NULL,'free',0.00,'\"[]\"','2026-07-10 20:17:40','2026-07-10 20:17:40');
/*!40000 ALTER TABLE `app_uploads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_versions`
--

DROP TABLE IF EXISTS `app_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_versions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_id` int(11) NOT NULL,
  `version` varchar(50) NOT NULL,
  `version_code` varchar(50) DEFAULT '',
  `size_mb` decimal(10,1) DEFAULT 0.0,
  `downloads` int(11) DEFAULT 0,
  `rating` decimal(2,1) DEFAULT 0.0,
  `update_content` text DEFAULT NULL,
  `tags` text DEFAULT NULL,
  `download_url` varchar(500) DEFAULT '',
  `is_current` tinyint(1) DEFAULT 0,
  `user_id` int(11) DEFAULT 0,
  `user_name` varchar(100) DEFAULT '',
  `official_tags` text DEFAULT NULL,
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  `description` text DEFAULT NULL,
  `screenshots` text DEFAULT NULL,
  `has_ads` int(11) DEFAULT 0,
  `has_paid_content` int(11) DEFAULT 0,
  `is_free` int(11) DEFAULT 1,
  `requires_network` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_app_versions_app_id` (`app_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_versions`
--

LOCK TABLES `app_versions` WRITE;
/*!40000 ALTER TABLE `app_versions` DISABLE KEYS */;
INSERT INTO `app_versions` VALUES
(1,3,'1.0.0','100',0.0,0,0.0,'','[]','',1,0,'',NULL,'1','2026-07-10 20:07:11','Real E2E test application','[]',0,0,1,0);
/*!40000 ALTER TABLE `app_versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `avatar_frames`
--

DROP TABLE IF EXISTS `avatar_frames`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `avatar_frames` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `image_url` varchar(500) DEFAULT '',
  `thumbnail_url` varchar(500) DEFAULT '',
  `description` varchar(500) DEFAULT '',
  `obtain_type` varchar(20) DEFAULT 'manual',
  `exp_level_required` int(11) DEFAULT 0,
  `member_level_required` int(11) DEFAULT 0,
  `sort_order` int(11) DEFAULT 0,
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `avatar_frames`
--

LOCK TABLES `avatar_frames` WRITE;
/*!40000 ALTER TABLE `avatar_frames` DISABLE KEYS */;
/*!40000 ALTER TABLE `avatar_frames` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `balance_records`
--

DROP TABLE IF EXISTS `balance_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `balance_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `type` varchar(20) NOT NULL DEFAULT 'earn',
  `amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `balance` decimal(10,2) DEFAULT 0.00,
  `source` varchar(200) DEFAULT '',
  `description` text DEFAULT NULL,
  `ref_id` int(11) DEFAULT 0,
  `ref_type` varchar(50) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_balance_records_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance_records`
--

LOCK TABLES `balance_records` WRITE;
/*!40000 ALTER TABLE `balance_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `balance_transfer_records`
--

DROP TABLE IF EXISTS `balance_transfer_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `balance_transfer_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from_user_id` int(11) NOT NULL,
  `from_user_name` varchar(100) DEFAULT '',
  `to_user_id` int(11) NOT NULL,
  `to_user_name` varchar(100) DEFAULT '',
  `amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `fee` decimal(10,2) DEFAULT 0.00,
  `remark` varchar(300) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance_transfer_records`
--

LOCK TABLES `balance_transfer_records` WRITE;
/*!40000 ALTER TABLE `balance_transfer_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance_transfer_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `browse_history`
--

DROP TABLE IF EXISTS `browse_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `browse_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `item_type` varchar(10) NOT NULL,
  `item_id` int(11) NOT NULL,
  `item_title` varchar(300) DEFAULT '',
  `item_cover` varchar(500) DEFAULT '',
  `item_url` varchar(500) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `browse_history`
--

LOCK TABLES `browse_history` WRITE;
/*!40000 ALTER TABLE `browse_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `browse_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `card_keys`
--

DROP TABLE IF EXISTS `card_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `card_keys` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `card_no` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `type` varchar(20) NOT NULL DEFAULT 'membership',
  `target_id` int(11) DEFAULT 0,
  `target_name` varchar(100) DEFAULT '',
  `value` int(11) DEFAULT 0,
  `extra_points` int(11) DEFAULT 0,
  `extra_experience` int(11) DEFAULT 0,
  `extra_balance` decimal(10,2) DEFAULT 0.00,
  `duration` int(11) DEFAULT 0,
  `duration_unit` varchar(10) DEFAULT '',
  `status` varchar(2) DEFAULT '0',
  `create_by` varchar(100) DEFAULT '管理员',
  `create_time` datetime DEFAULT current_timestamp(),
  `redeem_by` varchar(100) DEFAULT '',
  `redeem_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `card_no` (`card_no`),
  KEY `idx_card_keys_card_no` (`card_no`),
  KEY `idx_card_keys_type` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `card_keys`
--

LOCK TABLES `card_keys` WRITE;
/*!40000 ALTER TABLE `card_keys` DISABLE KEYS */;
INSERT INTO `card_keys` VALUES
(1,'CDKEY-MRFDDHKZJHWT','CCXK02LN','balance',0,'100元余额',100,0,0,0.00,30,'day','0','管理员','2026-07-10 20:09:50','',NULL),
(2,'CDKEY-MRFDEIA8FQIE','C2TINVAB','balance',0,'100元余额',100,0,0,0.00,0,'','0','管理员','2026-07-10 20:10:37','',NULL),
(3,'CDKEY-MRFDFY6MDUDL','CW846IXF','balance',0,'100元余额',100,0,0,0.00,30,'day','0','管理员','2026-07-10 20:11:44','',NULL),
(4,'CDKEY-MRFDI3H03B58','YA6W9T7Z','balance',0,'100元余额',100,0,0,0.00,30,'day','0','管理员','2026-07-10 20:13:25','',NULL),
(6,'CDKEY-MRFDJ9PME2DC','8ADBOA6O','makeup',1,'',1,0,0,0.00,12,'month','0','管理员','2026-07-10 20:14:19','',NULL),
(7,'CDKEY-MRFDNJM3G71W','07SQHY7Y','balance',0,'100元余额',100,0,0,0.00,30,'day','0','管理员','2026-07-10 20:17:39','',NULL);
/*!40000 ALTER TABLE `card_keys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_gift_records`
--

DROP TABLE IF EXISTS `chat_gift_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_gift_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `room_id` int(11) DEFAULT 0,
  `gift_id` int(11) NOT NULL,
  `from_user_id` int(11) NOT NULL,
  `to_user_id` int(11) DEFAULT 0,
  `quantity` int(11) DEFAULT 1,
  `points_cost` int(11) DEFAULT 0,
  `message_id` int(11) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_gift_records`
--

LOCK TABLES `chat_gift_records` WRITE;
/*!40000 ALTER TABLE `chat_gift_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `chat_gift_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_gifts`
--

DROP TABLE IF EXISTS `chat_gifts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_gifts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `icon` varchar(500) DEFAULT '',
  `price` int(11) DEFAULT 0,
  `coin_type` varchar(20) DEFAULT 'coin',
  `animation` varchar(500) DEFAULT '',
  `sort_order` int(11) DEFAULT 0,
  `status` varchar(20) DEFAULT 'active',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_gifts`
--

LOCK TABLES `chat_gifts` WRITE;
/*!40000 ALTER TABLE `chat_gifts` DISABLE KEYS */;
/*!40000 ALTER TABLE `chat_gifts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_reports`
--

DROP TABLE IF EXISTS `chat_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reporter_id` int(11) NOT NULL,
  `message_id` int(11) DEFAULT 0,
  `target_user_id` int(11) DEFAULT 0,
  `conversation_id` int(11) DEFAULT 0,
  `reason` varchar(50) DEFAULT '',
  `detail` text DEFAULT '',
  `status` varchar(20) DEFAULT 'pending',
  `handler_id` int(11) DEFAULT 0,
  `handle_notes` text DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  `handle_time` datetime DEFAULT NULL,
  `room_id` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_reports`
--

LOCK TABLES `chat_reports` WRITE;
/*!40000 ALTER TABLE `chat_reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `chat_reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_room_admin_logs`
--

DROP TABLE IF EXISTS `chat_room_admin_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_room_admin_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `room_id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `admin_name` varchar(100) DEFAULT '',
  `action` varchar(50) NOT NULL,
  `target_user_id` int(11) DEFAULT 0,
  `target_user_name` varchar(100) DEFAULT '',
  `detail` text DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_room_admin_logs`
--

LOCK TABLES `chat_room_admin_logs` WRITE;
/*!40000 ALTER TABLE `chat_room_admin_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `chat_room_admin_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_room_bans`
--

DROP TABLE IF EXISTS `chat_room_bans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_room_bans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `room_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `type` varchar(20) DEFAULT 'temp',
  `reason` text DEFAULT '',
  `ban_until` datetime DEFAULT NULL,
  `banned_by` int(11) NOT NULL,
  `status` varchar(20) DEFAULT 'active',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `room_id` (`room_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_room_bans`
--

LOCK TABLES `chat_room_bans` WRITE;
/*!40000 ALTER TABLE `chat_room_bans` DISABLE KEYS */;
/*!40000 ALTER TABLE `chat_room_bans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_room_files`
--

DROP TABLE IF EXISTS `chat_room_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_room_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `room_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `file_name` varchar(500) NOT NULL,
  `file_url` varchar(500) NOT NULL,
  `file_type` varchar(50) DEFAULT 'other',
  `file_size` int(11) DEFAULT 0,
  `mime_type` varchar(200) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_chat_room_files_room_id` (`room_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_room_files`
--

LOCK TABLES `chat_room_files` WRITE;
/*!40000 ALTER TABLE `chat_room_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `chat_room_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_room_join_requests`
--

DROP TABLE IF EXISTS `chat_room_join_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_room_join_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `room_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `user_avatar` varchar(200) DEFAULT '',
  `reason` text DEFAULT '',
  `status` varchar(20) DEFAULT 'pending',
  `reviewed_by` int(11) DEFAULT 0,
  `reviewed_name` varchar(100) DEFAULT '',
  `review_comment` text DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  `review_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `room_id` (`room_id`,`user_id`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_room_join_requests`
--

LOCK TABLES `chat_room_join_requests` WRITE;
/*!40000 ALTER TABLE `chat_room_join_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `chat_room_join_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_room_limit_upgrades`
--

DROP TABLE IF EXISTS `chat_room_limit_upgrades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_room_limit_upgrades` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `room_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `current_limit` int(11) DEFAULT 50,
  `request_limit` int(11) NOT NULL,
  `reason` text DEFAULT '',
  `status` varchar(20) DEFAULT 'pending',
  `reviewed_by` int(11) DEFAULT 0,
  `reviewed_name` varchar(100) DEFAULT '',
  `review_comment` text DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  `review_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_room_limit_upgrades`
--

LOCK TABLES `chat_room_limit_upgrades` WRITE;
/*!40000 ALTER TABLE `chat_room_limit_upgrades` DISABLE KEYS */;
/*!40000 ALTER TABLE `chat_room_limit_upgrades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_room_members`
--

DROP TABLE IF EXISTS `chat_room_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_room_members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `room_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `role` varchar(20) DEFAULT 'member',
  `muted_until` datetime DEFAULT NULL,
  `status` varchar(20) DEFAULT 'active',
  `join_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `room_id` (`room_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_room_members`
--

LOCK TABLES `chat_room_members` WRITE;
/*!40000 ALTER TABLE `chat_room_members` DISABLE KEYS */;
/*!40000 ALTER TABLE `chat_room_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_room_messages`
--

DROP TABLE IF EXISTS `chat_room_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_room_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `room_id` int(11) NOT NULL,
  `from_user_id` int(11) NOT NULL,
  `from_user_name` varchar(100) DEFAULT '',
  `from_user_avatar` varchar(200) DEFAULT '',
  `content` text DEFAULT '',
  `image_url` text DEFAULT '',
  `message_type` varchar(20) DEFAULT 'text',
  `mention_ids` text DEFAULT '[]',
  `is_recalled` tinyint(1) DEFAULT 0,
  `report_status` varchar(20) DEFAULT 'none',
  `order_card` text DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_room_messages`
--

LOCK TABLES `chat_room_messages` WRITE;
/*!40000 ALTER TABLE `chat_room_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `chat_room_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_rooms`
--

DROP TABLE IF EXISTS `chat_rooms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_rooms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `description` text DEFAULT '',
  `avatar` varchar(500) DEFAULT '',
  `owner_id` int(11) NOT NULL,
  `password` varchar(100) DEFAULT '',
  `max_members` int(11) DEFAULT 500,
  `member_limit` int(11) DEFAULT 50,
  `join_mode` varchar(20) DEFAULT 'public',
  `status` varchar(20) DEFAULT 'active',
  `chat_enabled` tinyint(1) DEFAULT 1,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_rooms`
--

LOCK TABLES `chat_rooms` WRITE;
/*!40000 ALTER TABLE `chat_rooms` DISABLE KEYS */;
/*!40000 ALTER TABLE `chat_rooms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `checkin_groups`
--

DROP TABLE IF EXISTS `checkin_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `checkin_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `level_id` int(11) DEFAULT 0,
  `icon` varchar(100) DEFAULT '',
  `icon_color` varchar(20) DEFAULT '#409EFF',
  `points` int(11) DEFAULT 5,
  `experience` int(11) DEFAULT 2,
  `balance` decimal(10,2) DEFAULT 0.00,
  `points_consecutive` int(11) DEFAULT 2,
  `experience_consecutive` int(11) DEFAULT 1,
  `balance_consecutive` decimal(10,2) DEFAULT 0.00,
  `sort_order` int(11) DEFAULT 0,
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `checkin_groups`
--

LOCK TABLES `checkin_groups` WRITE;
/*!40000 ALTER TABLE `checkin_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `checkin_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `checkin_milestones`
--

DROP TABLE IF EXISTS `checkin_milestones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `checkin_milestones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL DEFAULT 0,
  `days` int(11) NOT NULL DEFAULT 3,
  `points` int(11) DEFAULT 0,
  `experience` int(11) DEFAULT 0,
  `balance` decimal(10,2) DEFAULT 0.00,
  `card_key_type` varchar(20) DEFAULT '',
  `card_key_value` int(11) DEFAULT 0,
  `card_key_duration` int(11) DEFAULT 0,
  `card_key_duration_unit` varchar(10) DEFAULT '',
  `card_key_extra_points` int(11) DEFAULT 0,
  `card_key_extra_experience` int(11) DEFAULT 0,
  `card_key_extra_balance` decimal(10,2) DEFAULT 0.00,
  `sort_order` int(11) DEFAULT 0,
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `checkin_milestones`
--

LOCK TABLES `checkin_milestones` WRITE;
/*!40000 ALTER TABLE `checkin_milestones` DISABLE KEYS */;
/*!40000 ALTER TABLE `checkin_milestones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `checkin_records`
--

DROP TABLE IF EXISTS `checkin_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `checkin_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `checkin_date` date NOT NULL,
  `consecutive_days` int(11) DEFAULT 1,
  `points_earned` int(11) DEFAULT 0,
  `experience_earned` int(11) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`checkin_date`),
  KEY `idx_checkin_records_user_date` (`user_id`,`checkin_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `checkin_records`
--

LOCK TABLES `checkin_records` WRITE;
/*!40000 ALTER TABLE `checkin_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `checkin_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comment_likes`
--

DROP TABLE IF EXISTS `comment_likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `comment_likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `comment_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `comment_id` (`comment_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment_likes`
--

LOCK TABLES `comment_likes` WRITE;
/*!40000 ALTER TABLE `comment_likes` DISABLE KEYS */;
/*!40000 ALTER TABLE `comment_likes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commission_records`
--

DROP TABLE IF EXISTS `commission_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `commission_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) DEFAULT 0,
  `order_type` varchar(30) DEFAULT '',
  `order_amount` decimal(10,2) DEFAULT 0.00,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `referrer_id` int(11) NOT NULL,
  `referrer_name` varchar(100) DEFAULT '',
  `rate` decimal(5,2) DEFAULT 0.00,
  `amount` decimal(10,2) DEFAULT 0.00,
  `status` varchar(20) DEFAULT 'pending',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_commission_records_user` (`user_id`),
  KEY `idx_commission_records_referrer` (`referrer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commission_records`
--

LOCK TABLES `commission_records` WRITE;
/*!40000 ALTER TABLE `commission_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `commission_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commission_rules`
--

DROP TABLE IF EXISTS `commission_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `commission_rules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT '',
  `order_type` varchar(30) DEFAULT 'all',
  `rate` decimal(5,2) DEFAULT 0.00,
  `user_level_id` int(11) DEFAULT 0,
  `user_level_name` varchar(100) DEFAULT '',
  `user_id` int(11) DEFAULT 0,
  `invite_code_id` int(11) DEFAULT 0,
  `invite_code_type` varchar(20) DEFAULT '',
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commission_rules`
--

LOCK TABLES `commission_rules` WRITE;
/*!40000 ALTER TABLE `commission_rules` DISABLE KEYS */;
INSERT INTO `commission_rules` VALUES
(1,NULL,NULL,10.00,0,'',0,0,'','1','2026-07-10 20:09:50'),
(2,NULL,NULL,10.00,0,'',0,0,'','1','2026-07-10 20:10:49'),
(3,NULL,NULL,10.00,0,'',0,0,'','1','2026-07-10 20:11:45'),
(4,NULL,NULL,10.00,0,'',0,0,'','1','2026-07-10 20:13:25'),
(5,NULL,NULL,10.00,0,'',0,0,'','1','2026-07-10 20:13:56'),
(6,NULL,NULL,10.00,0,'',0,0,'','1','2026-07-10 20:17:39');
/*!40000 ALTER TABLE `commission_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_attach_purchases`
--

DROP TABLE IF EXISTS `community_attach_purchases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_attach_purchases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `attach_url` varchar(500) NOT NULL DEFAULT '',
  `coin_type` varchar(20) NOT NULL DEFAULT 'coin',
  `coin_amount` int(11) NOT NULL DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_attach_purchases`
--

LOCK TABLES `community_attach_purchases` WRITE;
/*!40000 ALTER TABLE `community_attach_purchases` DISABLE KEYS */;
/*!40000 ALTER TABLE `community_attach_purchases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_banned_users`
--

DROP TABLE IF EXISTS `community_banned_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_banned_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `reason` varchar(500) DEFAULT '',
  `banned_until` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `idx_community_banned_users_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_banned_users`
--

LOCK TABLES `community_banned_users` WRITE;
/*!40000 ALTER TABLE `community_banned_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `community_banned_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_coin_logs`
--

DROP TABLE IF EXISTS `community_coin_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_coin_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `from_user_id` int(11) NOT NULL,
  `from_user_name` varchar(100) DEFAULT '',
  `from_user_avatar` varchar(500) DEFAULT '',
  `to_user_id` int(11) NOT NULL DEFAULT 0,
  `amount` int(11) DEFAULT 0,
  `coin_type` varchar(20) DEFAULT 'coin',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_coin_logs`
--

LOCK TABLES `community_coin_logs` WRITE;
/*!40000 ALTER TABLE `community_coin_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `community_coin_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_comments`
--

DROP TABLE IF EXISTS `community_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `parent_id` int(11) DEFAULT 0,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `user_avatar` varchar(500) DEFAULT '',
  `content` text NOT NULL,
  `images` text DEFAULT '[]',
  `like_count` int(11) DEFAULT 0,
  `reply_count` int(11) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_community_comments_post_id` (`post_id`),
  KEY `idx_community_comments_parent_id` (`parent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_comments`
--

LOCK TABLES `community_comments` WRITE;
/*!40000 ALTER TABLE `community_comments` DISABLE KEYS */;
INSERT INTO `community_comments` VALUES
(1,1,0,1,'Alex Morgan','','Great E2E test comment!','[]',0,0,'2026-07-10 19:37:24');
/*!40000 ALTER TABLE `community_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_drafts`
--

DROP TABLE IF EXISTS `community_drafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_drafts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `section_id` int(11) DEFAULT 0,
  `title` varchar(500) DEFAULT '',
  `content` text DEFAULT '',
  `images` text DEFAULT '[]',
  `tags` text DEFAULT '[]',
  `official_tags` text DEFAULT '[]',
  `has_resource` int(11) DEFAULT 0,
  `resource_type` varchar(20) DEFAULT '',
  `resource_url` text DEFAULT '',
  `resource_price` double DEFAULT 0,
  `resource_price_type` varchar(20) DEFAULT 'free',
  `extract_code` varchar(100) DEFAULT '',
  `permission` varchar(20) DEFAULT 'public',
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_community_drafts_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_drafts`
--

LOCK TABLES `community_drafts` WRITE;
/*!40000 ALTER TABLE `community_drafts` DISABLE KEYS */;
/*!40000 ALTER TABLE `community_drafts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_favorites`
--

DROP TABLE IF EXISTS `community_favorites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_favorites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `post_id` (`post_id`,`user_id`),
  KEY `idx_community_favorites_post_user` (`post_id`,`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_favorites`
--

LOCK TABLES `community_favorites` WRITE;
/*!40000 ALTER TABLE `community_favorites` DISABLE KEYS */;
INSERT INTO `community_favorites` VALUES
(1,1,1,'2026-07-10 19:37:24');
/*!40000 ALTER TABLE `community_favorites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_likes`
--

DROP TABLE IF EXISTS `community_likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `post_id` (`post_id`,`user_id`),
  KEY `idx_community_likes_post_user` (`post_id`,`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_likes`
--

LOCK TABLES `community_likes` WRITE;
/*!40000 ALTER TABLE `community_likes` DISABLE KEYS */;
INSERT INTO `community_likes` VALUES
(1,1,1,'2026-07-10 19:37:24');
/*!40000 ALTER TABLE `community_likes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_moderators`
--

DROP TABLE IF EXISTS `community_moderators`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_moderators` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `section_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `user_avatar` varchar(500) DEFAULT '',
  `role` varchar(20) DEFAULT '版主',
  `sort_order` int(11) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `section_id` (`section_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_moderators`
--

LOCK TABLES `community_moderators` WRITE;
/*!40000 ALTER TABLE `community_moderators` DISABLE KEYS */;
/*!40000 ALTER TABLE `community_moderators` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_post_topics`
--

DROP TABLE IF EXISTS `community_post_topics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_post_topics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `topic_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `post_id` (`post_id`,`topic_id`),
  KEY `idx_post_topics_post` (`post_id`),
  KEY `idx_post_topics_topic` (`topic_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_post_topics`
--

LOCK TABLES `community_post_topics` WRITE;
/*!40000 ALTER TABLE `community_post_topics` DISABLE KEYS */;
/*!40000 ALTER TABLE `community_post_topics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_posts`
--

DROP TABLE IF EXISTS `community_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `section_id` int(11) NOT NULL DEFAULT 0,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `user_avatar` varchar(500) DEFAULT '',
  `title` varchar(500) DEFAULT '',
  `content` text DEFAULT '',
  `device` varchar(100) DEFAULT '',
  `tags` text DEFAULT '[]',
  `official_tags` text DEFAULT '[]',
  `images` text DEFAULT '[]',
  `has_resource` int(11) DEFAULT 0,
  `resource_type` varchar(20) DEFAULT '',
  `resource_url` text DEFAULT '',
  `resource_price` double DEFAULT 0,
  `resource_price_type` varchar(20) DEFAULT 'free',
  `extract_code` varchar(100) DEFAULT '',
  `permission` varchar(20) DEFAULT 'public',
  `is_pinned` int(11) DEFAULT 0,
  `is_essence` int(11) DEFAULT 0,
  `is_hot` int(11) DEFAULT 0,
  `hot_manually_disabled` tinyint(1) DEFAULT 0,
  `is_global_pinned` tinyint(1) DEFAULT 0,
  `custom_badge` varchar(50) DEFAULT '',
  `status` varchar(20) DEFAULT 'published',
  `like_count` int(11) DEFAULT 0,
  `comment_count` int(11) DEFAULT 0,
  `coin_count` int(11) DEFAULT 0,
  `view_count` int(11) DEFAULT 0,
  `favorite_count` int(11) DEFAULT 0,
  `topic_id` int(11) DEFAULT 0,
  `content_permission` varchar(20) DEFAULT 'public',
  `content_price` decimal(10,2) DEFAULT 0.00,
  `content_price_type` varchar(20) DEFAULT 'free',
  `access_password` varchar(100) DEFAULT '',
  `access_password_tips` varchar(500) DEFAULT '',
  `cover_url` varchar(500) DEFAULT '',
  `is_edited` int(11) DEFAULT 0,
  `edited_at` datetime DEFAULT NULL,
  `avatar_frame` varchar(500) DEFAULT '',
  `name_color` varchar(20) DEFAULT '',
  `is_anonymous` int(11) DEFAULT 0,
  `is_deleted` tinyint(1) DEFAULT 0,
  `deleted_at` datetime DEFAULT NULL,
  `edition` int(11) DEFAULT 1,
  `community_id` int(11) DEFAULT 0,
  `community_name` varchar(100) DEFAULT '',
  `community_icon` varchar(500) DEFAULT '',
  `review_status` varchar(20) DEFAULT 'approved',
  `reviewed_at` datetime DEFAULT NULL,
  `reviewed_by` varchar(100) DEFAULT '',
  `review_reason` text DEFAULT NULL,
  `reject_reason` text DEFAULT NULL,
  `locked` int(11) DEFAULT 0,
  `is_locked` int(11) DEFAULT 0,
  `locked_at` datetime DEFAULT NULL,
  `locked_by` int(11) DEFAULT 0,
  `locked_reason` varchar(500) DEFAULT '',
  `share_count` int(11) DEFAULT 0,
  `content_type` varchar(20) DEFAULT 'text',
  `attachment_urls` text DEFAULT NULL,
  `hidden_content` text DEFAULT NULL,
  `hidden_attachment_urls` text DEFAULT NULL,
  `free_read` int(11) DEFAULT 0,
  `free_count` int(11) DEFAULT 500,
  `cover_width` int(11) DEFAULT 0,
  `cover_height` int(11) DEFAULT 0,
  `duration_us` int(11) DEFAULT 0,
  `size_mb` decimal(10,2) DEFAULT 0.00,
  `mime_type` varchar(100) DEFAULT '',
  `voice_url` varchar(500) DEFAULT '',
  `voice_duration` int(11) DEFAULT 0,
  `video_width` int(11) DEFAULT 0,
  `video_height` int(11) DEFAULT 0,
  `original_lang` varchar(10) DEFAULT '',
  `translations` text DEFAULT NULL,
  `is_sticky_global` tinyint(1) DEFAULT 0,
  `sticky_order` int(11) DEFAULT 0,
  `sticky_section_id` int(11) DEFAULT 0,
  `sticky_until` datetime DEFAULT NULL,
  `post_uid` varchar(36) DEFAULT '',
  `summary` varchar(200) DEFAULT '',
  `sort_weight` decimal(10,2) DEFAULT 0.00,
  `scheduled_time` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_community_posts_section_id` (`section_id`),
  KEY `idx_community_posts_user_id` (`user_id`),
  KEY `idx_community_posts_status` (`status`),
  KEY `idx_community_posts_is_pinned` (`is_pinned`),
  KEY `idx_community_posts_is_essence` (`is_essence`),
  KEY `idx_community_posts_is_hot` (`is_hot`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_posts`
--

LOCK TABLES `community_posts` WRITE;
/*!40000 ALTER TABLE `community_posts` DISABLE KEYS */;
INSERT INTO `community_posts` VALUES
(1,1,1,'Alex Morgan','','E2E Updated','Updated E2E content','','e2e,test','[]','[]',0,'','',0,'free','','public',0,0,0,0,0,'','deleted',1,1,0,0,1,0,'public',0.00,'balance','','','',0,NULL,'','',0,0,NULL,1,0,'','','approved',NULL,'',NULL,NULL,0,0,NULL,0,'',0,'text',NULL,NULL,NULL,0,500,0,0,0,0.00,'','',0,0,0,'',NULL,0,0,0,NULL,'','',0.00,NULL,'2026-07-10 19:37:24','2026-07-10 19:37:26'),
(2,1,1,'Alex Morgan','','Paid E2E Post','Premium content for purchase test.','','paid,premium','[]','[]',0,'','',0,'free','','public',1,1,1,0,1,'6','deleted',0,0,0,0,0,0,'paid',10.00,'points','','','',0,NULL,'','',0,0,NULL,1,0,'','','approved',NULL,'',NULL,NULL,0,1,NULL,0,'',0,'text',NULL,NULL,NULL,0,500,0,0,0,0.00,'','',0,0,0,'',NULL,0,0,0,NULL,'','',0.00,NULL,'2026-07-10 19:37:24','2026-07-10 19:37:26');
/*!40000 ALTER TABLE `community_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_reports`
--

DROP TABLE IF EXISTS `community_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reporter_id` int(11) NOT NULL,
  `reporter_name` varchar(100) DEFAULT '',
  `target_type` varchar(20) NOT NULL,
  `target_id` int(11) NOT NULL,
  `report_reason` varchar(100) DEFAULT '其他',
  `report_detail` text DEFAULT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_reports`
--

LOCK TABLES `community_reports` WRITE;
/*!40000 ALTER TABLE `community_reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `community_reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_sections`
--

DROP TABLE IF EXISTS `community_sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `icon` varchar(500) DEFAULT '',
  `icon_bg_color` varchar(20) DEFAULT '#00BFA5',
  `description` text DEFAULT '',
  `today_heat` int(11) DEFAULT 0,
  `total_heat` int(11) DEFAULT 0,
  `post_count` int(11) DEFAULT 0,
  `view_count` int(11) DEFAULT 0,
  `sort_order` int(11) DEFAULT 0,
  `status` varchar(20) DEFAULT 'active',
  `visibility` varchar(20) DEFAULT 'public',
  `post_permission` varchar(20) DEFAULT 'all',
  `view_permission` varchar(20) DEFAULT 'all',
  `view_level_required` int(11) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_sections`
--

LOCK TABLES `community_sections` WRITE;
/*!40000 ALTER TABLE `community_sections` DISABLE KEYS */;
/*!40000 ALTER TABLE `community_sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_topics`
--

DROP TABLE IF EXISTS `community_topics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_topics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `icon` varchar(500) DEFAULT '',
  `description` text DEFAULT '',
  `creator_id` int(11) DEFAULT 0,
  `creator_name` varchar(100) DEFAULT '',
  `sort_order` int(11) DEFAULT 0,
  `post_count` int(11) DEFAULT 0,
  `view_count` int(11) DEFAULT 0,
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_topics`
--

LOCK TABLES `community_topics` WRITE;
/*!40000 ALTER TABLE `community_topics` DISABLE KEYS */;
INSERT INTO `community_topics` VALUES
(1,'test_crud_section','icon-test','CRUD test',1,'alexmorgan',0,0,0,'1','2026-07-11 04:09:50'),
(2,'test_crud','icon-test','test',1,'alexmorgan',0,0,0,'1','2026-07-11 04:10:49'),
(3,'test_crud_topic','icon-test','CRUD test',1,'alexmorgan',0,0,0,'1','2026-07-11 04:11:45'),
(4,'test_crud_topic2','icon-test','CRUD test',1,'alexmorgan',0,0,0,'1','2026-07-11 04:13:38'),
(5,'test_crud_t50214','icon-test','CRUD test',1,'alexmorgan',0,0,0,'1','2026-07-11 04:13:55'),
(6,'test_crud_t78669','icon-test','CRUD test',1,'alexmorgan',0,0,0,'1','2026-07-11 04:17:39');
/*!40000 ALTER TABLE `community_topics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_unlock_requests`
--

DROP TABLE IF EXISTS `community_unlock_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_unlock_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `reason` text DEFAULT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `admin_reply` varchar(500) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_unlock_requests`
--

LOCK TABLES `community_unlock_requests` WRITE;
/*!40000 ALTER TABLE `community_unlock_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `community_unlock_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `content_access_passwords`
--

DROP TABLE IF EXISTS `content_access_passwords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `content_access_passwords` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content_type` varchar(20) DEFAULT 'post',
  `content_id` int(11) NOT NULL,
  `password` varchar(100) NOT NULL,
  `tips` varchar(200) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_content_access_passwords_content` (`content_type`,`content_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `content_access_passwords`
--

LOCK TABLES `content_access_passwords` WRITE;
/*!40000 ALTER TABLE `content_access_passwords` DISABLE KEYS */;
/*!40000 ALTER TABLE `content_access_passwords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `content_purchases`
--

DROP TABLE IF EXISTS `content_purchases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `content_purchases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `content_type` varchar(20) DEFAULT 'post',
  `content_id` int(11) NOT NULL,
  `author_id` int(11) DEFAULT 0,
  `amount` decimal(10,2) DEFAULT 0.00,
  `pay_type` varchar(20) DEFAULT 'balance',
  `commission_amount` decimal(10,2) DEFAULT 0.00,
  `commission_rate` decimal(5,2) DEFAULT 0.00,
  `block_index` int(11) DEFAULT -1,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_content_purchases_user` (`user_id`),
  KEY `idx_content_purchases_content` (`content_type`,`content_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `content_purchases`
--

LOCK TABLES `content_purchases` WRITE;
/*!40000 ALTER TABLE `content_purchases` DISABLE KEYS */;
/*!40000 ALTER TABLE `content_purchases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coupon_usage_logs`
--

DROP TABLE IF EXISTS `coupon_usage_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `coupon_usage_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_coupon_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `coupon_id` int(11) NOT NULL,
  `coupon_name` varchar(200) DEFAULT '',
  `use_scene` varchar(50) DEFAULT '',
  `use_amount` decimal(10,2) DEFAULT 0.00,
  `before_remaining` decimal(10,2) DEFAULT NULL,
  `after_remaining` decimal(10,2) DEFAULT NULL,
  `order_desc` varchar(500) DEFAULT '',
  `use_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coupon_usage_logs`
--

LOCK TABLES `coupon_usage_logs` WRITE;
/*!40000 ALTER TABLE `coupon_usage_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `coupon_usage_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coupons`
--

DROP TABLE IF EXISTS `coupons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `coupons` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `description` text DEFAULT '',
  `type` varchar(20) NOT NULL DEFAULT 'fixed',
  `value` decimal(10,2) NOT NULL DEFAULT 0.00,
  `min_order` decimal(10,2) NOT NULL DEFAULT 0.00,
  `max_discount` decimal(10,2) DEFAULT 0.00,
  `scope` varchar(20) NOT NULL DEFAULT 'all',
  `target_ids` text DEFAULT '',
  `target_names` text DEFAULT '',
  `total_count` int(11) DEFAULT 0,
  `claimed_count` int(11) NOT NULL DEFAULT 0,
  `per_user_limit` int(11) NOT NULL DEFAULT 1,
  `start_time` datetime DEFAULT NULL,
  `expire_time` datetime DEFAULT NULL,
  `valid_days` int(11) DEFAULT 0,
  `category` varchar(20) DEFAULT 'general',
  `is_recommend` tinyint(1) DEFAULT 0,
  `is_new_user` tinyint(1) DEFAULT 0,
  `is_rush` tinyint(1) DEFAULT 0,
  `required_level_ids` text DEFAULT '',
  `required_level_names` text DEFAULT '',
  `is_multi_use` tinyint(1) DEFAULT 0,
  `sort_order` int(11) DEFAULT 0,
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_coupons_status` (`status`),
  KEY `idx_coupons_scope` (`scope`),
  KEY `idx_coupons_category` (`category`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coupons`
--

LOCK TABLES `coupons` WRITE;
/*!40000 ALTER TABLE `coupons` DISABLE KEYS */;
INSERT INTO `coupons` VALUES
(1,'E2E Coupon','','discount',10.00,1.00,0.00,'all','','',100,0,1,NULL,NULL,30,'general',0,0,0,'','',0,0,'1','2026-07-10 19:37:25'),
(7,'666','66','fixed',10.00,1.00,2.00,'all','','',0,0,1,NULL,NULL,7,'general',0,1,0,'1','',0,0,'1','2026-07-10 20:14:59');
/*!40000 ALTER TABLE `coupons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_tasks`
--

DROP TABLE IF EXISTS `custom_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `custom_tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `description` text DEFAULT '',
  `icon` varchar(500) DEFAULT '',
  `task_type` varchar(30) NOT NULL DEFAULT 'daily',
  `action_type` varchar(30) NOT NULL DEFAULT 'post',
  `target_count` int(11) DEFAULT 1,
  `section_id` int(11) DEFAULT 0,
  `section_limit` int(11) DEFAULT 0,
  `points_reward` int(11) DEFAULT 0,
  `exp_reward` int(11) DEFAULT 0,
  `balance_reward` decimal(10,2) DEFAULT 0.00,
  `card_key_type` varchar(20) DEFAULT '',
  `card_key_value` int(11) DEFAULT 0,
  `card_key_duration` int(11) DEFAULT 0,
  `title_id` int(11) DEFAULT 0,
  `status` varchar(2) DEFAULT '1',
  `sort_order` int(11) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_tasks`
--

LOCK TABLES `custom_tasks` WRITE;
/*!40000 ALTER TABLE `custom_tasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `custom_tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_titles`
--

DROP TABLE IF EXISTS `custom_titles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `custom_titles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `icon` varchar(500) DEFAULT '',
  `color` varchar(20) DEFAULT '#409EFF',
  `bg_color` varchar(20) DEFAULT '#ecf5ff',
  `description` varchar(500) DEFAULT '',
  `condition_type` varchar(20) DEFAULT 'manual',
  `condition_value` varchar(200) DEFAULT '',
  `sort_order` int(11) DEFAULT 0,
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_titles`
--

LOCK TABLES `custom_titles` WRITE;
/*!40000 ALTER TABLE `custom_titles` DISABLE KEYS */;
/*!40000 ALTER TABLE `custom_titles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_config`
--

DROP TABLE IF EXISTS `email_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `host` varchar(200) NOT NULL DEFAULT '',
  `port` int(11) NOT NULL DEFAULT 465,
  `secure` tinyint(1) DEFAULT 1,
  `user` varchar(200) NOT NULL DEFAULT '',
  `password` varchar(200) NOT NULL DEFAULT '',
  `from_name` varchar(100) DEFAULT '',
  `from_address` varchar(200) DEFAULT '',
  `test_address` varchar(200) DEFAULT '',
  `register_verify` tinyint(1) DEFAULT 0,
  `enabled` tinyint(1) DEFAULT 1,
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_config`
--

LOCK TABLES `email_config` WRITE;
/*!40000 ALTER TABLE `email_config` DISABLE KEYS */;
INSERT INTO `email_config` VALUES
(1,'smtp.test.com',587,1,'test@test.com','','Test','test@test.com','',0,0,'2026-07-10 20:17:39');
/*!40000 ALTER TABLE `email_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_push_config`
--

DROP TABLE IF EXISTS `email_push_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_push_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(50) DEFAULT '',
  `name` varchar(100) DEFAULT '',
  `subject` varchar(200) DEFAULT '',
  `template` text DEFAULT NULL,
  `enabled` tinyint(1) DEFAULT 0,
  `user_group` varchar(20) DEFAULT 'all',
  `level_ids` text DEFAULT NULL,
  `sort_order` int(11) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  `description` varchar(500) DEFAULT '',
  `target` varchar(100) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_push_config`
--

LOCK TABLES `email_push_config` WRITE;
/*!40000 ALTER TABLE `email_push_config` DISABLE KEYS */;
INSERT INTO `email_push_config` VALUES
(1,'new_submission','链接提交邮件','',NULL,0,'all',NULL,0,'2026-07-10 20:16:21','2026-07-10 20:16:21','前台有新的链接提交向管理员发送邮件','admin'),
(2,'new_order','新订单邮件','',NULL,0,'all',NULL,0,'2026-07-10 20:16:21','2026-07-10 20:16:21','用户支付订单后向管理员发送邮件','admin'),
(3,'withdraw_request','提现邮件','',NULL,0,'all',NULL,0,'2026-07-10 20:16:21','2026-07-10 20:16:21','用户申请提现向管理员发送邮件','admin'),
(4,'submission_review','投稿待审核通知邮件','',NULL,0,'all',NULL,0,'2026-07-10 20:16:21','2026-07-10 20:16:21','有用户投稿待审核时向管理员发送邮件','admin'),
(5,'post_review','帖子待审核通知邮件(管理员)','',NULL,0,'all',NULL,0,'2026-07-10 20:16:21','2026-07-10 20:16:21','[论坛]有用户发帖待审核时向管理员发送邮件','admin'),
(6,'post_review_moderator','帖子待审核通知邮件(版主)','',NULL,0,'all',NULL,0,'2026-07-10 20:16:21','2026-07-10 20:16:21','[论坛]有用户发帖待审核时向版主发送邮件','moderator'),
(7,'identity_verify','身份认证通知邮件','',NULL,0,'all',NULL,0,'2026-07-10 20:16:21','2026-07-10 20:16:21','有用户申请身份认证向管理员发送邮件','admin'),
(8,'account_appeal','帐号申诉通知邮件','',NULL,0,'all',NULL,0,'2026-07-10 20:16:21','2026-07-10 20:16:21','有用户帐号禁封申诉向管理员发送邮件','admin'),
(9,'report_notify','举报通知邮件','',NULL,0,'all',NULL,0,'2026-07-10 20:16:21','2026-07-10 20:16:21','收到举报信息向管理员发送邮件','admin'),
(10,'moderator_apply','版主申请通知邮件','',NULL,0,'all',NULL,0,'2026-07-10 20:16:21','2026-07-10 20:16:21','[论坛]有用户申请版主向管理员和超级版主发送邮件','admin'),
(11,'order_paid_user','新订单邮件(用户)','',NULL,0,'all',NULL,0,'2026-07-10 20:16:21','2026-07-10 20:16:21','用户支付订单后向用户发送邮件','user'),
(12,'withdraw_result','提现通知邮件','',NULL,0,'all',NULL,0,'2026-07-10 20:16:21','2026-07-10 20:16:21','处理用户提现申请后向用户发送邮件','user'),
(13,'order_paid_referrer','佣金通知邮件','',NULL,0,'all',NULL,0,'2026-07-10 20:16:21','2026-07-10 20:16:21','用户支付订单后向推荐人发送邮件','user'),
(14,'revenue_split','分成通知邮件','',NULL,0,'all',NULL,0,'2026-07-10 20:16:21','2026-07-10 20:16:21','用户支付订单后有创作分成时向分成作者发送邮件','user'),
(15,'comment_approved','评论审核邮件','',NULL,0,'all',NULL,0,'2026-07-10 20:16:21','2026-07-10 20:16:21','评论通过审核后向用户发送邮件','user'),
(16,'comment_reply','评论回复通知邮件','',NULL,0,'all',NULL,0,'2026-07-10 20:16:21','2026-07-10 20:16:21','评论有新的回复向用户发送邮件','user'),
(17,'content_approved','内容审核邮件','',NULL,0,'all',NULL,0,'2026-07-10 20:16:21','2026-07-10 20:16:21','投稿、发帖通过审核后向用户发送邮件','user'),
(18,'phone_changed','手机号修改通知邮件','',NULL,0,'all',NULL,0,'2026-07-10 20:16:21','2026-07-10 20:16:21','用户修改绑定手机号向用户发送邮件','user'),
(19,'identity_result','身份认证通知邮件(用户)','',NULL,0,'all',NULL,0,'2026-07-10 20:16:21','2026-07-10 20:16:21','处理用户身份认证申请后向用户发送邮件','user'),
(20,'account_ban_user','帐号禁封通知邮件','',NULL,0,'all',NULL,0,'2026-07-10 20:16:21','2026-07-10 20:16:21','用户帐号禁封、解封向用户发送邮件','user'),
(21,'report_result','举报反馈邮件','',NULL,0,'all',NULL,0,'2026-07-10 20:16:21','2026-07-10 20:16:21','处理用户举报后向用户发送邮件','user'),
(22,'moderator_apply_result','版主申请通知邮件(用户)','',NULL,0,'all',NULL,0,'2026-07-10 20:16:21','2026-07-10 20:16:21','[论坛]处理用户版主申请后向用户发送邮件','user'),
(23,'moderator_removed','版主移出通知邮件','',NULL,0,'all',NULL,0,'2026-07-10 20:16:21','2026-07-10 20:16:21','[论坛]将用户版主身份移出后向用户发送邮件','user'),
(24,'answer_accepted','回答被采纳','',NULL,0,'all',NULL,0,'2026-07-10 20:16:21','2026-07-10 20:16:21','[论坛]回答被采纳后向用户发送邮件','user'),
(25,'private_message','私信通知邮件','',NULL,0,'all',NULL,0,'2026-07-10 20:16:21','2026-07-10 20:16:21','收到私信后向收信用户发送邮件','user');
/*!40000 ALTER TABLE `email_push_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_templates`
--

DROP TABLE IF EXISTS `email_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT '',
  `code` varchar(50) DEFAULT '',
  `subject` varchar(200) DEFAULT '',
  `html_content` text DEFAULT NULL,
  `description` varchar(500) DEFAULT '',
  `sort_order` int(11) DEFAULT 0,
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_templates`
--

LOCK TABLES `email_templates` WRITE;
/*!40000 ALTER TABLE `email_templates` DISABLE KEYS */;
INSERT INTO `email_templates` VALUES
(1,'test_tpl_crud','test_crud_tpl','CRUD Test','','CRUD test',0,'1','2026-07-10 20:08:00','2026-07-10 20:08:00');
/*!40000 ALTER TABLE `email_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_verifications`
--

DROP TABLE IF EXISTS `email_verifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_verifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(200) NOT NULL,
  `code` varchar(10) NOT NULL,
  `type` varchar(20) DEFAULT 'register',
  `used` tinyint(1) DEFAULT 0,
  `expires_at` datetime NOT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_email_verifications_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_verifications`
--

LOCK TABLES `email_verifications` WRITE;
/*!40000 ALTER TABLE `email_verifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_verifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `experience_levels`
--

DROP TABLE IF EXISTS `experience_levels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `experience_levels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `level` int(11) NOT NULL DEFAULT 0,
  `exp_required` int(11) NOT NULL DEFAULT 0,
  `icon` varchar(100) DEFAULT '',
  `icon_color` varchar(20) DEFAULT '#00BFA5',
  `text_color` varchar(20) DEFAULT '#FFFFFF',
  `bg_color` varchar(20) DEFAULT '#508DFF',
  `benefits` text DEFAULT NULL,
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `experience_levels`
--

LOCK TABLES `experience_levels` WRITE;
/*!40000 ALTER TABLE `experience_levels` DISABLE KEYS */;
INSERT INTO `experience_levels` VALUES
(1,'Lv.1',1,0,'ri:star-line','#00BFA5','#FFFFFF','#508DFF','基础等级','1','2026-07-10 19:32:17'),
(2,'Lv.2',2,100,'ri:star-line','#42A5F5','#FFFFFF','#508DFF','解锁评论功能','1','2026-07-10 19:32:17'),
(3,'Lv.3',3,500,'ri:star-half-line','#7C4DFF','#FFFFFF','#508DFF','解锁发帖功能','1','2026-07-10 19:32:17'),
(4,'Lv.4',4,1000,'ri:star-half-fill','#FFB74D','#FFFFFF','#508DFF','解锁自定义头像','1','2026-07-10 19:32:17'),
(5,'Lv.5',5,2000,'ri:star-fill','#FF6B6B','#FFFFFF','#508DFF','解锁高级搜索','1','2026-07-10 19:32:17'),
(6,'Lv.6',6,5000,'ri:vip-crown-line','#FFD700','#FFFFFF','#508DFF','专属标识,优先客服','1','2026-07-10 19:32:17'),
(7,'Lv.7',7,10000,'ri:vip-crown-fill','#FF4081','#FFFFFF','#508DFF','全部权益,年度礼品','1','2026-07-10 19:32:17');
/*!40000 ALTER TABLE `experience_levels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `experience_records`
--

DROP TABLE IF EXISTS `experience_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `experience_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `amount` int(11) NOT NULL DEFAULT 0,
  `source` varchar(100) DEFAULT '',
  `description` varchar(500) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_experience_records_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `experience_records`
--

LOCK TABLES `experience_records` WRITE;
/*!40000 ALTER TABLE `experience_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `experience_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file_policies`
--

DROP TABLE IF EXISTS `file_policies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `file_policies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT '',
  `user_level_id` int(11) DEFAULT 0,
  `user_level_name` varchar(100) DEFAULT '',
  `role_code` varchar(100) DEFAULT '',
  `user_id` int(11) DEFAULT 0,
  `max_file_size_mb` int(11) DEFAULT 10,
  `allowed_types` text DEFAULT '',
  `banned_types` text DEFAULT '',
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file_policies`
--

LOCK TABLES `file_policies` WRITE;
/*!40000 ALTER TABLE `file_policies` DISABLE KEYS */;
INSERT INTO `file_policies` VALUES
(1,'',0,'','',0,10,'','','1','2026-07-10 20:09:50'),
(2,'',0,'','',0,10,'','','1','2026-07-10 20:10:49'),
(3,'',0,'','',0,10,'','','1','2026-07-10 20:11:45'),
(4,'',0,'','',0,10,'','','1','2026-07-10 20:13:25'),
(5,'',0,'','',0,10,'','','1','2026-07-10 20:13:56'),
(6,'',0,'','',0,10,'','','1','2026-07-10 20:17:40');
/*!40000 ALTER TABLE `file_policies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file_repository`
--

DROP TABLE IF EXISTS `file_repository`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `file_repository` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT 0,
  `user_name` varchar(100) DEFAULT '',
  `file_name` varchar(500) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_size` bigint(20) DEFAULT 0,
  `file_type` varchar(100) DEFAULT '',
  `mime_type` varchar(200) DEFAULT '',
  `category` varchar(50) DEFAULT 'other',
  `ref_id` int(11) DEFAULT 0,
  `ref_type` varchar(50) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_file_repository_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file_repository`
--

LOCK TABLES `file_repository` WRITE;
/*!40000 ALTER TABLE `file_repository` DISABLE KEYS */;
/*!40000 ALTER TABLE `file_repository` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hidden_conversations`
--

DROP TABLE IF EXISTS `hidden_conversations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `hidden_conversations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `partner_id` int(11) NOT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`partner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hidden_conversations`
--

LOCK TABLES `hidden_conversations` WRITE;
/*!40000 ALTER TABLE `hidden_conversations` DISABLE KEYS */;
/*!40000 ALTER TABLE `hidden_conversations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invite_codes`
--

DROP TABLE IF EXISTS `invite_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `invite_codes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL,
  `created_by` int(11) DEFAULT 0,
  `created_by_name` varchar(100) DEFAULT '',
  `used_by` int(11) DEFAULT 0,
  `used_by_name` varchar(100) DEFAULT '',
  `max_uses` int(11) DEFAULT 1,
  `use_count` int(11) DEFAULT 0,
  `status` varchar(2) DEFAULT '1',
  `used_at` datetime DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  `created_by_user_id` int(11) DEFAULT 0,
  `type` varchar(50) DEFAULT 'one_time',
  `reward_type` varchar(50) DEFAULT '',
  `reward_value` int(11) DEFAULT 0,
  `reward_duration` int(11) DEFAULT 0,
  `reward_duration_unit` varchar(10) DEFAULT 'day',
  `reward_target_id` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `idx_invite_codes_code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invite_codes`
--

LOCK TABLES `invite_codes` WRITE;
/*!40000 ALTER TABLE `invite_codes` DISABLE KEYS */;
INSERT INTO `invite_codes` VALUES
(1,'81068D10',1,'管理员',0,'',1,0,'1',NULL,NULL,'2026-07-10 20:09:50',0,'admin','balance',1,0,'day',0),
(2,'B85D8519',1,'管理员',0,'',1,0,'1',NULL,NULL,'2026-07-10 20:10:49',0,'admin','balance',1,0,'day',0),
(3,'E1C68357',1,'管理员',0,'',1,0,'1',NULL,NULL,'2026-07-10 20:11:45',0,'admin','balance',1,0,'day',0),
(4,'900BB2F1',1,'管理员',0,'',1,0,'1',NULL,NULL,'2026-07-10 20:13:25',0,'admin','balance',1,0,'day',0),
(5,'95C9C3B7',1,'管理员',0,'',1,0,'1',NULL,NULL,'2026-07-10 20:13:56',0,'admin','balance',1,0,'day',0),
(6,'3FF98E20',1,'管理员',0,'',1,0,'1',NULL,NULL,'2026-07-10 20:17:40',0,'admin','balance',1,0,'day',0);
/*!40000 ALTER TABLE `invite_codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_after_sales`
--

DROP TABLE IF EXISTS `mall_after_sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_after_sales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `order_item_id` int(11) DEFAULT 0,
  `user_id` int(11) NOT NULL,
  `type` varchar(20) DEFAULT 'refund',
  `reason` text DEFAULT '',
  `description` text DEFAULT '',
  `images` text DEFAULT '[]',
  `amount` double DEFAULT 0,
  `status` varchar(20) DEFAULT 'pending',
  `seller_reply` text DEFAULT '',
  `seller_reply_time` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_mall_after_sales_order` (`order_id`),
  KEY `idx_mall_after_sales_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_after_sales`
--

LOCK TABLES `mall_after_sales` WRITE;
/*!40000 ALTER TABLE `mall_after_sales` DISABLE KEYS */;
/*!40000 ALTER TABLE `mall_after_sales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_cart_items`
--

DROP TABLE IF EXISTS `mall_cart_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_cart_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `option_id` int(11) DEFAULT 0,
  `quantity` int(11) DEFAULT 1,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`product_id`,`option_id`),
  KEY `idx_mall_cart_items_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_cart_items`
--

LOCK TABLES `mall_cart_items` WRITE;
/*!40000 ALTER TABLE `mall_cart_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `mall_cart_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_categories`
--

DROP TABLE IF EXISTS `mall_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT 0,
  `name` varchar(100) NOT NULL,
  `icon` varchar(200) DEFAULT '',
  `sort_order` int(11) DEFAULT 0,
  `status` varchar(20) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_categories`
--

LOCK TABLES `mall_categories` WRITE;
/*!40000 ALTER TABLE `mall_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `mall_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_order_items`
--

DROP TABLE IF EXISTS `mall_order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_order_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `option_id` int(11) DEFAULT 0,
  `product_name` varchar(200) DEFAULT '',
  `option_name` varchar(200) DEFAULT '',
  `price` double DEFAULT 0,
  `quantity` int(11) DEFAULT 1,
  `image` varchar(500) DEFAULT '',
  `virtual_content` text DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `idx_mall_order_items_order` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_order_items`
--

LOCK TABLES `mall_order_items` WRITE;
/*!40000 ALTER TABLE `mall_order_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `mall_order_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_order_logistics`
--

DROP TABLE IF EXISTS `mall_order_logistics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_order_logistics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `company` varchar(100) DEFAULT '',
  `tracking_no` varchar(100) DEFAULT '',
  `status` varchar(20) DEFAULT 'pending',
  `details` text DEFAULT '[]',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_mall_order_logistics_order` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_order_logistics`
--

LOCK TABLES `mall_order_logistics` WRITE;
/*!40000 ALTER TABLE `mall_order_logistics` DISABLE KEYS */;
/*!40000 ALTER TABLE `mall_order_logistics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_orders`
--

DROP TABLE IF EXISTS `mall_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_no` varchar(32) NOT NULL,
  `user_id` int(11) NOT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `total_amount` double DEFAULT 0,
  `discount_amount` double DEFAULT 0,
  `freight` double DEFAULT 0,
  `payment_method` varchar(20) DEFAULT '',
  `payment_time` datetime DEFAULT NULL,
  `receiver_name` varchar(100) DEFAULT '',
  `receiver_phone` varchar(20) DEFAULT '',
  `receiver_address` varchar(500) DEFAULT '',
  `logistics_company` varchar(100) DEFAULT '',
  `logistics_no` varchar(100) DEFAULT '',
  `user_custom_fields` text DEFAULT '{}',
  `remark` varchar(500) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_no` (`order_no`),
  KEY `idx_mall_orders_status` (`status`),
  KEY `idx_mall_orders_user` (`user_id`),
  KEY `idx_mall_orders_order_no` (`order_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_orders`
--

LOCK TABLES `mall_orders` WRITE;
/*!40000 ALTER TABLE `mall_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `mall_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_product_images`
--

DROP TABLE IF EXISTS `mall_product_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_product_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `url` varchar(500) NOT NULL,
  `sort_order` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_mall_product_images_product` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_product_images`
--

LOCK TABLES `mall_product_images` WRITE;
/*!40000 ALTER TABLE `mall_product_images` DISABLE KEYS */;
/*!40000 ALTER TABLE `mall_product_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_product_options`
--

DROP TABLE IF EXISTS `mall_product_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_product_options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `spec_name` varchar(200) DEFAULT '',
  `price` double DEFAULT 0,
  `original_price` double DEFAULT 0,
  `points_price` double DEFAULT 0,
  `stock` int(11) DEFAULT 0,
  `image` varchar(500) DEFAULT '',
  `sort_order` int(11) DEFAULT 0,
  `card_config` text DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `idx_mall_product_options_product` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_product_options`
--

LOCK TABLES `mall_product_options` WRITE;
/*!40000 ALTER TABLE `mall_product_options` DISABLE KEYS */;
/*!40000 ALTER TABLE `mall_product_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_products`
--

DROP TABLE IF EXISTS `mall_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) DEFAULT 0,
  `name` varchar(200) NOT NULL,
  `subtitle` varchar(200) DEFAULT '',
  `description` text DEFAULT '',
  `cover_image` varchar(500) DEFAULT '',
  `cover_video` varchar(500) DEFAULT '',
  `price_type` varchar(20) DEFAULT 'balance',
  `price` double DEFAULT 0,
  `original_price` double DEFAULT 0,
  `stock` int(11) DEFAULT 0,
  `product_type` varchar(20) DEFAULT 'virtual_auto',
  `virtual_content` text DEFAULT '',
  `status` varchar(20) DEFAULT 'draft',
  `sales_count` int(11) DEFAULT 0,
  `is_recommended` int(11) DEFAULT 0,
  `sort_order` int(11) DEFAULT 0,
  `freight` double DEFAULT 0,
  `services` text DEFAULT '[]',
  `purchase_limit_config` text DEFAULT '[]',
  `commission_config` text DEFAULT '[]',
  `custom_fields` text DEFAULT '[]',
  `after_sales_config` text DEFAULT '{}',
  `tags` text DEFAULT '[]',
  `product_params` text DEFAULT '[]',
  `payment_methods` text DEFAULT '["balance"]',
  `sale_end_time` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  `created_by` int(11) DEFAULT 0,
  `created_by_name` varchar(100) DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `idx_mall_products_category` (`category_id`),
  KEY `idx_mall_products_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_products`
--

LOCK TABLES `mall_products` WRITE;
/*!40000 ALTER TABLE `mall_products` DISABLE KEYS */;
/*!40000 ALTER TABLE `mall_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_promotion_gifts`
--

DROP TABLE IF EXISTS `mall_promotion_gifts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_promotion_gifts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `promotion_id` int(11) NOT NULL,
  `gift_type` varchar(20) DEFAULT 'points',
  `gift_value` double DEFAULT 0,
  `gift_detail` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '{}' CHECK (json_valid(`gift_detail`)),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_promotion_gifts`
--

LOCK TABLES `mall_promotion_gifts` WRITE;
/*!40000 ALTER TABLE `mall_promotion_gifts` DISABLE KEYS */;
/*!40000 ALTER TABLE `mall_promotion_gifts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_promotion_products`
--

DROP TABLE IF EXISTS `mall_promotion_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_promotion_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `promotion_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `promotion_id` (`promotion_id`,`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_promotion_products`
--

LOCK TABLES `mall_promotion_products` WRITE;
/*!40000 ALTER TABLE `mall_promotion_products` DISABLE KEYS */;
/*!40000 ALTER TABLE `mall_promotion_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_promotions`
--

DROP TABLE IF EXISTS `mall_promotions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_promotions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `type` varchar(20) DEFAULT 'discount',
  `discount_value` double DEFAULT 0,
  `min_amount` double DEFAULT 0,
  `user_types` text DEFAULT '[]',
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `status` varchar(20) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_promotions`
--

LOCK TABLES `mall_promotions` WRITE;
/*!40000 ALTER TABLE `mall_promotions` DISABLE KEYS */;
/*!40000 ALTER TABLE `mall_promotions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_review_likes`
--

DROP TABLE IF EXISTS `mall_review_likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_review_likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `review_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `review_id` (`review_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_review_likes`
--

LOCK TABLES `mall_review_likes` WRITE;
/*!40000 ALTER TABLE `mall_review_likes` DISABLE KEYS */;
/*!40000 ALTER TABLE `mall_review_likes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_reviews`
--

DROP TABLE IF EXISTS `mall_reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_reviews` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `rating` int(11) DEFAULT 5,
  `content` text DEFAULT '',
  `images` text DEFAULT '[]',
  `reply` text DEFAULT '',
  `reply_time` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  `dim_product_rating` decimal(2,1) DEFAULT 0.0,
  `dim_service_rating` decimal(2,1) DEFAULT 0.0,
  `dim_logistics_rating` decimal(2,1) DEFAULT 0.0,
  PRIMARY KEY (`id`),
  KEY `idx_mall_reviews_product` (`product_id`),
  KEY `idx_mall_reviews_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_reviews`
--

LOCK TABLES `mall_reviews` WRITE;
/*!40000 ALTER TABLE `mall_reviews` DISABLE KEYS */;
/*!40000 ALTER TABLE `mall_reviews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `membership_levels`
--

DROP TABLE IF EXISTS `membership_levels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `membership_levels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `level` int(11) NOT NULL DEFAULT 0,
  `tier` int(11) DEFAULT 1,
  `parent_level_id` int(11) DEFAULT 0,
  `price` decimal(10,2) DEFAULT 0.00,
  `points_required` int(11) DEFAULT 0,
  `discount_rate` decimal(3,1) DEFAULT 1.0,
  `points_multiplier` decimal(3,1) DEFAULT 1.0,
  `points_discount_rate` decimal(3,1) DEFAULT 1.0,
  `text_color` varchar(20) DEFAULT '#FFFFFF',
  `bg_color` varchar(20) DEFAULT '#508DFF',
  `benefits` text DEFAULT NULL,
  `icon` varchar(100) DEFAULT '',
  `icon_color` varchar(20) DEFAULT '#909399',
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `membership_levels`
--

LOCK TABLES `membership_levels` WRITE;
/*!40000 ALTER TABLE `membership_levels` DISABLE KEYS */;
INSERT INTO `membership_levels` VALUES
(1,'普通会员',0,1,0,0.00,0,1.0,1.0,1.0,'#FFFFFF','#508DFF','基础权益','ri:user-line','#909399','1','2026-07-10 19:32:17'),
(2,'黄金会员',1,1,0,299.00,3000,0.9,1.5,1.0,'#FFFFFF','#508DFF','9折优惠,1.5倍积分,专属客服','ri:vip-crown-line','#ffb100','1','2026-07-10 19:32:17'),
(3,'钻石会员',2,1,0,599.00,6000,0.8,2.0,1.0,'#FFFFFF','#508DFF','8折优惠,2倍积分,专属客服,优先发货,生日礼包','ri:vip-diamond-line','#377dff','1','2026-07-10 19:32:17'),
(4,'至尊会员',3,1,0,999.00,10000,0.7,3.0,1.0,'#FFFFFF','#508DFF','7折优惠,3倍积分,专属客服,优先发货,生日礼包,年度礼品','ri:star-line','#ff6b6b','1','2026-07-10 19:32:17');
/*!40000 ALTER TABLE `membership_levels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `membership_products`
--

DROP TABLE IF EXISTS `membership_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `membership_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `level_id` int(11) NOT NULL DEFAULT 0,
  `name` varchar(100) DEFAULT '',
  `price` decimal(10,2) DEFAULT 0.00,
  `original_price` decimal(10,2) DEFAULT 0.00,
  `points_price` decimal(10,2) DEFAULT 0.00,
  `points_original_price` decimal(10,2) DEFAULT 0.00,
  `duration_days` int(11) DEFAULT 30,
  `is_promo` tinyint(1) DEFAULT 0,
  `promo_end_time` datetime DEFAULT NULL,
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `membership_products`
--

LOCK TABLES `membership_products` WRITE;
/*!40000 ALTER TABLE `membership_products` DISABLE KEYS */;
/*!40000 ALTER TABLE `membership_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `membership_purchases`
--

DROP TABLE IF EXISTS `membership_purchases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `membership_purchases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT 0,
  `level_id` int(11) DEFAULT 0,
  `level_name` varchar(100) DEFAULT '',
  `amount` decimal(10,2) DEFAULT 0.00,
  `pay_type` varchar(20) DEFAULT 'balance',
  `purchase_type` varchar(20) DEFAULT 'buy',
  `duration_days` int(11) DEFAULT 0,
  `expire_time` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_membership_purchases_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `membership_purchases`
--

LOCK TABLES `membership_purchases` WRITE;
/*!40000 ALTER TABLE `membership_purchases` DISABLE KEYS */;
/*!40000 ALTER TABLE `membership_purchases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menus`
--

DROP TABLE IF EXISTS `menus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `menus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT 0,
  `name` varchar(100) NOT NULL,
  `path` varchar(200) NOT NULL DEFAULT '',
  `component` varchar(200) DEFAULT '',
  `redirect` varchar(200) DEFAULT '',
  `title` varchar(100) NOT NULL,
  `icon` varchar(100) DEFAULT '',
  `sort_order` int(11) DEFAULT 0,
  `is_hidden` tinyint(1) DEFAULT 0,
  `is_full_page` tinyint(1) DEFAULT 0,
  `is_keep_alive` tinyint(1) DEFAULT 1,
  `is_fixed_tab` tinyint(1) DEFAULT 0,
  `auth_list` text DEFAULT NULL,
  `roles` text DEFAULT NULL,
  `enabled` tinyint(1) DEFAULT 1,
  `mobile_path` varchar(200) DEFAULT '',
  `icon_bg` varchar(20) DEFAULT '#4ECDC4',
  `icon_svg` text DEFAULT NULL,
  `category` varchar(50) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menus`
--

LOCK TABLES `menus` WRITE;
/*!40000 ALTER TABLE `menus` DISABLE KEYS */;
INSERT INTO `menus` VALUES
(1,0,'仪表盘','/dashboard','/index/index','/dashboard/console','menus.dashboard.title','ri:pie-chart-line',1,0,0,0,0,NULL,'[\"R_SUPER\",\"R_ADMIN\"]',1,'','#6C5CE7',NULL,'','2026-07-10 19:32:16','2026-07-10 19:32:16'),
(2,0,'运营管理','/operation','/index/index','','menus.operation.title','ri:settings-3-line',2,0,0,0,0,NULL,'[\"R_SUPER\",\"R_ADMIN\"]',1,'','#4ECDC4',NULL,'','2026-07-10 19:32:16','2026-07-10 19:32:16'),
(3,0,'系统管理','/system','/index/index','','menus.system.title','ri:user-3-line',3,0,0,0,0,NULL,'[\"R_SUPER\",\"R_ADMIN\"]',1,'','#4ECDC4',NULL,'','2026-07-10 19:32:16','2026-07-10 19:32:16'),
(4,0,'结果页','/result','/index/index','','menus.result.title','ri:checkbox-circle-line',5,0,0,0,0,NULL,NULL,1,'','#4ECDC4',NULL,'','2026-07-10 19:32:16','2026-07-10 19:32:16'),
(5,0,'异常页','/exception','/index/index','','menus.exception.title','ri:error-warning-line',6,0,0,0,0,NULL,NULL,1,'','#4ECDC4',NULL,'','2026-07-10 19:32:16','2026-07-10 19:32:16'),
(6,0,'应用商店','/appstore','/index/index','','menus.appstore.title','ri:apps-2-line',4,0,0,0,0,NULL,'[\"R_SUPER\",\"R_ADMIN\",\"R_USER\"]',1,'','#4ECDC4',NULL,'','2026-07-10 19:32:16','2026-07-10 19:32:16'),
(7,1,'控制台','console','/dashboard/console','','menus.dashboard.console','',1,0,0,1,1,NULL,NULL,1,'/dashboard/console','#6C5CE7','M3 13h8V3H3v10zm0 8h8v-6H3v6zm10 0h8V11h-8v10zm0-18v6h8V3h-8z','','2026-07-10 19:32:16','2026-07-10 19:32:16'),
(8,2,'卡密管理','cardkey','/operation/cardkey/index','','menus.operation.cardkey','',1,0,0,1,0,NULL,NULL,1,'/appstore/cardkey-manage','#A29BFE','M20 12H4v-2h16v2zm0 6H4v-2h16v2zM20 4v2H4V4h16z','','2026-07-10 19:32:16','2026-07-10 19:32:16'),
(9,2,'会员管理','membership','/operation/membership/index','','menus.operation.membership','',2,0,0,1,0,NULL,NULL,1,'/appstore/operation/membership','#A29BFE','M20 2H4c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-2 11h-3v3c0 .55-.45 1-1 1h-2c-.55 0-1-.45-1-1v-3H8c-.55 0-1-.45-1-1v-2c0-.55.45-1 1-1h3V6c0-.55.45-1 1-1h2c.55 0 1 .45 1 1v3h3c.55 0 1 .45 1 1v2c0 .55-.45 1-1 1z','','2026-07-10 19:32:16','2026-07-10 19:32:16'),
(10,2,'优惠券管理','coupon','/operation/coupon/index','','menus.operation.coupon','',3,0,0,1,0,NULL,NULL,1,'/appstore/operation/coupon','#FDCB6E','M20 6.67c0 .55-.23 1.07-.6 1.43L12 14.9l-7.4-6.8c-.37-.36-.6-.88-.6-1.43 0-1.12.92-2.01 2.06-2.01.55 0 1.06.22 1.43.58L12 9.1l4.51-3.84c.37-.36.88-.58 1.43-.58C19.08 4.67 20 5.57 20 6.67z M20 12c0 .55-.23 1.07-.6 1.43L12 20.2l-7.4-6.8c-.37-.36-.6-.88-.6-1.43 0-1.12.92-2.01 2.06-2.01.55 0 1.06.22 1.43.58L12 14.4l4.51-3.84c.37-.36.88-.58 1.43-.58C19.08 9.97 20 10.87 20 12z','','2026-07-10 19:32:16','2026-07-10 19:32:16'),
(11,2,'积分管理','points','/operation/points/index','','menus.operation.points','',4,0,0,1,0,NULL,NULL,1,'/appstore/operation/points','#FDCB6E','M11.8 10.9c-2.27-.59-3-1.2-3-2.15 0-1.09 1.01-1.85 2.7-1.85 1.78 0 2.44.85 2.5 2.1h2.21c-.07-1.72-1.12-3.3-3.21-3.81V3h-3v2.16c-1.94.42-3.5 1.68-3.5 3.61 0 2.31 1.91 3.46 4.7 4.13 2.5.6 3 1.48 3 2.41 0 .69-.49 1.79-2.7 1.79-2.06 0-2.87-.92-2.98-2.1h-2.2c.12 2.19 1.76 3.42 3.68 3.83V21h3v-2.15c1.95-.37 3.5-1.5 3.5-3.55 0-2.84-2.43-3.81-4.7-4.4z','','2026-07-10 19:32:16','2026-07-10 19:32:16'),
(12,2,'经验等级','experience','/operation/experience/index','','menus.operation.experience','',5,0,0,1,0,NULL,NULL,1,'/appstore/experience-manage','#FDCB6E','M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z','','2026-07-10 19:32:16','2026-07-10 19:32:16'),
(13,2,'插件管理','plugins','/operation/plugins/index','','menus.operation.plugins','',6,0,0,1,0,NULL,NULL,1,'/appstore/plugin-manage','#0984E3','M19.56 11.36L13 8.44V7c0-.55-.45-1-1-1s-1 .45-1 1v1.44l-6.56 2.92c-.32.14-.44.42-.44.74 0 .32.12.6.44.74L11 15.56V18l-1.3 1.22c-.24.22-.36.44-.36.56 0 .4.44.72.66.72.1 0 .2-.02.3-.06L12 20l1.7.44c.1.04.2.06.3.06.22 0 .66-.32.66-.72 0-.12-.12-.34-.36-.56L13 18v-2.44l6.56-2.92c.32-.14.44-.42.44-.74 0-.32-.12-.6-.44-.74z','','2026-07-10 19:32:16','2026-07-10 19:32:16'),
(14,2,'称号管理','title','/operation/title/index','','称号管理','',7,0,0,1,0,NULL,NULL,1,'/appstore/title-manage','#A29BFE','M20.5 11H19V7c0-1.1-.9-2-2-2h-4V3.5C13 2.12 11.88 1 10.5 1S8 2.12 8 3.5V5H4c-1.1 0-1.99.9-1.99 2v3.8H3.5c1.49 0 2.7 1.21 2.7 2.7s-1.21 2.7-2.7 2.7H2V20c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2v-3.8h-1.5c-1.49 0-2.7-1.21-2.7-2.7s1.21-2.7 2.7-2.7H22V7c0-1.1-.9-2-2-2h-4V3.5C16 2.12 14.88 1 13.5 1S11 2.12 11 3.5V5H8V3.5C8 2.12 6.88 1 5.5 1S3 2.12 3 3.5V11h-.5C1.12 11 0 12.12 0 13.5S1.12 16 2.5 16H3v4h18v-4h.5c1.38 0 2.5-1.12 2.5-2.5S21.38 11 20.5 11z','','2026-07-10 19:32:16','2026-07-10 19:32:16'),
(15,2,'推广返佣','commission','/operation/commission/index','','推广返佣','',8,0,0,1,0,NULL,NULL,1,'/appstore/commission-manage','#A29BFE','M20 6h-2.18c.11-.31.18-.65.18-1 0-1.66-1.34-3-3-3-1.05 0-1.96.54-2.5 1.35l-.5.67-.5-.68C10.96 2.54 10.05 2 9 2 7.34 2 6 3.34 6 5c0 .35.07.69.18 1H4c-1.11 0-1.99.89-1.99 2L2 19c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V8c0-1.11-.89-2-2-2zm-5-2c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zM9 4c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zm11 15H4v-2h16v2zm0-5H4V8h5.08L7 10.83 8.62 12 11 8.76l1-1.36 1 1.36L15.38 12 17 10.83 14.92 8H20v6z','','2026-07-10 19:32:16','2026-07-10 19:32:16'),
(16,2,'文件上传策略','filepolicy','/operation/filepolicy/index','','文件上传策略','',9,0,0,1,0,NULL,NULL,1,'/appstore/file-policy-manage','#A29BFE','M3 13h8V3H3v10zm0 8h8v-6H3v6zm10 0h8V11h-8v10zm0-18v6h8V3h-8z','','2026-07-10 19:32:16','2026-07-10 19:32:16'),
(17,2,'结算规则','settlement','/operation/settlement/index','','结算规则','ri:exchange-funds-line',10,0,0,1,0,NULL,NULL,1,'/appstore/operation/settlement','#A29BFE','M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zM9 17H7v-7h2v7zm4 0h-2V7h2v10zm4 0h-2v-4h2v4z','','2026-07-10 19:32:16','2026-07-10 19:32:16'),
(18,2,'会员商品','membership-products','/operation/membership-products/index','','会员商品','',11,0,0,1,0,NULL,NULL,1,'/appstore/operation/membership-products','#A29BFE','M12 3L1 9l4 2.18v6L12 21l7-3.82v-6l2-1.09V17h2V9L12 3zm6.82 6L12 12.72 5.18 9 12 5.28 18.82 9zM17 15.99l-5 2.73-5-2.73v-3.72L12 15l5-2.73v3.72z','','2026-07-10 19:32:16','2026-07-10 19:32:16'),
(19,2,'购买记录','membership-purchases','/operation/membership-purchases/index','','购买记录','',12,0,0,1,0,NULL,NULL,1,'/appstore/operation/purchase-records','#A29BFE','M20 4H4c-1.11 0-1.99.89-1.99 2L2 18c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V6c0-1.11-.89-2-2-2zm0 14H4v-6h16v6zm0-10H4V6h16v2z','','2026-07-10 19:32:16','2026-07-10 19:32:16'),
(20,2,'付费内容订单','content-purchases','/operation/content-purchases/index','','付费内容订单','',13,0,0,1,0,NULL,NULL,1,'/appstore/operation/content-purchases','#A29BFE','M20 4H4c-1.11 0-2 .89-2 2v12c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V6c0-1.11-.89-2-2-2zm-8 7c1.66 0 3-1.34 3-3s-1.34-3-3-3-3 1.34-3 3 1.34 3 3 3zm0 2c-2.67 0-8 1.34-8 4v1h16v-1c0-2.66-5.33-4-8-4z','','2026-07-10 19:32:16','2026-07-10 19:32:16'),
(21,3,'用户管理','user','/system/user','','menus.system.user','',1,0,0,1,0,NULL,NULL,1,'/appstore/user-manage','#0984E3','M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5C6.34 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z','','2026-07-10 19:32:16','2026-07-10 19:32:16'),
(22,3,'角色管理','role','/system/role','','menus.system.role','',2,0,0,1,0,NULL,NULL,1,'/appstore/role-manage','#0984E3','M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z','','2026-07-10 19:32:16','2026-07-10 19:32:16'),
(23,3,'个人中心','user-center','/system/user-center','','menus.system.userCenter','',3,1,0,1,1,NULL,NULL,1,'/system/user-center','#0984E3','M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z','','2026-07-10 19:32:16','2026-07-10 19:32:16'),
(24,3,'菜单管理','menu','/system/menu','','menus.system.menu','',4,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]',NULL,1,'/appstore/menu-manage','#0984E3','M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z','','2026-07-10 19:32:16','2026-07-10 19:32:16'),
(25,3,'注销审核','delete-review','/system/user/delete-review','','注销审核','',5,0,0,1,0,NULL,NULL,1,'/appstore/delete-review','#0984E3','M15 3H6c-.83 0-1.54.5-1.84 1.22l-3.02 7.05c-.09.23-.14.47-.14.73v2c0 1.1.9 2 2 2h6.31l-.95 4.57-.03.32c0 .41.17.79.44 1.06L9.83 23l6.59-6.59c.36-.36.58-.86.58-1.41V5c0-1.1-.9-2-2-2zm4 0v12h4V3h-4z','','2026-07-10 19:32:16','2026-07-10 19:32:16'),
(26,3,'蓝V认证审核','verification','/system/verification/index','','蓝V认证审核','',6,0,0,1,0,NULL,NULL,1,'/appstore/verification-manage','#0984E3','M23 12l-2.44-2.78.34-3.68-3.61-.82-1.89-3.18L12 3 8.6 1.54 6.71 4.72l-3.61.81.34 3.68L1 12l2.44 2.78-.34 3.69 3.61.82 1.89 3.18L12 21l3.4 1.46 1.89-3.18 3.61-.82-.34-3.68L23 12zm-10 5h-2v-2h2v2zm0-4h-2V7h2v6z','','2026-07-10 19:32:16','2026-07-10 19:32:16'),
(27,3,'邀请码管理','invite','/system/invite/index','','邀请码管理','',7,0,0,1,0,NULL,NULL,1,'/appstore/invite-manage','#0984E3','M20 8h-3V4H3c-1.1 0-2 .9-2 2v11h2c0 1.66 1.34 3 3 3s3-1.34 3-3h6c0 1.66 1.34 3 3 3s3-1.34 3-3h2v-5l-3-4zm-5 0v3H7V8h8zM6 18.5c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zm12 0c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5z','','2026-07-10 19:32:16','2026-07-10 19:32:16'),
(28,3,'邮件配置','email','/system/email/index','','邮件配置','',8,0,0,1,0,NULL,NULL,1,'/appstore/email-config','#0984E3','M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z','','2026-07-10 19:32:16','2026-07-10 19:32:16'),
(29,3,'文件仓库','filerepo','/system/filerepo/index','','文件仓库','',9,0,0,1,0,NULL,NULL,1,'/appstore/file-repo-manage','#0984E3','M20 2H8c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-2 5h-3v5.5c0 1.38-1.12 2.5-2.5 2.5S10 13.88 10 12.5s1.12-2.5 2.5-2.5c.57 0 1.08.19 1.5.51V5h4v2zM4 6H2v14c0 1.1.9 2 2 2h14v-2H4V6z','','2026-07-10 19:32:16','2026-07-10 19:32:16'),
(30,3,'回收站','recycle','/system/recycle/index','','回收站','',10,0,0,1,0,NULL,NULL,1,'/system/recycle','#0984E3','M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z','','2026-07-10 19:32:16','2026-07-10 19:32:16'),
(31,3,'系统日志','syslog','/system/syslog/index','','系统日志','',11,0,0,1,0,NULL,NULL,1,'/system/syslog','#0984E3','M19 3h-4.18C14.4 1.84 13.3 1 12 1c-1.3 0-2.4.84-2.82 2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-7 0c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zm2 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z','','2026-07-10 19:32:16','2026-07-10 19:32:16'),
(32,3,'系统配置','sysconfig','/system/sysconfig/index','','系统配置','',12,0,0,1,0,NULL,NULL,1,'/system/sysconfig','#0984E3','M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94L14.4 2.81c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41L9.25 5.35c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.07.62-.07.94s.02.64.07.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z','','2026-07-10 19:32:16','2026-07-10 19:32:16'),
(33,3,'任务管理','task','/system/task/index','','任务管理','',13,0,0,1,0,NULL,NULL,1,'/appstore/task-manage','#0984E3','M19 3h-4.18C14.4 1.84 13.3 1 12 1c-1.3 0-2.4.84-2.82 2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-7 0c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zm-2 14l-4-4 1.41-1.41L10 14.17l6.59-6.59L18 9l-8 8z','','2026-07-10 19:32:16','2026-07-10 19:32:16'),
(34,3,'邮件卡片','email-templates','/appstore/email-templates','','邮件卡片','',14,0,0,1,0,NULL,NULL,1,'/appstore/email-templates','#0984E3','M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 14H4V6h16v12zM6 10h2v2H6zm0 4h8v2H6zm10 0h2v2h-2zm-6-4h8v2h-8z','','2026-07-10 19:32:16','2026-07-10 19:32:16'),
(35,3,'邮件推送','email-push','/appstore/email-push','','邮件推送','',15,0,0,1,0,NULL,NULL,1,'/appstore/email-push','#0984E3','M2.01 21L23 12 2.01 3 2 10l15 2-15 2 .01 7z','','2026-07-10 19:32:16','2026-07-10 19:32:16'),
(36,3,'对象存储','storage-config','/appstore/storage-config','','对象存储','',16,0,0,1,0,NULL,NULL,1,'/appstore/storage-config','#0984E3','M22 6c0-1.1-.9-2-2-2H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6zm-2 0l-8 5-8-5h16zm0 12H4V8l8 5 8-5v10z','','2026-07-10 19:32:16','2026-07-10 19:32:16'),
(37,6,'应用列表','list','/appstore/list','','menus.appstore.list','',1,0,0,1,0,NULL,NULL,1,'/appstore/list','#00B894','M3 5h18v2H3V5zm0 4h12v2H3V9zm0 4h18v2H3v-2zm0 4h12v2H3v-2z','','2026-07-10 19:32:16','2026-07-10 19:32:16'),
(38,6,'应用详情','detail/:id','/appstore/detail','','menus.appstore.detail','',2,1,0,0,0,NULL,NULL,1,'/appstore/browse/detail','#00B894','M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z','','2026-07-10 19:32:16','2026-07-10 19:32:16'),
(39,6,'分类管理','category-manage','/appstore/category','','menus.appstore.category','ri:apps-2-line',3,0,0,1,0,NULL,'[\"R_SUPER\",\"R_ADMIN\"]',1,'/appstore/category','#00B894','M7 18h2V6H7v12zm4 4h2V2h-2v20zm-8-8h2v-4H3v4zm12 4h2V6h-2v12zm4-8v4h2v-4h-2z','','2026-07-10 19:32:16','2026-07-10 19:32:16'),
(40,6,'举报管理','reports','/appstore/reports','','menus.appstore.reports','ri:apps-2-line',4,0,0,1,0,NULL,'[\"R_SUPER\",\"R_ADMIN\"]',1,'','#4ECDC4',NULL,'','2026-07-10 19:32:16','2026-07-10 19:32:16'),
(41,6,'我的提交','my-submissions','/appstore/submissions','','menus.appstore.mySubmissions','',5,0,0,1,0,NULL,'[\"R_SUPER\",\"R_ADMIN\",\"R_USER\"]',1,'/appstore/submissions','#00B894','M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41L9 16.17z','','2026-07-10 19:32:16','2026-07-10 19:32:16'),
(42,6,'提交审核','review','/appstore/review','','menus.appstore.review','',6,0,0,1,0,NULL,'[\"R_SUPER\",\"R_ADMIN\"]',1,'/appstore/review','#00B894','M19 3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-9 14l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z','','2026-07-10 19:32:16','2026-07-10 19:32:16'),
(43,6,'移动端审核','review-mobile','/appstore/review/mobile','','menus.appstore.review','',7,1,0,1,0,NULL,'[\"R_SUPER\",\"R_ADMIN\"]',1,'/appstore/review-mobile','#00B894','M17 1.01L7 1c-1.1 0-2 .9-2 2v18c0 1.1.9 2 2 2h10c1.1 0 2-.9 2-2V3c0-1.1-.9-1.99-2-1.99zM17 19H7V5h10v14z','','2026-07-10 19:32:16','2026-07-10 19:32:16'),
(44,6,'官方标签','official-tags','/appstore/official-tags','','menus.appstore.officialTags','',8,0,0,1,0,NULL,'[\"R_SUPER\",\"R_ADMIN\"]',1,'/appstore/official-tags','#00B894','M17.63 5.84C17.27 5.33 16.67 5 16 5L5 5.01C3.9 5.01 3 5.9 3 7v10c0 1.1.9 1.99 2 1.99L16 19c.67 0 1.27-.33 1.63-.84L22 12l-4.37-6.16z','','2026-07-10 19:32:16','2026-07-10 19:32:16'),
(45,6,'板块管理','section-manage','','','板块管理','',9,1,0,0,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"},{\"title\":\"管理版主\",\"authMark\":\"moderate\"},{\"title\":\"启停\",\"authMark\":\"toggle\"},{\"title\":\"处理解锁\",\"authMark\":\"unlock\"}]','[\"R_SUPER\",\"R_ADMIN\"]',1,'/appstore/section-manage','#00B894','M3 21h18v-2H3v2zm6-4h12v-2H9v2zm-6-4h18v-2H3v2zm6-4h12V7H9v2zM3 3v2h18V3H3z','','2026-07-10 19:32:16','2026-07-10 19:32:16'),
(46,6,'帖子管理','community-posts','','','帖子管理','',10,1,0,0,0,'[{\"title\":\"置顶\",\"authMark\":\"pin\"},{\"title\":\"加精\",\"authMark\":\"essence\"},{\"title\":\"热帖\",\"authMark\":\"boost\"},{\"title\":\"锁定\",\"authMark\":\"lock\"},{\"title\":\"审核\",\"authMark\":\"approve\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]','[\"R_SUPER\",\"R_ADMIN\"]',1,'','#4ECDC4',NULL,'','2026-07-10 19:32:16','2026-07-10 19:32:16'),
(47,6,'举报管理','community-reports','','','举报管理','',11,1,0,0,0,'[{\"title\":\"处理\",\"authMark\":\"handle\"},{\"title\":\"忽略\",\"authMark\":\"ignore\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]','[\"R_SUPER\",\"R_ADMIN\"]',1,'','#4ECDC4',NULL,'','2026-07-10 19:32:16','2026-07-10 19:32:16'),
(48,6,'评论管理','community-comments','','','评论管理','',12,1,0,0,0,'[{\"title\":\"置顶\",\"authMark\":\"pin\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]','[\"R_SUPER\",\"R_ADMIN\"]',1,'','#4ECDC4',NULL,'','2026-07-10 19:32:16','2026-07-10 19:32:16'),
(49,4,'成功页','success','/result/success/index','','menus.result.success','',1,0,1,0,0,NULL,NULL,1,'/result/success','#27AE60','M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z','','2026-07-10 19:32:16','2026-07-10 19:32:16'),
(50,4,'失败页','fail','/result/fail/index','','menus.result.fail','',2,0,1,0,0,NULL,NULL,1,'/result/fail','#E74C3C','M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z','','2026-07-10 19:32:16','2026-07-10 19:32:16'),
(51,5,'403页面','403','/exception/403/index','','menus.exception.forbidden','',1,0,1,0,0,NULL,NULL,1,'/403','#E17055','M14.4 6L14 4H5v17h2v-7h5.6l.4 2h7V6h-5.6z','','2026-07-10 19:32:16','2026-07-10 19:32:16'),
(52,5,'404页面','404','/exception/404/index','','menus.exception.notFound','',2,0,1,0,0,NULL,NULL,1,'/404','#E17055','M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z','','2026-07-10 19:32:16','2026-07-10 19:32:16'),
(53,5,'500页面','500','/exception/500/index','','menus.exception.serverError','',3,0,1,0,0,NULL,NULL,1,'/500','#E17055','M21 19V5c0-1.1-.9-2-2-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2zM8.5 13.5l2.5 3.01L14.5 12l4.5 6H5l3.5-4.5z','','2026-07-10 19:32:16','2026-07-10 19:32:16'),
(55,0,'test_crud_menu','/test-crud','test/index','','CRUD Menu','',99,0,0,0,0,NULL,NULL,1,'','#4ECDC4','','system','2026-07-10 20:11:44','2026-07-10 20:11:44'),
(56,0,'test_crud_menu2','/test-crud2','test/index2','','CRUD Menu 2','',100,0,0,0,0,NULL,NULL,1,'','#4ECDC4','','system','2026-07-10 20:11:44','2026-07-10 20:11:44'),
(58,0,'test_crud_menu','/test-crud','test/index','','CRUD Menu','',99,0,0,0,0,NULL,NULL,1,'','#4ECDC4','','system','2026-07-10 20:13:24','2026-07-10 20:13:24'),
(59,0,'test_crud_menu2','/test-crud2','test/index2','','CRUD Menu 2','',100,0,0,0,0,NULL,NULL,1,'','#4ECDC4','','system','2026-07-10 20:13:24','2026-07-10 20:13:24'),
(61,0,'test_crud_menu','/test-crud','test/index','','CRUD Menu','',99,0,0,0,0,NULL,NULL,1,'','#4ECDC4','','system','2026-07-10 20:13:55','2026-07-10 20:13:55'),
(62,0,'test_crud_menu2','/test-crud2','test/index2','','CRUD Menu 2','',100,0,0,0,0,NULL,NULL,1,'','#4ECDC4','','system','2026-07-10 20:13:55','2026-07-10 20:13:55'),
(64,0,'test_crud_menu','/test-crud','test/index','','CRUD Menu','',99,0,0,0,0,NULL,NULL,1,'','#4ECDC4','','system','2026-07-10 20:17:39','2026-07-10 20:17:39'),
(65,0,'test_crud_menu2','/test-crud2','test/index2','','CRUD Menu 2','',100,0,0,0,0,NULL,NULL,1,'','#4ECDC4','','system','2026-07-10 20:17:39','2026-07-10 20:17:39');
/*!40000 ALTER TABLE `menus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_no` varchar(50) NOT NULL,
  `buyer_id` int(11) NOT NULL,
  `buyer_name` varchar(100) DEFAULT '',
  `seller_id` int(11) DEFAULT 0,
  `seller_name` varchar(100) DEFAULT '',
  `order_type` varchar(30) NOT NULL,
  `order_desc` varchar(500) DEFAULT '',
  `ref_id` int(11) DEFAULT 0,
  `ref_table` varchar(50) DEFAULT '',
  `pay_type` varchar(20) DEFAULT 'balance',
  `total_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `coupon_id` int(11) DEFAULT 0,
  `coupon_discount` decimal(10,2) DEFAULT 0.00,
  `paid_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `status` varchar(20) DEFAULT 'shipped',
  `confirm_days` int(11) DEFAULT 7,
  `confirm_deadline` datetime DEFAULT NULL,
  `shipped_at` datetime DEFAULT NULL,
  `confirmed_at` datetime DEFAULT NULL,
  `refund_reason` varchar(500) DEFAULT '',
  `refund_requested_at` datetime DEFAULT NULL,
  `refund_responded_at` datetime DEFAULT NULL,
  `refund_reviewed_by` int(11) DEFAULT 0,
  `refund_reviewed_by_name` varchar(100) DEFAULT '',
  `reviewed_at` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_no` (`order_no`),
  KEY `idx_orders_buyer` (`buyer_id`),
  KEY `idx_orders_seller` (`seller_id`),
  KEY `idx_orders_status` (`status`),
  KEY `idx_orders_no` (`order_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plugins`
--

DROP TABLE IF EXISTS `plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `plugins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `version` varchar(50) DEFAULT '1.0.0',
  `author` varchar(100) DEFAULT '',
  `icon` varchar(500) DEFAULT '',
  `entry_url` varchar(500) DEFAULT '',
  `component_name` varchar(200) DEFAULT '',
  `plugin_dir` varchar(100) DEFAULT '',
  `manifest` text DEFAULT NULL,
  `enabled` int(11) DEFAULT 1,
  `sort_order` int(11) DEFAULT 0,
  `points` int(11) DEFAULT 0,
  `points_name` varchar(20) DEFAULT '金币',
  `tags` text DEFAULT NULL,
  `format` varchar(20) DEFAULT 'package',
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plugins`
--

LOCK TABLES `plugins` WRITE;
/*!40000 ALTER TABLE `plugins` DISABLE KEYS */;
INSERT INTO `plugins` VALUES
(1,'feature-panel','应用商店浏览页功能入口面板','1.0.0','Admin','ri:apps-line','/plugins/feature-panel/scripts/panel.js','FeaturePanel','feature-panel','{\"name\":\"feature-panel\",\"type\":\"frontend\",\"slot\":\"appstore-browse\",\"config\":{\"cardShow\":false,\"items\":[{\"label\":\"签到\",\"icon\":\"checkin\",\"color\":\"#FF6B35\",\"url\":\"/app/checkin\",\"show\":true},{\"label\":\"投稿\",\"icon\":\"submit\",\"color\":\"#3B82F6\",\"url\":\"/appstore/submissions\",\"show\":true},{\"label\":\"收藏\",\"icon\":\"fav\",\"color\":\"#EF4444\",\"url\":\"/appstore/favorites\",\"show\":true},{\"label\":\"排行\",\"icon\":\"rank\",\"color\":\"#EC4899\",\"url\":\"/appstore/category\",\"show\":true},{\"label\":\"交流群\",\"icon\":\"group\",\"color\":\"#22C55E\",\"url\":\"/community\",\"show\":true}],\"links\":[{\"label\":\"新贴\",\"url\":\"/community\",\"show\":true},{\"label\":\"发帖子\",\"url\":\"/community/create\",\"show\":true},{\"label\":\"热门话题\",\"url\":\"/community/hot\",\"show\":true}],\"banner\":{\"show\":true,\"text\":\"新手必看教程——发帖指引之基础篇\",\"url\":\"/help/guide\",\"closable\":true},\"mineBanner\":{\"show\":true,\"text\":\"全站规则，快来看看，不然就亏大了\",\"url\":\"https://monkeycode-ai.com/?ic=019f2c74-4064-7d7c-9003-743ce2df5af9\",\"closable\":false}},\"configSchema\":{\"cardShow\":{\"label\":\"图标卡片显示\"},\"items\":{\"label\":\"图标按钮\"},\"links\":{\"label\":\"底部链接\"},\"banner\":{\"label\":\"公告横幅\"},\"mineBanner\":{\"label\":\"我的页公告\"}}}',1,0,0,'金币',NULL,'package','1','2026-07-10 20:34:49');
/*!40000 ALTER TABLE `plugins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `points_records`
--

DROP TABLE IF EXISTS `points_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `points_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `type` varchar(20) NOT NULL DEFAULT 'earn',
  `points` int(11) NOT NULL DEFAULT 0,
  `balance` int(11) DEFAULT 0,
  `source` varchar(200) DEFAULT '',
  `description` text DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  `ref_id` int(11) DEFAULT 0,
  `ref_type` varchar(50) DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `idx_points_records_user_id` (`user_id`),
  KEY `idx_points_records_type` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `points_records`
--

LOCK TABLES `points_records` WRITE;
/*!40000 ALTER TABLE `points_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `points_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `points_transfer_records`
--

DROP TABLE IF EXISTS `points_transfer_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `points_transfer_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from_user_id` int(11) NOT NULL,
  `from_user_name` varchar(100) DEFAULT '',
  `to_user_id` int(11) NOT NULL,
  `to_user_name` varchar(100) DEFAULT '',
  `amount` int(11) NOT NULL DEFAULT 0,
  `fee` int(11) DEFAULT 0,
  `remark` varchar(300) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `points_transfer_records`
--

LOCK TABLES `points_transfer_records` WRITE;
/*!40000 ALTER TABLE `points_transfer_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `points_transfer_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post_favorites`
--

DROP TABLE IF EXISTS `post_favorites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `post_favorites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`post_id`),
  KEY `idx_post_favorites_user` (`user_id`),
  KEY `idx_post_favorites_post` (`post_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_favorites`
--

LOCK TABLES `post_favorites` WRITE;
/*!40000 ALTER TABLE `post_favorites` DISABLE KEYS */;
/*!40000 ALTER TABLE `post_favorites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `private_messages`
--

DROP TABLE IF EXISTS `private_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `private_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from_user_id` int(11) NOT NULL,
  `from_user_name` varchar(100) DEFAULT '',
  `from_user_avatar` varchar(20) DEFAULT '#448AFF',
  `to_user_id` int(11) NOT NULL,
  `content` text DEFAULT '',
  `is_read` tinyint(1) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  `image_url` varchar(500) DEFAULT '',
  `message_type` varchar(20) DEFAULT 'text',
  `order_card` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_private_messages_from` (`from_user_id`),
  KEY `idx_private_messages_to` (`to_user_id`),
  KEY `idx_private_messages_conversation` (`from_user_id`,`to_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `private_messages`
--

LOCK TABLES `private_messages` WRITE;
/*!40000 ALTER TABLE `private_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `private_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recharge_amounts`
--

DROP TABLE IF EXISTS `recharge_amounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `recharge_amounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `label` varchar(100) DEFAULT '',
  `discount` varchar(100) DEFAULT '',
  `status` tinyint(1) DEFAULT 1,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recharge_amounts`
--

LOCK TABLES `recharge_amounts` WRITE;
/*!40000 ALTER TABLE `recharge_amounts` DISABLE KEYS */;
INSERT INTO `recharge_amounts` VALUES
(5,10.00,'CRUD Test 10','',1,'2026-07-10 20:17:40');
/*!40000 ALTER TABLE `recharge_amounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recharge_orders`
--

DROP TABLE IF EXISTS `recharge_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `recharge_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_no` varchar(64) NOT NULL,
  `user_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `pay_method` varchar(20) DEFAULT 'epay',
  `status` varchar(20) DEFAULT 'pending',
  `trade_no` varchar(100) DEFAULT '',
  `paid_time` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_recharge_orders_user` (`user_id`),
  KEY `idx_recharge_orders_order_no` (`order_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recharge_orders`
--

LOCK TABLES `recharge_orders` WRITE;
/*!40000 ALTER TABLE `recharge_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `recharge_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recycle_bin`
--

DROP TABLE IF EXISTS `recycle_bin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `recycle_bin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `original_table` varchar(100) NOT NULL,
  `original_id` int(11) NOT NULL,
  `data_json` text NOT NULL,
  `deleted_by` int(11) DEFAULT 0,
  `deleted_by_name` varchar(100) DEFAULT '',
  `delete_reason` varchar(500) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_recycle_bin_table` (`original_table`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recycle_bin`
--

LOCK TABLES `recycle_bin` WRITE;
/*!40000 ALTER TABLE `recycle_bin` DISABLE KEYS */;
/*!40000 ALTER TABLE `recycle_bin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `referral_links`
--

DROP TABLE IF EXISTS `referral_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `referral_links` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `code` varchar(32) NOT NULL,
  `mode` varchar(20) DEFAULT 'purchase',
  `discount` decimal(5,2) DEFAULT 0.00,
  `click_count` int(11) DEFAULT 0,
  `register_count` int(11) DEFAULT 0,
  `purchase_count` int(11) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  UNIQUE KEY `code` (`code`),
  KEY `idx_referral_links_code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `referral_links`
--

LOCK TABLES `referral_links` WRITE;
/*!40000 ALTER TABLE `referral_links` DISABLE KEYS */;
/*!40000 ALTER TABLE `referral_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_permissions`
--

DROP TABLE IF EXISTS `role_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `auth_mark` varchar(100) DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_id` (`role_id`,`menu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=107 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_permissions`
--

LOCK TABLES `role_permissions` WRITE;
/*!40000 ALTER TABLE `role_permissions` DISABLE KEYS */;
INSERT INTO `role_permissions` VALUES
(1,1,1,''),
(2,1,2,''),
(3,1,3,''),
(4,1,4,''),
(5,1,5,''),
(6,1,6,''),
(7,1,7,''),
(8,1,8,''),
(9,1,9,''),
(10,1,10,''),
(11,1,11,''),
(12,1,12,''),
(13,1,13,''),
(14,1,14,''),
(15,1,15,''),
(16,1,16,''),
(17,1,17,''),
(18,1,18,''),
(19,1,19,''),
(20,1,20,''),
(21,1,21,''),
(22,1,22,''),
(23,1,23,''),
(24,1,24,''),
(25,1,25,''),
(26,1,26,''),
(27,1,27,''),
(28,1,28,''),
(29,1,29,''),
(30,1,30,''),
(31,1,31,''),
(32,1,32,''),
(33,1,33,''),
(34,1,34,''),
(35,1,35,''),
(36,1,36,''),
(37,1,37,''),
(38,1,38,''),
(39,1,39,''),
(40,1,40,''),
(41,1,41,''),
(42,1,42,''),
(43,1,43,''),
(44,1,44,''),
(45,1,45,''),
(46,1,46,''),
(47,1,47,''),
(48,1,48,''),
(49,1,49,''),
(50,1,50,''),
(51,1,51,''),
(52,1,52,''),
(53,1,53,''),
(54,2,1,''),
(55,2,2,''),
(56,2,3,''),
(57,2,4,''),
(58,2,5,''),
(59,2,6,''),
(60,2,7,''),
(61,2,8,''),
(62,2,9,''),
(63,2,10,''),
(64,2,11,''),
(65,2,12,''),
(66,2,13,''),
(67,2,14,''),
(68,2,15,''),
(69,2,16,''),
(70,2,17,''),
(71,2,18,''),
(72,2,19,''),
(73,2,20,''),
(74,2,21,''),
(75,2,22,''),
(76,2,23,''),
(77,2,24,''),
(78,2,25,''),
(79,2,26,''),
(80,2,27,''),
(81,2,28,''),
(82,2,29,''),
(83,2,30,''),
(84,2,31,''),
(85,2,32,''),
(86,2,33,''),
(87,2,34,''),
(88,2,35,''),
(89,2,36,''),
(90,2,37,''),
(91,2,38,''),
(92,2,39,''),
(93,2,40,''),
(94,2,41,''),
(95,2,42,''),
(96,2,43,''),
(97,2,44,''),
(98,2,45,''),
(99,2,46,''),
(100,2,47,''),
(101,2,48,''),
(102,2,49,''),
(103,2,50,''),
(104,2,51,''),
(105,2,52,''),
(106,2,53,'');
/*!40000 ALTER TABLE `role_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(100) NOT NULL,
  `role_code` varchar(100) NOT NULL,
  `description` varchar(500) DEFAULT '',
  `enabled` tinyint(1) DEFAULT 1,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_code` (`role_code`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES
(1,'超级管理员','R_SUPER','系统超级管理员',1,'2026-07-10 19:32:16'),
(2,'管理员','R_ADMIN','系统管理员',1,'2026-07-10 19:32:16'),
(3,'普通用户','R_USER','普通用户',1,'2026-07-10 19:32:16');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `section_moderators`
--

DROP TABLE IF EXISTS `section_moderators`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `section_moderators` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `section_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `section_id` (`section_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `section_moderators`
--

LOCK TABLES `section_moderators` WRITE;
/*!40000 ALTER TABLE `section_moderators` DISABLE KEYS */;
/*!40000 ALTER TABLE `section_moderators` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sensitive_words`
--

DROP TABLE IF EXISTS `sensitive_words`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sensitive_words` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `word` varchar(100) NOT NULL,
  `category` varchar(20) DEFAULT 'general',
  `enabled` tinyint(1) DEFAULT 1,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sensitive_words`
--

LOCK TABLES `sensitive_words` WRITE;
/*!40000 ALTER TABLE `sensitive_words` DISABLE KEYS */;
/*!40000 ALTER TABLE `sensitive_words` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `token` varchar(100) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `roles` text DEFAULT '[]',
  `created_at` int(11) NOT NULL,
  PRIMARY KEY (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settlement_config`
--

DROP TABLE IF EXISTS `settlement_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `settlement_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `level_id` int(11) DEFAULT 0,
  `level_name` varchar(100) DEFAULT '普通用户',
  `confirm_days` int(11) DEFAULT 7,
  `enabled` int(11) DEFAULT 1,
  `balance_transfer_enabled` int(11) DEFAULT 1,
  `points_transfer_enabled` int(11) DEFAULT 1,
  `single_min_balance` decimal(10,2) DEFAULT 0.00,
  `single_max_balance` decimal(10,2) DEFAULT 0.00,
  `single_min_points` int(11) DEFAULT 0,
  `single_max_points` int(11) DEFAULT 0,
  `daily_limit_balance_amount` decimal(10,2) DEFAULT 0.00,
  `daily_limit_points_amount` int(11) DEFAULT 0,
  `daily_limit_times` int(11) DEFAULT 0,
  `weekly_limit_times` int(11) DEFAULT 0,
  `yearly_limit_times` int(11) DEFAULT 0,
  `balance_transfer_fee` decimal(5,2) DEFAULT 0.00,
  `points_transfer_fee` decimal(5,2) DEFAULT 0.00,
  `balance_to_points_rate` decimal(10,2) DEFAULT 1.00,
  `points_to_balance_rate` decimal(10,2) DEFAULT 1.00,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settlement_config`
--

LOCK TABLES `settlement_config` WRITE;
/*!40000 ALTER TABLE `settlement_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `settlement_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `storage_configs`
--

DROP TABLE IF EXISTS `storage_configs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `storage_configs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(50) DEFAULT 'local',
  `name` varchar(100) DEFAULT '',
  `config` text DEFAULT NULL,
  `is_default` tinyint(1) DEFAULT 0,
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  `endpoint` varchar(500) DEFAULT '',
  `region` varchar(100) DEFAULT '',
  `bucket` varchar(200) DEFAULT '',
  `access_key` varchar(500) DEFAULT '',
  `secret_key` varchar(500) DEFAULT '',
  `local_dir` varchar(500) DEFAULT '',
  `remote_dir` varchar(500) DEFAULT '',
  `base_url` varchar(500) DEFAULT '',
  `applicable_roles` text DEFAULT NULL,
  `applicable_levels` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `storage_configs`
--

LOCK TABLES `storage_configs` WRITE;
/*!40000 ALTER TABLE `storage_configs` DISABLE KEYS */;
INSERT INTO `storage_configs` VALUES
(1,'local','本地',NULL,0,'1','2026-07-10 20:08:00','2026-07-10 20:33:05','','','','','','uploads/user','','','',''),
(8,'oss','用户阿里云OSS',NULL,1,'1','2026-07-10 20:27:58','2026-07-10 20:32:19','oss-cn-hongkong.aliyuncs.com','cn‑hongkong','appiapp','LTAI5t6oq445VTWdqXpkw1ud','26V7K8ml5mSSsOR7FDy31LrOCqlG4M','','user/admin','','all','all'),
(9,'oss','后台-阿里云OSS',NULL,0,'1','2026-07-10 20:31:56','2026-07-10 20:31:56','oss-cn-hongkong.aliyuncs.com','cn‑hongkong','appiapp','LTAI5t6oq445VTWdqXpkw1ud','26V7K8ml5mSSsOR7FDy31LrOCqlG4M','','user/admin','','','backend');
/*!40000 ALTER TABLE `storage_configs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_config`
--

DROP TABLE IF EXISTS `sys_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `config_key` varchar(100) NOT NULL,
  `config_value` text DEFAULT '',
  `description` varchar(200) DEFAULT '',
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `config_key` (`config_key`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_config`
--

LOCK TABLES `sys_config` WRITE;
/*!40000 ALTER TABLE `sys_config` DISABLE KEYS */;
INSERT INTO `sys_config` VALUES
(1,'system_log_enabled','true','系统日志总开关','2026-07-10 19:32:17'),
(2,'log_enabled_login','true','登录日志开关','2026-07-10 19:32:17'),
(3,'log_enabled_user','true','用户操作日志开关','2026-07-10 19:32:17'),
(4,'log_enabled_operation','true','运营管理日志开关','2026-07-10 19:32:17'),
(5,'log_enabled_content','true','内容管理日志开关','2026-07-10 19:32:17'),
(6,'log_enabled_system','true','系统配置日志开关','2026-07-10 19:32:17'),
(7,'invite_user_enabled','false','用户生成邀请码开关','2026-07-10 19:32:17'),
(8,'invite_user_max','5','用户最大可生成邀请码数','2026-07-10 19:32:17'),
(9,'register_invite_required','false','注册必须邀请码','2026-07-10 19:32:17'),
(10,'commission_enabled','false','推广返佣开关','2026-07-10 19:32:17'),
(11,'commission_mode','purchase','返佣模式','2026-07-10 19:32:17'),
(12,'points_transfer_enabled','false','积分转账开关','2026-07-10 19:32:17'),
(13,'points_transfer_fee','0','积分转账手续费比例%','2026-07-10 19:32:17'),
(14,'balance_transfer_enabled','false','余额转账开关','2026-07-10 19:32:17'),
(15,'balance_transfer_fee','0','余额转账手续费比例%','2026-07-10 19:32:17'),
(16,'points_purchase_enabled','false','积分购买开关','2026-07-10 19:32:17'),
(17,'points_purchase_rate','1','1元等于多少积分','2026-07-10 19:32:17'),
(18,'content_split_enabled','true','创作分成开关','2026-07-10 19:32:17'),
(19,'content_split_global_rate','70','创作分成全局比例%','2026-07-10 19:32:17'),
(20,'checkin_enabled','true','签到功能开关','2026-07-10 19:32:17'),
(21,'site_name','Art Design Pro Test','Site name','2026-07-10 20:17:40');
/*!40000 ALTER TABLE `sys_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_notifications`
--

DROP TABLE IF EXISTS `sys_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `content` text DEFAULT '',
  `type` varchar(20) DEFAULT 'system',
  `target_user_id` int(11) DEFAULT 0,
  `from_user_id` int(11) DEFAULT 0,
  `from_user_name` varchar(100) DEFAULT '',
  `from_user_avatar` varchar(200) DEFAULT '',
  `is_read` tinyint(1) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_sys_notifications_target_user` (`target_user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_notifications`
--

LOCK TABLES `sys_notifications` WRITE;
/*!40000 ALTER TABLE `sys_notifications` DISABLE KEYS */;
INSERT INTO `sys_notifications` VALUES
(1,'新粉丝','Alex Morgan 关注了您','system',2,1,'Alex Morgan','',0,'2026-07-10 19:37:24'),
(2,'认证申请已提交','您的蓝V认证申请已提交，请耐心等待管理员审核','verification',1,0,'系统','',0,'2026-07-10 19:37:25'),
(3,'新的认证申请','E2E Person 提交了蓝V认证申请，请及时审核','verification',1,1,'alexmorgan','',0,'2026-07-10 19:37:25');
/*!40000 ALTER TABLE `sys_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_logs`
--

DROP TABLE IF EXISTS `system_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT 0,
  `user_name` varchar(100) DEFAULT 'system',
  `type` varchar(30) NOT NULL,
  `target_type` varchar(50) DEFAULT '',
  `target_id` int(11) DEFAULT 0,
  `detail` text DEFAULT '',
  `ip` varchar(50) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_system_logs_user` (`user_id`),
  KEY `idx_system_logs_type` (`type`),
  KEY `idx_system_logs_create` (`create_time`)
) ENGINE=InnoDB AUTO_INCREMENT=253 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_logs`
--

LOCK TABLES `system_logs` WRITE;
/*!40000 ALTER TABLE `system_logs` DISABLE KEYS */;
INSERT INTO `system_logs` VALUES
(1,0,'anonymous','login','user',1,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-10 19:32:25'),
(2,0,'anonymous','login','user',1,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-10 19:32:25'),
(3,0,'anonymous','login','user',1,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-10 19:33:54'),
(4,0,'anonymous','login','user',1,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-10 19:34:00'),
(5,0,'anonymous','login','user',1,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-10 19:34:29'),
(6,0,'anonymous','login','user',1,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-10 19:37:22'),
(7,0,'anonymous','login','user',1,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-10 19:37:23'),
(8,0,'e2etester','create','user',2,'用户注册','','2026-07-10 19:37:24'),
(9,0,'anonymous','theme','themes',1,'创建主题: E2E Theme','::ffff:127.0.0.1','2026-07-10 19:37:25'),
(10,0,'anonymous','theme','themes',1,'更新主题: E2E Theme Updated','::ffff:127.0.0.1','2026-07-10 19:37:25'),
(11,0,'anonymous','theme','themes',1,'激活主题: E2E Theme Updated','::ffff:127.0.0.1','2026-07-10 19:37:25'),
(12,0,'anonymous','create','coupon',1,'创建优惠券:E2E Coupon','::ffff:127.0.0.1','2026-07-10 19:37:25'),
(13,0,'anonymous','login','user',1,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-10 19:37:39'),
(14,0,'anonymous','login','user',1,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-10 19:37:49'),
(15,0,'anonymous','login','user',1,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-10 19:37:49'),
(16,0,'anonymous','login','user',1,'用户 alexmorgan 登录','223.160.214.111','2026-07-10 19:39:40'),
(17,0,'anonymous','login','user',1,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-10 19:45:09'),
(18,0,'anonymous','login','user',1,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-10 19:46:12'),
(19,0,'anonymous','login','user',1,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-10 19:48:12'),
(20,0,'anonymous','login','user',1,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-10 19:48:18'),
(21,0,'anonymous','login','user',1,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-10 19:48:18'),
(22,0,'anonymous','login','user',1,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-10 19:48:20'),
(23,0,'anonymous','login','user',1,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-10 19:50:02'),
(24,0,'anonymous','login','user',1,'用户 alexmorgan 登录','223.160.214.111','2026-07-10 19:50:20'),
(25,0,'anonymous','login','user',1,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-10 19:52:01'),
(26,0,'anonymous','login','user',1,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-10 19:54:04'),
(27,0,'anonymous','login','user',1,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-10 19:55:27'),
(28,0,'anonymous','login','user',1,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-10 19:55:41'),
(29,0,'anonymous','login','user',1,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-10 19:55:41'),
(30,0,'anonymous','login','user',1,'用户 alexmorgan 登录','223.160.215.111','2026-07-10 19:55:46'),
(31,0,'anonymous','login','user',1,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-10 19:59:00'),
(32,0,'anonymous','login','user',1,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-10 19:59:00'),
(33,0,'anonymous','login','user',1,'用户 alexmorgan 登录','223.160.215.111','2026-07-10 19:59:53'),
(34,1,'alexmorgan','pin','post',2,'版块置顶帖子《Paid E2E Post》','','2026-07-10 20:00:02'),
(35,1,'alexmorgan','pin','post',2,'全站置顶帖子《Paid E2E Post》','','2026-07-10 20:00:03'),
(36,1,'alexmorgan','set_badge','post',2,'设置自定义徽章《Paid E2E Post》：6','','2026-07-10 20:00:06'),
(37,1,'alexmorgan','essence','post',2,'设为精华帖子《Paid E2E Post》','','2026-07-10 20:00:07'),
(38,1,'alexmorgan','hot','post',2,'设为热帖帖子《Paid E2E Post》','','2026-07-10 20:00:08'),
(39,1,'alexmorgan','lock','post',2,'锁定帖子《Paid E2E Post》','','2026-07-10 20:00:09'),
(40,1,'alexmorgan','unlock','post',2,'解锁帖子《Paid E2E Post》','','2026-07-10 20:00:10'),
(41,1,'alexmorgan','lock','post',2,'锁定帖子《Paid E2E Post》','','2026-07-10 20:00:11'),
(42,0,'anonymous','update','submission',2,'审核投稿ID:2 下架','223.160.215.111','2026-07-10 20:02:14'),
(43,0,'anonymous','update','submission',2,'审核投稿ID:2 下架','223.160.215.111','2026-07-10 20:02:24'),
(44,0,'anonymous','update','submission',2,'审核投稿ID:2 下架','223.160.215.111','2026-07-10 20:02:34'),
(45,0,'anonymous','update','submission',2,'审核投稿ID:2 下架','223.160.215.111','2026-07-10 20:03:22'),
(46,0,'anonymous','update','submission',2,'审核投稿ID:2 下架','223.160.214.111','2026-07-10 20:07:09'),
(47,0,'anonymous','update','submission',2,'审核投稿ID:2 通过','223.160.214.111','2026-07-10 20:07:11'),
(48,0,'anonymous','login','user',1,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-10 20:07:57'),
(49,0,'anonymous','login','user',1,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-10 20:07:58'),
(50,0,'anonymous','login','user',1,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-10 20:07:59'),
(51,0,'anonymous','theme','themes',2,'创建主题: test_theme_crud','::ffff:127.0.0.1','2026-07-10 20:07:59'),
(52,0,'anonymous','create','coupon',2,'创建优惠券:test_coupon_crud','::ffff:127.0.0.1','2026-07-10 20:07:59'),
(53,0,'anonymous','theme','themes',2,'删除主题: test_theme_crud','::ffff:127.0.0.1','2026-07-10 20:08:00'),
(54,0,'anonymous','delete','coupon',2,'删除优惠券ID:2','::ffff:127.0.0.1','2026-07-10 20:08:00'),
(55,0,'anonymous','login','user',1,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-10 20:09:48'),
(56,0,'anonymous','login','user',1,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-10 20:09:48'),
(57,0,'anonymous','create','role',4,'新建角色\"test_crud_role\"','::ffff:127.0.0.1','2026-07-10 20:09:49'),
(58,0,'anonymous','login','user',1,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-10 20:09:49'),
(59,0,'admin','create','menu',54,'新建菜单\"CRUD Menu\"，路径:/test-crud','::ffff:127.0.0.1','2026-07-10 20:09:49'),
(60,0,'admin','update','menu',54,'更新菜单\"CRUD Menu Updated\"。旧数据:{\"id\":54,\"parent_id\":0,\"name\":\"test_crud_menu\",\"path\":\"/test-crud\",\"component\":\"test/index\",\"redirect\":\"\",\"title\":\"CRUD Menu\",\"icon\":\"\",\"sort_order\":99,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":0,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":null,\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"system\",\"create_time\":\"2026-07-10T12:09:49.000Z\",\"update_time\":\"2026-07-10T12:09:49.000Z\"}','::ffff:127.0.0.1','2026-07-10 20:09:49'),
(61,0,'anonymous','theme','themes',3,'创建主题: test_crud_theme','::ffff:127.0.0.1','2026-07-10 20:09:50'),
(62,0,'anonymous','create','coupon',3,'创建优惠券:test_crud_coupon','::ffff:127.0.0.1','2026-07-10 20:09:50'),
(63,1,'alexmorgan','create','cardkey',1,'生成1张卡密(100元余额)','::ffff:127.0.0.1','2026-07-10 20:09:50'),
(64,1,'alexmorgan','create','experience',8,'新增经验等级\"test_crud_exp\"','::ffff:127.0.0.1','2026-07-10 20:09:50'),
(65,1,'alexmorgan','create','membership',5,'新增会员等级\"test_crud_member\"','::ffff:127.0.0.1','2026-07-10 20:09:50'),
(66,1,'alexmorgan','create','checkin_group',1,'新建签到规则《test_crud_checkin》','','2026-07-10 20:09:50'),
(67,0,'anonymous','create','official_tag',1,'新增官方标签\"test_crud_tag\"','::ffff:127.0.0.1','2026-07-10 20:09:50'),
(68,1,'alexmorgan','create','title',1,'新增称号\"test_crud_title\"','::ffff:127.0.0.1','2026-07-10 20:09:50'),
(69,1,'alexmorgan','create','avatar_frame',1,'新增头像框\"test_crud_avatar\"','::ffff:127.0.0.1','2026-07-10 20:09:50'),
(70,0,'anonymous','create','commission_rule',1,'新增返佣规则\"undefined\"','::ffff:127.0.0.1','2026-07-10 20:09:50'),
(71,1,'alexmorgan','config','email',0,'更新邮件服务配置','::ffff:127.0.0.1','2026-07-10 20:09:50'),
(72,0,'admin','delete','menu',54,'删除菜单\"CRUD Menu Updated\"。被删除数据:{\"id\":54,\"parent_id\":0,\"name\":\"test_crud_menu\",\"path\":\"/test-crud2\",\"component\":\"\",\"redirect\":\"\",\"title\":\"CRUD Menu Updated\",\"icon\":\"\",\"sort_order\":100,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":0,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":null,\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"system\",\"create_time\":\"2026-07-10T12:09:49.000Z\",\"update_time\":\"2026-07-10T12:09:49.000Z\"}','::ffff:127.0.0.1','2026-07-10 20:09:51'),
(73,0,'anonymous','theme','themes',3,'删除主题: test_crud_theme','::ffff:127.0.0.1','2026-07-10 20:09:51'),
(74,0,'anonymous','delete','coupon',3,'删除优惠券ID:3','::ffff:127.0.0.1','2026-07-10 20:09:51'),
(75,1,'alexmorgan','delete','experience',8,'删除经验等级\"test_crud_exp\"','::ffff:127.0.0.1','2026-07-10 20:09:51'),
(76,1,'alexmorgan','delete','membership',5,'删除会员等级\"test_crud_member\"','::ffff:127.0.0.1','2026-07-10 20:09:51'),
(77,1,'alexmorgan','delete','checkin_group',1,'删除签到规则《test_crud_checkin》','','2026-07-10 20:09:51'),
(78,0,'anonymous','delete','official_tag',1,'删除官方标签ID:1','::ffff:127.0.0.1','2026-07-10 20:09:51'),
(79,0,'anonymous','login','user',1,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-10 20:10:11'),
(80,0,'anonymous','login','user',1,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-10 20:10:37'),
(81,0,'anonymous','create','role',5,'新建角色\"test_crud\"','::ffff:127.0.0.1','2026-07-10 20:10:37'),
(82,1,'alexmorgan','create','cardkey',2,'生成1张卡密(100元余额)','::ffff:127.0.0.1','2026-07-10 20:10:37'),
(83,1,'alexmorgan','create','title',2,'新增称号\"test_crud\"','::ffff:127.0.0.1','2026-07-10 20:10:37'),
(84,1,'alexmorgan','create','avatar_frame',2,'新增头像框\"test_crud\"','::ffff:127.0.0.1','2026-07-10 20:10:37'),
(85,0,'anonymous','login','user',1,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-10 20:10:49'),
(86,0,'anonymous','create','commission_rule',2,'新增返佣规则\"undefined\"','::ffff:127.0.0.1','2026-07-10 20:10:49'),
(87,0,'anonymous','login','user',1,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-10 20:11:42'),
(88,0,'anonymous','login','user',1,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-10 20:11:42'),
(89,0,'anonymous','login','user',1,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-10 20:11:44'),
(90,0,'anonymous','create','role',7,'新建角色\"test_crud_role2\"','::ffff:127.0.0.1','2026-07-10 20:11:44'),
(91,0,'anonymous','update','role',7,'更新角色\"test_crud_updated\"','::ffff:127.0.0.1','2026-07-10 20:11:44'),
(92,0,'admin','create','menu',55,'新建菜单\"CRUD Menu\"，路径:/test-crud','::ffff:127.0.0.1','2026-07-10 20:11:44'),
(93,0,'admin','create','menu',56,'新建菜单\"CRUD Menu 2\"，路径:/test-crud2','::ffff:127.0.0.1','2026-07-10 20:11:44'),
(94,1,'alexmorgan','create','user',3,'新建用户\"test_crud_user\"','','2026-07-10 20:11:44'),
(95,1,'alexmorgan','update','user',1,'更新用户信息','','2026-07-10 20:11:44'),
(96,0,'anonymous','theme','themes',4,'创建主题: test_crud_theme','::ffff:127.0.0.1','2026-07-10 20:11:44'),
(97,0,'anonymous','create','coupon',4,'创建优惠券:test_crud_coupon','::ffff:127.0.0.1','2026-07-10 20:11:44'),
(98,1,'alexmorgan','create','cardkey',3,'生成1张卡密(100元余额)','::ffff:127.0.0.1','2026-07-10 20:11:44'),
(99,1,'alexmorgan','create','experience',9,'新增经验等级\"test_crud_exp\"','::ffff:127.0.0.1','2026-07-10 20:11:45'),
(100,1,'alexmorgan','create','membership',6,'新增会员等级\"test_crud_member\"','::ffff:127.0.0.1','2026-07-10 20:11:45'),
(101,1,'alexmorgan','create','checkin_group',2,'新建签到规则《test_crud_checkin》','','2026-07-10 20:11:45'),
(102,0,'anonymous','create','official_tag',2,'新增官方标签\"test_crud_tag\"','::ffff:127.0.0.1','2026-07-10 20:11:45'),
(103,1,'alexmorgan','config','email',0,'更新邮件服务配置','::ffff:127.0.0.1','2026-07-10 20:11:45'),
(104,1,'alexmorgan','create','title',3,'新增称号\"test_crud_title\"','::ffff:127.0.0.1','2026-07-10 20:11:45'),
(105,1,'alexmorgan','create','avatar_frame',3,'新增头像框\"test_crud_avatar\"','::ffff:127.0.0.1','2026-07-10 20:11:45'),
(106,0,'anonymous','create','commission_rule',3,'新增返佣规则\"undefined\"','::ffff:127.0.0.1','2026-07-10 20:11:45'),
(107,0,'admin','create','menu',57,'新建菜单\"To Delete\"，路径:/test-del','::ffff:127.0.0.1','2026-07-10 20:11:46'),
(108,0,'admin','delete','menu',57,'删除菜单\"To Delete\"。被删除数据:{\"id\":57,\"parent_id\":0,\"name\":\"test_crud_del_menu\",\"path\":\"/test-del\",\"component\":\"test/del\",\"redirect\":\"\",\"title\":\"To Delete\",\"icon\":\"\",\"sort_order\":999,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":0,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":null,\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"system\",\"create_time\":\"2026-07-10T12:11:46.000Z\",\"update_time\":\"2026-07-10T12:11:46.000Z\"}','::ffff:127.0.0.1','2026-07-10 20:11:46'),
(109,0,'anonymous','create','role',8,'新建角色\"test_crud_del_role\"','::ffff:127.0.0.1','2026-07-10 20:11:46'),
(110,0,'anonymous','delete','role',8,'删除角色\"test_crud_del_role\"','::ffff:127.0.0.1','2026-07-10 20:11:46'),
(111,0,'anonymous','delete','role',4,'删除角色\"test_crud_role\"','::ffff:127.0.0.1','2026-07-10 20:11:46'),
(112,0,'anonymous','delete','role',5,'删除角色\"test_crud\"','::ffff:127.0.0.1','2026-07-10 20:11:46'),
(113,0,'anonymous','delete','role',7,'删除角色\"test_crud_updated\"','::ffff:127.0.0.1','2026-07-10 20:11:46'),
(114,0,'anonymous','theme','themes',4,'删除主题: test_crud_theme','::ffff:127.0.0.1','2026-07-10 20:11:46'),
(115,0,'anonymous','delete','coupon',4,'删除优惠券ID:4','::ffff:127.0.0.1','2026-07-10 20:11:46'),
(116,1,'alexmorgan','delete','experience',9,'删除经验等级\"test_crud_exp\"','::ffff:127.0.0.1','2026-07-10 20:11:46'),
(117,1,'alexmorgan','delete','membership',6,'删除会员等级\"test_crud_member\"','::ffff:127.0.0.1','2026-07-10 20:11:46'),
(118,1,'alexmorgan','delete','checkin_group',2,'删除签到规则《test_crud_checkin》','','2026-07-10 20:11:46'),
(119,0,'anonymous','delete','official_tag',2,'删除官方标签ID:2','::ffff:127.0.0.1','2026-07-10 20:11:46'),
(120,1,'alexmorgan','delete','title',1,'删除称号ID:1','::ffff:127.0.0.1','2026-07-10 20:11:46'),
(121,1,'alexmorgan','delete','title',2,'删除称号ID:2','::ffff:127.0.0.1','2026-07-10 20:11:46'),
(122,1,'alexmorgan','delete','title',3,'删除称号ID:3','::ffff:127.0.0.1','2026-07-10 20:11:46'),
(123,1,'alexmorgan','delete','avatar_frame',1,'删除头像框ID:1','::ffff:127.0.0.1','2026-07-10 20:11:46'),
(124,1,'alexmorgan','delete','avatar_frame',2,'删除头像框ID:2','::ffff:127.0.0.1','2026-07-10 20:11:46'),
(125,1,'alexmorgan','delete','avatar_frame',3,'删除头像框ID:3','::ffff:127.0.0.1','2026-07-10 20:11:46'),
(126,0,'anonymous','login','user',1,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-10 20:12:00'),
(127,0,'anonymous','create','role',9,'新建角色\"test_crud_role\"','::ffff:127.0.0.1','2026-07-10 20:12:00'),
(128,0,'anonymous','login','user',1,'用户 alexmorgan 登录','223.160.215.111','2026-07-10 20:12:54'),
(129,0,'anonymous','login','user',1,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-10 20:13:23'),
(130,0,'anonymous','login','user',1,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-10 20:13:23'),
(131,0,'anonymous','login','user',1,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-10 20:13:24'),
(132,0,'anonymous','create','role',10,'新建角色\"test_crud_role3\"','::ffff:127.0.0.1','2026-07-10 20:13:24'),
(133,0,'anonymous','create','role',11,'新建角色\"test_crud_role2\"','::ffff:127.0.0.1','2026-07-10 20:13:24'),
(134,0,'anonymous','update','role',11,'更新角色\"test_crud_updated\"','::ffff:127.0.0.1','2026-07-10 20:13:24'),
(135,0,'admin','create','menu',58,'新建菜单\"CRUD Menu\"，路径:/test-crud','::ffff:127.0.0.1','2026-07-10 20:13:24'),
(136,0,'admin','create','menu',59,'新建菜单\"CRUD Menu 2\"，路径:/test-crud2','::ffff:127.0.0.1','2026-07-10 20:13:24'),
(137,1,'alexmorgan','update','user',1,'更新用户信息','','2026-07-10 20:13:24'),
(138,0,'anonymous','theme','themes',5,'创建主题: test_crud_theme','::ffff:127.0.0.1','2026-07-10 20:13:25'),
(139,0,'anonymous','create','coupon',5,'创建优惠券:test_crud_coupon','::ffff:127.0.0.1','2026-07-10 20:13:25'),
(140,1,'alexmorgan','create','cardkey',4,'生成1张卡密(100元余额)','::ffff:127.0.0.1','2026-07-10 20:13:25'),
(141,1,'alexmorgan','create','experience',10,'新增经验等级\"test_crud_exp\"','::ffff:127.0.0.1','2026-07-10 20:13:25'),
(142,1,'alexmorgan','create','membership',7,'新增会员等级\"test_crud_member\"','::ffff:127.0.0.1','2026-07-10 20:13:25'),
(143,1,'alexmorgan','create','checkin_group',3,'新建签到规则《test_crud_checkin》','','2026-07-10 20:13:25'),
(144,0,'anonymous','create','official_tag',3,'新增官方标签\"test_crud_tag\"','::ffff:127.0.0.1','2026-07-10 20:13:25'),
(145,1,'alexmorgan','config','email',0,'更新邮件服务配置','::ffff:127.0.0.1','2026-07-10 20:13:25'),
(146,1,'alexmorgan','create','title',4,'新增称号\"test_crud_title\"','::ffff:127.0.0.1','2026-07-10 20:13:25'),
(147,1,'alexmorgan','create','avatar_frame',4,'新增头像框\"test_crud_avatar\"','::ffff:127.0.0.1','2026-07-10 20:13:25'),
(148,0,'anonymous','create','commission_rule',4,'新增返佣规则\"undefined\"','::ffff:127.0.0.1','2026-07-10 20:13:25'),
(149,0,'anonymous','config','sys_config',0,'更新系统配置: site_name','::ffff:127.0.0.1','2026-07-10 20:13:26'),
(150,0,'admin','create','menu',60,'新建菜单\"To Delete\"，路径:/test-del','::ffff:127.0.0.1','2026-07-10 20:13:26'),
(151,0,'admin','delete','menu',60,'删除菜单\"To Delete\"。被删除数据:{\"id\":60,\"parent_id\":0,\"name\":\"test_crud_del_menu\",\"path\":\"/test-del\",\"component\":\"test/del\",\"redirect\":\"\",\"title\":\"To Delete\",\"icon\":\"\",\"sort_order\":999,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":0,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":null,\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"system\",\"create_time\":\"2026-07-10T12:13:26.000Z\",\"update_time\":\"2026-07-10T12:13:26.000Z\"}','::ffff:127.0.0.1','2026-07-10 20:13:26'),
(152,0,'anonymous','create','role',12,'新建角色\"test_crud_del_role\"','::ffff:127.0.0.1','2026-07-10 20:13:26'),
(153,0,'anonymous','delete','role',12,'删除角色\"test_crud_del_role\"','::ffff:127.0.0.1','2026-07-10 20:13:26'),
(154,0,'anonymous','delete','role',9,'删除角色\"test_crud_role\"','::ffff:127.0.0.1','2026-07-10 20:13:26'),
(155,0,'anonymous','delete','role',10,'删除角色\"test_crud_role3\"','::ffff:127.0.0.1','2026-07-10 20:13:26'),
(156,0,'anonymous','delete','role',11,'删除角色\"test_crud_updated\"','::ffff:127.0.0.1','2026-07-10 20:13:26'),
(157,0,'anonymous','theme','themes',5,'删除主题: test_crud_theme','::ffff:127.0.0.1','2026-07-10 20:13:26'),
(158,0,'anonymous','delete','coupon',5,'删除优惠券ID:5','::ffff:127.0.0.1','2026-07-10 20:13:26'),
(159,1,'alexmorgan','delete','experience',10,'删除经验等级\"test_crud_exp\"','::ffff:127.0.0.1','2026-07-10 20:13:26'),
(160,1,'alexmorgan','delete','membership',7,'删除会员等级\"test_crud_member\"','::ffff:127.0.0.1','2026-07-10 20:13:26'),
(161,1,'alexmorgan','delete','checkin_group',3,'删除签到规则《test_crud_checkin》','','2026-07-10 20:13:26'),
(162,0,'anonymous','delete','official_tag',3,'删除官方标签ID:3','::ffff:127.0.0.1','2026-07-10 20:13:26'),
(163,1,'alexmorgan','delete','title',4,'删除称号ID:4','::ffff:127.0.0.1','2026-07-10 20:13:26'),
(164,1,'alexmorgan','delete','avatar_frame',4,'删除头像框ID:4','::ffff:127.0.0.1','2026-07-10 20:13:26'),
(165,0,'anonymous','login','user',1,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-10 20:13:38'),
(166,0,'anonymous','login','user',1,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-10 20:13:53'),
(167,0,'anonymous','login','user',1,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-10 20:13:53'),
(168,0,'anonymous','create','role',13,'新建角色\"test_crud_role3\"','::ffff:127.0.0.1','2026-07-10 20:13:55'),
(169,0,'anonymous','login','user',1,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-10 20:13:55'),
(170,0,'anonymous','update','role',14,'更新角色\"test_crud_updated\"','::ffff:127.0.0.1','2026-07-10 20:13:55'),
(171,0,'anonymous','create','role',14,'新建角色\"test_crud_role2\"','::ffff:127.0.0.1','2026-07-10 20:13:55'),
(172,0,'admin','create','menu',61,'新建菜单\"CRUD Menu\"，路径:/test-crud','::ffff:127.0.0.1','2026-07-10 20:13:55'),
(173,0,'admin','create','menu',62,'新建菜单\"CRUD Menu 2\"，路径:/test-crud2','::ffff:127.0.0.1','2026-07-10 20:13:55'),
(174,1,'alexmorgan','create','user',4,'新建用户\"crudtest60004\"','','2026-07-10 20:13:55'),
(175,1,'alexmorgan','update','user',1,'更新用户信息','','2026-07-10 20:13:55'),
(176,0,'anonymous','theme','themes',6,'创建主题: test_crud_theme','::ffff:127.0.0.1','2026-07-10 20:13:55'),
(177,0,'anonymous','create','coupon',6,'创建优惠券:test_crud_coupon','::ffff:127.0.0.1','2026-07-10 20:13:55'),
(178,1,'alexmorgan','create','cardkey',5,'生成1张卡密(100元余额)','::ffff:127.0.0.1','2026-07-10 20:13:55'),
(179,1,'alexmorgan','create','experience',11,'新增经验等级\"test_crud_exp\"','::ffff:127.0.0.1','2026-07-10 20:13:55'),
(180,1,'alexmorgan','create','membership',8,'新增会员等级\"test_crud_member\"','::ffff:127.0.0.1','2026-07-10 20:13:55'),
(181,1,'alexmorgan','create','checkin_group',4,'新建签到规则《test_crud_checkin》','','2026-07-10 20:13:56'),
(182,0,'anonymous','create','official_tag',4,'新增官方标签\"test_crud_tag\"','::ffff:127.0.0.1','2026-07-10 20:13:56'),
(183,1,'alexmorgan','config','email',0,'更新邮件服务配置','::ffff:127.0.0.1','2026-07-10 20:13:56'),
(184,1,'alexmorgan','create','title',5,'新增称号\"test_crud_title\"','::ffff:127.0.0.1','2026-07-10 20:13:56'),
(185,1,'alexmorgan','create','avatar_frame',5,'新增头像框\"test_crud_avatar\"','::ffff:127.0.0.1','2026-07-10 20:13:56'),
(186,0,'anonymous','create','commission_rule',5,'新增返佣规则\"undefined\"','::ffff:127.0.0.1','2026-07-10 20:13:56'),
(187,0,'anonymous','config','sys_config',0,'更新系统配置: site_name','::ffff:127.0.0.1','2026-07-10 20:13:56'),
(188,0,'admin','create','menu',63,'新建菜单\"To Delete\"，路径:/test-del','::ffff:127.0.0.1','2026-07-10 20:13:56'),
(189,0,'admin','delete','menu',63,'删除菜单\"To Delete\"。被删除数据:{\"id\":63,\"parent_id\":0,\"name\":\"test_crud_del_menu\",\"path\":\"/test-del\",\"component\":\"test/del\",\"redirect\":\"\",\"title\":\"To Delete\",\"icon\":\"\",\"sort_order\":999,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":0,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":null,\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"system\",\"create_time\":\"2026-07-10T12:13:56.000Z\",\"update_time\":\"2026-07-10T12:13:56.000Z\"}','::ffff:127.0.0.1','2026-07-10 20:13:56'),
(190,0,'anonymous','create','role',15,'新建角色\"test_crud_del_role\"','::ffff:127.0.0.1','2026-07-10 20:13:56'),
(191,0,'anonymous','delete','role',15,'删除角色\"test_crud_del_role\"','::ffff:127.0.0.1','2026-07-10 20:13:56'),
(192,0,'anonymous','delete','role',13,'删除角色\"test_crud_role3\"','::ffff:127.0.0.1','2026-07-10 20:13:56'),
(193,0,'anonymous','delete','role',14,'删除角色\"test_crud_updated\"','::ffff:127.0.0.1','2026-07-10 20:13:56'),
(194,0,'anonymous','theme','themes',6,'删除主题: test_crud_theme','::ffff:127.0.0.1','2026-07-10 20:13:56'),
(195,0,'anonymous','delete','coupon',6,'删除优惠券ID:6','::ffff:127.0.0.1','2026-07-10 20:13:56'),
(196,1,'alexmorgan','delete','experience',11,'删除经验等级\"test_crud_exp\"','::ffff:127.0.0.1','2026-07-10 20:13:56'),
(197,1,'alexmorgan','delete','membership',8,'删除会员等级\"test_crud_member\"','::ffff:127.0.0.1','2026-07-10 20:13:56'),
(198,1,'alexmorgan','delete','checkin_group',4,'删除签到规则《test_crud_checkin》','','2026-07-10 20:13:56'),
(199,0,'anonymous','delete','official_tag',4,'删除官方标签ID:4','::ffff:127.0.0.1','2026-07-10 20:13:56'),
(200,1,'alexmorgan','delete','title',5,'删除称号ID:5','::ffff:127.0.0.1','2026-07-10 20:13:56'),
(201,1,'alexmorgan','delete','avatar_frame',5,'删除头像框ID:5','::ffff:127.0.0.1','2026-07-10 20:13:56'),
(202,1,'alexmorgan','delete','cardkey',5,'删除卡密 CDKEY-MRFDIR42CAWU','223.160.215.111','2026-07-10 20:14:10'),
(203,1,'alexmorgan','create','cardkey',6,'生成1张卡密()','223.160.215.111','2026-07-10 20:14:19'),
(204,0,'anonymous','create','coupon',7,'创建优惠券:666','223.160.215.111','2026-07-10 20:14:59'),
(205,1,'alexmorgan','update','user',4,'更新用户信息','','2026-07-10 20:15:20'),
(206,1,'alexmorgan','update','user',4,'更新用户信息','','2026-07-10 20:15:27'),
(207,0,'anonymous','login','user',1,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-10 20:16:53'),
(208,0,'anonymous','login','user',1,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-10 20:17:36'),
(209,0,'anonymous','login','user',1,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-10 20:17:37'),
(210,0,'anonymous','login','user',1,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-10 20:17:37'),
(211,0,'anonymous','login','user',1,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-10 20:17:38'),
(212,0,'anonymous','create','role',16,'新建角色\"test_crud_role3\"','::ffff:127.0.0.1','2026-07-10 20:17:38'),
(213,0,'anonymous','create','role',17,'新建角色\"test_crud_role2\"','::ffff:127.0.0.1','2026-07-10 20:17:38'),
(214,0,'anonymous','update','role',17,'更新角色\"test_crud_updated\"','::ffff:127.0.0.1','2026-07-10 20:17:38'),
(215,0,'admin','create','menu',64,'新建菜单\"CRUD Menu\"，路径:/test-crud','::ffff:127.0.0.1','2026-07-10 20:17:39'),
(216,0,'admin','create','menu',65,'新建菜单\"CRUD Menu 2\"，路径:/test-crud2','::ffff:127.0.0.1','2026-07-10 20:17:39'),
(217,1,'alexmorgan','create','user',5,'新建用户\"crudtest93850\"','','2026-07-10 20:17:39'),
(218,1,'alexmorgan','update','user',1,'更新用户信息','','2026-07-10 20:17:39'),
(219,0,'anonymous','theme','themes',7,'创建主题: test_crud_theme','::ffff:127.0.0.1','2026-07-10 20:17:39'),
(220,0,'anonymous','create','coupon',8,'创建优惠券:test_crud_coupon','::ffff:127.0.0.1','2026-07-10 20:17:39'),
(221,1,'alexmorgan','create','cardkey',7,'生成1张卡密(100元余额)','::ffff:127.0.0.1','2026-07-10 20:17:39'),
(222,1,'alexmorgan','create','experience',12,'新增经验等级\"test_crud_exp\"','::ffff:127.0.0.1','2026-07-10 20:17:39'),
(223,1,'alexmorgan','create','membership',9,'新增会员等级\"test_crud_member\"','::ffff:127.0.0.1','2026-07-10 20:17:39'),
(224,1,'alexmorgan','create','checkin_group',5,'新建签到规则《test_crud_checkin》','','2026-07-10 20:17:39'),
(225,0,'anonymous','create','official_tag',5,'新增官方标签\"test_crud_tag\"','::ffff:127.0.0.1','2026-07-10 20:17:39'),
(226,1,'alexmorgan','config','email',0,'更新邮件服务配置','::ffff:127.0.0.1','2026-07-10 20:17:39'),
(227,1,'alexmorgan','create','title',6,'新增称号\"test_crud_title\"','::ffff:127.0.0.1','2026-07-10 20:17:39'),
(228,1,'alexmorgan','create','avatar_frame',6,'新增头像框\"test_crud_avatar\"','::ffff:127.0.0.1','2026-07-10 20:17:39'),
(229,0,'anonymous','create','commission_rule',6,'新增返佣规则\"undefined\"','::ffff:127.0.0.1','2026-07-10 20:17:39'),
(230,0,'anonymous','config','sys_config',0,'更新系统配置: site_name','::ffff:127.0.0.1','2026-07-10 20:17:40'),
(231,0,'admin','create','menu',66,'新建菜单\"To Delete\"，路径:/test-del','::ffff:127.0.0.1','2026-07-10 20:17:40'),
(232,0,'admin','delete','menu',66,'删除菜单\"To Delete\"。被删除数据:{\"id\":66,\"parent_id\":0,\"name\":\"test_crud_del_menu\",\"path\":\"/test-del\",\"component\":\"test/del\",\"redirect\":\"\",\"title\":\"To Delete\",\"icon\":\"\",\"sort_order\":999,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":0,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":null,\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"system\",\"create_time\":\"2026-07-10T12:17:40.000Z\",\"update_time\":\"2026-07-10T12:17:40.000Z\"}','::ffff:127.0.0.1','2026-07-10 20:17:40'),
(233,0,'anonymous','create','role',18,'新建角色\"test_crud_del_role\"','::ffff:127.0.0.1','2026-07-10 20:17:40'),
(234,0,'anonymous','delete','role',18,'删除角色\"test_crud_del_role\"','::ffff:127.0.0.1','2026-07-10 20:17:40'),
(235,0,'anonymous','delete','role',16,'删除角色\"test_crud_role3\"','::ffff:127.0.0.1','2026-07-10 20:17:40'),
(236,0,'anonymous','delete','role',17,'删除角色\"test_crud_updated\"','::ffff:127.0.0.1','2026-07-10 20:17:40'),
(237,0,'anonymous','theme','themes',7,'删除主题: test_crud_theme','::ffff:127.0.0.1','2026-07-10 20:17:40'),
(238,0,'anonymous','delete','coupon',8,'删除优惠券ID:8','::ffff:127.0.0.1','2026-07-10 20:17:40'),
(239,1,'alexmorgan','delete','experience',12,'删除经验等级\"test_crud_exp\"','::ffff:127.0.0.1','2026-07-10 20:17:40'),
(240,1,'alexmorgan','delete','membership',9,'删除会员等级\"test_crud_member\"','::ffff:127.0.0.1','2026-07-10 20:17:40'),
(241,1,'alexmorgan','delete','checkin_group',5,'删除签到规则《test_crud_checkin》','','2026-07-10 20:17:40'),
(242,0,'anonymous','delete','official_tag',5,'删除官方标签ID:5','::ffff:127.0.0.1','2026-07-10 20:17:40'),
(243,1,'alexmorgan','delete','title',6,'删除称号ID:6','::ffff:127.0.0.1','2026-07-10 20:17:40'),
(244,1,'alexmorgan','delete','avatar_frame',6,'删除头像框ID:6','::ffff:127.0.0.1','2026-07-10 20:17:40'),
(245,0,'anonymous','login','user',1,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-10 20:21:44'),
(246,0,'anonymous','login','user',1,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-10 20:24:12'),
(247,0,'anonymous','login','user',1,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-10 20:24:27'),
(248,0,'anonymous','login','user',1,'用户 alexmorgan 登录','223.160.215.111','2026-07-10 20:24:46'),
(249,0,'anonymous','login','user',1,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-10 20:34:30'),
(250,0,'anonymous','login','user',1,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-10 20:34:55'),
(251,0,'anonymous','login','user',1,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-10 20:34:59'),
(252,0,'anonymous','login','user',1,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-10 20:40:03');
/*!40000 ALTER TABLE `system_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `task_records`
--

DROP TABLE IF EXISTS `task_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `task_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `task_id` int(11) NOT NULL,
  `task_name` varchar(200) DEFAULT '',
  `progress` int(11) DEFAULT 0,
  `target_count` int(11) DEFAULT 1,
  `status` varchar(20) DEFAULT 'pending',
  `completed_at` datetime DEFAULT NULL,
  `period_key` varchar(20) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_task_records_user` (`user_id`),
  KEY `idx_task_records_period` (`period_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `task_records`
--

LOCK TABLES `task_records` WRITE;
/*!40000 ALTER TABLE `task_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `task_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `themes`
--

DROP TABLE IF EXISTS `themes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `themes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT '',
  `thumbnail` varchar(500) DEFAULT '',
  `vars` text DEFAULT '{}',
  `vars_dark` text DEFAULT '{}',
  `vars_mobile` text DEFAULT '{}',
  `vars_mobile_dark` text DEFAULT '{}',
  `is_preset` tinyint(1) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `themes`
--

LOCK TABLES `themes` WRITE;
/*!40000 ALTER TABLE `themes` DISABLE KEYS */;
INSERT INTO `themes` VALUES
(1,'E2E Theme Updated','Test theme for E2E','','{\"primary\":\"#1890ff\"}','{}','{}','{}',0,1,'2026-07-10 19:37:25','2026-07-10 19:37:25');
/*!40000 ALTER TABLE `themes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `topic_follows`
--

DROP TABLE IF EXISTS `topic_follows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `topic_follows` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `topic_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `topic_id` (`topic_id`,`user_id`),
  KEY `idx_topic_follows_topic` (`topic_id`),
  KEY `idx_topic_follows_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `topic_follows`
--

LOCK TABLES `topic_follows` WRITE;
/*!40000 ALTER TABLE `topic_follows` DISABLE KEYS */;
/*!40000 ALTER TABLE `topic_follows` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_avatar_frames`
--

DROP TABLE IF EXISTS `user_avatar_frames`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_avatar_frames` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `frame_id` int(11) NOT NULL,
  `is_active` tinyint(1) DEFAULT 0,
  `obtain_type` varchar(20) DEFAULT 'manual',
  `obtain_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`frame_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_avatar_frames`
--

LOCK TABLES `user_avatar_frames` WRITE;
/*!40000 ALTER TABLE `user_avatar_frames` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_avatar_frames` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_blocks`
--

DROP TABLE IF EXISTS `user_blocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_blocks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `blocker_id` int(11) NOT NULL,
  `blocked_id` int(11) NOT NULL,
  `reason` text DEFAULT '',
  `status` varchar(20) DEFAULT 'active',
  `reviewed` tinyint(1) DEFAULT 0,
  `review_notes` text DEFAULT '',
  `reviewer_id` int(11) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `blocker_id` (`blocker_id`,`blocked_id`),
  KEY `idx_user_blocks_blocker` (`blocker_id`),
  KEY `idx_user_blocks_blocked` (`blocked_id`),
  KEY `idx_user_blocks_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_blocks`
--

LOCK TABLES `user_blocks` WRITE;
/*!40000 ALTER TABLE `user_blocks` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_blocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_coupons`
--

DROP TABLE IF EXISTS `user_coupons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_coupons` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `coupon_id` int(11) NOT NULL,
  `status` varchar(10) NOT NULL DEFAULT 'unused',
  `coupon_data` text NOT NULL,
  `expire_time` datetime NOT NULL,
  `use_time` datetime DEFAULT NULL,
  `use_scene` varchar(50) DEFAULT '',
  `use_order_id` int(11) DEFAULT 0,
  `use_amount` decimal(10,2) DEFAULT 0.00,
  `remaining_value` decimal(10,2) DEFAULT NULL,
  `receive_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user_coupons_user` (`user_id`),
  KEY `idx_user_coupons_status` (`status`),
  KEY `idx_user_coupons_coupon` (`coupon_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_coupons`
--

LOCK TABLES `user_coupons` WRITE;
/*!40000 ALTER TABLE `user_coupons` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_coupons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_delete_requests`
--

DROP TABLE IF EXISTS `user_delete_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_delete_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `username` varchar(100) DEFAULT '',
  `admin_id` int(11) DEFAULT 0,
  `admin_note` varchar(500) DEFAULT '',
  `status` varchar(20) DEFAULT 'pending',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_delete_requests`
--

LOCK TABLES `user_delete_requests` WRITE;
/*!40000 ALTER TABLE `user_delete_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_delete_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_follows`
--

DROP TABLE IF EXISTS `user_follows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_follows` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `follower_id` int(11) NOT NULL,
  `following_id` int(11) NOT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `follower_id` (`follower_id`,`following_id`),
  KEY `idx_user_follows_follower` (`follower_id`),
  KEY `idx_user_follows_following` (`following_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_follows`
--

LOCK TABLES `user_follows` WRITE;
/*!40000 ALTER TABLE `user_follows` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_follows` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_titles`
--

DROP TABLE IF EXISTS `user_titles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_titles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `title_id` int(11) NOT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `grant_by` varchar(100) DEFAULT '',
  `grant_time` datetime DEFAULT current_timestamp(),
  `expire_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`title_id`),
  KEY `idx_user_titles_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_titles`
--

LOCK TABLES `user_titles` WRITE;
/*!40000 ALTER TABLE `user_titles` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_titles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(200) NOT NULL DEFAULT '123456',
  `password_hash` varchar(200) DEFAULT '',
  `phone` varchar(20) DEFAULT '',
  `email` varchar(100) DEFAULT '',
  `nickname` varchar(100) DEFAULT '',
  `bio` text DEFAULT NULL,
  `balance` decimal(10,2) DEFAULT 0.00,
  `experience` int(11) DEFAULT 0,
  `gender` varchar(10) DEFAULT '男',
  `avatar` varchar(500) DEFAULT '',
  `bg_url` varchar(500) DEFAULT '',
  `signature` varchar(300) DEFAULT '',
  `qq` varchar(20) DEFAULT '',
  `show_coin` int(11) DEFAULT 1,
  `follow_count` int(11) DEFAULT 0,
  `fans_count` int(11) DEFAULT 0,
  `status` varchar(2) DEFAULT '1',
  `points` int(11) DEFAULT 0,
  `level_id` int(11) DEFAULT 0,
  `level_name` varchar(100) DEFAULT '普通会员',
  `expire_time` datetime DEFAULT NULL,
  `ban_until` datetime DEFAULT NULL,
  `is_verified` tinyint(1) DEFAULT 0,
  `verified_org` varchar(200) DEFAULT '',
  `active_title_id` int(11) DEFAULT 0,
  `active_title_name` varchar(100) DEFAULT '',
  `last_checkin_date` date DEFAULT NULL,
  `consecutive_checkins` int(11) DEFAULT 0,
  `referrer_id` int(11) DEFAULT 0,
  `referrer_code` varchar(32) DEFAULT '',
  `age` int(11) DEFAULT 0,
  `register_address` varchar(200) DEFAULT '',
  `deleted_at` datetime DEFAULT NULL,
  `roles` text DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  `active_frame_id` int(11) DEFAULT 0,
  `active_frame_url` varchar(500) DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `idx_users_username` (`username`),
  KEY `idx_users_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'alexmorgan','123456','$2b$10$/.FNHkCYaKzbUE8rGc37CuBUij97c6atO6wN4xZwTs4I1mnooqLWu','18670001591','alexmorgan@company.com','Alex M (test)','CRUD test bio',0.00,0,'男','','','','',1,1,0,'1',0,0,'普通会员',NULL,NULL,0,'',0,'',NULL,0,0,'',0,'',NULL,'[\"R_SUPER\"]','2026-07-10 19:32:17','2026-07-10 20:17:39',0,''),
(2,'e2etester','Test123!','$2b$10$.OVZxfbUWDRSDaFLQl/xb.9gaUy9yEKpWFFRn4ZVZLyUtrzKuu3fq','','','',NULL,0.00,0,'男','','','','',1,0,1,'1',0,0,'普通会员',NULL,NULL,0,'',0,'',NULL,0,0,'',0,'',NULL,NULL,'2026-07-10 19:37:24','2026-07-10 19:37:24',0,''),
(3,'test_crud_user','123456','','13800000000','test_crud@test.com','CRUD Test','',0.00,0,'保密','','','','',1,0,0,'1',0,0,'普通会员',NULL,NULL,0,'',0,'',NULL,0,0,'',0,'',NULL,'[]','2026-07-10 20:11:44','2026-07-10 20:11:44',0,''),
(4,'crudtest60004','123456','','13800000004','crud60004@test.com','CRUD Test','',0.00,0,'保密','','','','',1,0,0,'1',3,0,'普通会员',NULL,NULL,0,'',0,'',NULL,0,0,'',0,'',NULL,'[]','2026-07-10 20:13:55','2026-07-10 20:15:27',0,''),
(5,'crudtest93850','123456','','13800000850','crud93850@test.com','CRUD Test','',0.00,0,'保密','','','','',1,0,0,'1',0,0,'普通会员',NULL,NULL,0,'',0,'',NULL,0,0,'',0,'',NULL,'[]','2026-07-10 20:17:39','2026-07-10 20:17:39',0,'');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `verification_config`
--

DROP TABLE IF EXISTS `verification_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `verification_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `condition_type` varchar(50) NOT NULL,
  `threshold` int(11) DEFAULT 0,
  `is_active` int(11) DEFAULT 0,
  `logic_type` varchar(20) DEFAULT 'any',
  `logic_count` int(11) DEFAULT 1,
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `verification_config`
--

LOCK TABLES `verification_config` WRITE;
/*!40000 ALTER TABLE `verification_config` DISABLE KEYS */;
INSERT INTO `verification_config` VALUES
(3,'follower_count',100,1,'AND',2,'2026-07-10 20:17:40','2026-07-10 20:17:40');
/*!40000 ALTER TABLE `verification_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `verification_requests`
--

DROP TABLE IF EXISTS `verification_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `verification_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `real_name` varchar(100) DEFAULT '',
  `id_card` varchar(50) DEFAULT '',
  `organization` varchar(200) DEFAULT '',
  `reason` text DEFAULT NULL,
  `proof_urls` text DEFAULT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `review_comment` text DEFAULT NULL,
  `review_by` varchar(100) DEFAULT '',
  `review_time` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  `selected_condition` varchar(50) DEFAULT '',
  `selected_app_id` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_verification_requests_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `verification_requests`
--

LOCK TABLES `verification_requests` WRITE;
/*!40000 ALTER TABLE `verification_requests` DISABLE KEYS */;
INSERT INTO `verification_requests` VALUES
(1,1,'alexmorgan','E2E Person','','E2E Org','E2E testing','[]','pending',NULL,'',NULL,'2026-07-10 19:37:25','',0);
/*!40000 ALTER TABLE `verification_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `withdraw_records`
--

DROP TABLE IF EXISTS `withdraw_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `withdraw_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `amount` decimal(10,2) NOT NULL,
  `method` varchar(30) DEFAULT 'alipay',
  `account` varchar(200) DEFAULT '',
  `real_name` varchar(50) DEFAULT '',
  `status` varchar(20) DEFAULT 'pending',
  `remark` text DEFAULT '',
  `reviewed_by` int(11) DEFAULT 0,
  `reviewed_by_name` varchar(100) DEFAULT '',
  `reviewed_at` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_withdraw_records_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `withdraw_records`
--

LOCK TABLES `withdraw_records` WRITE;
/*!40000 ALTER TABLE `withdraw_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `withdraw_records` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-10 20:44:26
