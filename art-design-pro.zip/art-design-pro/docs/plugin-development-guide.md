# 插件开发完整教程

本教程基于 Art Design Pro 项目内置的插件系统，从零开始教你如何创建、配置、打包和部署一个自定义插件。以 `feature-panel`（功能入口面板）插件为参考范例，深入讲解插件系统的每一个环节。

---

## 目录

1. [插件系统概述](#1-插件系统概述)
2. [插件目录结构](#2-插件目录结构)
3. [plugin.json 清单文件](#3-pluginjson-清单文件)
4. [配置系统详解](#4-配置系统详解)
5. [前端注入脚本开发](#5-前端注入脚本开发)
6. [CSS 样式规范](#6-css-样式规范)
7. [后端 API 参考](#7-后端-api-参考)
8. [配置编辑机制](#8-配置编辑机制)
9. [打包与部署](#9-打包与部署)
10. [调试与排错](#10-调试与排错)
11. [完整示例：从零创建通知条插件](#11-完整示例从零创建通知条插件)
12. [完整配置类型体系（27 种）](#12-完整配置类型体系27-种)
13. [配套功能（联动/校验/默认值/导入导出/分组折叠）](#13-配套功能联动校验默认值导入导出分组折叠)
14. [后端扩展机制完整体系](#14-后端扩展机制完整体系)
    - [14.1 总览与架构](#141-总览与架构)
    - [14.2 HTTP 层扩展（6 种）](#142-http-层扩展6-种)
    - [14.3 数据库层扩展（4 种）](#143-数据库层扩展4-种)
    - [14.4 事件系统（12 个事件）](#144-事件系统12-个事件)
    - [14.5 UI/前端注入点（8 种）](#145-ui前端注入点8-种)
    - [14.6 服务层扩展（5 种）](#146-服务层扩展5-种)
    - [14.7 调度与任务（3 种）](#147-调度与任务3-种)
    - [14.8 国际化与资源（3 种）](#148-国际化与资源3-种)
    - [14.9 权限与安全（4 种）](#149-权限与安全4-种)
    - [14.10 插件间交互（3 种）](#1410-插件间交互3-种)
    - [14.11 完整 context 对象 API 参考](#1411-完整-context-对象-api-参考)
    - [14.12 插件开发终极清单](#1412-插件开发终极清单)

---

## 1. 插件系统概述

### 1.1 工作原理

插件系统采用 **服务端存储 + 前端注入** 的架构：

```
管理员上传 .zip → 后端解压 → 存入 server/plugins/{name}/
                                    ↓
管理员启用插件 → 数据库 status='1'
                                    ↓
用户打开页面 → App.vue onMounted → usePluginInject.loadPlugins()
                                    ↓
             GET /api/plugins/inject → 返回 CSS/JS 内容 + config
                                    ↓
             injectStyles → <style> 注入到 <head>
             injectConfig → window.__PLUGIN_CONFIG__ = { 插件名: 配置对象 }
             injectScripts → <script> 注入到 <head>
                                    ↓
             插件脚本执行 → 读取配置 → 构建 DOM → 插入页面
```

### 1.2 插件能做什么

- 在页面任意位置注入自定义 HTML/CSS/JS
- 通过后台配置面板实时修改文案、开关、颜色等
- 支持布尔值（开关）、字符串（输入框）、对象（嵌套配置）、数组（列表项）四种配置类型
- 配置修改即时生效，无需重启服务
- SPA 路由切换时自动重新注入

### 1.3 核心文件

| 文件 | 职责 |
|------|------|
| `server/plugins/{name}/plugin.json` | 插件清单：元数据、配置、配置元数据 |
| `server/plugins/{name}/scripts/*.js` | 前端注入脚本：读取配置、构建 DOM |
| `server/plugins/{name}/styles/*.css` | 注入样式 |
| `server/routes/plugins.cjs` | 后端：安装、卸载、配置、注入 API |
| `src/hooks/core/usePluginInject.ts` | 前端：注入 CSS/JS 到页面 |
| `src/views/operation/plugins/index.vue` | 管理后台：插件列表、配置编辑 |

---

## 2. 插件目录结构

一个标准的插件包含以下文件：

```
my-plugin/
  plugin.json          # 必须：插件清单文件
  scripts/
    index.js           # 必须（路径可在 plugin.json 中配置）：前端注入脚本
  styles/
    style.css          # 可选：注入样式
  assets/              # 可选：静态资源（图片等）
    icon.png
```

### 2.1 目录名规则

目录名即插件唯一标识（`name` 字段）。安装时会对目录名做 sanitize 处理：
- 非字母、数字、下划线、连字符的字符会被替换为 `_`
- 首尾下划线会被去除

例如：`name: "My Feature Panel"` → 目录名 `My_Feature_Panel`

**建议**：`name` 字段使用小写字母 + 连字符，如 `feature-panel`、`notice-bar`。

### 2.2 参考范例

`server/plugins/feature-panel/` 目录结构：

```
feature-panel/
  plugin.json           # 137 行，含 config 和 configMeta
  scripts/
    panel.js            # 194 行，DOM 构建 + 路由导航 + MutationObserver
  styles/
    panel.css           # 146 行，面板、卡片、横幅样式
```

---

## 3. plugin.json 清单文件

### 3.1 基础字段

| 字段 | 类型 | 必需 | 说明 |
|------|------|------|------|
| `name` | string | **是** | 插件唯一标识，用作目录名 |
| `version` | string | **是** | 语义化版本号，如 `"1.0.0"` |
| `description` | string | 否 | 插件功能描述 |
| `author` | string | 否 | 作者名称 |
| `styles` | string[] | 否 | 要注入的 CSS 文件路径，相对于插件根目录 |
| `scripts` | string[] | 否 | 要注入的 JS 文件路径，相对于插件根目录 |
| `config` | object | 否 | 插件默认配置，任意 JSON 对象 |
| `configMeta` | object | 否 | 配置元数据，用于管理后台生成编辑 UI |

### 3.2 最小化示例

```json
{
  "name": "hello-world",
  "version": "1.0.0",
  "description": "一个最简单的插件示例",
  "author": "Admin",
  "scripts": ["scripts/index.js"],
  "styles": ["styles/style.css"]
}
```

### 3.3 完整示例

```json
{
  "name": "notice-bar",
  "version": "1.0.0",
  "description": "页面顶部通知条",
  "author": "Admin",
  "styles": ["styles/style.css"],
  "scripts": ["scripts/index.js"],
  "config": {
    "show": true,
    "text": "欢迎来到本站！",
    "url": "/help",
    "bgColor": "#FF6B35",
    "closable": true
  },
  "configMeta": {
    "show": {
      "label": "显示通知条"
    },
    "text": {
      "label": "通知文案"
    },
    "url": {
      "label": "点击跳转链接"
    },
    "bgColor": {
      "label": "背景颜色"
    },
    "closable": {
      "label": "可关闭"
    }
  }
}
```

---

## 4. 配置系统详解

### 4.1 config 字段

`config` 是一个任意 JSON 对象，完全由开发者定义结构。支持四种基础数据类型：

| 类型 | JSON 类型 | 管理后台呈现 | 示例值 |
|------|-----------|-------------|--------|
| boolean | `true` / `false` | Switch 开关 | `true` |
| string | `"..."` | Input 输入框 | `"欢迎"` |
| object | `{ ... }` | 分组子字段 | `{ "show": true, "text": "公告" }` |
| array | `[ ... ]` | 可增删的列表 | `[{ "label": "签到", "url": "/checkin" }]` |

类型由运行时值自动推断（`typeof` + `Array.isArray`），无需在 json 中显式声明。

如果你需要更多配置类型（如 select 下拉框、number 数字输入、color 颜色选择器等），请参考 **第 12 章：扩展配置类型**。

### 4.2 嵌套配置示例（object 类型）

```json
{
  "config": {
    "banner": {
      "show": true,
      "text": "公告内容",
      "url": "/help"
    }
  },
  "configMeta": {
    "banner": {
      "label": "页面公告",
      "childrenMeta": {
        "show": { "label": "显示公告" },
        "text": { "label": "公告文案" },
        "url": { "label": "跳转链接" }
      }
    }
  }
}
```

### 4.3 列表配置示例（array 类型）

```json
{
  "config": {
    "links": [
      { "label": "首页", "url": "/", "show": true },
      { "label": "帮助", "url": "/help", "show": true }
    ]
  },
  "configMeta": {
    "links": {
      "label": "快捷链接",
      "itemMeta": {
        "label": { "label": "文字" },
        "url": { "label": "链接" },
        "show": { "label": "显示" }
      }
    }
  }
}
```

### 4.4 configMeta 规范

`configMeta` 是与 `config` 结构平行的元数据对象，用于管理后台生成编辑表单。每个顶级键对应 `config` 中的一个字段。

**字段级别**：
```json
{
  "字段名": { "label": "显示标签" }
}
```

**object 类型**（含子字段组）：
```json
{
  "字段名": {
    "label": "分组标签",
    "childrenMeta": {
      "子字段名": { "label": "子字段标签" },
      ...
    }
  }
}
```

**array 类型**（含列表项字段定义）：
```json
{
  "字段名": {
    "label": "列表标签",
    "itemMeta": {
      "列表项字段名": { "label": "字段标签" },
      ...
    }
  }
}
```

如果某个字段没有在 `configMeta` 中定义，管理后台会自动使用 `keyToLabel` 函数将驼峰命名转换为空格分隔的单词（如 `bgColor` → `Bg Color`）作为标签。

---

## 5. 前端注入脚本开发

### 5.1 脚本基本结构

注入脚本采用 IIFE（立即执行函数）模式，避免全局变量污染：

```javascript
(function() {
  'use strict';

  // ===== 1. 读取配置 =====
  var PLUGIN_NAME = 'my-plugin';
  var config = (window.__PLUGIN_CONFIG__ && window.__PLUGIN_CONFIG__[PLUGIN_NAME]) || null;

  // 降级默认配置（当 window.__PLUGIN_CONFIG__ 不可用时使用）
  if (!config) {
    config = {
      show: true,
      text: '默认通知文案',
      url: '/help'
    };
  }

  // ===== 2. 构建 DOM =====
  function buildElement() {
    if (!config.show) return null;

    var el = document.createElement('div');
    el.className = 'mp-notice';
    el.setAttribute('data-plugin-panel', PLUGIN_NAME);

    el.innerHTML = '<span>' + config.text + '</span>';
    return el;
  }

  // ===== 3. 导航函数 =====
  function navigate(url) {
    if (!url || url === '#') return;
    if (url.startsWith('http')) {
      window.open(url, '_blank');
      return;
    }
    // 内部路由：拼接 hash 路径
    window.location.href = window.location.origin + '/#/' + url.replace(/^\//, '');
  }

  // ===== 4. 事件绑定 =====
  function bindEvents(el) {
    el.querySelectorAll('[data-mp-url]').forEach(function(link) {
      link.addEventListener('click', function(e) {
        navigate(link.getAttribute('data-mp-url'));
      });
    });
  }

  // ===== 5. 插入 DOM（带去重） =====
  function tryInsert() {
    if (document.querySelector('[data-plugin-panel="' + PLUGIN_NAME + '"]')) return;

    var target = document.querySelector('.some-parent');
    if (!target) return;

    var el = buildElement();
    if (!el) return;

    bindEvents(el);
    target.prepend(el);
  }

  // ===== 6. 生命周期管理 =====
  function init() {
    tryInsert();

    // MutationObserver：监听 DOM 变化自动重新注入
    var target = document.querySelector('.some-parent');
    if (target) {
      var observer = new MutationObserver(function() {
        tryInsert();
      });
      observer.observe(target, { childList: true, subtree: false });
    }

    // 定时轮询保底：最多重试 20 次，每次 500ms
    var retries = 0;
    var interval = setInterval(function() {
      retries++;
      tryInsert();
      if (document.querySelector('[data-plugin-panel="' + PLUGIN_NAME + '"]') || retries > 20) {
        clearInterval(interval);
      }
    }, 500);
  }

  // ===== 7. 启动 =====
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function() {
      setTimeout(init, 300);
    });
  } else {
    setTimeout(init, 300);
  }
})();
```

### 5.2 关键设计要点

**去重机制**：使用 `data-plugin-panel` 属性标记已注入元素，`tryInsert()` 中先检查是否已存在。

**三重重试**：
1. 首次调用 `tryInsert()`
2. `MutationObserver` 监听目标容器变化
3. 定时轮询（最多 20 次，500ms 间隔，共 10 秒）

**路由切换**：App.vue 监听到路由变化后，会 clone 并重新执行所有 `script[data-plugin]` 元素，插件脚本会重新执行并重建 DOM。

**延迟启动**：`init()` 延迟 300ms 执行，等待 Vue 渲染主框架后再注入。

### 5.3 如何确定插入位置

你需要找到页面中一个稳定的容器元素，通过 CSS 选择器定位。例如：

```javascript
// 查找方法 1：通过 CSS 选择器
var main = document.querySelector('.main');
var target = main.querySelector('.some-section');

// 查找方法 2：通过 data 属性
var target = document.querySelector('[data-section="hot"]');

// 查找方法 3：多层查找
var app = document.querySelector('#app');
var container = app.querySelector('.page-container');
var target = container.querySelector('.list-wrapper');
```

**选择器技巧**：
- 使用 `.class-name` 查找特定类名元素
- 使用 `[data-xxx]` 查找有特定 data 属性的元素
- 先确保父容器存在，再查找子元素
- 在 Chrome DevTools 中右键元素 → Copy → Copy selector 获取精确选择器

### 5.4 内部路由导航

项目使用 hash 路由模式（`#/path`）。插件脚本中的导航函数需要正确处理：

```javascript
function navigate(url) {
  if (!url || url === '#') return;
  if (url.startsWith('http')) {
    window.open(url, '_blank');  // 外部链接新标签打开
    return;
  }
  // 内部路由
  window.location.href = window.location.origin + '/#/' + url.replace(/^\//, '');
}
```

---

## 6. CSS 样式规范

### 6.1 命名空间

所有 CSS 类名必须使用插件名前缀，避免与宿主页面样式冲突。推荐使用插件名的缩写作为前缀：

- `feature-panel` → `fp-` 前缀
- `notice-bar` → `nb-` 前缀
- `my-plugin` → `mp-` 前缀

### 6.2 样式示例

```css
/* 容器 */
.nb-notice {
  position: sticky;
  top: 0;
  z-index: 100;
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 14px;
  background: #FF6B35;
  border-radius: 0;
  cursor: pointer;
  user-select: none;
  -webkit-tap-highlight-color: transparent;
}

/* 点击反馈 */
.nb-notice:active {
  opacity: 0.85;
}

/* 文字 */
.nb-notice-text {
  flex: 1;
  font-size: 13px;
  color: #fff;
  font-weight: 500;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

/* 关闭按钮 */
.nb-notice-close {
  width: 22px;
  height: 22px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  border-radius: 50%;
  transition: background 0.15s;
}
.nb-notice-close:hover {
  background: rgba(255, 255, 255, 0.2);
}
.nb-notice-close svg {
  width: 14px;
  height: 14px;
  color: #fff;
}
```

### 6.3 设计注意事项

- 使用 `-webkit-tap-highlight-color: transparent` 消除移动端点击高亮
- 使用 `user-select: none` 防止文字被选中
- 动画使用 `transform` 而非 `width/height` 以获得 GPU 加速
- 字体族使用系统默认栈：`-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif`

---

## 7. 后端 API 参考

### 7.1 插件注入 API

**GET `/api/plugins/inject`**（无需认证）

返回所有启用插件的样式和脚本内容：

```json
{
  "code": 200,
  "data": [
    {
      "id": 4,
      "name": "feature-panel",
      "version": "1.0.0",
      "config": {
        "cardShow": false,
        "items": [...],
        "banner": { "show": true, "text": "公告", "url": "/help" }
      },
      "styles": [".fp-panel { margin: 0 0 14px 0; ... }"],
      "scripts": ["(function() { 'use strict'; ... })();"]
    }
  ]
}
```

### 7.2 插件管理 API

以下接口需要管理员认证：

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/api/plugins/list` | 插件列表 |
| POST | `/api/plugins/upload` | 上传安装（ZIP） |
| PUT | `/api/plugins/:id/toggle` | 启用/禁用 |
| PUT | `/api/plugins/:name/config` | 保存配置 |
| POST | `/api/plugins/:id/upgrade` | 升级（上传新 ZIP） |
| DELETE | `/api/plugins/:id` | 删除 |

### 7.3 配置保存流程

```
管理后台点击"保存配置"
  → handleSaveConfig() 深拷贝 configData
  → PUT /api/plugins/:name/config
  → 后端读取 plugin.json
  → 覆盖 config 字段
  → 写回 plugin.json 文件
  → 更新数据库 plugins 表 manifest 字段
  → 返回成功
```

---

## 8. 配置编辑机制

### 8.1 配置表单自动生成

管理后台根据 `config` 的运行时值和 `configMeta` 的元数据自动生成编辑表单：

- `typeof val === 'boolean'` → **Switch 开关**
- 其他基本类型 → **Input 输入框**
- `typeof val === 'object'`（非数组）→ **分组面板**，循环渲染子字段
- `Array.isArray(val)` → **列表编辑器**，支持添加/删除行

### 8.2 标签来源优先级

```
1. configMeta.{key}.label                   → 使用元数据中的自定义标签
2. configMeta.{key}.childrenMeta.{ck}.label → 子字段的元数据标签
3. configMeta.{key}.itemMeta.{ik}.label      → 数组元素的元数据标签
4. keyToLabel(key)                           → 驼峰拆分（cardShow → Card Show）
```

### 8.3 保存时的数据处理

```typescript
async function handleSaveConfig() {
  // 1. 深拷贝 configData，防止引用污染
  const cfg = JSON.parse(JSON.stringify(configData))

  // 2. 构建请求体
  const payload: Record<string, any> = { config: cfg }
  if (Object.keys(configMeta.value).length > 0) {
    payload.configMeta = configMeta.value
  }

  // 3. 发送保存请求
  await fetchPluginUpdateConfig(configTarget.value.name, payload)
}
```

**注意**：`configMeta` 是可选的保存在 `payload` 中。如果已有 configMeta 的情况，选择不传则不会覆盖原有 configMeta。

---

## 9. 打包与部署

### 9.1 文件准备

将插件文件按标准目录结构组织：

```
my-plugin/
  plugin.json
  scripts/
    index.js
  styles/
    style.css
```

### 9.2 打包为 ZIP

```bash
# 在插件目录的上一级执行
cd /path/to/my-plugin/..
zip -r my-plugin.zip my-plugin/
```

**注意**：
- ZIP 文件不要包含外层父目录嵌套
- 确保 `plugin.json` 在 ZIP 根目录
- 文件大小不超过 50MB

### 9.3 上传安装

1. 登录管理后台
2. 进入 **运营管理 → 插件管理**
3. 点击 **上传插件**
4. 选择 ZIP 文件，点击上传
5. 安装成功后，在列表中找到插件，点击 **启用**

### 9.4 升级

1. 修改插件代码
2. 更新 `plugin.json` 中的 `version` 字段
3. 重新打包为 ZIP
4. 在插件列表中点击 **升级**，上传新 ZIP

### 9.5 手动安装（开发阶段）

开发阶段可以直接将插件文件放到 `server/plugins/` 目录下，然后通过管理后台的上传功能安装，或者直接在数据库中添加记录：

```sql
INSERT INTO plugins (name, description, version, author, plugin_dir, manifest, status)
VALUES ('my-plugin', '我的插件', '1.0.0', 'Admin', 'my-plugin', '{"name":"my-plugin",...}', '1');
```

---

## 10. 调试与排错

### 10.1 检查注入是否成功

打开浏览器 DevTools Console：

```javascript
// 检查配置是否注入
console.log(window.__PLUGIN_CONFIG__)

// 检查 DOM 是否已插入
document.querySelector('[data-plugin-panel="my-plugin"]')
```

### 10.2 检查脚本是否执行

在插件脚本开头添加 `console.log`：

```javascript
console.log('[my-plugin] 脚本开始执行, config:', config)
```

然后观察 Console 输出。

### 10.3 常见问题

**问题：插件不显示**

1. 检查插件状态是否为"已启用"（`status='1'`）
2. 检查 `tryInsert()` 中的目标选择器是否存在
3. 检查 Console 是否有 JS 错误
4. 检查 `/api/plugins/inject` 是否返回了插件数据

**问题：配置修改后不生效**

1. 确认插件脚本中正确读取了 `window.__PLUGIN_CONFIG__`
2. 刷新页面重新加载配置
3. 检查 `plugin.json` 文件中 `config` 是否被正确更新

**问题：路由切换后插件消失**

1. 检查 MutationObserver 是否监听了正确的容器
2. 检查定时轮询是否设置了足够的重试次数
3. 检查 `tryInsert()` 中去重逻辑是否正确

**问题：样式被覆盖**

1. 使用更具体的 CSS 选择器
2. 使用 `!important`（仅作为最后手段）
3. 检查是否有其他插件的样式产生冲突

### 10.4 开发建议

1. **先硬编码，后配置化**：先用硬编码值验证 DOM 构建和注入逻辑，确认无误后再迁移到 `config` 中
2. **使用 Console 调试**：在关键步骤添加 `console.log` 输出状态
3. **分步测试**：先测试静态 HTML 注入，再测试事件绑定，最后测试配置读取
4. **检查 API 响应**：直接在浏览器访问 `/api/plugins/inject` 查看返回数据

---

## 11. 完整示例：从零创建通知条插件

### 11.1 需求概述

创建一个页面顶部通知条插件，支持：
- 开关控制显示/隐藏
- 自定义文案
- 点击跳转（支持内部路由和外部链接）
- 可关闭
- 自定义背景色

### 11.2 目录结构

```
notice-bar/
  plugin.json
  scripts/
    index.js
  styles/
    style.css
```

### 11.3 plugin.json

```json
{
  "name": "notice-bar",
  "version": "1.0.0",
  "description": "页面顶部通知条，支持自定义文案和跳转",
  "author": "Admin",
  "styles": ["styles/style.css"],
  "scripts": ["scripts/index.js"],
  "config": {
    "show": true,
    "text": "欢迎访问本站！",
    "url": "/help",
    "bgColor": "#FF6B35",
    "closable": true
  },
  "configMeta": {
    "show": {
      "label": "显示通知条"
    },
    "text": {
      "label": "通知文案"
    },
    "url": {
      "label": "跳转链接"
    },
    "bgColor": {
      "label": "背景颜色"
    },
    "closable": {
      "label": "可关闭"
    }
  }
}
```

### 11.4 scripts/index.js

```javascript
(function() {
  'use strict';

  var PLUGIN_NAME = 'notice-bar';
  var config = (window.__PLUGIN_CONFIG__ && window.__PLUGIN_CONFIG__[PLUGIN_NAME]) || null;

  if (!config) {
    config = {
      show: true,
      text: '欢迎访问本站！',
      url: '/help',
      bgColor: '#FF6B35',
      closable: true
    };
  }

  // SVG 图标内嵌
  var ICONS = {
    bell: '<svg viewBox="0 0 24 24" fill="none"><path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9M13.73 21a2 2 0 01-3.46 0" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    close: '<svg viewBox="0 0 24 24" fill="none"><path d="M6 6l12 12M18 6L6 18" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>'
  };

  function navigate(url) {
    if (!url || url === '#') return;
    if (url.startsWith('http')) {
      window.open(url, '_blank');
      return;
    }
    window.location.href = window.location.origin + '/#/' + url.replace(/^\//, '');
  }

  function buildNotice() {
    if (!config.show) return null;

    var notice = document.createElement('div');
    notice.className = 'nb-notice';
    notice.style.background = config.bgColor || '#FF6B35';
    notice.setAttribute('data-plugin-panel', PLUGIN_NAME);
    notice.setAttribute('data-nb-url', config.url || '#');

    // 左侧图标
    var icon = document.createElement('div');
    icon.className = 'nb-notice-icon';
    icon.innerHTML = ICONS.bell;
    notice.appendChild(icon);

    // 中间文字
    var text = document.createElement('span');
    text.className = 'nb-notice-text';
    text.textContent = config.text || '';
    notice.appendChild(text);

    // 右侧关闭按钮
    if (config.closable !== false) {
      var closeBtn = document.createElement('span');
      closeBtn.className = 'nb-notice-close';
      closeBtn.innerHTML = ICONS.close;
      closeBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        notice.style.display = 'none';
      });
      notice.appendChild(closeBtn);
    }

    return notice;
  }

  function bindEvents(notice) {
    // 点击通知条跳转
    var url = notice.getAttribute('data-nb-url');
    if (url) {
      notice.addEventListener('click', function() {
        navigate(url);
      });
    }
  }

  function tryInsert() {
    if (document.querySelector('[data-plugin-panel="' + PLUGIN_NAME + '"]')) return;

    var app = document.querySelector('#app');
    if (!app) return;

    var notice = buildNotice();
    if (!notice) return;

    bindEvents(notice);

    // 插入到 #app 的最顶部
    var firstChild = app.firstChild;
    if (firstChild) {
      app.insertBefore(notice, firstChild);
    } else {
      app.appendChild(notice);
    }
  }

  function init() {
    tryInsert();

    var app = document.querySelector('#app');
    if (app) {
      var observer = new MutationObserver(function() {
        tryInsert();
      });
      observer.observe(app, { childList: true, subtree: false });
    }

    var retries = 0;
    var interval = setInterval(function() {
      retries++;
      tryInsert();
      if (document.querySelector('[data-plugin-panel="' + PLUGIN_NAME + '"]') || retries > 20) {
        clearInterval(interval);
      }
    }, 500);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function() {
      setTimeout(init, 300);
    });
  } else {
    setTimeout(init, 300);
  }
})();
```

### 11.5 styles/style.css

```css
.nb-notice {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 14px;
  cursor: pointer;
  user-select: none;
  -webkit-tap-highlight-color: transparent;
  z-index: 999;
  position: relative;
}

.nb-notice:active {
  opacity: 0.85;
}

.nb-notice-icon {
  width: 20px;
  height: 20px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}

.nb-notice-icon svg {
  width: 18px;
  height: 18px;
}

.nb-notice-text {
  flex: 1;
  font-size: 13px;
  color: #fff;
  font-weight: 500;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
}

.nb-notice-close {
  width: 22px;
  height: 22px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  cursor: pointer;
  border-radius: 50%;
  transition: background 0.15s;
}

.nb-notice-close:hover {
  background: rgba(255, 255, 255, 0.2);
}

.nb-notice-close:active {
  background: rgba(255, 255, 255, 0.3);
}

.nb-notice-close svg {
  width: 14px;
  height: 14px;
  color: #fff;
}
```

### 11.6 部署测试

```bash
# 1. 创建目录
mkdir -p /path/to/notice-bar/scripts /path/to/notice-bar/styles

# 2. 写入上述文件内容

# 3. 打包
cd /path/to
zip -r notice-bar.zip notice-bar/

# 4. 通过管理后台上传 notice-bar.zip

# 5. 启用插件

# 6. 进入配置页面，修改文案和链接

# 7. 刷新前端页面查看效果
```

---

## 12. 完整配置类型体系（27 种）

第 4 章介绍了四种基础类型（bool/string/object/array）。本章将配置类型扩展为 **9 大类 27 种**，覆盖插件开发中所有常见场景。

### 12.1 类型总览

| 大类 | 类型数量 | 包含 |
|------|---------|------|
| 一、基础值类 | 4 类 9 细分 | bool(3) + string(5) + object(2) + array(2) |
| 二、数字数值类 | 4 种 | 整数、浮点数、滑块、金额 |
| 三、枚举选择类 | 4 种 | 单选下拉、多选复选、单选按钮组、树形选择 |
| 四、媒体文件类 | 5 种 | 单图、多图、文件、颜色拾取、图标 |
| 五、富文本/时间类 | 5 种 | 富文本、Markdown、日期、日期时间、时间区间 |
| 六、业务关联类 | 5 种 | 用户关联、角色权限、API接口、模板选择、Cron |

---

### 一、基础值类（原有 4 类升级细分）

#### 1. 布尔值（bool）

| 细分类型 | uiType | 控件 | 存储值 | 适用场景 |
|---------|--------|------|--------|---------|
| 普通开关 | `"switch"` | ElSwitch | `true`/`false` | 功能启用/禁用 |
| 启用/禁用单选 | `"radio-bool"` | ElRadioGroup | `true`/`false` | 启停模式切换 |
| 是否弹窗提示 | `"confirm-bool"` | ElSwitch + 提示文字 | `true`/`false` | 危险操作确认 |

configMeta 声明：

```json
{
  "enableFeature": { "label": "启用功能", "uiType": "switch" },
  "notifyMode": {
    "label": "通知方式",
    "uiType": "radio-bool",
    "options": [
      { "label": "站内信", "value": false },
      { "label": "短信通知", "value": true }
    ]
  },
  "showConfirm": {
    "label": "删除前弹窗确认",
    "uiType": "confirm-bool",
    "confirmText": "开启后，每次删除操作都会弹出二次确认窗口"
  }
}
```

#### 2. 字符串文本（string）

| 细分类型 | uiType | 控件 | 说明 |
|---------|--------|------|------|
| 单行短文本 | `"text"` | ElInput | 账号、名称、关键词 |
| 多行长文本 | `"textarea"` | ElInput textarea | 简介、备注、规则文案 |
| 密码加密 | `"password"` | ElInput show-password | 自动掩码，存储哈希 |
| URL 专用 | `"url"` | ElInput + 格式校验 | 链接输入框 |
| 邮箱/手机号 | `"email"` `"phone"` | ElInput + 正则校验 | 联系信息 |

configMeta 声明：

```json
{
  "keyword": { "label": "关键词", "uiType": "text", "maxlength": 50 },
  "description": { "label": "插件简介", "uiType": "textarea", "rows": 4 },
  "apiKey": { "label": "API 密钥", "uiType": "password" },
  "redirectUrl": { "label": "回调地址", "uiType": "url", "placeholder": "https://" },
  "contactEmail": { "label": "联系邮箱", "uiType": "email" },
  "contactPhone": { "label": "联系电话", "uiType": "phone" }
}
```

#### 3. 对象（object）

| 细分类型 | 说明 | 示例 |
|---------|------|------|
| 单层简单对象 | 一组平级配置字段 | `{ "show": true, "text": "公告" }` |
| 多层级嵌套对象 | 配置内部再嵌套子对象 | `{ "header": { "style": { "bg": "#fff" } } }` |

多层级嵌套 configMeta：

```json
{
  "header": {
    "label": "页头配置",
    "childrenMeta": {
      "show": { "label": "显示" },
      "style": {
        "label": "样式",
        "childrenMeta": {
          "bg": { "label": "背景色", "uiType": "color" },
          "height": { "label": "高度", "uiType": "number" }
        }
      }
    }
  }
}
```

#### 4. 数组（array）

| 细分类型 | 说明 | 示例 |
|---------|------|------|
| 基础文本数组 | 纯字符串列表，换行拆分 | `["标签1", "标签2", "标签3"]` |
| 结构化对象数组 | 每条含多字段表单 | `[{ "label":"首页", "url":"/", "show":true }]` |

基础文本数组的 configMeta（自动将换行文本拆为数组）：

```json
{
  "tags": {
    "label": "标签列表",
    "uiType": "textarea-array",
    "placeholder": "每行一个标签"
  }
}
```

---

### 二、数字数值类（新增）

#### 5. 整数（integer）

```json
{
  "pointThreshold": {
    "label": "积分阈值",
    "uiType": "number",
    "integer": true,
    "min": 0,
    "max": 99999,
    "unit": "分"
  }
}
```

#### 6. 浮点数（float）

```json
{
  "discountRate": {
    "label": "折扣比例",
    "uiType": "number",
    "precision": 2,
    "min": 0.01,
    "max": 1.00,
    "unit": "%"
  }
}
```

#### 7. 范围滑块数值（slider）

```json
{
  "opacity": {
    "label": "透明度",
    "uiType": "slider",
    "min": 0,
    "max": 100,
    "step": 1,
    "marks": { "0": "0%", "50": "50%", "100": "100%" }
  }
}
```

#### 8. 金额专用数值（amount）

```json
{
  "price": {
    "label": "充值价格",
    "uiType": "amount",
    "precision": 2,
    "min": 0,
    "currency": "CNY",
    "showThousands": true
  }
}
```

---

### 三、枚举选择类（新增）

#### 9. 单选下拉枚举（select）

```json
{
  "userRole": {
    "label": "用户身份",
    "uiType": "select",
    "options": [
      { "label": "普通用户", "value": "user" },
      { "label": "VIP 会员", "value": "vip" },
      { "label": "管理员", "value": "admin" }
    ]
  }
}
```

#### 10. 多选复选枚举（multi-select）

```json
{
  "permissions": {
    "label": "权限标签",
    "uiType": "multi-select",
    "options": [
      { "label": "查看", "value": "read" },
      { "label": "编辑", "value": "write" },
      { "label": "删除", "value": "delete" },
      { "label": "导出", "value": "export" }
    ]
  }
}
```

存储为数组：`["read", "write"]`

#### 11. 单选按钮组（radio-group）

```json
{
  "runMode": {
    "label": "运行模式",
    "uiType": "radio-group",
    "options": [
      { "label": "本地", "value": "local" },
      { "label": "在线", "value": "online" },
      { "label": "沙盒", "value": "sandbox" }
    ]
  }
}
```

#### 12. 树形下拉选择（tree-select）

```json
{
  "categoryId": {
    "label": "分类",
    "uiType": "tree-select",
    "treeData": [
      {
        "label": "电子产品", "value": "1",
        "children": [
          { "label": "手机", "value": "11" },
          { "label": "电脑", "value": "12" }
        ]
      },
      { "label": "服装", "value": "2" }
    ]
  }
}
```

---

### 四、媒体与文件类型（新增）

#### 13. 单图上传（image）

```json
{
  "avatar": {
    "label": "头像",
    "uiType": "image",
    "accept": ".png,.jpg,.jpeg",
    "maxSize": 2,
    "crop": "circle",
    "width": 200,
    "height": 200
  }
}
```

| 参数 | 说明 |
|------|------|
| `crop` | 裁切形状：`"circle"`（圆形） `"square"`（方形） `null`（不裁切） |
| `maxSize` | 最大文件大小（MB） |
| `width`/`height` | 建议尺寸 |

#### 14. 多图数组上传（images）

```json
{
  "banners": {
    "label": "轮播图",
    "uiType": "images",
    "maxCount": 6,
    "accept": ".png,.jpg,.jpeg,.webp",
    "maxSize": 5
  }
}
```

存储为数组：`["/uploads/a.jpg", "/uploads/b.png"]`

#### 15. 文件上传（file）

```json
{
  "pluginZip": {
    "label": "插件包",
    "uiType": "file",
    "accept": ".zip",
    "maxSize": 50
  },
  "importExcel": {
    "label": "导入 Excel",
    "uiType": "file",
    "accept": ".xlsx,.xls,.csv",
    "maxSize": 10,
    "onUpload": "handleExcelImport"
  }
}
```

#### 16. 颜色拾取器（color）

```json
{
  "primaryColor": {
    "label": "主色调",
    "uiType": "color",
    "showAlpha": true,
    "presets": ["#409EFF", "#67C23A", "#E6A23C", "#F56C6C"]
  },
  "gradientBg": {
    "label": "渐变背景",
    "uiType": "gradient-color",
    "direction": "to right"
  }
}
```

渐变双色存储格式：`"linear-gradient(to right, #FF6B35, #FF4500)"`

#### 17. 图标选择（icon）

```json
{
  "navIcon": {
    "label": "导航图标",
    "uiType": "icon",
    "iconSet": "element-plus"
  }
}
```

---

### 五、富文本与时间类型（新增）

#### 18. 富文本编辑器（richtext）

```json
{
  "announcement": {
    "label": "公告内容",
    "uiType": "richtext",
    "toolbar": "basic",
    "height": 400
  }
}
```

| toolbar | 功能 |
|---------|------|
| `"basic"` | 加粗/斜体/下划线/链接/图片/列表 |
| `"full"` | 全部功能：表格、视频、源码、字体颜色 |

#### 19. Markdown 编辑器（markdown）

```json
{
  "docContent": {
    "label": "使用文档",
    "uiType": "markdown",
    "height": 500,
    "preview": true
  }
}
```

#### 20. 日期选择器（date）

```json
{
  "startDate": {
    "label": "活动开始日期",
    "uiType": "date",
    "placeholder": "选择日期"
  }
}
```

#### 21. 日期时间选择器（datetime）

```json
{
  "executeTime": {
    "label": "定时执行时间",
    "uiType": "datetime",
    "placeholder": "选择日期时间"
  }
}
```

#### 22. 时间区间选择器（date-range）

```json
{
  "activityPeriod": {
    "label": "活动有效期",
    "uiType": "date-range",
    "startPlaceholder": "开始日期",
    "endPlaceholder": "结束日期"
  }
}
```

存储为数组：`["2026-07-01", "2026-07-31"]`

---

### 六、业务关联联动类型（后台系统专属）

#### 23. 用户关联选择（user-select）

```json
{
  "adminId": {
    "label": "指定管理员",
    "uiType": "user-select",
    "apiUrl": "/api/users/search",
    "multiple": false
  },
  "blacklistUserIds": {
    "label": "黑名单用户",
    "uiType": "user-select",
    "apiUrl": "/api/users/search",
    "multiple": true
  }
}
```

#### 24. 角色/权限关联（role-select）

```json
{
  "bindRoleId": {
    "label": "绑定角色",
    "uiType": "role-select",
    "apiUrl": "/api/roles/list"
  },
  "bindPermissionGroup": {
    "label": "关联权限组",
    "uiType": "role-select",
    "apiUrl": "/api/permissions/groups",
    "multiple": true
  }
}
```

#### 25. 接口地址配置（api-config）

```json
{
  "thirdPartyApi": {
    "label": "第三方 API",
    "uiType": "api-config",
    "fields": {
      "baseUrl": { "label": "接口地址", "uiType": "url" },
      "appId": { "label": "App ID", "uiType": "text" },
      "appSecret": { "label": "App Secret", "uiType": "password" },
      "timeout": { "label": "超时(ms)", "uiType": "number", "min": 1000, "max": 60000 }
    }
  }
}
```

#### 26. 模板选择（template-select）

```json
{
  "pageLayout": {
    "label": "页面布局",
    "uiType": "template-select",
    "options": [
      { "label": "经典布局 (1号)", "value": "layout-1", "preview": "/templates/layout1.png" },
      { "label": "卡片布局 (2号)", "value": "layout-2", "preview": "/templates/layout2.png" }
    ]
  }
}
```

#### 27. 定时任务表达式（cron）

```json
{
  "cleanCron": {
    "label": "定时清理任务",
    "uiType": "cron",
    "placeholder": "0 0 3 * * ?",
    "presets": [
      { "label": "每天凌晨 3 点", "value": "0 0 3 * * ?" },
      { "label": "每周一凌晨 3 点", "value": "0 0 3 ? * MON" },
      { "label": "每月 1 号凌晨 3 点", "value": "0 0 3 1 * ?" }
    ]
  }
}
```

### 12.2 统一 configMeta 字段规范

所有 27 种类型共用的 configMeta 字段：

| 字段 | 类型 | 适用 | 说明 |
|------|------|------|------|
| `label` | string | **全部** | 配置项的中文标签 |
| `uiType` | string | **全部** | 显式声明控件类型，覆盖值推断 |
| `placeholder` | string | text/textarea/url/email/phone | 输入框占位提示 |
| `tips` | string | **全部** | 配置项下方的灰色提示文字 |
| `required` | boolean | **全部** | 是否必填 |
| `disabled` | boolean | **全部** | 是否禁用编辑 |
| `default` | any | **全部** | 默认值（参见 13.3 节） |
| `rules` | object | **全部** | 校验规则（参见 13.2 节） |
| `visible` | object | **全部** | 联动显示条件（参见 13.1 节） |

各类型专属字段：

| 字段 | 适用类型 | 说明 |
|------|---------|------|
| `options` | select/multi-select/radio-group/radio-bool | 选项列表 |
| `treeData` | tree-select | 树形数据 |
| `min`/`max` | number/slider/amount | 数值范围 |
| `precision` | number/amount | 小数位数 |
| `integer` | number | 是否仅整数 |
| `step` | slider | 滑块步长 |
| `marks` | slider | 滑块刻度标记 |
| `unit` | number/amount | 单位显示（如"分"、"%"） |
| `currency` | amount | 货币符号（CNY/USD） |
| `rows` | textarea | 文本区域行数 |
| `maxlength` | text/textarea | 最大字符数 |
| `accept` | image/images/file | 允许的文件格式 |
| `maxSize` | image/images/file | 最大文件大小(MB) |
| `maxCount` | images | 最多图片数量 |
| `crop` | image | 裁切形状 |
| `width`/`height` | image | 建议尺寸 |
| `showAlpha` | color | 是否显示透明度 |
| `presets` | color/cron | 预设值列表 |
| `iconSet` | icon | 图标库名称 |
| `toolbar` | richtext | 工具栏模式 |
| `preview` | markdown | 是否显示预览 |
| `confirmText` | confirm-bool | 确认提示文字 |
| `apiUrl` | user-select/role-select | 数据源 API 地址 |
| `multiple` | multi-select/user-select/role-select | 是否多选 |
| `fields` | api-config | 子字段配置 |
| `startPlaceholder`/`endPlaceholder` | date-range | 起止日期占位 |

### 12.3 前端代码扩展方案

`FieldDescriptor` 接口扩展为：

```typescript
interface FieldDescriptor {
  key: string
  label: string
  type: 'bool' | 'string' | 'object' | 'array'
  uiType?: UiType  // 27 种细分类型
  // 通用字段
  placeholder?: string; tips?: string; required?: boolean
  disabled?: boolean; default?: any
  rules?: ValidationRule[]; visible?: VisibilityCondition
  // 选择类字段
  options?: { label: string; value: any }[]
  treeData?: TreeNode[]
  // 数值类字段
  min?: number; max?: number; precision?: number; integer?: boolean
  step?: number; marks?: Record<number, string>
  unit?: string; currency?: string
  // 文本类字段
  rows?: number; maxlength?: number
  // 文件类字段
  accept?: string; maxSize?: number; maxCount?: number
  crop?: 'circle' | 'square' | null
  width?: number; height?: number
  // 颜色类字段
  showAlpha?: boolean; presets?: string[]
  // 图标类字段
  iconSet?: string
  // 富文本类字段
  toolbar?: 'basic' | 'full'; height?: number; preview?: boolean
  // 业务类字段
  apiUrl?: string; multiple?: boolean
  fields?: Record<string, FieldDescriptor>
  startPlaceholder?: string; endPlaceholder?: string
  confirmText?: string
  // 子字段
  children?: FieldDescriptor[]
  itemFields?: FieldDescriptor[]
}

type UiType =
  // 布尔
  | 'switch' | 'radio-bool' | 'confirm-bool'
  // 字符串
  | 'text' | 'textarea' | 'password' | 'url' | 'email' | 'phone'
  | 'textarea-array'
  // 数字
  | 'number' | 'slider' | 'amount'
  // 枚举选择
  | 'select' | 'multi-select' | 'radio-group' | 'tree-select'
  // 媒体文件
  | 'image' | 'images' | 'file' | 'color' | 'gradient-color' | 'icon'
  // 富文本/时间
  | 'richtext' | 'markdown' | 'date' | 'datetime' | 'date-range'
  // 业务关联
  | 'user-select' | 'role-select' | 'api-config' | 'template-select' | 'cron'
```

---

## 13. 配套功能（联动/校验/默认值/导入导出/分组折叠）

完整的配置系统需要以下 5 项配套能力来解决复杂的多类型联动需求。

### 13.1 配置联动显示

根据布尔开关或枚举值，动态隐藏/展示其他配置项。

**configMeta 声明方式**：

```json
{
  "configMeta": {
    "enableAdvanced": { "label": "高级模式" },
    "advancedSettings": {
      "label": "高级设置",
      "visible": {
        "dependsOn": "enableAdvanced",
        "condition": "eq",
        "value": true
      },
      "childrenMeta": {
        "cacheTime": { "label": "缓存时间", "uiType": "number" },
        "debugMode": { "label": "调试模式" }
      }
    },
    "notifyChannel": {
      "label": "通知渠道",
      "uiType": "select",
      "options": [
        { "label": "不通知", "value": "none" },
        { "label": "站内信", "value": "internal" },
        { "label": "短信", "value": "sms" }
      ]
    },
    "smsTemplate": {
      "label": "短信模板",
      "uiType": "text",
      "visible": {
        "dependsOn": "notifyChannel",
        "condition": "in",
        "value": ["sms", "both"]
      }
    }
  }
}
```

**联动条件运算符**：

| condition | 说明 | 示例 |
|-----------|------|------|
| `eq` | 等于 | `{ "dependsOn":"show", "condition":"eq", "value":true }` |
| `neq` | 不等于 | `{ "dependsOn":"type", "condition":"neq", "value":"disabled" }` |
| `in` | 在数组中 | `{ "dependsOn":"mode", "condition":"in", "value":["a","b"] }` |
| `gt`/`gte` | 大于/大于等于 | `{ "dependsOn":"count", "condition":"gt", "value":0 }` |
| `lt`/`lte` | 小于/小于等于 | `{ "dependsOn":"percent", "condition":"lt", "value":100 }` |

**前端实现逻辑**：

```typescript
function isFieldVisible(field: FieldDescriptor, configData: Record<string, any>): boolean {
  if (!field.visible) return true
  const { dependsOn, condition, value } = field.visible
  const currentVal = configData[dependsOn]

  switch (condition) {
    case 'eq': return currentVal === value
    case 'neq': return currentVal !== value
    case 'in': return Array.isArray(value) && value.includes(currentVal)
    case 'gt': return Number(currentVal) > Number(value)
    case 'gte': return Number(currentVal) >= Number(value)
    case 'lt': return Number(currentVal) < Number(value)
    case 'lte': return Number(currentVal) <= Number(value)
    default: return true
  }
}
```

### 13.2 自定义校验规则

每种类型可自定义正则、数值区间、文件大小等校验规则。

```json
{
  "configMeta": {
    "username": {
      "label": "用户名",
      "uiType": "text",
      "rules": [
        { "type": "required", "message": "用户名不能为空" },
        { "type": "minlength", "value": 3, "message": "至少 3 个字符" },
        { "type": "maxlength", "value": 20, "message": "最多 20 个字符" },
        { "type": "pattern", "value": "^[a-zA-Z0-9_]+$", "message": "只允许字母数字下划线" }
      ]
    },
    "price": {
      "label": "价格",
      "uiType": "amount",
      "rules": [
        { "type": "required", "message": "价格不能为空" },
        { "type": "min", "value": 0.01, "message": "价格不能小于 0.01" },
        { "type": "max", "value": 999999.99, "message": "价格不能超过 999999.99" }
      ]
    },
    "email": {
      "label": "邮箱",
      "uiType": "email",
      "rules": [
        { "type": "required", "message": "邮箱不能为空" },
        { "type": "email", "message": "邮箱格式不正确" }
      ]
    },
    "avatar": {
      "label": "头像",
      "uiType": "image",
      "rules": [
        { "type": "filesize", "value": 2, "message": "图片不能超过 2MB" },
        { "type": "filetype", "value": ["png","jpg","jpeg"], "message": "只允许 PNG/JPG 格式" }
      ]
    },
    "banners": {
      "label": "轮播图",
      "uiType": "images",
      "rules": [
        { "type": "minCount", "value": 1, "message": "至少上传 1 张图片" },
        { "type": "maxCount", "value": 6, "message": "最多上传 6 张图片" }
      ]
    }
  }
}
```

**支持的校验类型**：

| type | 说明 | value 示例 |
|------|------|-----------|
| `required` | 必填 | 无 |
| `minlength` | 最小长度 | `3` |
| `maxlength` | 最大长度 | `50` |
| `min` | 最小值(数字) | `0` |
| `max` | 最大值(数字) | `100` |
| `pattern` | 正则表达式 | `"^[a-z]+$"` |
| `email` | 邮箱格式 | 无 |
| `url` | URL 格式 | 无 |
| `phone` | 手机号格式 | 无 |
| `filesize` | 文件大小(MB) | `5` |
| `filetype` | 文件类型 | `["png","jpg"]` |
| `minCount` | 最少数量(数组) | `1` |
| `maxCount` | 最多数量(数组) | `10` |

**前端校验钩子**：

```typescript
function validateField(field: FieldDescriptor, value: any): string | null {
  if (!field.rules) return null
  for (const rule of field.rules) {
    const msg = rule.message || '校验失败'
    switch (rule.type) {
      case 'required':
        if (value === undefined || value === null || value === '') return msg
        break
      case 'minlength':
        if (typeof value === 'string' && value.length < rule.value) return msg
        break
      case 'maxlength':
        if (typeof value === 'string' && value.length > rule.value) return msg
        break
      case 'min':
        if (Number(value) < rule.value) return msg
        break
      case 'max':
        if (Number(value) > rule.value) return msg
        break
      case 'pattern':
        if (!new RegExp(rule.value).test(String(value))) return msg
        break
      case 'email':
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(value))) return msg
        break
      case 'url':
        try { new URL(String(value)) } catch { return msg }
        break
      default: break
    }
  }
  return null
}

// 保存前校验所有字段
function validateAllConfig(fields: FieldDescriptor[], data: Record<string, any>): string[] {
  const errors: string[] = []
  for (const field of fields) {
    const error = validateField(field, data[field.key])
    if (error) errors.push(`${field.label}: ${error}`)
  }
  return errors
}
```

### 13.3 默认值预设

所有类型支持填写默认配置，当配置值为空或未设置时自动回退。

**声明方式**：

```json
{
  "config": {
    "show": true,
    "theme": "blue",
    "title": "默认标题"
  },
  "configMeta": {
    "show": {
      "label": "显示",
      "default": true
    },
    "theme": {
      "label": "主题",
      "uiType": "select",
      "options": [
        { "label": "蓝色", "value": "blue" },
        { "label": "绿色", "value": "green" }
      ],
      "default": "blue"
    },
    "title": {
      "label": "标题",
      "uiType": "text",
      "default": "默认标题"
    }
  }
}
```

配置编辑器中提供"恢复默认"按钮：

```html
<div class="cfg-row">
  <span class="cfg-label">{{ field.label }}</span>
  <ElInput v-model="configData[field.key]" size="small" class="cfg-input" />
  <ElButton
    v-if="field.default !== undefined && configData[field.key] !== field.default"
    size="small"
    link
    type="warning"
    @click="configData[field.key] = field.default"
  >恢复默认</ElButton>
</div>
```

### 13.4 批量导入导出

支持将配置以 JSON 格式批量导入导出，便于配置迁移和备份。

**插件管理后台增加功能入口**：

```
插件列表 → 操作列 → [导出配置] [导入配置]
```

**导出逻辑**：

```typescript
async function exportConfig(plugin: PluginRecord) {
  const manifest = typeof plugin.manifest === 'string'
    ? JSON.parse(plugin.manifest) : plugin.manifest
  const exportData = {
    pluginName: plugin.name,
    version: plugin.version,
    exportTime: new Date().toISOString(),
    config: manifest.config || {},
    configMeta: manifest.configMeta || {}
  }
  const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = `${plugin.name}-config-${Date.now()}.json`
  a.click()
  URL.revokeObjectURL(url)
}
```

**导入逻辑**：

```typescript
async function importConfig(plugin: PluginRecord, file: File) {
  const text = await file.text()
  const importData = JSON.parse(text)

  // 校验导入数据
  if (!importData.config) {
    throw new Error('导入文件格式不正确：缺少 config 字段')
  }
  if (importData.pluginName !== plugin.name) {
    throw new Error('配置与插件不匹配：插件名不一致')
  }

  // 合并导入的 config 和 configMeta
  const payload: Record<string, any> = { config: importData.config }
  if (importData.configMeta) {
    payload.configMeta = importData.configMeta
  }

  await fetchPluginUpdateConfig(plugin.name, payload)
  ElMessage.success('配置导入成功')
}
```

### 13.5 分组折叠面板

当插件配置项较多时（超过 10 个顶级字段），按业务模块分组折叠。

```json
{
  "name": "advanced-plugin",
  "version": "1.0.0",
  "config": {
    "basic": {
      "enabled": true,
      "title": "插件标题"
    },
    "appearance": {
      "theme": "blue",
      "primaryColor": "#409EFF",
      "fontSize": 14
    },
    "advanced": {
      "cacheEnabled": false,
      "cacheTime": 3600,
      "debugMode": false
    }
  },
  "configMeta": {
    "basic": {
      "label": "基础设置",
      "collapsible": true,
      "collapsed": false,
      "childrenMeta": {
        "enabled": { "label": "启用" },
        "title": { "label": "标题" }
      }
    },
    "appearance": {
      "label": "外观设置",
      "collapsible": true,
      "collapsed": false,
      "childrenMeta": {
        "theme": { "label": "主题", "uiType": "select", "options": [...] },
        "primaryColor": { "label": "主色调", "uiType": "color" },
        "fontSize": { "label": "字号", "uiType": "number", "min": 12, "max": 24 }
      }
    },
    "advanced": {
      "label": "高级设置",
      "collapsible": true,
      "collapsed": true,
      "childrenMeta": {
        "cacheEnabled": { "label": "启用缓存" },
        "cacheTime": { "label": "缓存时间(秒)", "uiType": "number" },
        "debugMode": { "label": "调试模式" }
      }
    }
  }
}
```

**关键字段**：

| 字段 | 默认值 | 说明 |
|------|-------|------|
| `collapsible` | `false` | 是否可折叠 |
| `collapsed` | `false` | 默认是否折叠 |

**前端渲染逻辑**：

```typescript
// object 类型分支，增加折叠处理
<template v-else-if="field.type === 'object' && field.collapsible">
  <ElCollapse v-model="collapsedGroups">
    <ElCollapseItem :title="field.label" :name="field.key">
      <template v-for="sf in field.children" :key="sf.key">
        <!-- 子字段渲染同前 -->
      </template>
    </ElCollapseItem>
  </ElCollapse>
</template>
```

如果配置顶级字段超过 10 个且未分组，系统应自动建议使用折叠分组：

```
提示：当前插件有 15 个配置项，建议在 configMeta 中为 object 字段添加
"collapsible": true 以启用分组折叠，提升管理体验。
```

---

## 14. 后端扩展机制完整体系

### 14.1 总览与架构

插件系统提供 **7 大类 46 种扩展机制**，覆盖从 HTTP 请求到数据库、从事件到 UI、从定时任务到权限安全的完整扩展面。

| 大类 | 数量 | 核心能力 |
|------|------|---------|
| HTTP 层扩展 | 6 | 中间件、拦截器、响应改写、静态资源、CORS |
| 数据库层扩展 | 4 | 新建表、修改旧表、查询钩子、事务钩子 |
| 事件系统 | 12 | 用户/内容/系统三级事件监听 |
| UI 前端注入点 | 8 | 命名插槽、菜单、仪表盘、Tab、批量操作 |
| 服务层扩展 | 5 | 服务替换/装饰、验证器、通知、支付 |
| 调度与任务 | 3 | Cron、队列、延迟任务 |
| 国际化与资源 | 3 | 翻译、邮件模板、静态资源打包 |
| 权限与安全 | 4 | 权限节点、角色扩展、登录方式、验证码 |
| 插件间交互 | 3 | 依赖声明、暴露 API、共享数据 |

**扩展上下文对象（PluginContext）**：

```typescript
interface PluginContext {
  // 核心实例
  app       : Express.Application
  db        : Database.Database
  router    : Express.Router            // 自动创建的独立 Router

  // 扩展能力
  events    : EventBus                  // 事件总线
  scheduler : Scheduler                 // 任务调度器
  menus     : MenuRegistry              // 菜单注册
  slots     : SlotRegistry              // UI 插槽注册
  perms     : PermissionRegistry        // 权限节点注册
  services  : ServiceRegistry           // 服务注册表
  i18n      : I18nRegistry              // 多语言注册
  mail      : MailTemplateRegistry      // 邮件模板
  notify    : NotifyChannelRegistry     // 通知通道

  // 插件信息
  pluginConfig : PluginManifest
  pluginDir    : string
  pluginId     : number
  logger       : PluginLogger
  cache        : PluginCache            // 插件专属缓存
}
```

### 14.2 HTTP 层扩展（6 种）

这是最基础的扩展能力——插件可以介入 HTTP 请求的全生命周期。

#### 14.2.1 路由中间件注入

在已有路由之前/之后插入中间件，修改请求或拦截响应。回到"话题管理插件"的例子：版主删帖需要先检查版主身份。

```javascript
// server.js
module.exports = function(ctx) {
  const { app, db, logger } = ctx

  // 在 /api/community/post/:id 路由之前插入版主权限检查
  app.use('/api/community/post/:id', (req, res, next) => {
    if (req.method === 'DELETE') {
      const userId = getUserIdFromToken(req)
      const postId = req.params.id

      // 查询该帖子的版主
      const isModerator = db.prepare(
        'SELECT 1 FROM topic_moderators tm JOIN community_posts p ON p.topic_id = tm.topic_id WHERE p.id = ? AND tm.user_id = ?'
      ).get(postId, userId)

      if (isModerator) return next()  // 版主放行
      return res.json({ code: 403, msg: '只有版主可以删除此帖' })
    }
    next()
  })
}
```

#### 14.2.2 请求/响应拦截器

对所有请求或指定路径的请求进行预处理/后处理：

```javascript
// 请求拦截器：为所有 API 请求注入请求ID
app.use((req, res, next) => {
  req.pluginRequestId = `${ctx.pluginConfig.name}-${Date.now()}`
  next()
})

// 响应拦截器：统一包装响应数据
const originalJson = res.json.bind(res)
res.json = function(data) {
  if (data && data.code === 200) {
    data._plugin = ctx.pluginConfig.name   // 标记由哪个插件处理
    data._serverTime = Date.now()
  }
  return originalJson(data)
}
```

#### 14.2.3 全局错误处理器

```javascript
app.use((err, req, res, next) => {
  logger.error('插件捕获到错误:', err.message)
  if (err.type === 'plugin-validation') {
    return res.status(422).json({ code: 422, msg: err.message })
  }
  next(err)  // 非插件错误继续抛出
})
```

#### 14.2.4 响应数据后处理

在 JSON 响应发送前统一修改数据结构：

```javascript
ctx.events.on('response:beforeSend', ({ req, data }) => {
  // 为帖子列表自动附加版主标记
  if (req.path === '/api/community/posts' && Array.isArray(data?.data)) {
    const userId = getUserIdFromToken(req)
    data.data = data.data.map(post => ({
      ...post,
      isPostModerator: checkModerator(post.topicId, userId)
    }))
  }
})
```

#### 14.2.5 静态资源服务

插件可以将自己的静态文件（图片、字体、前端页面）暴露为 HTTP 可访问：

```javascript
const path = require('path')
app.use('/plugin-assets/' + ctx.pluginConfig.name,
  express.static(path.join(ctx.pluginDir, 'public')))
```

在 `plugin.json` 中声明：

```json
{ "extends": { "serveStatic": { "path": "public", "urlPrefix": "/plugin-assets/account-switcher" } } }
```

#### 14.2.6 自定义认证提供者

扩展登录方式，例如"账号存储插件"中切换已保存的账号：

```javascript
// 注册自定义认证策略
ctx.services.register('auth:strategy', {
  name: 'stored-account',
  // 验证已存储账号的 token
  async authenticate(token) {
    const account = db.prepare(
      'SELECT * FROM stored_accounts WHERE token = ? AND expires_at > datetime("now")'
    ).get(token)
    if (!account) return null
    return { userId: account.user_id, username: account.username }
  },
  // 刷新 token
  async refresh(oldToken) { /* ... */ }
})
```

### 14.3 数据库层扩展（4 种）

#### 14.3.1 新建独立表（已有能力，保留）

插件通过 `migrations/` SQL 文件创建自己的表，安装时自动执行。

```
migrations/
  001_initial.sql     -- CREATE TABLE IF NOT EXISTS ...
  002_add_columns.sql -- ALTER TABLE ... ADD COLUMN ...
```

在 `plugin.json` 中声明：

```json
{ "extends": { "migrations": ["migrations/001_initial.sql", "migrations/002_add_columns.sql"] } }
```

#### 14.3.2 修改已有表结构（新增）

插件可以声明对**系统已有表**的 `ALTER TABLE` 迁移：

```json
{
  "extends": {
    "alterTables": {
      "users": [
        "ALTER TABLE users ADD COLUMN stored_account_count INTEGER DEFAULT 0",
        "ALTER TABLE users ADD COLUMN max_stored_accounts INTEGER DEFAULT 3"
      ],
      "community_posts": [
        "ALTER TABLE community_posts ADD COLUMN moderator_note TEXT DEFAULT ''"
      ]
    }
  }
}
```

后端执行逻辑：

```javascript
// plugins.cjs — 安装插件时
if (manifest.extends?.alterTables) {
  for (const [tableName, statements] of Object.entries(manifest.extends.alterTables)) {
    for (const sql of statements) {
      try {
        db.exec(sql)
      } catch (e) {
        // SQLite: 字段已存在时静默跳过
        if (!e.message.includes('duplicate column')) throw e
      }
    }
  }
}
```

**卸载时回滚声明**：

```json
{
  "extends": {
    "alterTables": {
      "users": [
        { "install": "ALTER TABLE users ADD COLUMN max_stored_accounts INTEGER DEFAULT 3",
          "uninstall": "ALTER TABLE users DROP COLUMN max_stored_accounts" }
      ]
    }
  }
}
```

#### 14.3.3 查询拦截器（Query Interceptor）

在已有 SQL 查询执行前注入额外的 WHERE 条件或 JOIN：

```javascript
ctx.events.on('db:beforeQuery', ({ table, sql, params, context }) => {
  // 账号存储插件：查询用户列表时追加存储账号统计
  if (table === 'users' && context === 'list') {
    return {
      sql: sql.replace('SELECT ', 'SELECT (SELECT COUNT(*) FROM stored_accounts WHERE user_id = u.id) as account_count, '),
      params
    }
  }
})
```

#### 14.3.4 事务钩子

在数据库事务前后执行逻辑：

```javascript
ctx.events.on('db:beforeCommit', ({ changes }) => {
  // 检测到帖子被删除 → 自动清理版主指派记录
  if (changes.posts?.deleted?.length) {
    const postIds = changes.posts.deleted.map(p => p.id)
    db.prepare('DELETE FROM topic_moderators WHERE post_id IN (?)').run(postIds)
  }
})

ctx.events.on('db:afterRollback', ({ error }) => {
  logger.warn('事务回滚:', error.message)
})
```

### 14.4 事件系统（12 个事件）

插件可以监听系统发出的各种事件，分为三类：用户事件、内容事件、系统事件。

#### 14.4.1 用户事件

| 事件名 | 触发时机 | payload |
|--------|---------|---------|
| `user:beforeLogin` | 登录验证前 | `{ username, password, ip }` |
| `user:afterLogin` | 登录成功后 | `{ userId, username, token, ip, time }` |
| `user:beforeRegister` | 注册前 | `{ username, email, ip }` |
| `user:afterRegister` | 注册成功后 | `{ userId, username, email }` |
| `user:profileUpdate` | 个人资料更新后 | `{ userId, changes: { field, oldVal, newVal } }` |
| `user:beforeDelete` | 删除用户前 | `{ userId, username }` |
| `user:afterDelete` | 删除用户后 | `{ userId }` |

```javascript
// 账号存储插件：用户注册后自动创建存储槽位
ctx.events.on('user:afterRegister', ({ userId }) => {
  const maxAccounts = ctx.pluginConfig.config.maxAccountsPerUser || 3
  db.prepare('UPDATE users SET max_stored_accounts = ? WHERE id = ?').run(maxAccounts, userId)
  logger.info(`用户 ${userId} 的账号存储槽位已初始化，上限: ${maxAccounts}`)
})

// 用户登录时记录登录历史
ctx.events.on('user:afterLogin', ({ userId, ip, time }) => {
  db.prepare(
    'INSERT INTO login_history (user_id, ip, login_time) VALUES (?,?,?)'
  ).run(userId, ip, time)
})
```

#### 14.4.2 内容事件

| 事件名 | 触发时机 | payload |
|--------|---------|---------|
| `post:beforeCreate` | 发帖前 | `{ topicId, userId, title, content }` |
| `post:afterCreate` | 发帖成功后 | `{ postId, topicId, userId, title }` |
| `post:beforeUpdate` | 编辑帖子前 | `{ postId, changes }` |
| `post:afterUpdate` | 编辑帖子后 | `{ postId, changes }` |
| `post:beforeDelete` | 删帖前 | `{ postId, userId, topicId }` |
| `post:afterDelete` | 删帖后 | `{ postId, topicId }` |
| `comment:beforeCreate` | 评论前 | `{ postId, userId, content }` |
| `comment:afterCreate` | 评论后 | `{ commentId, postId, userId }` |

```javascript
// 话题管理插件：帖子创建后自动分配版主（如果配置了）
ctx.events.on('post:afterCreate', ({ postId, topicId }) => {
  const autoMod = ctx.pluginConfig.config.autoAssignModerator
  if (!autoMod) return

  const existing = db.prepare(
    'SELECT 1 FROM topic_moderators WHERE topic_id = ?'
  ).get(topicId)
  if (!existing) {
    const topic = db.prepare('SELECT created_by FROM community_topics WHERE id = ?').get(topicId)
    if (topic) {
      db.prepare('INSERT INTO topic_moderators (topic_id, user_id) VALUES (?,?)').run(topicId, topicId.created_by)
    }
  }
})

// 删帖时检查版主权限（事件可中断操作）
ctx.events.on('post:beforeDelete', ({ postId, userId, topicId }) => {
  const post = db.prepare('SELECT user_id FROM community_posts WHERE id = ?').get(postId)
  const isModerator = db.prepare(
    'SELECT 1 FROM topic_moderators WHERE topic_id = ? AND user_id = ?'
  ).get(topicId, userId)

  // 非作者也非版主 → 拒绝
  if (post.user_id !== userId && !isModerator) {
    throw new PluginError('只有作者或版主可以删除帖子', 403)
  }
})

// 事件抛出的 PluginError 会被框架捕获并返回对应的 HTTP 状态码
class PluginError extends Error {
  constructor(message, statusCode = 400) {
    super(message)
    this.statusCode = statusCode
  }
}
```

#### 14.4.3 系统事件

| 事件名 | 触发时机 | payload |
|--------|---------|---------|
| `system:boot` | 服务启动完成 | `{ port, startTime }` |
| `system:beforeShutdown` | 服务关闭前 | `{ signal }` |
| `system:configChange` | 任意插件配置变更 | `{ pluginName, oldConfig, newConfig }` |
| `system:cronTick` | 定时任务触发 | `{ jobName, scheduledTime }` |
| `system:pluginEnabled` | 插件被启用 | `{ pluginName }` |
| `system:pluginDisabled` | 插件被禁用 | `{ pluginName }` |

```javascript
ctx.events.on('system:boot', ({ port }) => {
  // 服务启动后立即执行一次缓存预热
  refreshModeratorCache()
  logger.info(`缓存已预热，端口: ${port}`)
})

ctx.events.on('system:beforeShutdown', ({ signal }) => {
  // 优雅关闭：保存缓存到文件
  saveModeratorCacheToFile()
  logger.info(`收到 ${signal} 信号，缓存已持久化`)
})
```

### 14.5 UI/前端注入点（8 种）

插件不仅可以在浏览器中注入任意位置，还可以使用**命名插槽**将 UI 注入到预定义的页面区域，并注册后台菜单、仪表盘小组件等。

#### 14.5.1 页面命名插槽

系统前端预留命名插槽，插件可以通过 `plugin.json` 声明注入位置：

```json
{
  "frontend": {
    "slots": {
      "user:profile:afterAvatar": {
        "script": "scripts/profile-slot.js",
        "mount": "#user-profile-section"
      },
      "community:postDetail:toolbar": {
        "script": "scripts/moderator-toolbar.js"
      },
      "admin:dashboard:widgets": {
        "script": "scripts/admin-widget.js",
        "style": "styles/admin-widget.css"
      }
    }
  }
}
```

**系统预设插槽列表**：

| 插槽名 | 位置描述 | 你的场景 |
|--------|---------|---------|
| `user:avatar:after` | 头像旁边 | 账号存储插件：显示"N个已存账号" |
| `user:dropdown:beforeLogout` | 下拉菜单退出前 | 账号存储插件：切换账号入口 |
| `user:profile:stats` | 个人主页统计区 | 显示账号存储数量 |
| `community:postList:beforeItem` | 帖子列表每项前面 | 显示版主标识 |
| `community:postDetail:toolbar` | 帖子详情工具栏 | 版主管理按钮 |
| `community:topicHeader:actions` | 话题页头操作区 | 设置版主按钮 |
| `admin:dashboard:widgets` | 仪表盘小组件区 | 存储统计图表 |
| `admin:sidebar:bottom` | 后台侧边栏底部 | 自定义管理入口 |

实现方式——插槽脚本接收上下文：

```javascript
// scripts/profile-slot.js
// 系统会将 slotContext 注入到全局
(function() {
  const ctx = window.__PLUGIN_SLOT_CONTEXT__ // { slotName, pluginConfig, currentRoute, currentUser }
  const count = ctx.pluginConfig._runtime?.accountCount || 0

  const badge = document.createElement('span')
  badge.className = 'ps-account-badge'
  badge.textContent = count
  badge.title = `${count} 个已存账号`

  const avatar = document.querySelector(ctx.mount || '#user-avatar')
  if (avatar) avatar.parentNode.appendChild(badge)
})()
```

#### 14.5.2 后台菜单注册

```javascript
ctx.menus.register({
  // 后台侧边栏
  adminSidebar: [
    {
      label: '账号管理',
      icon: 'user',
      path: '/admin/accounts',
      permission: 'plugin:account-switcher:view',
      children: [
        { label: '存储记录', path: '/admin/accounts/records' },
        { label: '存储设置', path: '/admin/accounts/settings' }
      ]
    }
  ],
  // 用户个人菜单
  userDropdown: [
    { label: '切换账号', action: 'openAccountSwitcher', order: 50 },
    { label: '账号管理', path: '/user/accounts/manage', order: 51 }
  ]
})
```

#### 14.5.3 仪表盘小组件

```javascript
ctx.menus.registerDashboardWidget({
  id: 'account-stats',
  title: '账号存储统计',
  size: 'medium',     // small | medium | large | full
  order: 10,
  script: 'scripts/dashboard-widget.js',
  refreshInterval: 30000  // 30秒自动刷新
})
```

#### 14.5.4 表单字段注册

插件可以注册自定义表单字段类型，在后台的任意表单中使用：

```javascript
ctx.services.registerFormField('stored-account-picker', {
  component: 'scripts/fields/account-picker.vue',  // Vue SFC 组件
  props: { multiple: false, maxCount: 3 },
  defaultValue: null
})
```

#### 14.5.5 列表批量操作注册

```javascript
ctx.menus.registerBatchAction('community:postList', {
  label: '批量设为版主',
  icon: 'shield',
  permission: 'plugin:topic-moderator:assign',
  async handler(selectedIds) {
    for (const postId of selectedIds) {
      const post = db.prepare('SELECT topic_id FROM community_posts WHERE id = ?').get(postId)
      if (post) {
        db.prepare('INSERT OR IGNORE INTO topic_moderators (topic_id, user_id) SELECT topic_id, user_id FROM community_posts WHERE id = ?').run(postId)
      }
    }
    return { success: true, msg: `已设置 ${selectedIds.length} 个版主` }
  }
})
```

#### 14.5.6 详情页 Tab 扩展

```javascript
ctx.menus.registerDetailTab('community:postDetail', {
  label: '管理日志',
  key: 'mod-log',
  order: 99,
  script: 'scripts/mod-log-tab.js',
  visible: (post) => {
    return ctx.pluginConfig.config.showModLog &&
      db.prepare('SELECT 1 FROM topic_moderators WHERE user_id = ? AND topic_id = ?').get(post.userId, post.topicId)
  }
})
```

#### 14.5.7 全局 CSS 变量注入

```javascript
// server.js 中通过 ctx 注册全局 CSS 变量
ctx.slots.injectStyle(`
  :root {
    --plugin-account-badge-bg: ${ctx.pluginConfig.config.badgeColor || '#F56C6C'};
    --plugin-account-badge-size: 18px;
  }
`)
```

#### 14.5.8 路由钩子

```javascript
// 监听前端路由变化，触发插件逻辑
ctx.events.on('router:changed', ({ to, from }) => {
  if (to.path === '/community/post/:id') {
    // 进入帖子详情页时，预加载版主信息
    const postId = to.params.id
    const moderatorInfo = fetchModeratorInfo(postId)
    window.__PLUGIN_RUNTIME__ = { moderatorInfo }
  }
})
```

### 14.6 服务层扩展（5 种）

#### 14.6.1 服务替换（Service Override）

用自定义实现替换系统原有服务：

```javascript
// 替换图片上传服务为自定义的水印版本
ctx.services.override('upload:image', {
  async upload(file, options) {
    const original = await ctx.services.callOriginal('upload:image', file, options)
    // 添加水印
    const watermarked = await addWatermark(original.url, ctx.pluginConfig.config.watermarkText)
    return { ...original, url: watermarked }
  }
})
```

#### 14.6.2 服务装饰（Service Decorator）

在已有服务前后插入逻辑：

```javascript
ctx.services.decorate('user:getProfile', {
  async after(result, { userId }) {
    // 账号存储插件：用户资料中附加已存账号数量
    const count = db.prepare(
      'SELECT COUNT(*) as cnt FROM stored_accounts WHERE user_id = ?'
    ).get(userId)?.cnt || 0
    return { ...result, storedAccountCount: count, maxStoredAccounts: ctx.pluginConfig.config.maxAccountsPerUser }
  }
})
```

#### 14.6.3 自定义验证器

```javascript
ctx.services.registerValidator('stored-account-limit', {
  async validate(userId) {
    const count = db.prepare(
      'SELECT COUNT(*) as cnt FROM stored_accounts WHERE user_id = ?'
    ).get(userId)?.cnt || 0
    const max = ctx.pluginConfig.config.maxAccountsPerUser || 3
    if (count >= max) {
      return { valid: false, message: `最多存储 ${max} 个账号，当前已有 ${count} 个` }
    }
    return { valid: true }
  }
})
```

#### 14.6.4 通知通道注册

```javascript
ctx.notify.registerChannel({
  name: 'account-stored',
  label: '账号存储通知',
  async send({ userId, title, content, data }) {
    // 自定义通知逻辑：站内信 + 标记
    db.prepare(
      'INSERT INTO notifications (user_id, title, content, type, data) VALUES (?,?,?,?,?)'
    ).run(userId, title, content, 'plugin:account', JSON.stringify(data))
    return { sent: true, channel: 'internal' }
  }
})
```

#### 14.6.5 支付网关注册

```javascript
ctx.services.registerPaymentGateway({
  name: 'custom-gateway',
  label: '自定义支付',
  async createOrder({ amount, description, metadata }) {
    // 对接第三方支付 API
    const order = await thirdPartyAPI.createOrder({ amount, description })
    return { orderId: order.id, payUrl: order.pay_url }
  },
  async verifyPayment(orderId) {
    const result = await thirdPartyAPI.queryOrder(orderId)
    return { paid: result.status === 'SUCCESS', transactionId: result.transaction_id }
  },
  async refund(orderId, amount) { /* ... */ }
})
```

### 14.7 调度与任务（3 种）

#### 14.7.1 Cron 定时任务

```javascript
// 在 server.js 中注册
ctx.scheduler.registerCron({
  name: 'clean-expired-accounts',
  cron: '0 3 * * *',               // 每天凌晨 3 点
  timezone: 'Asia/Shanghai',
  async run() {
    // 清理已过期的存储账号 token
    const result = db.prepare(
      'DELETE FROM stored_accounts WHERE expires_at < datetime("now")'
    ).run()
    logger.info(`已清理 ${result.changes} 个过期存储账号`)
  }
})
```

也支持在 `plugin.json` 中声明：

```json
{
  "extends": {
    "cronJobs": [
      {
        "name": "auto-backup-accounts",
        "cron": "0 */6 * * *",
        "handler": "scripts/cron/backup.js"
      }
    ]
  }
}
```

#### 14.7.2 队列任务

```javascript
// 注册一个队列任务处理器
ctx.scheduler.registerQueue('account-bulk-import', {
  concurrency: 3,
  async process(job) {
    const { accounts } = job.data
    for (const account of accounts) {
      db.prepare(
        'INSERT OR IGNORE INTO stored_accounts (user_id, username, token, expires_at) VALUES (?,?,?,?)'
      ).run(job.userId, account.username, account.token, account.expiresAt)
    }
    return { imported: accounts.length }
  }
})

// 向队列提交任务
ctx.scheduler.enqueue('account-bulk-import', {
  userId: 1,
  accounts: [{ username: 'user1', token: 'xxx' }, { username: 'user2', token: 'yyy' }]
})
```

#### 14.7.3 延迟任务

```javascript
// 5 分钟后执行
ctx.scheduler.schedule({
  name: 'send-account-reminder',
  delay: 5 * 60 * 1000,
  async run() {
    // 提醒用户账号即将过期
    const expiringAccounts = db.prepare(
      "SELECT * FROM stored_accounts WHERE expires_at < datetime('now', '+1 day')"
    ).all()
    for (const acc of expiringAccounts) {
      await sendExpiryReminder(acc.user_id, acc.username)
    }
  }
})
```

### 14.8 国际化与资源（3 种）

#### 14.8.1 翻译文件注册

```
my-plugin/
  i18n/
    zh-CN.json
    en-US.json
    ja-JP.json
```

```json
// i18n/zh-CN.json
{
  "accountSwitcher.title": "切换账号",
  "accountSwitcher.stored": "已存 {count} 个账号",
  "accountSwitcher.maxReached": "已达上限",
  "topicModerator.assign": "设为版主",
  "topicModerator.remove": "取消版主"
}
```

在 `plugin.json` 中声明：

```json
{
  "extends": {
    "i18n": {
      "dir": "i18n",
      "defaultLocale": "zh-CN"
    }
  }
}
```

在前端脚本中使用：

```javascript
const t = window.__PLUGIN_I18N__['account-switcher']
el.textContent = t('accountSwitcher.stored', { count: 3 })
// → "已存 3 个账号"
```

#### 14.8.2 邮件模板注册

```
my-plugin/
  emails/
    account-expiry/
      zh-CN.html
      en-US.html
```

```html
<!-- emails/account-expiry/zh-CN.html -->
<h2>账号即将过期</h2>
<p>{{username}} 的存储账号将于 {{expiryDate}} 过期，请及时续期。</p>
```

```javascript
ctx.mail.registerTemplate('account-expiry', {
  dir: 'emails/account-expiry',
  subject: { 'zh-CN': '账号即将过期提醒', 'en-US': 'Account Expiry Reminder' },
  defaults: { expiryDate: '--' }
})

// 发送邮件
await ctx.mail.send('account-expiry', {
  to: 'user@example.com',
  locale: 'zh-CN',
  data: { username: '张三', expiryDate: '2026-08-01' }
})
```

#### 14.8.3 静态资源打包

插件的图片、字体等静态资源可在上传时自动处理：

```json
{
  "extends": {
    "assets": {
      "dir": "assets",
      "serveAt": "/plugin-assets/account-switcher"
    }
  }
}
```

前端引用：

```html
<img src="/plugin-assets/account-switcher/icons/switch.svg" />
```

### 14.9 权限与安全（4 种）

#### 14.9.1 自定义权限节点

```javascript
ctx.perms.register([
  {
    node: 'plugin:account-switcher:view',
    label: '查看账号存储',
    group: '账号存储插件',
    defaultRoles: ['user', 'admin']
  },
  {
    node: 'plugin:account-switcher:manage',
    label: '管理存储账号',
    group: '账号存储插件',
    defaultRoles: ['admin']
  },
  {
    node: 'plugin:topic-moderator:assign',
    label: '分配版主',
    group: '话题管理插件',
    defaultRoles: ['admin']
  },
  {
    node: 'plugin:topic-moderator:deletePost',
    label: '以版主身份删帖',
    group: '话题管理插件',
    defaultRoles: ['admin'],
    inheritFrom: ['plugin:topic-moderator:assign']
  }
])

// 在路由中使用权限守卫
router.delete('/moderator/:topicId/:userId', ctx.perms.guard('plugin:topic-moderator:assign'), (req, res) => {
  // 只有有权限的用户才能执行
})
```

#### 14.9.2 角色能力扩展

为已有角色添加插件定义的能力：

```javascript
ctx.perms.extendRole('user', {
  canStoreAccounts: true,
  maxStoredAccounts: 3
})

ctx.perms.extendRole('vip', {
  maxStoredAccounts: 10
})
```

#### 14.9.3 登录方式扩展

插件可以注册新的登录/认证方式：

```javascript
ctx.services.registerAuthMethod({
  name: 'stored-account-login',
  label: '已存账号一键登录',
  async login({ storedAccountId, userId }) {
    const account = db.prepare(
      'SELECT * FROM stored_accounts WHERE id = ? AND user_id = ? AND expires_at > datetime("now")'
    ).get(storedAccountId, userId)
    if (!account) throw new Error('账号不存在或已过期')
    // 生成新的登录 token
    const token = generateToken({ userId: account.target_user_id, username: account.username })
    return { token, userId: account.target_user_id, username: account.username }
  }
})
```

#### 14.9.4 验证码/2FA 扩展

```javascript
ctx.services.registerCaptchaProvider({
  name: 'custom-slider',
  label: '滑块验证',
  async generate() {
    return { captchaId: 'xxx', imageUrl: '/plugin-assets/slider-captcha/bg.png' }
  },
  async verify(captchaId, solution) {
    return solution.x > 200  // 滑块位置验证
  }
})
```

### 14.10 插件间交互（3 种）

#### 14.10.1 依赖声明

```json
{
  "extends": {
    "dependsOn": {
      "feature-panel": ">=1.0.0",
      "user-profile": "^2.0.0"
    }
  }
}
```

安装时检查依赖是否满足，不满足则拒绝安装并提示缺少哪些插件。

#### 14.10.2 暴露 API 给其他插件

```javascript
// 账号存储插件暴露 API
module.exports.exposeAPI = {
  // 查询用户已存账号数量
  getStoredAccountCount(userId) {
    return db.prepare(
      'SELECT COUNT(*) as cnt FROM stored_accounts WHERE user_id = ?'
    ).get(userId)?.cnt || 0
  },
  // 检查是否达到存储上限
  canStoreMore(userId) {
    const count = this.getStoredAccountCount(userId)
    return count < (ctx.pluginConfig.config.maxAccountsPerUser || 3)
  }
}
```

其他插件通过 `ctx.services.callPlugin('account-switcher', 'getStoredAccountCount', userId)` 调用。

#### 14.10.3 共享数据存储

```javascript
// 写入共享数据（跨插件可读）
ctx.services.setShared('lastLoginTime', Date.now())

// 其他插件读取
const lastLogin = ctx.services.getShared('lastLoginTime')
```

### 14.11 完整 context 对象 API 参考

```typescript
interface PluginContext {
  // ===== 核心实例 =====
  app       : Express.Application          // Express 实例
  db        : Database.Database            // 数据库实例
  router    : Express.Router               // 插件专属 Router

  // ===== 扩展注册表 =====
  events    : {
    on(event, handler)                     // 监听事件
    off(event, handler)                    // 取消监听
    emit(event, payload)                   // 触发事件
    once(event, handler)                   // 单次监听
  }
  scheduler : {
    registerCron(opts)                     // 注册定时任务
    registerQueue(name, opts)              // 注册队列
    enqueue(name, data)                    // 入队
    schedule(opts)                         // 延迟任务
  }
  menus     : {
    register(menus)                        // 注册菜单
    registerBatchAction(scope, action)     // 批量操作
    registerDetailTab(scope, tab)          // 详情 Tab
    registerDashboardWidget(widget)        // 仪表盘
    update(name, changes)                  // 动态更新菜单
    remove(name)                           // 移除菜单
  }
  slots     : {
    injectStyle(css)                       // 注入全局 CSS
    render(name, data?)                    // 渲染命名插槽
  }
  perms     : {
    register(nodes)                        // 注册权限节点
    guard(node)                            // 权限守卫中间件
    extendRole(role, capabilities)         // 扩展角色
    hasPermission(userId, node)            // 检查权限
  }
  services  : {
    register(name, impl)                   // 注册服务
    override(name, impl)                   // 替换服务
    decorate(name, decorator)              // 装饰服务
    callOriginal(name, ...args)            // 调用原始服务
    callPlugin(name, method, ...args)      // 调用其他插件 API
    setShared(key, value)                  // 写共享数据
    getShared(key)                         // 读共享数据
    registerFormField(name, component)     // 表单字段
    registerValidator(name, impl)          // 验证器
    registerPaymentGateway(gw)             // 支付网关
    registerAuthMethod(method)             // 认证方式
    registerCaptchaProvider(provider)      // 验证码
  }
  i18n      : {
    t(key, params?)                        // 翻译
    setLocale(locale)                      // 切换语言
  }
  mail      : {
    registerTemplate(name, opts)           // 邮件模板
    send(template, opts)                   // 发送邮件
  }
  notify    : {
    registerChannel(channel)               // 通知通道
    send(channel, opts)                    // 发送通知
  }

  // ===== 插件信息 =====
  pluginConfig : PluginManifest            // 完整 plugin.json
  pluginDir    : string                    // 插件目录
  pluginId     : number                    // 数据库插件 ID
  logger       : {
    info(...args)
    warn(...args)
    error(...args)
    debug(...args)
  }
  cache       : {
    get(key)                               // 读缓存
    set(key, value, ttl?)                  // 写缓存
    del(key)                               // 删缓存
    clear()                                // 清空本插件缓存
  }
}
```

### 14.12 插件开发终极清单

按你的两个真实场景从头梳理：

**场景 A：账号存储插件**

| 需要的能力 | 对应扩展机制 | 参考章节 |
|-----------|-------------|---------|
| 首页头像旁显示"N个已存账号" | 命名插槽 `user:avatar:after` | 14.5.1 |
| 点击弹出切换面板 | 前端注入脚本 (IIFE) | 第 5 章 |
| 数据库存储账号表 | 新建独立表迁移 | 14.3.1 |
| 用户表增加 max 字段 | 修改已有表结构 | 14.3.2 |
| 查询用户时附带账号数 | 查询拦截器 | 14.3.3 |
| 切换账号 API（CRUD） | 自定义路由 | 14.2.1 |
| 切换登录认证 | 登录方式扩展 | 14.9.3 |
| 用户注册时初始化存储槽位 | 用户事件 `user:afterRegister` | 14.4.1 |
| 账号过期自动清理 | Cron 定时任务 | 14.7.1 |
| 后台菜单"账号管理" | 后台菜单注册 | 14.5.2 |
| 后台配置"每用户最大账号数" | config number + slider | 12章 |
| 权限控制 | 自定义权限节点 | 14.9.1 |
| 前端多语言 | 翻译文件注册 | 14.8.1 |

**场景 B：话题管理（版主）插件**

| 需要的能力 | 对应扩展机制 | 参考章节 |
|-----------|-------------|---------|
| 版主关系表 | 新建独立表迁移 | 14.3.1 |
| 帖子表加版主备注字段 | 修改已有表结构 | 14.3.2 |
| 版主删帖权限检查 | 路由中间件注入 | 14.2.1 |
| 删帖前拦截（非版主拒绝） | 事件 `post:beforeDelete` | 14.4.2 |
| 发帖后自动分配版主 | 事件 `post:afterCreate` | 14.4.2 |
| 帖子列表显示版主标识 | UI 插槽 | 14.5.1 |
| 帖子详情工具栏加版主按钮 | UI 插槽 | 14.5.1 |
| 设置/移除版主 API | 自定义路由 | 14.2.1 |
| 批量设版主 | 批量操作注册 | 14.5.5 |
| 帖子详情页管理日志 Tab | 详情 Tab 扩展 | 14.5.6 |
| 仪表盘版主统计 | 仪表盘小组件 | 14.5.3 |
| 后台菜单"版主管理" | 后台菜单注册 | 14.5.2 |
| 后续依赖其他插件 | 依赖声明 | 14.10.1 |
| 暴露"是否版主"查询给其他插件 | 暴露 API | 14.10.2 |

---

## 附录 A：配置类型速查表

| config 值 | 推断类型 | 后台控件 | v-model 绑定方式 |
|-----------|---------|---------|-----------------|
| `true` / `false` | `bool` | ElSwitch | `configData[key]` |
| `"hello"` | `string` | ElInput | `configData[key]` |
| `{ "a": 1, "b": "x" }` | `object` | 分组面板 | `configData[key][subKey]` |
| `[{ "label": "A" }]` | `array` | 列表编辑器 | `item[subKey]` |

## 附录 B：后端关键代码位置速查

| 功能 | 文件 | 行号 |
|------|------|------|
| 插件目录常量 | `server/routes/plugins.cjs` | 10 |
| 读取 manifest | `server/routes/plugins.cjs` | 41-49 |
| 注入 API | `server/routes/plugins.cjs` | 374-410 |
| 保存配置 API | `server/routes/plugins.cjs` | 340-370 |
| 插件列表 API | `server/routes/plugins.cjs` | 412-429 |
| 前端注入钩子 | `src/hooks/core/usePluginInject.ts` | 1-90 |
| 管理后台配置页 | `src/views/operation/plugins/index.vue` | 98-176 |

## 附录 C：参考插件 feature-panel 文件速查

| 文件 | 行数 | 说明 |
|------|------|------|
| `server/plugins/feature-panel/plugin.json` | 137 | 完整配置清单 |
| `server/plugins/feature-panel/scripts/panel.js` | 194 | DOM 构建 + 路由 + Observer |
| `server/plugins/feature-panel/styles/panel.css` | 146 | 面板、卡片、横幅样式 |
